#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Nimbus dev bootstrap — reinstalls everything after a fresh machine/sandbox
# and starts the server. Packages live outside the project folder, so they do
# not survive a reboot; this script puts them back in ~40 seconds.
#
#   ./bootstrap.sh          # core deps + start server
#   ./bootstrap.sh --browser # also install Playwright Chromium (browser tools)
# ---------------------------------------------------------------------------
set -euo pipefail
cd "$(dirname "$0")"

PORT=${NIMBUS_PORT:-8000}
DATA_DIR=${NIMBUS_DATA_DIR:-$(pwd)/data}

echo "▸ installing core dependencies"
pip install -q --upgrade pip
pip install -q -r requirements.txt

if [ "${1:-}" = "--browser" ] || [ "${NIMBUS_BROWSER:-0}" = "1" ]; then
  echo "▸ installing Playwright + Chromium (browser_* tools)"
  pip install -q playwright
  playwright install chromium >/dev/null 2>&1 || true
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get install -y -qq libnspr4 libnss3 libatk1.0-0 libatk-bridge2.0-0 libcups2 \
      libxkbcommon0 libasound2t64 libxdamage1 libxcomposite1 libxrandr2 libgbm1 \
      libpango-1.0-0 libcairo2 >/dev/null 2>&1 || true
  fi
fi

if python -c "import playwright" 2>/dev/null; then
  echo "▸ browser tools: enabled"
else
  echo "▸ browser tools: skipped (run ./bootstrap.sh --browser to enable)"
fi

echo ""
echo "  Nimbus  →  http://localhost:${PORT}"
echo "  data    →  ${DATA_DIR}"
echo ""
exec env NIMBUS_DATA_DIR="${DATA_DIR}" NIMBUS_PORT="${PORT}" NIMBUS_HOST=0.0.0.0 python -m nimbus.server
