#!/usr/bin/env bash
# Nimbus launcher — creates a venv, installs deps, starts the server.
set -euo pipefail
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
PORT=${NIMBUS_PORT:-8000}

if [ ! -d .venv ]; then
  echo "▸ creating virtualenv (.venv)"
  "$PY" -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate

echo "▸ installing dependencies"
pip install -q --upgrade pip
pip install -q -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  echo "▸ created .env from .env.example — add API keys there (or in the Setup tab)"
fi

if python -c "import playwright" 2>/dev/null; then
  echo "▸ playwright detected (browser tools enabled)"
else
  echo "▸ tip: for real browser control run:  pip install playwright && playwright install chromium"
fi

echo ""
echo "  Nimbus  →  http://localhost:${PORT}"
echo "  (offline demo model works with zero API keys; add a key in Setup for real reasoning)"
echo ""
exec python -m nimbus.server
