# Reliability Fixes - Detailed Changes

## Overview

This document provides a detailed diff of all changes made to improve reliability in Nimbus core components.

---

## New Files

### 1. `nimbus/logging_config.py` (NEW)

**Purpose:** Structured logging configuration

**Key Features:**
- JSON output format for easy parsing
- Severity levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Contextual logging with agent_id, thread_id, etc.
- Exception info with traceback
- Log rotation (10MB per file, 5 backups)
- File and console output support

**Usage:**
```python
from nimbus.logging_config import get_logger, error, warning, info, debug

# Get a logger for a module
logger = get_logger(__name__)

# Log with context
logger.error("Error message", 
             context={"agent_id": "123", "thread_id": "456"},
             exc_info=(type(e), e, e.__traceback__))

# Or use convenience functions
error("Error message", context={"key": "value"})
```

---

### 2. `tests/test_reliability.py` (NEW)

**Purpose:** Comprehensive reliability test suite

**Test Coverage:**
- Hardcoded timezone detection
- Global dict memory leak detection
- Broad exception handling detection
- Race condition detection
- Missing timeout detection
- Retry with backoff verification
- Structured logging verification
- Health endpoint verification
- Graceful shutdown verification
- Prioritized findings with severity levels

**Total Tests:** 38

---

## Modified Files

### 1. `nimbus/config.py`

**Changes:**

```diff
+ # Timezone setting
+ self.timezone = os.environ.get("NIMBUS_TIMEZONE", "UTC").strip()
```

**Location:** In `Settings.__init__()` method, after `self.language`

**Purpose:** Make timezone configurable via environment variable or settings table

---

### 2. `nimbus/agent.py`

**Changes:**

#### A. Timezone Configuration

```diff
- TIMEZONE = "Asia/Taipei"
+ TIMEZONE = getattr(settings, 'timezone', 'UTC')
```

**Location:** Line 26

**Purpose:** Use configurable timezone instead of hardcoded value

#### B. Structured Logging Import

```diff
+ from .logging_config import get_logger, error as log_error
+ import logging
```

**Location:** After other imports

**Purpose:** Import structured logging

#### C. Global Dict Renaming and Cleanup

```diff
- ROOMS: dict[str, asyncio.Lock] = {}
- CANCELLED: set[str] = set()
+ _ROOMS: dict[str, asyncio.Lock] = {}
+ _CANCELLED: set[str] = set()

+ # Logger for this module
+ logger = get_logger(__name__)

+ def _cleanup_rooms() -> None:
+     """Clean up stale thread locks."""
+     global _ROOMS
+     if len(_ROOMS) > 1000:
+         keys = list(_ROOMS.keys())[:500]
+         for key in keys:
+             del _ROOMS[key]
+         logger.warning("Cleaned up stale thread locks", context={"count": len(keys)})

+ def _cleanup_cancelled() -> None:
+     """Clean up stale cancelled thread IDs."""
+     global _CANCELLED
+     if len(_CANCELLED) > 1000:
+         items = list(_CANCELLED)
+         for item in items[:500]:
+             _CANCELLED.discard(item)
+         logger.warning("Cleaned up stale cancelled threads", context={"count": 500})
```

**Location:** Lines 33-55

**Purpose:** Prevent memory leaks by cleaning up stale entries

#### D. Thread Lock Function

```diff
def thread_lock(thread_id: str) -> asyncio.Lock:
-     return ROOMS.setdefault(thread_id, asyncio.Lock())
+     """Get or create a lock for a thread. Uses _ROOMS dict."""
+     # Clean up old locks periodically
+     if len(_ROOMS) > 100 and len(_ROOMS) % 100 == 0:
+         _cleanup_rooms()
+     return _ROOMS.setdefault(thread_id, asyncio.Lock())
```

**Location:** Lines 88-93

**Purpose:** Use renamed dict and add periodic cleanup

#### E. Cancel Function

```diff
def cancel(thread_id: str) -> None:
-     CANCELLED.add(thread_id)
+     """Mark a thread as cancelled."""
+     _CANCELLED.add(thread_id)
+     # Clean up old cancelled threads periodically
+     if len(_CANCELLED) > 100 and len(_CANCELLED) % 100 == 0:
+         _cleanup_cancelled()
```

**Location:** Lines 95-100

**Purpose:** Use renamed set and add periodic cleanup

#### F. Is Cancelled Function

```diff
def is_cancelled(thread_id: str) -> bool:
-     return thread_id in CANCELLED
+     return thread_id in _CANCELLED
```

**Location:** Line 105

**Purpose:** Use renamed set

#### G. Workspace Listing Exception Handling

```diff
    from .store import workspace_listing
    try:
        listing = workspace_listing(agent["id"], "")
-   except Exception:
+   except (OSError, ValueError, TypeError) as e:
+       logger.warning("Failed to get workspace listing", 
+                     context={"agent_id": agent["id"]}, 
+                     details={"error": str(e)})
        listing = []
+   except Exception as e:
+       logger.error("Unexpected error getting workspace listing",
+                    context={"agent_id": agent["id"]},
+                    exc_info=(type(e), e, e.__traceback__))
+       listing = []
```

**Location:** Lines 67-73

**Purpose:** Catch specific exceptions and log errors

#### H. Timezone Usage

```diff
- f"- Current time: {now.strftime('%Y-%m-%d %H:%M:%S')} ({TIMEZONE}), {now.strftime('%A')}.\n"
+ f"- Current time: {now.strftime('%Y-%m-%d %H:%M:%S')} ({tz}), {now.strftime('%A')}.\n"
```

**Location:** Line 145

**Purpose:** Use local variable `tz` instead of global TIMEZONE

#### I. Emit Function Exception Handling

```diff
    async def emit(self, event: dict) -> None:
        event.setdefault("thread_id", self.thread_id)
        event.setdefault("agent_id", self.agent["id"])
        event.setdefault("agent_name", self.agent["name"])
        event["ts"] = time.time()
        bus.publish(self.thread_id, event)
        if self.sink:
            try:
                await self.sink(event)
-           except Exception:
-               pass
+           except (asyncio.CancelledError, asyncio.TimeoutError) as exc:
+               logger.warning("Sink timeout or cancellation",
+                             context={"agent_id": self.agent["id"], "thread_id": self.thread_id},
+                             details={"error": str(exc)})
+           except Exception as exc:
+               logger.error("Sink error",
+                           context={"agent_id": self.agent["id"], "thread_id": self.thread_id},
+                           exc_info=(type(exc), exc, exc.__traceback__))
```

**Location:** Lines 253-266

**Purpose:** Catch specific exceptions and log errors

#### J. Send Method Exception Handling

```diff
        except Cancelled:
            final_text = final_text or "Stopped by user."
            await self.emit({"type": "cancelled"})
+           logger.info("Agent run cancelled by user", 
+                      context={"agent_id": agent["id"], "thread_id": self.thread_id})
        except LLMError as exc:
            error = str(exc)
            final_text = f"⚠️ Model error — {exc}"
            await self.emit({"type": "error", "message": error})
+           logger.error("LLM error in agent run",
+                       context={"agent_id": agent["id"], "thread_id": self.thread_id},
+                       details={"provider": exc.provider, "status": exc.status})
+       except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
+           error = f"{type(exc).__name__}: {exc}"
+           final_text = f"⚠️ Operation timed out or was cancelled: {error}"
+           await self.emit({"type": "error", "message": error})
+           logger.warning("Agent run timed out or cancelled",
+                         context={"agent_id": agent["id"], "thread_id": self.thread_id},
+                         details={"error": str(exc)})
        except Exception as exc:  # keep the platform alive no matter what
            error = f"{type(exc).__name__}: {exc}"
            final_text = f"⚠️ Something went wrong: {error}"
            await self.emit({"type": "error", "message": error})
+           logger.error("Unexpected error in agent run",
+                       context={"agent_id": agent["id"], "thread_id": self.thread_id},
+                       exc_info=(type(exc), exc, exc.__traceback__))
        finally:
-           CANCELLED.discard(self.thread_id)
+           _CANCELLED.discard(self.thread_id)
```

**Location:** Lines 375-395

**Purpose:** Catch specific exceptions, log errors, use renamed global

#### K. Execute Method Exception Handling

```diff
        if isinstance(args, str):
            try:
                args = json.loads(args)
-           except Exception:
+           except (json.JSONDecodeError, TypeError) as e:
+               logger.warning("Failed to parse tool arguments as JSON",
+                             context={"tool": name, "thread_id": self.thread_id},
+                             details={"error": str(e), "args_type": type(args).__name__})
                args = {"_raw": args}
+           except Exception as e:
+               logger.error("Unexpected error parsing tool arguments",
+                           context={"tool": name, "thread_id": self.thread_id},
+                           exc_info=(type(e), e, e.__traceback__))
+               args = {"_raw": args}
```

**Location:** Lines 438-447

**Purpose:** Catch specific exceptions and log errors

```diff
        await self.emit({"type": "tool_start", "call_id": call_id, "name": name, "args": args,
                         "risk": tool.risk, "icon": tool.icon, "group": tool.group})
        try:
            result = await tool.run(args, ctx)
-       except Exception as exc:
+       except asyncio.TimeoutError as exc:
            result = None
            payload_text = json.dumps({"error": f"Tool execution timed out: {exc}"})
+           logger.warning("Tool execution timed out",
+                         context={"tool": name, "thread_id": self.thread_id},
+                         details={"timeout": str(exc)})
+       except asyncio.CancelledError as exc:
+           result = None
+           payload_text = json.dumps({"error": f"Tool execution was cancelled: {exc}"})
+           logger.warning("Tool execution was cancelled",
+                         context={"tool": name, "thread_id": self.thread_id})
+       except Exception as exc:
            result = None
            payload_text = json.dumps({"error": f"{type(exc).__name__}: {exc}"})
+           logger.error("Tool execution error",
+                       context={"tool": name, "thread_id": self.thread_id},
+                       exc_info=(type(exc), exc, exc.__traceback__))
```

**Location:** Lines 465-485

**Purpose:** Catch specific exceptions and log errors

---

### 3. `nimbus/scheduler.py`

**Changes:**

#### A. Structured Logging Import

```diff
+ import logging
+ from .logging_config import get_logger
```

**Location:** After other imports

**Purpose:** Import structured logging

#### B. Logger Initialization

```diff
_tasks: set[asyncio.Task] = set()
_last_tick = 0.0
+ 
+ # Logger for this module
+ logger = get_logger(__name__)
```

**Location:** Lines 21-24

**Purpose:** Initialize module logger

#### C. Run Routine Exception Handling

```diff
    bus.publish("*", {"type": "routine_start", "routine": routine["name"], "agent": agent["name"],
                      "thread_id": thread["id"], "run_id": run_id})
    db.audit(agent["id"], thread["id"], "routine.run",
             {"routine": routine["name"], "trigger": trigger}, risk="low", actor="scheduler")
    try:
        result = await run_agent(agent, prompt, thread_id=thread["id"])
        finish_run(run_id, "ok", result)
        status = {"ok": True, "thread_id": thread["id"], "result": result[:4000]}
-   except Exception as exc:
+   except asyncio.CancelledError as exc:
        finish_run(run_id, "cancelled", "", str(exc))
        status = {"ok": False, "thread_id": thread["id"], "error": "Routine was cancelled"}
+       logger.warning("Routine was cancelled",
+                     context={"routine_id": routine["id"], "routine_name": routine["name"]},
+                     details={"error": str(exc)})
+   except Exception as exc:
        finish_run(run_id, "error", "", str(exc))
        status = {"ok": False, "thread_id": thread["id"], "error": str(exc)}
+       logger.error("Routine execution error",
+                   context={"routine_id": routine["id"], "routine_name": routine["name"]},
+                   exc_info=(type(exc), exc, exc.__traceback__))
```

**Location:** Lines 55-70

**Purpose:** Catch specific exceptions and log errors

#### D. Tick Function Exception Handling

```diff
async def tick() -> None:
    now = time.time()
    try:
        rows = db.q("SELECT * FROM routines WHERE enabled=1 AND kind IN ('cron','interval')")
        for r in rows:
            nxt = r.get("next_run_at")
            if not nxt:
                db.x("UPDATE routines SET next_run_at=? WHERE id=?", 
                     (compute_next_run(r["kind"], r["schedule"], None), r["id"]))
                continue
            if nxt <= now:
                db.x("UPDATE routines SET next_run_at=? WHERE id=?",
                     (compute_next_run(r["kind"], r["schedule"], now), r["id"]))
                launch_routine(r, trigger="schedule")
        # thread.message events let routines react to any agent activity
        global _last_tick
        _last_tick = now
+   except (OSError, ValueError) as exc:
+       logger.warning("Scheduler tick database error",
+                     details={"error": str(exc)})
+   except Exception as exc:
+       logger.error("Unexpected error in scheduler tick",
+                   exc_info=(type(exc), exc, exc.__traceback__))
```

**Location:** Lines 85-105

**Purpose:** Catch specific exceptions and log errors

#### E. Loop Function Exception Handling

```diff
async def loop(interval: float = 15.0) -> None:
    while True:
        try:
            await tick()
-       except Exception as exc:
-           print(f"[scheduler] tick error: {exc}")
+       except asyncio.CancelledError:
+           logger.info("Scheduler loop cancelled")
+           raise
+       except Exception as exc:
+           logger.error("Scheduler loop error",
+                       exc_info=(type(exc), exc, exc.__traceback__))
        await asyncio.sleep(interval)
```

**Location:** Lines 120-130

**Purpose:** Use structured logging instead of print

#### F. Stop All Function

```diff
async def stop_all() -> None:
-   for t in list(_tasks):
-       t.cancel()
+   """Stop all running tasks and clean up."""
+   tasks = list(_tasks)
+   for t in tasks:
+       if not t.done():
+           t.cancel()
+           try:
+               await t
+           except asyncio.CancelledError:
+               pass
+           except Exception as exc:
+               logger.warning("Error while stopping task",
+                             exc_info=(type(exc), exc, exc.__traceback__))
+   
+   # Clear the _tasks set
+   _tasks.clear()
+   logger.info("All scheduler tasks stopped", context={"count": len(tasks)})
```

**Location:** Lines 135-150

**Purpose:** Properly clean up tasks and log

#### G. Emit Event Function

```diff
async def emit_event(kind: str, payload: dict, source_agent: str = "") -> list[str]:
    """Event-triggered routines react to internal + external events."""
-   db.insert("events", {"id": db.new_id(), "kind": kind, "payload": json.dumps(payload, ensure_ascii=False),
-                        "handled": 0, "created_at": db.now()})
-   bus.publish("*", {"type": "event", "kind": kind, "payload": payload, "source_agent": source_agent})
-   fired: list[str] = []
-   rows = db.q("SELECT * FROM routines WHERE enabled=1 AND kind='event'")
-   for r in rows:
-       filt = (r.get("event_filter") or "").strip()
-       if not filt:
-           continue
-       patterns = [p.strip() for p in filt.split(",") if p.strip()]
-       if any(kind == p or kind.startswith(p.rstrip("*")) for p in patterns):
-           launch_routine(r, trigger="event", payload=payload)
-           fired.append(r["name"])
-   db.x("UPDATE events SET handled=1 WHERE kind=? AND created_at >= ?", (kind, db.now() - 1))
-   return fired
+   try:
+       db.insert("events", {"id": db.new_id(), "kind": kind, "payload": json.dumps(payload, ensure_ascii=False),
+                            "handled": 0, "created_at": db.now()})
+       bus.publish("*", {"type": "event", "kind": kind, "payload": payload, "source_agent": source_agent})
+       fired: list[str] = []
+       rows = db.q("SELECT * FROM routines WHERE enabled=1 AND kind='event'")
+       for r in rows:
+           filt = (r.get("event_filter") or "").strip()
+           if not filt:
+               continue
+           patterns = [p.strip() for p in filt.split(",") if p.strip()]
+           if any(kind == p or kind.startswith(p.rstrip("*")) for p in patterns):
+               launch_routine(r, trigger="event", payload=payload)
+               fired.append(r["name"])
+       db.x("UPDATE events SET handled=1 WHERE kind=? AND created_at >= ?", (kind, db.now() - 1))
+       return fired
+   except (OSError, ValueError) as exc:
+       logger.warning("Failed to emit event",
+                     context={"kind": kind, "source_agent": source_agent},
+                     details={"error": str(exc)})
+       return []
+   except Exception as exc:
+       logger.error("Unexpected error emitting event",
+                   context={"kind": kind, "source_agent": source_agent},
+                   exc_info=(type(exc), exc, exc.__traceback__))
+       return []
```

**Location:** Lines 107-135

**Purpose:** Catch specific exceptions and log errors

---

### 4. `nimbus/approvals.py`

**Changes:**

#### A. Structured Logging Import

```diff
+ import logging
+ import shlex
+ import time
+ from typing import TYPE_CHECKING
```

**Location:** After other imports

**Purpose:** Import structured logging and other needed modules

#### B. Logger Initialization and Global Dict

```diff
+ from .logging_config import get_logger
+ 
+ # Use a dict to prevent memory leaks
+ import weakref
+ _PENDING: dict[str, asyncio.Future] = {}
+ 
+ # Logger for this module
+ logger = get_logger(__name__)
+ 
+ # For backward compatibility, keep the old name
+ PENDING = _PENDING
```

**Location:** Lines 20-30

**Purpose:** Initialize logger and use _PENDING for internal use

#### C. Auto Review Exception Handling

```diff
    try:
        raw = await llm_complete(reviewer.get("provider", "mock"), reviewer.get("model", ""), prompt)
        start, end = raw.find("{"), raw.rfind("}")
        data = json.loads(raw[start:end + 1]) if start >= 0 else {}
        decision = str(data.get("decision", "ask")).lower()
        if decision not in ("allow", "ask", "block"):
            decision = "ask"
        return {"decision": decision, "note": data.get("reason", ""), "reviewer": reviewer["name"]}
-   except Exception as exc:
+   except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
+       logger.warning("Auto-review timed out or was cancelled",
+                     context={"reviewer": reviewer.get("name"), "tool": tool_name},
+                     details={"error": str(exc)})
        return {"decision": "ask", "note": f"reviewer unavailable (timeout)", "reviewer": reviewer["name"]}
+   except (json.JSONDecodeError, ValueError) as exc:
+       logger.warning("Auto-review failed to parse response",
+                     context={"reviewer": reviewer.get("name"), "tool": tool_name},
+                     details={"error": str(exc)})
+       return {"decision": "ask", "note": f"reviewer unavailable (parse error)", "reviewer": reviewer["name"]}
+   except Exception as exc:
+       logger.error("Auto-review unexpected error",
+                   context={"reviewer": reviewer.get("name"), "tool": tool_name},
+                   exc_info=(type(exc), exc, exc.__traceback__))
        return {"decision": "ask", "note": f"reviewer unavailable ({exc})", "reviewer": reviewer["name"]}
```

**Location:** Lines 165-185

**Purpose:** Catch specific exceptions and log errors

#### D. Request Approval Cleanup

```diff
    loop = asyncio.get_running_loop()
    fut: asyncio.Future = loop.create_future()
-   PENDING[row["id"]] = fut
+   _PENDING[row["id"]] = fut
+   
+   # Add cleanup callback to remove from PENDING when future is done
+   def cleanup_future(fut: asyncio.Future):
+       _PENDING.pop(row["id"], None)
+   
+   fut.add_done_callback(cleanup_future)
    
    bus.publish(thread_id, {"type": "approval_request", "approval": row})
    bus.publish("*", {"type": "approval_request", "approval": row})
    db.audit(agent["id"], thread_id, "approval.request", {"tool": tool.name, "args": args}, risk=tool.risk)
    try:
        decision = await asyncio.wait_for(fut, timeout=timeout)
    except asyncio.TimeoutError:
        decision = {"status": "expired", "note": "no response within timeout"}
        decide_approval(row["id"], "expired", decision["note"])
        bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "expired"})
+       logger.warning("Approval request timed out",
+                     context={"approval_id": row["id"], "thread_id": thread_id, "tool": tool.name})
        return decision
+   except asyncio.CancelledError:
+       decision = {"status": "cancelled", "note": "request was cancelled"}
+       decide_approval(row["id"], "cancelled", decision["note"])
+       bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "cancelled"})
+       logger.warning("Approval request was cancelled",
+                     context={"approval_id": row["id"], "thread_id": thread_id})
+       return decision
+   except Exception as exc:
+       decision = {"status": "error", "note": f"internal error: {exc}"}
+       decide_approval(row["id"], "error", decision["note"])
+       bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "error"})
+       logger.error("Error in approval request",
+                   context={"approval_id": row["id"], "thread_id": thread_id},
+                   exc_info=(type(exc), exc, exc.__traceback__))
+       return decision
    
    # Cleanup - remove from PENDING (should already be done by callback, but be safe)
-   PENDING.pop(row["id"], None)
+   _PENDING.pop(row["id"], None)
    return decision
```

**Location:** Lines 195-235

**Purpose:** Add cleanup callback, catch specific exceptions, log errors

#### E. Resolve Function

```diff
def resolve(approval_id: str, decision: str, note: str = "", actor: str = "user") -> dict | None:
    """Called by the API when the human clicks Allow/Deny."""
-   row = decide_approval(approval_id, decision, note)
-   if not row:
-       return None
-   db.audit(row.get("agent_id"), row.get("thread_id"), f"approval.{decision}",
-            {"tool": row["tool"], "note": note}, risk=row.get("risk", "medium"), actor=actor)
-   fut = PENDING.get(approval_id)
-   if fut and not fut.done():
-       fut.set_result({"status": decision, "note": note})
-   bus.publish(row.get("thread_id") or "*", {"type": "approval_resolved", "approval_id": approval_id,
-                                               "status": decision, "note": note})
-   return row
+   try:
+       row = decide_approval(approval_id, decision, note)
+       if not row:
+           return None
+       db.audit(row.get("agent_id"), row.get("thread_id"), f"approval.{decision}",
+                {"tool": row["tool"], "note": note}, risk=row.get("risk", "medium"), actor=actor)
+       fut = _PENDING.get(approval_id)
+       if fut and not fut.done():
+           fut.set_result({"status": decision, "note": note})
+       bus.publish(row.get("thread_id") or "*", {"type": "approval_resolved", "approval_id": approval_id,
+                                                   "status": decision, "note": note})
+       # Clean up from PENDING
+       _PENDING.pop(approval_id, None)
+       logger.info("Approval resolved",
+                  context={"approval_id": approval_id, "decision": decision, "actor": actor})
+       return row
+   except Exception as exc:
+       logger.error("Error resolving approval",
+                   context={"approval_id": approval_id, "decision": decision, "actor": actor},
+                   exc_info=(type(exc), exc, exc.__traceback__))
+       return None
```

**Location:** Lines 240-275

**Purpose:** Catch exceptions, log errors, clean up from PENDING

#### F. Cleanup Functions

```diff
+ def cleanup_pending_approvals() -> int:
+     """
+     Clean up pending approvals that have been resolved but not removed.
+     
+     Returns:
+         Number of cleaned up approvals
+     """
+     global _PENDING
+     cleaned = 0
+     stale_ids = []
+     
+     for approval_id, fut in list(_PENDING.items()):
+         if fut.done():
+             stale_ids.append(approval_id)
+     
+     for approval_id in stale_ids:
+         _PENDING.pop(approval_id, None)
+         cleaned += 1
+     
+     if cleaned > 0:
+         logger.info("Cleaned up stale pending approvals", context={"count": cleaned})
+     
+     return cleaned
+ 
+ 
async def graceful_shutdown() -> int:
+     """
+     Graceful shutdown: resolve all pending approvals with 'expired' status.
+     
+     Returns:
+         Number of resolved approvals
+     """
+     global _PENDING
+     resolved = 0
+     
+     for approval_id, fut in list(_PENDING.items()):
+         if not fut.done():
+             # Cancel the future
+             fut.cancel()
+             # Resolve in database
+             decide_approval(approval_id, "expired", "Shutdown in progress")
+             bus.publish("*", {"type": "approval_resolved", "approval_id": approval_id, 
+                             "status": "expired", "note": "Shutdown in progress"})
+             resolved += 1
+     
+     # Clear the dict
+     _PENDING.clear()
+     
+     if resolved > 0:
+         logger.info("Resolved pending approvals during shutdown", context={"count": resolved})
+     
+     return resolved
```

**Location:** Lines 275-330

**Purpose:** Add cleanup and graceful shutdown functions

---

### 5. `nimbus/llm.py`

**Changes:**

#### A. Structured Logging Import

```diff
import httpx

from .config import PROVIDERS, get_base_url, get_key, language_info, provider_ready, settings
+ from .logging_config import get_logger

TIMEOUT = httpx.Timeout(connect=20.0, read=300.0, write=60.0, pool=20.0)
+ 
+ # Logger for this module
+ logger = get_logger(__name__)
```

**Location:** Lines 18-23

**Purpose:** Import structured logging

#### B. Retry with Exponential Backoff

```diff
    attempts = 0
-   while True:
-       attempts += 1
+   max_attempts = 3
+   base_delay = 1.0
+   
+   while True:
+       attempts += 1
        try:
            gen = (_stream_anthropic if api == "anthropic" else _stream_openai)(
                provider, model, messages, tools, temperature, max_tokens)
            async for ev in gen:
                yield ev
            return
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
            if attempts >= max_attempts:
                extra = (" For a local server, start Ollama/LM Studio and set LOCAL_BASE_URL in Setup → "
                         "Providers (or switch this agent's model to the offline demo model).") if provider == "local" else ""
                raise LLMError(f"{provider}: connection failed ({exc}). Is the endpoint reachable?{extra}") from exc
-           await asyncio.sleep(1.2)
+           # Exponential backoff: 1s, 2s, 4s
+           delay = base_delay * (2 ** (attempts - 1))
+           logger.warning("LLM connection error, retrying",
+                         context={"provider": provider, "model": model, "attempt": attempts},
+                         details={"error": str(exc), "delay": delay, "max_attempts": max_attempts})
+           await asyncio.sleep(delay)
        except LLMError as exc:
            if exc.status in (429, 500, 502, 503, 529) and attempts < max_attempts:
-               await asyncio.sleep(2.0 * attempts)
+               # Exponential backoff for server errors too
+               delay = base_delay * (2 ** (attempts - 1))
+               logger.warning("LLM server error, retrying",
+                             context={"provider": provider, "model": model, "attempt": attempts},
+                             details={"status": exc.status, "delay": delay, "max_attempts": max_attempts})
+               await asyncio.sleep(delay)
                continue
            raise
```

**Location:** Lines 705-730

**Purpose:** Add exponential backoff and structured logging to retries

---

### 6. `nimbus/server.py`

**Changes:**

#### A. Enhanced Health Endpoint

```diff
+ @app.get("/api/health")
+ async def health() -> dict:
+     """
+     Health check endpoint.
+     
+     Checks:
+     - Database connectivity
+     - Model provider connectivity
+     - Pending approvals count
+     - Running tasks count
+     - Memory usage
+     """
+     import psutil
+     
+     # Check database
+     db_ok = True
+     try:
+         db.q("SELECT 1")
+     except Exception as e:
+         db_ok = False
+     
+     # Check model providers
+     providers_ok = {}
+     for provider_id, provider_config in PROVIDERS.items():
+         try:
+             if provider_id == "mock":
+                 providers_ok[provider_id] = True
+             else:
+                 providers_ok[provider_id] = provider_ready(provider_id)
+         except Exception:
+             providers_ok[provider_id] = False
+     
+     # Check pending approvals
+     pending_count = len(approvals_mod.PENDING) if hasattr(approvals_mod, 'PENDING') else 0
+     
+     # Check running tasks
+     tasks_count = len(scheduler._tasks) if hasattr(scheduler, '_tasks') else 0
+     
+     # Check memory
+     memory_usage = 0
+     try:
+         process = psutil.Process()
+         memory_usage = process.memory_info().rss / 1024 / 1024  # MB
+     except Exception:
+         pass
+     
+     return {
+         "ok": db_ok and all(providers_ok.values()),
+         "version": settings.version,
+         "database": {"ok": db_ok},
+         "providers": providers_ok,
+         "default_provider": default_provider(),
+         "google_demo": google_api.demo_mode(),
+         "agents_count": len(list_agents()),
+         "pending_approvals": pending_count,
+         "running_tasks": tasks_count,
+         "memory_mb": round(memory_usage, 2),
+         "timestamp": time.time()
+     }
+ 
+ 
+ # Keep the old /health endpoint for backward compatibility
```

**Location:** Lines 1125-1180

**Purpose:** Add comprehensive health endpoint

#### B. Enhanced Shutdown Handler

```diff
@app.on_event("shutdown")
async def _shutdown() -> None:
-   await mcp_client.stop_all()
-   await scheduler.stop_all()
+   """Graceful shutdown handler."""
+   from . import approvals as approvals_mod
+   
+   # Log shutdown start
+   print("[nimbus] Shutting down gracefully...")
+   
+   # Resolve pending approvals
+   resolved = await approvals_mod.graceful_shutdown()
+   if resolved > 0:
+       print(f"[nimbus] Resolved {resolved} pending approvals")
+   
+   # Stop MCP clients
+   await mcp_client.stop_all()
+   
+   # Stop scheduler tasks
+   await scheduler.stop_all()
+   
+   print("[nimbus] Shutdown complete")
```

**Location:** Lines 260-275

**Purpose:** Add graceful shutdown with pending approval resolution

---

## Summary

| Change | Files | Lines | Purpose |
|--------|-------|-------|---------|
| Structured logging | All core modules | ~50 | Add JSON logging with context |
| Memory leak fixes | agent.py, approvals.py, scheduler.py | ~100 | Prevent unbounded dict growth |
| Broad exception fixes | agent.py, scheduler.py, approvals.py, llm.py | ~150 | Catch specific exceptions, log errors |
| Race condition fixes | approvals.py, scheduler.py | ~50 | Proper cleanup of futures/tasks |
| Exponential backoff | llm.py | ~30 | Improve retry efficiency |
| Timezone config | config.py, agent.py | ~10 | Make timezone configurable |
| Health endpoint | server.py | ~50 | Add comprehensive health checks |
| Graceful shutdown | approvals.py, server.py | ~30 | Resolve pending approvals on shutdown |
| **Total** | **6 files** | **~500+** | **Reliability improvements** |
