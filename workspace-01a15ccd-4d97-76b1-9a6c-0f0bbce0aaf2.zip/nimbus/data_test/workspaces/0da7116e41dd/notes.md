# Notes

please write a file with my notes about launch planning
