# Summary

_Requested: summarise the new file

Trigger event `file.upload` payload:
{"path": "x.csv"}_

{'messages': [], 'count': 0, 'source': 'demo'}
