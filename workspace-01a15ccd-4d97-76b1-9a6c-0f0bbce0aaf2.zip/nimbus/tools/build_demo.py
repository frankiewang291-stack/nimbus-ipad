#!/usr/bin/env python3
"""
Build nimbus/web/components-demo.html from the real sources.

The reference page must never drift from the shipped code, so nothing about the
three components is written twice:

    nimbus/web/components.js + composer.js → inlined verbatim (JS)
    nimbus/web/styles.css  §8–§9           → inlined verbatim (CSS; §10 chrome excluded)
    nimbus/web/i18n.js     step.*, appr.*, cmp.*, chat.jumpLatest, rel.now → sample strings

Usage:
    python3 tools/build_demo.py          # rewrite nimbus/web/components-demo.html
    python3 tools/build_demo.py --check   # exit 1 if the file is stale (used by tests)
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "nimbus" / "web"
TEMPLATE = Path(__file__).resolve().parent / "demo_template.html"
OUT = WEB / "components-demo.html"

KEYS = re.compile(r"'(step\.[\w.]+|appr\.[\w.]+|cmp\.[\w.]+|chat\.jumpLatest|rel\.now)':\s*'((?:[^'\\]|\\.)*)'")


def component_css() -> str:
    """Sections 8–9 of the stylesheet — every component rule — verbatim."""
    css = (WEB / "styles.css").read_text(encoding="utf-8")
    start = css.index("/* ==========================================================================\n   8. Chat components")
    end = css.index("/* ==========================================================================\n   10. Chrome")   # app chrome is not a demo component
    body = css[start:end].rstrip()
    # the global reduced-motion block lives in §10; the demo page carries its own
    return body


def strings() -> dict[str, dict[str, str]]:
    src = (WEB / "i18n.js").read_text(encoding="utf-8")
    out: dict[str, dict[str, str]] = {}
    for lang in ("en", "zh", "es"):
        block = re.search(rf"\n  {lang}: \{{(.*?)\n  \}},", src, re.S).group(1)
        table = {k: v for k, v in KEYS.findall(block)}
        # the demo drops emoji/figure quotes so the JSON stays readable
        out[lang] = table
    missing = [k for k in out["en"] if not all(k in out[l] for l in ("zh", "es"))]
    if missing:  # pragma: no cover - guarded by the test suite too
        raise SystemExit(f"i18n keys missing in zh/es: {missing}")
    return out


def build() -> str:
    html = TEMPLATE.read_text(encoding="utf-8")
    js = "\n".join((WEB / name).read_text(encoding="utf-8").rstrip()
                    for name in ("components.js", "composer.js"))
    i18n = json.dumps(strings(), ensure_ascii=False, indent=2)
    i18n = "\n".join("  " + line for line in i18n.splitlines())          # keep it inside the file
    html = html.replace("/*__COMPONENT_CSS__*/", component_css(), 1)
    html = html.replace("/*__COMPONENTS_JS__*/", js, 1)
    html = html.replace("/*__DEMO_I18N__*/", i18n.strip(), 1)
    return html


def main() -> int:
    html = build()
    check = "--check" in sys.argv
    if check:
        current = OUT.read_text(encoding="utf-8") if OUT.exists() else ""
        if current != html:
            print("components-demo.html is stale — run: python3 tools/build_demo.py")
            return 1
        print("components-demo.html is up to date")
        return 0
    OUT.write_text(html, encoding="utf-8")
    print(f"wrote {OUT.relative_to(ROOT)} ({len(html.splitlines())} lines)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
