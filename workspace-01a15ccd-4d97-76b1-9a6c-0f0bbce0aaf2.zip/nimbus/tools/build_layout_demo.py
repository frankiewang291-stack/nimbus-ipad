#!/usr/bin/env python3
"""
Build nimbus/web/layout_demo.html from the real stylesheet and the real strings.

The reference page must never drift from what ships, so nothing here is written
twice:

    nimbus/web/styles.css  §1–§7  + §10–§11 → inlined verbatim (CSS)
    nimbus/web/i18n.js     top.*, chip.*, side.*, tab.*, drawer.*, sheet.*, brand.* → labels
    tools/layout_demo_template.html          → the markup and the ~200-line harness

The harness mirrors nimbus/web/app.js (same classes, same thresholds, same
gestures); only the data is fake, so the page runs from the file system.

Usage:
    python3 tools/build_layout_demo.py          # rewrite nimbus/web/layout_demo.html
    python3 tools/build_layout_demo.py --check  # exit 1 if the file is stale (used by tests)
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "nimbus" / "web"
TEMPLATE = Path(__file__).resolve().parent / "layout_demo_template.html"
OUT = WEB / "layout_demo.html"

KEYS = re.compile(r"'(brand\.[\w.]+|top\.[\w.]+|chip\.[\w.]+|side\.[\w.]+|tab\.[\w.]+|drawer\.[\w.]+|sheet\.[\w.]+)':\s*'((?:[^'\\]|\\.)*)'")


def chrome_css() -> str:
    """§1–§7 (everything except the chat components and the composer) + §10–§11."""
    css = (WEB / "styles.css").read_text(encoding="utf-8")
    head = css[:css.index("/* ==========================================================================\n   8. Chat components")]
    tail = css[css.index("/* ==========================================================================\n   10. Chrome"):]
    note = ("/* §8–§9 — the chat components and the rich composer — are inlined in\n"
            "   components-demo.html instead; between them the two pages carry every\n"
            "   rule Nimbus ships. */")
    return head.rstrip() + "\n\n" + note + "\n\n" + tail.rstrip()


def strings() -> dict[str, dict[str, str]]:
    src = (WEB / "i18n.js").read_text(encoding="utf-8")
    out: dict[str, dict[str, str]] = {}
    for lang in ("en", "zh", "es"):
        block = re.search(rf"\n  {lang}: \{{(.*?)\n  \}},", src, re.S).group(1)
        out[lang] = {k: v for k, v in KEYS.findall(block)}
    missing = [k for k in out["en"] if not all(k in out[l] for l in ("zh", "es"))]
    if missing:  # pragma: no cover - the key-parity test covers this too
        raise SystemExit(f"i18n keys missing in zh/es: {missing}")
    return out


def build() -> str:
    html = TEMPLATE.read_text(encoding="utf-8")
    i18n = json.dumps(strings(), ensure_ascii=False, indent=2)
    i18n = "\n".join("  " + line for line in i18n.splitlines())      # keep it inside the file
    html = html.replace("/*__LAYOUT_CSS__*/", chrome_css(), 1)
    html = html.replace("/*__DEMO_I18N__*/", i18n.strip(), 1)
    return html


def main() -> int:
    page = build()
    check = "--check" in sys.argv
    if check:
        current = OUT.read_text(encoding="utf-8") if OUT.exists() else ""
        if current != page:
            print("nimbus/web/layout_demo.html is stale — run: python3 tools/build_layout_demo.py",
                  file=sys.stderr)
            return 1
        print("layout_demo.html is up to date")
        return 0
    OUT.write_text(page, encoding="utf-8")
    print(f"wrote nimbus/web/layout_demo.html ({len(page.splitlines())} lines)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
