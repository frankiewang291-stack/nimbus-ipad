"""
Nimbus Slack Connector - MCP Server Implementation

This connector allows Nimbus agents to interact with Slack:
- Send messages to channels
- Read channel history
- React to messages
- Manage threads
- Get user/channel information

Requirements:
- Python 3.8+
- slack-sdk package
- MCP protocol support

Setup:
1. Create a Slack App at https://api.slack.com/apps
2. Add OAuth scopes: chat:write, channels:read, groups:read, im:read, mpim:read
3. Install app to your workspace
4. Get Bot Token (xoxb-*) and Signing Secret
5. Set environment variables: SLACK_BOT_TOKEN, SLACK_SIGNING_SECRET

Usage:
- The connector exposes Slack API methods as MCP tools
- Agents can call these tools to interact with Slack
- Supports both direct calls and event-driven interactions
"""

from typing import Optional, List, Dict, Any
import os
import json
import logging
from datetime import datetime

# MCP protocol imports (simplified for Nimbus)
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource

logger = logging.getLogger(__name__)

class SlackConnector:
    """
    Slack connector for Nimbus agents.
    
    Provides tools for Slack integration including:
    - Sending messages
    - Reading channel history
    - Managing threads
    - User/channel info
    """
    
    def __init__(self):
        self.name = "slack"
        self.display_name = "Slack"
        self.description = "Connect to Slack for team collaboration"
        self.icon = "💬"
        self.tools: List[Tool] = []
        self._initialized = False
        
    async def initialize(self) -> bool:
        """Initialize the Slack connector."""
        try:
            # Check for required environment variables
            if not os.environ.get('SLACK_BOT_TOKEN'):
                logger.warning("SLACK_BOT_TOKEN not set. Slack integration will be limited.")
                return False
            
            # Import slack_sdk only when needed
            from slack_sdk import WebClient
            from slack_sdk.errors import SlackApiError
            
            self.client = WebClient(token=os.environ['SLACK_BOT_TOKEN'])
            
            # Register tools
            self.tools = [
                Tool(
                    name="slack_send_message",
                    description="Send a message to a Slack channel or DM",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "channel": {
                                "type": "string",
                                "description": "Channel ID (e.g., C1234567890) or user ID for DM"
                            },
                            "text": {
                                "type": "string",
                                "description": "Message text (supports Markdown)"
                            },
                            "thread_ts": {
                                "type": "string",
                                "description": "Timestamp of parent message to create a thread"
                            },
                            "blocks": {
                                "type": "array",
                                "description": "Slack message blocks for rich formatting",
                                "items": {"type": "object"}
                            }
                        },
                        "required": ["channel", "text"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "ts": {"type": "string"},
                            "channel": {"type": "string"},
                            "message": {"type": "object"}
                        }
                    }
                ),
                Tool(
                    name="slack_get_channel_history",
                    description="Get recent messages from a Slack channel",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "channel": {
                                "type": "string",
                                "description": "Channel ID"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Number of messages to retrieve (default: 100, max: 1000)",
                                "default": 100,
                                "maximum": 1000
                            },
                            "oldest": {
                                "type": "string",
                                "description": "Oldest message timestamp (inclusive)"
                            },
                            "latest": {
                                "type": "string",
                                "description": "Latest message timestamp (inclusive)"
                            }
                        },
                        "required": ["channel"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "messages": {
                                "type": "array",
                                "items": {"type": "object"}
                            },
                            "has_more": {"type": "boolean"}
                        }
                    }
                ),
                Tool(
                    name="slack_get_thread_replies",
                    description="Get all replies in a Slack message thread",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "channel": {
                                "type": "string",
                                "description": "Channel ID"
                            },
                            "thread_ts": {
                                "type": "string",
                                "description": "Timestamp of the parent message"
                            }
                        },
                        "required": ["channel", "thread_ts"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "messages": {
                                "type": "array",
                                "items": {"type": "object"}
                            }
                        }
                    }
                ),
                Tool(
                    name="slack_add_reaction",
                    description="Add an emoji reaction to a Slack message",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "channel": {
                                "type": "string",
                                "description": "Channel ID"
                            },
                            "timestamp": {
                                "type": "string",
                                "description": "Message timestamp"
                            },
                            "name": {
                                "type": "string",
                                "description": "Emoji name (without ::, e.g., 'thumbsup', 'heart')"
                            }
                        },
                        "required": ["channel", "timestamp", "name"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"}
                        }
                    }
                ),
                Tool(
                    name="slack_get_user_info",
                    description="Get information about a Slack user",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "user": {
                                "type": "string",
                                "description": "User ID (e.g., U1234567890)"
                            }
                        },
                        "required": ["user"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "user": {"type": "object"}
                        }
                    }
                ),
                Tool(
                    name="slack_get_channel_info",
                    description="Get information about a Slack channel",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "channel": {
                                "type": "string",
                                "description": "Channel ID"
                            }
                        },
                        "required": ["channel"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "channel": {"type": "object"}
                        }
                    }
                ),
                Tool(
                    name="slack_list_channels",
                    description="List all Slack channels the bot has access to",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "cursor": {
                                "type": "string",
                                "description": "Pagination cursor"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of channels to return (default: 100, max: 1000)",
                                "default": 100
                            },
                            "exclude_archived": {
                                "type": "boolean",
                                "description": "Exclude archived channels",
                                "default": True
                            }
                        }
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "channels": {
                                "type": "array",
                                "items": {"type": "object"}
                            },
                            "response_metadata": {"type": "object"}
                        }
                    }
                ),
                Tool(
                    name="slack_search_messages",
                    description="Search for messages in Slack",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "Search query"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Number of results (default: 20, max: 100)",
                                "default": 20
                            },
                            "sort": {
                                "type": "string",
                                "description": "Sort order ('timestamp' or 'score')",
                                "default": "timestamp"
                            },
                            "sort_dir": {
                                "type": "string",
                                "description": "Sort direction ('asc' or 'desc')",
                                "default": "desc"
                            }
                        },
                        "required": ["query"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "ok": {"type": "boolean"},
                            "messages": {
                                "type": "object",
                                "additionalProperties": {"type": "array"}
                            }
                        }
                    }
                )
            ]
            
            self._initialized = True
            logger.info("Slack connector initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Slack connector: {e}")
            return False
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call a Slack tool with the given arguments."""
        if not self._initialized:
            await self.initialize()
        
        try:
            if tool_name == "slack_send_message":
                return await self._send_message(**arguments)
            elif tool_name == "slack_get_channel_history":
                return await self._get_channel_history(**arguments)
            elif tool_name == "slack_get_thread_replies":
                return await self._get_thread_replies(**arguments)
            elif tool_name == "slack_add_reaction":
                return await self._add_reaction(**arguments)
            elif tool_name == "slack_get_user_info":
                return await self._get_user_info(**arguments)
            elif tool_name == "slack_get_channel_info":
                return await self._get_channel_info(**arguments)
            elif tool_name == "slack_list_channels":
                return await self._list_channels(**arguments)
            elif tool_name == "slack_search_messages":
                return await self._search_messages(**arguments)
            else:
                return {"error": f"Unknown tool: {tool_name}"}
        except Exception as e:
            logger.error(f"Error in Slack tool {tool_name}: {e}")
            return {"error": str(e)}
    
    async def _send_message(self, channel: str, text: str, thread_ts: Optional[str] = None, 
                           blocks: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """Send a message to a Slack channel or DM."""
        try:
            result = self.client.chat_postMessage(
                channel=channel,
                text=text,
                thread_ts=thread_ts,
                blocks=blocks or []
            )
            return {
                "ok": result["ok"],
                "ts": result.get("ts"),
                "channel": result.get("channel"),
                "message": result.get("message", {})
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _get_channel_history(self, channel: str, limit: int = 100, 
                                    oldest: Optional[str] = None, 
                                    latest: Optional[str] = None) -> Dict[str, Any]:
        """Get recent messages from a Slack channel."""
        try:
            result = self.client.conversations_history(
                channel=channel,
                limit=min(limit, 1000),
                oldest=oldest,
                latest=latest
            )
            return {
                "ok": result["ok"],
                "messages": result.get("messages", []),
                "has_more": result.get("has_more", False)
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _get_thread_replies(self, channel: str, thread_ts: str) -> Dict[str, Any]:
        """Get all replies in a Slack message thread."""
        try:
            result = self.client.conversations_replies(
                channel=channel,
                ts=thread_ts
            )
            return {
                "ok": result["ok"],
                "messages": result.get("messages", [])
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _add_reaction(self, channel: str, timestamp: str, name: str) -> Dict[str, Any]:
        """Add an emoji reaction to a Slack message."""
        try:
            result = self.client.reactions_add(
                channel=channel,
                timestamp=timestamp,
                name=name
            )
            return {"ok": result["ok"]}
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _get_user_info(self, user: str) -> Dict[str, Any]:
        """Get information about a Slack user."""
        try:
            result = self.client.users_info(user=user)
            return {
                "ok": result["ok"],
                "user": result.get("user", {})
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _get_channel_info(self, channel: str) -> Dict[str, Any]:
        """Get information about a Slack channel."""
        try:
            result = self.client.conversations_info(channel=channel)
            return {
                "ok": result["ok"],
                "channel": result.get("channel", {})
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _list_channels(self, cursor: Optional[str] = None, limit: int = 100, 
                           exclude_archived: bool = True) -> Dict[str, Any]:
        """List all Slack channels the bot has access to."""
        try:
            result = self.client.conversations_list(
                cursor=cursor,
                limit=min(limit, 1000),
                exclude_archived=exclude_archived,
                types="public_channel,private_channel"
            )
            return {
                "ok": result["ok"],
                "channels": result.get("channels", []),
                "response_metadata": result.get("response_metadata", {})
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}
    
    async def _search_messages(self, query: str, limit: int = 20, 
                              sort: str = "timestamp", sort_dir: str = "desc") -> Dict[str, Any]:
        """Search for messages in Slack."""
        try:
            result = self.client.search_messages(
                query=query,
                limit=min(limit, 100),
                sort=sort,
                sort_dir=sort_dir
            )
            return {
                "ok": result["ok"],
                "messages": result.get("messages", {})
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}


# Singleton instance
slack_connector = SlackConnector()
