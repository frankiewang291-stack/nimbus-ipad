"""
Nimbus Microsoft Teams Connector - MCP Server Implementation

This connector allows Nimbus agents to interact with Microsoft Teams:
- Send messages to channels
- Read channel messages
- Create and manage teams
- Get user/team information

Requirements:
- Python 3.8+
- azure-identity package
- azure-mgmt-teams package (for admin operations)
- Microsoft Graph API access

Setup:
1. Register an application in Azure AD: https://portal.azure.com
2. Add API permissions:
   - ChannelMessage.Read
   - ChannelMessage.Send
   - Team.ReadBasic.All
   - User.Read
   - User.Read.All
3. Grant admin consent for the permissions
4. Set environment variables:
   - AZURE_TENANT_ID
   - AZURE_CLIENT_ID
   - AZURE_CLIENT_SECRET
   - TEAMS_BOT_TOKEN (optional, for bot framework)

Usage:
- The connector exposes Teams API methods as MCP tools
- Agents can call these tools to interact with Teams
- Supports both direct calls and event-driven interactions
"""

from typing import Optional, List, Dict, Any
import os
import json
import logging
from datetime import datetime

# MCP protocol imports (simplified for Nimbus)
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource

logger = logging.getLogger(__name__)

class TeamsConnector:
    """
    Microsoft Teams connector for Nimbus agents.
    
    Provides tools for Teams integration including:
    - Sending messages
    - Reading channel messages
    - Managing teams
    - User/team info
    """
    
    def __init__(self):
        self.name = "teams"
        self.display_name = "Microsoft Teams"
        self.description = "Connect to Microsoft Teams for enterprise collaboration"
        self.icon = "🏢"
        self.tools: List[Tool] = []
        self._initialized = False
        self._client = None
        
    async def initialize(self) -> bool:
        """Initialize the Teams connector."""
        try:
            # Check for required environment variables
            required_vars = ['AZURE_TENANT_ID', 'AZURE_CLIENT_ID', 'AZURE_CLIENT_SECRET']
            missing = [var for var in required_vars if not os.environ.get(var)]
            if missing:
                logger.warning(f"Missing environment variables for Teams: {missing}. "
                             "Teams integration will be limited.")
                return False
            
            # Import Microsoft Graph SDK
            from azure.identity import ClientSecretCredential
            from msgraph import GraphServiceClient
            
            # Authenticate
            credential = ClientSecretCredential(
                tenant_id=os.environ['AZURE_TENANT_ID'],
                client_id=os.environ['AZURE_CLIENT_ID'],
                client_secret=os.environ['AZURE_CLIENT_SECRET']
            )
            
            self._client = GraphServiceClient(credential=credential)
            
            # Register tools
            self.tools = [
                Tool(
                    name="teams_send_message",
                    description="Send a message to a Teams channel",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "team_id": {
                                "type": "string",
                                "description": "Teams team ID"
                            },
                            "channel_id": {
                                "type": "string",
                                "description": "Channel ID within the team"
                            },
                            "content": {
                                "type": "string",
                                "description": "Message content (supports HTML)"
                            },
                            "reply_to_id": {
                                "type": "string",
                                "description": "Message ID to reply to (for threads)"
                            }
                        },
                        "required": ["team_id", "channel_id", "content"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "createdDateTime": {"type": "string"},
                            "body": {"type": "object"}
                        }
                    }
                ),
                Tool(
                    name="teams_get_channel_messages",
                    description="Get messages from a Teams channel",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "team_id": {
                                "type": "string",
                                "description": "Teams team ID"
                            },
                            "channel_id": {
                                "type": "string",
                                "description": "Channel ID within the team"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Number of messages to retrieve (default: 50, max: 100)",
                                "default": 50,
                                "maximum": 100
                            }
                        },
                        "required": ["team_id", "channel_id"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "value": {
                                "type": "array",
                                "items": {"type": "object"}
                            }
                        }
                    }
                ),
                Tool(
                    name="teams_list_teams",
                    description="List all Teams the user has access to",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of teams to return (default: 100)",
                                "default": 100
                            }
                        }
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "value": {
                                "type": "array",
                                "items": {"type": "object"}
                            }
                        }
                    }
                ),
                Tool(
                    name="teams_list_channels",
                    description="List all channels in a Teams team",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "team_id": {
                                "type": "string",
                                "description": "Teams team ID"
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of channels to return (default: 100)",
                                "default": 100
                            }
                        },
                        "required": ["team_id"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "value": {
                                "type": "array",
                                "items": {"type": "object"}
                            }
                        }
                    }
                ),
                Tool(
                    name="teams_get_team_info",
                    description="Get information about a Teams team",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "team_id": {
                                "type": "string",
                                "description": "Teams team ID"
                            }
                        },
                        "required": ["team_id"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "displayName": {"type": "string"},
                            "description": {"type": "string"},
                            "createdDateTime": {"type": "string"},
                            "members": {
                                "type": "array",
                                "items": {"type": "object"}
                            }
                        }
                    }
                ),
                Tool(
                    name="teams_get_user_info",
                    description="Get information about a user",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "user_id": {
                                "type": "string",
                                "description": "User ID (principal name or object ID)"
                            }
                        },
                        "required": ["user_id"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "displayName": {"type": "string"},
                            "mail": {"type": "string"},
                            "userPrincipalName": {"type": "string"}
                        }
                    }
                ),
                Tool(
                    name="teams_create_team",
                    description="Create a new Teams team",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "displayName": {
                                "type": "string",
                                "description": "Team display name"
                            },
                            "description": {
                                "type": "string",
                                "description": "Team description"
                            },
                            "mailNickname": {
                                "type": "string",
                                "description": "Mail nickname for the team"
                            },
                            "visibility": {
                                "type": "string",
                                "enum": ["private", "public"],
                                "description": "Team visibility",
                                "default": "private"
                            },
                            "members": {
                                "type": "array",
                                "description": "List of user IDs to add as members",
                                "items": {"type": "string"}
                            }
                        },
                        "required": ["displayName"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "displayName": {"type": "string"}
                        }
                    }
                ),
                Tool(
                    name="teams_create_channel",
                    description="Create a new channel in a Teams team",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "team_id": {
                                "type": "string",
                                "description": "Teams team ID"
                            },
                            "displayName": {
                                "type": "string",
                                "description": "Channel display name"
                            },
                            "description": {
                                "type": "string",
                                "description": "Channel description"
                            },
                            "membershipType": {
                                "type": "string",
                                "enum": ["standard", "private", "shared"],
                                "description": "Channel membership type",
                                "default": "standard"
                            }
                        },
                        "required": ["team_id", "displayName"]
                    },
                    outputSchema={
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "displayName": {"type": "string"}
                        }
                    }
                )
            ]
            
            self._initialized = True
            logger.info("Teams connector initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Teams connector: {e}")
            return False
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Call a Teams tool with the given arguments."""
        if not self._initialized:
            await self.initialize()
        
        if not self._client:
            return {"error": "Teams connector not properly initialized"}
        
        try:
            if tool_name == "teams_send_message":
                return await self._send_message(**arguments)
            elif tool_name == "teams_get_channel_messages":
                return await self._get_channel_messages(**arguments)
            elif tool_name == "teams_list_teams":
                return await self._list_teams(**arguments)
            elif tool_name == "teams_list_channels":
                return await self._list_channels(**arguments)
            elif tool_name == "teams_get_team_info":
                return await self._get_team_info(**arguments)
            elif tool_name == "teams_get_user_info":
                return await self._get_user_info(**arguments)
            elif tool_name == "teams_create_team":
                return await self._create_team(**arguments)
            elif tool_name == "teams_create_channel":
                return await self._create_channel(**arguments)
            else:
                return {"error": f"Unknown tool: {tool_name}"}
        except Exception as e:
            logger.error(f"Error in Teams tool {tool_name}: {e}")
            return {"error": str(e)}
    
    async def _send_message(self, team_id: str, channel_id: str, content: str, 
                          reply_to_id: Optional[str] = None) -> Dict[str, Any]:
        """Send a message to a Teams channel."""
        try:
            # Use the Graph API to send a message
            # Note: This requires the ChannelMessage.Send permission
            endpoint = f"/teams/{team_id}/channels/{channel_id}/messages"
            
            message = {
                "body": {
                    "content": content,
                    "contentType": "html"
                }
            }
            
            if reply_to_id:
                # For thread replies, we need to use the replies endpoint
                endpoint = f"/teams/{team_id}/channels/{channel_id}/messages/{reply_to_id}/replies"
            
            result = self._client.post(endpoint, data=message)
            
            return {
                "id": result.get("id"),
                "createdDateTime": result.get("createdDateTime"),
                "body": result.get("body", {})
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _get_channel_messages(self, team_id: str, channel_id: str, 
                                    limit: int = 50) -> Dict[str, Any]:
        """Get messages from a Teams channel."""
        try:
            endpoint = f"/teams/{team_id}/channels/{channel_id}/messages"
            result = self._client.get(endpoint, params={"$top": min(limit, 100)})
            return {"value": result.get("value", [])}
        except Exception as e:
            return {"error": str(e)}
    
    async def _list_teams(self, limit: int = 100) -> Dict[str, Any]:
        """List all Teams the user has access to."""
        try:
            result = self._client.get("/me/joinedTeams", params={"$top": limit})
            return {"value": result.get("value", [])}
        except Exception as e:
            return {"error": str(e)}
    
    async def _list_channels(self, team_id: str, limit: int = 100) -> Dict[str, Any]:
        """List all channels in a Teams team."""
        try:
            endpoint = f"/teams/{team_id}/channels"
            result = self._client.get(endpoint, params={"$top": limit})
            return {"value": result.get("value", [])}
        except Exception as e:
            return {"error": str(e)}
    
    async def _get_team_info(self, team_id: str) -> Dict[str, Any]:
        """Get information about a Teams team."""
        try:
            endpoint = f"/teams/{team_id}"
            result = self._client.get(endpoint)
            
            # Get members
            members_result = self._client.get(f"/teams/{team_id}/members")
            
            return {
                "id": result.get("id"),
                "displayName": result.get("displayName"),
                "description": result.get("description"),
                "createdDateTime": result.get("createdDateTime"),
                "members": members_result.get("value", [])
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _get_user_info(self, user_id: str) -> Dict[str, Any]:
        """Get information about a user."""
        try:
            endpoint = f"/users/{user_id}"
            result = self._client.get(endpoint)
            return {
                "id": result.get("id"),
                "displayName": result.get("displayName"),
                "mail": result.get("mail"),
                "userPrincipalName": result.get("userPrincipalName")
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _create_team(self, displayName: str, description: Optional[str] = None,
                         mailNickname: Optional[str] = None, 
                         visibility: str = "private",
                         members: Optional[List[str]] = None) -> Dict[str, Any]:
        """Create a new Teams team."""
        try:
            team = {
                "displayName": displayName,
                "description": description or "",
                "mailNickname": mailNickname or displayName.lower().replace(" ", ""),
                "visibility": visibility
            }
            
            result = self._client.post("/teams", data=team)
            
            team_id = result.get("id")
            
            # Add members if specified
            if members and team_id:
                for member in members:
                    await self._add_member_to_team(team_id, member)
            
            return {
                "id": team_id,
                "displayName": displayName
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _create_channel(self, team_id: str, displayName: str,
                             description: Optional[str] = None,
                             membershipType: str = "standard") -> Dict[str, Any]:
        """Create a new channel in a Teams team."""
        try:
            channel = {
                "displayName": displayName,
                "description": description or "",
                "membershipType": membershipType
            }
            
            endpoint = f"/teams/{team_id}/channels"
            result = self._client.post(endpoint, data=channel)
            
            return {
                "id": result.get("id"),
                "displayName": displayName
            }
        except Exception as e:
            return {"error": str(e)}
    
    async def _add_member_to_team(self, team_id: str, user_id: str) -> bool:
        """Add a member to a Teams team."""
        try:
            endpoint = f"/teams/{team_id}/members"
            data = {
                "@odata.bind": f"https://graph.microsoft.com/v1.0/users('{user_id}')"
            }
            self._client.post(endpoint, data=data)
            return True
        except Exception as e:
            logger.error(f"Failed to add member to team: {e}")
            return False


# Singleton instance
teams_connector = TeamsConnector()
