/* ==========================================================================
   Nimbus Standalone UI — Pure browser version with localStorage persistence
   ========================================================================== */

// ======================== UTILITIES ========================
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtBytes = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : b > 1024 ? (b / 1024).toFixed(1) + ' KB' : (b || 0) + ' B';
const fmtTime = (t) => t ? new Date(t * 1000).toLocaleString() : '—';

// ======================== LOCAL STORAGE MANAGER ========================
const Storage = {
  init() {
    if (!localStorage.getItem('nimbus_init')) {
      const defaults = {
        system: {
          id: 'local',
          name: 'Nimbus Local',
          version: '1.0.0',
          language: 'auto',
          languages: [
            { id: 'en', name: 'English', locale: 'en-US' },
            { id: 'zh', name: '中文', locale: 'zh-CN' },
            { id: 'es', name: 'Español', locale: 'es-ES' }
          ],
          limits: { file_transfer: '50 MB' },
          capabilities: ['chat', 'memory', 'skills']
        },
        agents: [
          { id: 'default', name: 'Assistant', description: 'Your helpful AI assistant', model: 'gpt-4', emoji: '🤖', created_at: Date.now() / 1000 }
        ],
        threads: [],
        messages: []
      };
      this.save('system', defaults.system);
      this.save('agents', defaults.agents);
      this.save('threads', defaults.threads);
      this.save('messages', defaults.messages);
      localStorage.setItem('nimbus_init', '1');
    }
  },
  
  save(key, data) {
    try {
      localStorage.setItem(`nimbus_${key}`, JSON.stringify(data));
    } catch (e) {
      console.error('Storage save error:', e);
    }
  },
  
  load(key, defaultValue = null) {
    try {
      const data = localStorage.getItem(`nimbus_${key}`);
      return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
      console.error('Storage load error:', e);
      return defaultValue;
    }
  },
  
  generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }
};

// ======================== I18N SETUP ========================
let currentLang = 'en';
let langSetting = localStorage.getItem('nimbus.language') || 'auto';

// Use the I18N from i18n.js (already loaded via script tag)
const I18N = window.NIMBUS_I18N || { en: {} };

function T(key, vars) {
  const table = I18N[currentLang] || I18N.en || {};
  let text = table[key];
  if (text === undefined) text = (I18N.en || {})[key];
  if (text === undefined) return key;
  if (typeof text === 'string' && text.includes('|') && vars && vars.n !== undefined) {
    const parts = text.split('|');
    text = Number(vars.n) === 1 ? parts[0] : (parts[1] || parts[0]);
  }
  return String(text).replace(/\\{(\\w+)\\}/g, (_, k) => (vars && vars[k] !== undefined ? vars[k] : '{' + k + '}'));
}

const rel = (t) => {
  if (!t) return '—';
  const s = Date.now() / 1000 - t;
  if (s < 60) return T('rel.now');
  if (s < 3600) return T('rel.min', { n: Math.floor(s / 60) });
  if (s < 86400) return T('rel.hour', { n: Math.floor(s / 3600) });
  return T('rel.day', { n: Math.floor(s / 86400) });
};

function applyStaticI18n() {
  document.documentElement.lang = currentLang === 'zh' ? 'zh-Hans' : currentLang;
  $$('[data-i18n]').forEach(el => { el.textContent = T(el.dataset.i18n); });
  $$('[data-i18n-title]').forEach(el => { el.title = T(el.dataset.i18nTitle); });
  document.title = currentLang === 'zh' ? 'Nimbus — 常驻智能体平台'
                 : currentLang === 'es' ? 'Nimbus — agentes siempre activos' : 'Nimbus — always-on agents';
}

async function setLanguage(code, { persist = true } = {}) {
  langSetting = code;
  currentLang = code === 'auto'
    ? ((navigator.language || 'en').toLowerCase().startsWith('zh') ? 'zh'
       : (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en')
    : code;
  if (persist) {
    localStorage.setItem('nimbus.language', code);
  }
  applyStaticI18n();
}

// ======================== STATE ========================
const state = {
  system: null, agents: [], agent: null, threads: [], thread: null, messages: [],
  tab: 'chat', drawerOpen: false, streamingEl: null, busy: false,
  composer: null, drawerKind: 'activity',
  filePath: '', approvals: [], feed: [], taskBusy: false,
  showAllThreads: false,
  details: localStorage.getItem('nimbus.details') === '1'
};

function compact() { return window.innerWidth < 620; }

// ======================== MOCK API (localStorage-based) ========================
async function api(path, opts = {}) {
  await new Promise(resolve => setTimeout(resolve, 50));
  
  try {
    // System
    if (path === '/api/system' || path === '/api/system?') {
      return Storage.load('system', {
        id: 'local', name: 'Nimbus Local', version: '1.0.0',
        language: langSetting,
        languages: [
          { id: 'en', name: 'English', locale: 'en-US' },
          { id: 'zh', name: '中文', locale: 'zh-CN' },
          { id: 'es', name: 'Español', locale: 'es-ES' }
        ],
        limits: { file_transfer: '50 MB' },
        capabilities: ['chat', 'memory', 'skills']
      });
    }
    
    // Agents
    if (path === '/api/agents' || path === '/api/agents?') {
      return Storage.load('agents', []);
    }
    if (path.match(/\/api\/agents\/[^\/]+$/) && (!opts.method || opts.method === 'GET')) {
      const agentId = path.split('/')[3];
      const agents = Storage.load('agents', []);
      return agents.find(a => a.id === agentId);
    }
    if (path === '/api/agents' && opts.method === 'POST') {
      const agents = Storage.load('agents', []);
      const newAgent = { id: Storage.generateId(), ...opts.body, created_at: Date.now() / 1000 };
      agents.push(newAgent);
      Storage.save('agents', agents);
      return newAgent;
    }
    if (path.match(/\/api\/agents\/[^\/]+$/) && opts.method === 'PATCH') {
      const agentId = path.split('/')[3];
      const agents = Storage.load('agents', []);
      const idx = agents.findIndex(a => a.id === agentId);
      if (idx !== -1) {
        agents[idx] = { ...agents[idx], ...opts.body };
        Storage.save('agents', agents);
      }
      return agents[idx];
    }
    if (path.match(/\/api\/agents\/[^\/]+$/) && opts.method === 'DELETE') {
      const agentId = path.split('/')[3];
      const agents = Storage.load('agents', []).filter(a => a.id !== agentId);
      Storage.save('agents', agents);
      return { deleted: true };
    }
    
    // Threads
    if (path === '/api/threads' || path === '/api/threads?limit=80') {
      return Storage.load('threads', []);
    }
    if (path.match(/\/api\/agents\/[^\/]+\/threads/) && opts.method === 'POST') {
      const agentId = path.split('/')[3];
      const threads = Storage.load('threads', []);
      const newThread = { id: Storage.generateId(), agent_id: agentId, title: opts.body?.title || 'New thread', created_at: Date.now() / 1000, updated_at: Date.now() / 1000 };
      threads.push(newThread);
      Storage.save('threads', threads);
      return newThread;
    }
    if (path.match(/\/api\/threads\/[^\/]+$/) && (!opts.method || opts.method === 'GET')) {
      const threadId = path.split('/')[3];
      const threads = Storage.load('threads', []);
      return threads.find(t => t.id === threadId);
    }
    if (path.match(/\/api\/threads\/[^\/]+$/) && opts.method === 'DELETE') {
      const threadId = path.split('/')[3];
      Storage.save('threads', Storage.load('threads', []).filter(t => t.id !== threadId));
      Storage.save('messages', Storage.load('messages', []).filter(m => m.thread_id !== threadId));
      return { deleted: true };
    }
    
    // Messages
    if (path.match(/\/api\/threads\/[^\/]+\/messages/) && opts.method === 'POST') {
      const threadId = path.split('/')[3];
      const messages = Storage.load('messages', []);
      const userMsg = { id: Storage.generateId(), thread_id: threadId, role: 'user', content: opts.body?.content || '', created_at: Date.now() / 1000 };
      messages.push(userMsg);
      
      // Simulate AI response
      const aiMsg = { id: Storage.generateId(), thread_id: threadId, role: 'assistant', content: generateAIResponse(opts.body?.content || ''), created_at: Date.now() / 1000 };
      messages.push(aiMsg);
      Storage.save('messages', messages);
      
      // Update thread
      const threads = Storage.load('threads', []);
      const idx = threads.findIndex(t => t.id === threadId);
      if (idx !== -1) {
        threads[idx].updated_at = Date.now() / 1000;
        Storage.save('threads', threads);
      }
      return aiMsg;
    }
    
    // Stop thread
    if (path.match(/\/api\/threads\/[^\/]+\/stop/) && opts.method === 'POST') {
      return { stopped: true };
    }
    
    // Approvals
    if (path === '/api/approvals') {
      return Storage.load('approvals', []);
    }
    if (path.match(/\/api\/approvals\/[^\/]+$/) && opts.method === 'POST') {
      return { resolved: true };
    }
    
    // Settings
    if (path === '/api/settings' && opts.method === 'POST') {
      localStorage.setItem('nimbus.language', opts.body?.language || langSetting);
      if (opts.body?.details !== undefined) {
        localStorage.setItem('nimbus.details', opts.body.details ? '1' : '0');
      }
      return { saved: true };
    }
    
    // Demo seeding
    if (path === '/api/demo/team' && opts.method === 'POST') {
      const agents = Storage.load('agents', []);
      if (agents.length === 0) {
        const demoAgents = [
          { id: 'assistant', name: 'Assistant', description: 'Your general AI assistant', model: 'gpt-4', emoji: '🤖', created_at: Date.now() / 1000 },
          { id: 'analyst', name: 'Analyst', description: 'Data analysis specialist', model: 'gpt-4', emoji: '📊', created_at: Date.now() / 1000 },
          { id: 'writer', name: 'Writer', description: 'Creative writing assistant', model: 'gpt-4', emoji: '✍️', created_at: Date.now() / 1000 }
        ];
        Storage.save('agents', demoAgents);
        return { created: demoAgents.map(a => ({ type: 'agent', id: a.id })) };
      }
      return { created: [] };
    }
    
    // Skills
    if (path === '/api/skills') {
      return [];
    }
    
    console.warn('Unhandled API path:', path);
    return {};
  } catch (e) {
    console.error('API error:', path, e);
    throw e;
  }
}

function generateAIResponse(userContent) {
  const responses = [
    `I understand you said: "${userContent}". How can I help you with that?`,
    `That's an interesting question! Let me think about "${userContent}"...`,
    `I've received your message: "${userContent}". What would you like me to do next?`,
    `Got it! Regarding "${userContent}", here are my thoughts...`,
    `Hello! You mentioned "${userContent}". I'm here to assist you.`
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

// ======================== UI FUNCTIONS ========================
function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind;
  el.textContent = msg;
  $('#toastRoot').appendChild(el);
  setTimeout(() => el.remove(), kind === 'err' ? 7000 : 3800);
}

function modal({ title, body, footer, wide }) {
  const wrap = document.createElement('div');
  wrap.className = 'modal-wrap';
  wrap.innerHTML = `<div class="modal" style="${wide ? 'width:min(880px,100%)' : ''}">
    <header><h3>${esc(title)}</h3><div class="spacer"></div><button class="btn ghost sm" data-x>✕</button></header>
    <div class="content"></div><footer></footer></div>`;
  const content = $('.content', wrap);
  content.innerHTML = body || '';
  const f = $('footer', wrap);
  (footer || [{ label: T('modal.close') }]).forEach(b => {
    const btn = document.createElement('button');
    btn.className = 'btn ' + (b.kind || '');
    btn.textContent = b.label;
    btn.onclick = async () => {
      if (b.onClick) {
        const keep = await b.onClick(content, wrap);
        if (keep === false) return;
      }
      wrap.remove();
    };
    f.appendChild(btn);
  });
  $('#modalRoot').appendChild(wrap);
  $('[data-x]', wrap).onclick = () => wrap.remove();
  return wrap;
}

function syncDetailsChrome() {
  document.body.classList.toggle('details-on', state.details);
  const label = state.details ? T('top.simple') : T('top.details');
  ['#btnDetails', '#chipDetails', '[data-mirror="details"]'].forEach(sel => {
    const b = $(sel);
    if (!b) return;
    b.classList.toggle('active', state.details);
    const span = $('span', b);
    if (span) span.textContent = label;
    else if (b.dataset.mirror) b.textContent = label;
    b.title = label;
  });
}

function renderAgentList() {
  const list = $('#agentList');
  if (!list) return;
  const agents = state.agents || [];
  const currentId = state.agent?.id;
  list.innerHTML = agents.map(a => `
    <button class="agent-item ${a.id === currentId ? 'active' : ''}" data-id="${a.id}" title="${esc(a.description || '')}">
      <span class="agent-emoji">${esc(a.emoji || '🤖')}</span>
      <span class="agent-name">${esc(a.name)}</span>
      <span class="agent-model mono">${esc(a.model || '')}</span>
    </button>
  `).join('');
  list.querySelectorAll('.agent-item').forEach(el => {
    el.onclick = () => selectAgent(agents.find(a => a.id === el.dataset.id));
  });
}

function renderThreadList() {
  const list = $('#threadList');
  if (!list) return;
  const threads = (state.threads || []).filter(t => !state.agent || t.agent_id === state.agent.id);
  const currentId = state.thread?.id;
  const showAll = state.showAllThreads;
  const displayThreads = showAll ? threads : threads.slice(0, 5);
  
  const items = displayThreads.map(t => {
    const agent = state.agents.find(a => a.id === t.agent_id);
    const agentName = agent ? esc(agent.name) : 'Unknown';
    const agentEmoji = agent ? esc(agent.emoji || '🤖') : '🤖';
    return `
      <button class="thread-item ${t.id === currentId ? 'active' : ''}" data-id="${t.id}">
        <span class="thread-emoji">${agentEmoji}</span>
        <div class="thread-info">
          <div class="thread-title">${esc(t.title || 'Untitled')}</div>
          <div class="thread-meta">
            <span class="thread-agent">${agentName}</span>
            <span class="thread-time">${rel(t.updated_at || t.created_at)}</span>
          </div>
        </div>
        <button class="btn sm ghost icon-only thread-delete" data-id="${t.id}" title="Delete">✕</button>
      </button>
    `;
  }).join('');
  
  const moreHtml = threads.length > 5 && !showAll ? `<button class="thread-more" id="threadMore">+${threads.length - 5} more</button>` : '';
  list.innerHTML = items + moreHtml;
  
  list.querySelectorAll('.thread-item').forEach(el => {
    el.onclick = (e) => {
      if (e.target.classList.contains('thread-delete')) return;
      selectThread(threads.find(t => t.id === el.dataset.id));
    };
  });
  
  list.querySelectorAll('.thread-delete').forEach(el => {
    el.onclick = (e) => {
      e.stopPropagation();
      const thread = threads.find(t => t.id === el.dataset.id);
      if (thread) {
        modal({
          title: T('thread.delete'),
          body: T('thread.delete.confirm'),
          footer: [
            { label: T('modal.close'), kind: 'ghost' },
            { label: T('thread.delete'), kind: 'danger', onClick: async () => {
              await api(`/api/threads/${thread.id}`, { method: 'DELETE' });
              state.threads = state.threads.filter(t => t.id !== thread.id);
              if (state.thread?.id === thread.id) {
                state.thread = null;
                state.messages = [];
              }
              renderThreadList();
              renderChat();
            }}
          ]
        });
      }
    };
  });
  
  $('#threadMore')?.onclick = () => { state.showAllThreads = true; renderThreadList(); };
}

function formatMessage(content) {
  if (!content) return '';
  let formatted = esc(content);
  formatted = formatted.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  formatted = formatted.replace(/\*(.+?)\*/g, '<em>$1</em>');
  formatted = formatted.replace(/`(.+?)`/g, '<code>$1</code>');
  formatted = formatted.replace(/\n/g, '<br>');
  return formatted;
}

function renderChat() {
  const pane = $('#pane');
  if (!pane) return;
  
  if (!state.agent) {
    pane.innerHTML = `<div class="empty-state"><div class="empty-icon">🤖</div><h3>${T('top.pick')}</h3><p>Select an agent from the sidebar to start chatting</p></div>`;
    return;
  }
  
  if (!state.thread) {
    pane.innerHTML = `<div class="empty-state"><div class="empty-icon">💬</div><h3>No thread selected</h3><p>Create a new thread or select an existing one</p><button class="btn" id="newThreadBtn">+ New Thread</button></div>`;
    $('#newThreadBtn')?.onclick = createNewThread;
    return;
  }
  
  const messages = state.messages || [];
  const msgHtml = messages.map(m => {
    const isUser = m.role === 'user';
    const cls = isUser ? 'msg user' : 'msg ai';
    const avatar = isUser ? '👤' : (state.agent?.emoji || '🤖');
    return `<div class="${cls}"><div class="msg-avatar">${avatar}</div><div class="msg-content"><div class="msg-bubble">${formatMessage(m.content)}</div><div class="msg-time">${fmtTime(m.created_at)}</div></div></div>`;
  }).join('');
  
  pane.innerHTML = `
    <div class="chat-header">
      <button class="btn sm ghost" id="backToThreads">← Back</button>
      <span class="chat-title">${esc(state.thread.title || 'Untitled')}</span>
      <div class="spacer"></div>
      <button class="btn sm ghost" id="threadSettings">⚙️</button>
    </div>
    <div class="chat-messages" id="chatMessages">${msgHtml}</div>
    <div class="chat-input-wrap"><div id="composerRoot"></div></div>
  `;
  
  $('#chatMessages')?.scrollTo(0, $('#chatMessages')?.scrollHeight);
  $('#backToThreads')?.onclick = () => { state.thread = null; state.messages = []; renderChat(); renderThreadList(); };
  $('#threadSettings')?.onclick = showThreadSettings;
  
  mountComposer();
}

function selectAgent(agent) {
  state.agent = agent;
  state.thread = null;
  state.messages = [];
  renderAgentList();
  renderThreadList();
  renderChat();
  renderAgentChip();
}

function selectThread(thread) {
  state.thread = thread;
  api(`/api/threads/${thread.id}/messages`).then(msgs => {
    state.messages = msgs;
    renderChat();
    renderThreadList();
  }).catch(() => { state.messages = []; renderChat(); });
}

function renderAgentChip() {
  const chip = $('#agentChip');
  const nameEl = $('#agentName');
  const emojiEl = $('#agentEmoji');
  const modelEl = $('#agentModel');
  const statusEl = $('#agentStatus');
  
  if (state.agent) {
    chip?.classList.add('has-agent');
    if (nameEl) nameEl.textContent = esc(state.agent.name);
    if (emojiEl) emojiEl.textContent = esc(state.agent.emoji || '🤖');
    if (modelEl) modelEl.textContent = esc(state.agent.model || '—');
    if (statusEl) statusEl.textContent = T('top.idle');
  } else {
    chip?.classList.remove('has-agent');
    if (nameEl) nameEl.textContent = T('top.pick');
    if (emojiEl) emojiEl.textContent = '🛰️';
    if (modelEl) modelEl.textContent = '—';
    if (statusEl) statusEl.textContent = T('top.idle');
  }
}

async function createNewThread() {
  if (!state.agent) { toast('Please select an agent first', 'err'); return; }
  const thread = await api(`/api/agents/${state.agent.id}/threads`, { method: 'POST', body: { title: 'New thread' } });
  state.threads.push(thread);
  state.thread = thread;
  state.messages = [];
  renderThreadList();
  renderChat();
}

function showThreadSettings() {
  if (!state.thread) return;
  modal({
    title: 'Thread Settings',
    body: `<div class="form-group"><label>Title</label><input type="text" id="threadTitleInput" value="${esc(state.thread.title || '')}" class="form-input" /></div>`,
    footer: [
      { label: 'Cancel', kind: 'ghost' },
      { label: 'Save', kind: 'primary', onClick: () => {
        state.thread.title = $('#threadTitleInput')?.value || 'Untitled';
        renderThreadList(); renderChat();
      }},
      { label: T('thread.delete'), kind: 'danger', onClick: async () => {
        await api(`/api/threads/${state.thread.id}`, { method: 'DELETE' });
        state.threads = state.threads.filter(t => t.id !== state.thread.id);
        state.thread = null; state.messages = [];
        renderThreadList(); renderChat();
      }}
    ]
  });
}

function showAgentEditor(agent = null) {
  const isNew = !agent;
  const a = agent || { name: '', description: '', model: 'gpt-4', emoji: '🤖' };
  modal({
    title: isNew ? T('agent.create') : T('agent.update'),
    body: `
      <div class="form-group"><label>${T('agent.emoji')}</label><input type="text" id="agentEmojiInput" value="${esc(a.emoji || '')}" class="form-input" placeholder="🤖" maxlength="2" /></div>
      <div class="form-group"><label>${T('agent.name')}</label><input type="text" id="agentNameInput" value="${esc(a.name || '')}" class="form-input" placeholder="Assistant" /></div>
      <div class="form-group"><label>${T('agent.description')}</label><textarea id="agentDescInput" class="form-input">${esc(a.description || '')}</textarea></div>
      <div class="form-group"><label>${T('agent.model')}</label>
        <select id="agentModelInput" class="form-input">
          <option value="gpt-4" ${a.model === 'gpt-4' ? 'selected' : ''}>GPT-4</option>
          <option value="gpt-3.5" ${a.model === 'gpt-3.5' ? 'selected' : ''}>GPT-3.5</option>
          <option value="claude-3" ${a.model === 'claude-3' ? 'selected' : ''}>Claude 3</option>
        </select>
      </div>
    `,
    footer: [
      { label: T('modal.close'), kind: 'ghost' },
      { label: isNew ? T('agent.create') : T('agent.update'), kind: 'primary', onClick: async () => {
        const body = { emoji: $('#agentEmojiInput')?.value || '🤖', name: $('#agentNameInput')?.value || 'New Agent', description: $('#agentDescInput')?.value || '', model: $('#agentModelInput')?.value || 'gpt-4' };
        let newAgent;
        if (isNew) {
          newAgent = await api('/api/agents', { method: 'POST', body });
          state.agents.push(newAgent);
        } else {
          newAgent = await api(`/api/agents/${agent.id}`, { method: 'PATCH', body });
          const idx = state.agents.findIndex(a => a.id === agent.id);
          if (idx !== -1) state.agents[idx] = newAgent;
        }
        renderAgentList();
        if (isNew) selectAgent(newAgent);
      }}
    ]
  });
}

function showSettings() {
  modal({
    title: T('settings.title'),
    body: `
      <div class="form-group"><label>${T('settings.language')}</label>
        <select id="settingsLang" class="form-input">
          <option value="auto" ${langSetting === 'auto' ? 'selected' : ''}>Auto</option>
          <option value="en" ${langSetting === 'en' ? 'selected' : ''}>English</option>
          <option value="zh" ${langSetting === 'zh' ? 'selected' : ''}>中文</option>
          <option value="es" ${langSetting === 'es' ? 'selected' : ''}>Español</option>
        </select>
      </div>
      <div class="form-group"><label>${T('settings.theme')}</label>
        <select id="settingsTheme" class="form-input">
          <option value="simple" ${!state.details ? 'selected' : ''}>Simple Mode</option>
          <option value="details" ${state.details ? 'selected' : ''}>Details Mode</option>
        </select>
      </div>
    `,
    footer: [
      { label: T('modal.close'), kind: 'ghost' },
      { label: T('settings.save'), kind: 'primary', onClick: async () => {
        const lang = $('#settingsLang')?.value || 'auto';
        const theme = $('#settingsTheme')?.value || 'simple';
        await setLanguage(lang, { persist: true });
        state.details = theme === 'details';
        syncDetailsChrome();
      }}
    ]
  });
}

function renderDrawer() {
  const drawer = $('#drawer');
  const body = $('#drawerBody');
  const title = $('#drawerTitle');
  if (!drawer || !body) return;
  if (state.drawerKind === 'activity') {
    if (title) title.textContent = T('top.liveActivity');
    body.innerHTML = `<div class="activity-list"><p style="padding: 1rem; color: var(--muted);">${T('activity.empty')}</p></div>`;
  } else if (state.drawerKind === 'approvals') {
    if (title) title.textContent = T('side.approvals');
    body.innerHTML = `<div class="approvals-list"><p style="padding: 1rem; color: var(--muted);">${T('approvals.empty')}</p></div>`;
  }
}

function setTab(tab) {
  state.tab = tab;
  $$('#tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $$('#moreMenu button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const pane = $('#pane');
  if (!pane) return;
  
  const tabs = {
    chat: () => renderChat(),
    files: () => pane.innerHTML = `<div class="empty-state"><div class="empty-icon">📁</div><h3>Files</h3><p>File management coming soon</p></div>`,
    routines: () => pane.innerHTML = `<div class="empty-state"><div class="empty-icon">⚙️</div><h3>Automations</h3><p>Automation features coming soon</p></div>`,
    settings: () => { showSettings(); setTimeout(() => setTab('chat'), 100); },
    skills: () => pane.innerHTML = `<div class="empty-state"><div class="empty-icon">✨</div><h3>Skills</h3><p>Skill system coming soon</p></div>`,
    memory: () => pane.innerHTML = `<div class="empty-state"><div class="empty-icon">🧠</div><h3>Memory</h3><p>Memory features coming soon</p></div>`,
    activity: () => { state.drawerKind = 'activity'; renderDrawer(); openDrawer(); },
    audit: () => pane.innerHTML = `<div class="empty-state"><div class="empty-icon">📊</div><h3>Audit</h3><p>Audit logs coming soon</p></div>`
  };
  (tabs[tab] || tabs.chat)();
}

function openDrawer() { $('#drawer')?.classList.add('open'); state.drawerOpen = true; }
function closeDrawer() { $('#drawer')?.classList.remove('open'); state.drawerOpen = false; }
function toggleDrawer() { state.drawerOpen ? closeDrawer() : openDrawer(); }

function mountComposer() {
  if (state.composer || typeof NB === 'undefined' || !NB.Composer) return;
  state.composer = new NB.Composer({
    mount: $('#composerRoot'),
    onSend: (text) => {
      if (!state.agent) { toast('Please select an agent first', 'err'); return; }
      if (!state.thread) { createNewThread().then(() => sendMessageAfterThread(text)); return; }
      sendMessageToThread(text);
    },
    sendLabel: T('chat.send', {}),
    upload: (file) => { toast(`File: ${file.name} (${fmtBytes(file.size)})`); return Promise.resolve({ url: '', name: file.name }); },
    T: T
  });
}

async function sendMessageAfterThread(text) {
  if (state.thread) {
    await api(`/api/threads/${state.thread.id}/messages`, { method: 'POST', body: { content: text } });
    state.messages.push({ id: Storage.generateId(), thread_id: state.thread.id, role: 'user', content: text, created_at: Date.now() / 1000 });
    const msgs = Storage.load('messages', []).filter(m => m.thread_id === state.thread.id);
    state.messages = msgs;
    state.thread.updated_at = Date.now() / 1000;
    renderChat();
    renderThreadList();
  }
}

async function sendMessageToThread(text) {
  try {
    const msg = await api(`/api/threads/${state.thread.id}/messages`, { method: 'POST', body: { content: text } });
    state.messages.push({ id: Storage.generateId(), thread_id: state.thread.id, role: 'user', content: text, created_at: Date.now() / 1000 });
    state.messages.push(msg);
    state.thread.updated_at = Date.now() / 1000;
    renderChat();
    renderThreadList();
  } catch (e) { toast('Failed to send message', 'err'); }
}

function setupEventListeners() {
  // Sidebar
  $('#btnSide')?.onclick = () => $('#sidebar')?.classList.toggle('open');
  $('#btnNewAgent')?.onclick = () => showAgentEditor();
  $('#btnNewThread')?.onclick = createNewThread;
  
  // Agent chip
  $('#agentChip')?.onclick = (e) => { $('#agentPop')?.classList.toggle('hidden'); e.stopPropagation(); };
  $('#chipEdit')?.onclick = () => { if (state.agent) showAgentEditor(state.agent); $('#agentPop')?.classList.add('hidden'); };
  $('#chipDetails')?.onclick = () => { state.details = !state.details; syncDetailsChrome(); $('#agentPop')?.classList.add('hidden'); };
  $('#btnDetails')?.onclick = () => { state.details = !state.details; syncDetailsChrome(); };
  
  // Drawer
  $('#btnDrawer')?.onclick = () => { state.drawerKind = 'activity'; renderDrawer(); toggleDrawer(); };
  $('#btnApprovals')?.onclick = () => { state.drawerKind = 'approvals'; renderDrawer(); toggleDrawer(); };
  $('#drawerClose')?.onclick = closeDrawer;
  
  // Overflow menus
  $('#btnOverflow')?.onclick = (e) => { $('#overflowMenu')?.classList.toggle('hidden'); e.stopPropagation(); };
  $('#btnMore')?.onclick = (e) => { $('#moreMenu')?.classList.toggle('hidden'); e.stopPropagation(); };
  
  // Tabs
  $$('#tabs button, #moreMenu button').forEach(btn => {
    btn.onclick = () => { const tab = btn.dataset.tab; if (tab) setTab(tab); };
  });
  
  // Settings
  $('#btnSettings')?.onclick = showSettings;
  $('#btnThemeToggle')?.onclick = () => document.body.classList.toggle('glass-theme');
  
  // Close modals
  $('#scrim').onclick = () => { $$('.modal-wrap').forEach(w => w.remove()); $$('.dropdown, .chip-pop').forEach(d => d.classList.add('hidden')); };
  
  // Close dropdowns on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#agentChip')) $('#agentPop')?.classList.add('hidden');
    if (!e.target.closest('#btnOverflow')) $('#overflowMenu')?.classList.add('hidden');
    if (!e.target.closest('#btnMore')) $('#moreMenu')?.classList.add('hidden');
  });
}

// ======================== INITIALIZATION ========================
async function init() {
  try {
    // Initialize storage
    Storage.init();
    
    // Set language
    currentLang = langSetting === 'auto'
      ? ((navigator.language || 'en').toLowerCase().startsWith('zh') ? 'zh'
         : (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en')
      : langSetting;
    applyStaticI18n();
    
    // Load data
    state.system = Storage.load('system', { id: 'local', name: 'Nimbus Local', version: '1.0.0', languages: [{ id: 'en' }, { id: 'zh' }, { id: 'es' }] });
    state.agents = Storage.load('agents', []);
    state.threads = Storage.load('threads', []);
    state.messages = Storage.load('messages', []);
    
    // Set defaults
    if (!state.agent && state.agents.length > 0) state.agent = state.agents[0];
    if (!state.thread && state.threads.length > 0) {
      state.thread = state.threads[0];
      state.messages = state.messages.filter(m => m.thread_id === state.thread.id);
    }
    
    // Seed demo data if empty
    if (state.agents.length === 0) {
      const demoAgents = [
        { id: 'assistant', name: 'Assistant', description: 'Your helpful AI assistant', model: 'gpt-4', emoji: '🤖', created_at: Date.now() / 1000 },
        { id: 'analyst', name: 'Analyst', description: 'Data analysis specialist', model: 'gpt-4', emoji: '📊', created_at: Date.now() / 1000 },
        { id: 'writer', name: 'Writer', description: 'Creative writing assistant', model: 'gpt-4', emoji: '✍️', created_at: Date.now() / 1000 }
      ];
      Storage.save('agents', demoAgents);
      state.agents = demoAgents;
      state.agent = demoAgents[0];
    }
    
    // Render UI
    renderAgentList();
    renderThreadList();
    renderAgentChip();
    setTab(state.tab || 'chat');
    setupEventListeners();
    
    // Hide loading spinner
    document.getElementById('loading')?.classList.add('hidden');
    
    console.log('✅ Nimbus Standalone initialized successfully');
  } catch (e) {
    console.error('❌ Nimbus initialization failed:', e);
    document.getElementById('loading')?.innerHTML = `<div style="text-align:center;color:#ef4444;"><div>❌ Error loading Nimbus</div><div style="font-size:0.8em;margin-top:0.5em;">${esc(e.message)}</div></div>`;
  }
}

// Start when DOM is ready
document.addEventListener('DOMContentLoaded', init);

// Handle window resize
window.addEventListener('resize', () => syncDetailsChrome());

// Handle escape key
window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) {
    $$('.dropdown, .chip-pop, .modal-wrap').forEach(el => { if (el.classList) el.classList.add('hidden'); else if (el.remove) el.remove(); });
  }
});
