/* ==========================================================================
   Nimbus chat components — vanilla JS, no dependencies
   --------------------------------------------------------------------------
   Three pieces of rendering logic, shared by the app (nimbus/web/app.js) and
   by the standalone reference page (nimbus/web/components-demo.html):

     1. NB.ToolStepper   — groups consecutive tool calls into one pill/accordion
                           with a running pulse and an expandable transcript.
     2. NB.tpl.approval  — glassmorphic approval banner: risk badge, argument
                           and diff viewer, Allow once / Always allow / Reject.
     3. NB.Typer         — smooth streaming reveal with a blinking cursor and
                           auto-scroll that only follows if the reader is at the
                           bottom already.

   Everything here is pure DOM + strings; `t` is the app's translator
   (NB.defaultT is used when there isn't one, so the demo page works alone).
   ========================================================================== */
(function (global) {
  'use strict';

  /* ----------------------------------------------------------------------
     Small helpers
     ---------------------------------------------------------------------- */
  const SEP = '›';                                   // chain separator

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function defaultT(key) { return key; }             // the demo page's fallback

  function clamp(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }

  function basename(p) {
    const s = String(p || '').replace(/\\/g, '/').replace(/\/+$/, '');
    const parts = s.split('/');
    return parts[parts.length - 1] || s;
  }

  function hostOf(url) {
    try { return new URL(String(url)).host.replace(/^www\./, ''); }
    catch { return clamp(url, 30); }
  }

  /* ----------------------------------------------------------------------
     Step labels — "Wrote summary.md", "Searched Drive", "Ran ls -la"
     ---------------------------------------------------------------------- */
  const VERBS = {
    write_file: 'Wrote', read_file: 'Read', edit_file: 'Edited', delete_file: 'Deleted',
    list_files: 'Listed', search_files: 'Searched files in', make_dir: 'Created folder',
    move_file: 'Moved', download_file: 'Downloaded', workspace_info: 'Checked', run_command: 'Ran',
    fetch_url: 'Fetched', web_search: 'Searched the web for', youtube_transcript: 'Read the video',
    gdrive_search: 'Searched Drive', gdrive_read: 'Read', gdrive_upload: 'Uploaded',
    gdrive_create_folder: 'Created folder', gdrive_delete: 'Deleted from Drive',
    gdocs_create: 'Wrote the doc', gdocs_read: 'Read the doc', gdocs_append: 'Appended to the doc',
    gdocs_list: 'Listed docs', gsheets_create: 'Created the sheet', gsheets_read: 'Read the sheet',
    gsheets_write: 'Updated the sheet', gsheets_append: 'Appended rows to the sheet',
    gmail_list_messages: 'Read the inbox', gmail_read_message: 'Read the email',
    gmail_send_email: 'Sent the email', gmail_create_draft: 'Drafted the email',
    gcal_list_events: 'Read the calendar', gcal_create_event: 'Scheduled',
    browser_open: 'Opened', browser_snapshot: 'Looked at', browser_screenshot: 'Captured',
    remember: 'Remembered', recall: 'Recalled', forget: 'Forgot',
    delegate_task: 'Delegated to', spawn_agent: 'Created the agent', list_team: 'Listed the team',
    agent_card: 'Checked the agent', create_routine: 'Scheduled', list_routines: 'Listed routines',
    delete_routine: 'Deleted the routine', create_skill: 'Saved the skill', list_skills: 'Listed skills',
    read_skill: 'Read the skill', run_skill: 'Ran the skill', mcp_call: 'Used a connected app',
  };

  /* What to say when a call has no readable target: "Read a file", not "Read". */
  const FALLBACK = {
    read_file: 'Read a file', write_file: 'Wrote a file', edit_file: 'Edited a file',
    delete_file: 'Deleted a file', list_files: 'Listed the files', search_files: 'Searched the files',
    make_dir: 'Created a folder', run_command: 'Ran a command', fetch_url: 'Fetched a page',
    web_search: 'Searched the web', youtube_transcript: 'Read a video',
    gdrive_search: 'Searched Drive', gdrive_read: 'Read a file', gdrive_upload: 'Uploaded a file',
    gdrive_create_folder: 'Created a Drive folder', gdrive_delete: 'Deleted from Drive',
    gdocs_create: 'Wrote a doc', gdocs_read: 'Read a doc', gdocs_append: 'Appended to a doc',
    gdocs_list: 'Listed the docs', gsheets_create: 'Created a sheet', gsheets_read: 'Read a sheet',
    gsheets_write: 'Updated a sheet', gsheets_append: 'Appended rows',
    gmail_list_messages: 'Read the inbox', gmail_read_message: 'Read an email',
    gmail_send_email: 'Sent an email', gmail_create_draft: 'Drafted an email',
    gcal_list_events: 'Read the calendar', gcal_create_event: 'Scheduled an event',
    browser_open: 'Opened a page', browser_snapshot: 'Looked at a page',
    browser_screenshot: 'Captured the screen', delegate_task: 'Delegated the task',
    spawn_agent: 'Created an agent', mcp_call: 'Used a connected app',
  };

  /** Best-effort human target for a tool call (a file, host, query, recipient…). */
  function stepTarget(name, args) {
    args = args || {};
    const first = (keys) => { for (const k of keys) if (args[k]) return String(args[k]); return ''; };
    const p = first(['path', 'file', 'filename', 'local_path', 'target', 'destination']);
    if (p && /(^|\/)[^/]+$/.test(p)) return basename(p);
    if (args.to) return 'to ' + clamp(args.to, 34);
    if (args.url) return hostOf(args.url);
    if (args.query) return '"' + clamp(args.query, 28) + '"';
    if (args.command) return '`' + clamp(args.command, 34) + '`';
    if (args.title || args.name) return '"' + clamp(args.title || args.name, 30) + '"';
    const id = first(['file_id', 'document_id', 'spreadsheet_id']);
    if (id) return /[./]/.test(id) ? basename(id) : '';   // opaque ids stay hidden
    if (args.range) return String(args.range);
    if (args.agent || args.agent_name) return clamp(args.agent || args.agent_name, 24);
    return '';
  }

  /** "Searched Drive › Wrote summary.md" — one readable label per tool call. */
  function stepLabel(name, args) {
    const verb = VERBS[name];
    const target = stepTarget(name, args);
    if (verb && target) return verb + ' ' + target;
    if (verb) return FALLBACK[name] || verb;
    const base = String(name || 'tool').replace(/^mcp__/, '').replace(/_/g, ' ');
    return base.charAt(0).toUpperCase() + base.slice(1) + (target ? ' ' + target : '');
  }

  /** Collapse runs of the same label: [a, a, b] → [{label:a, n:2}, {label:b, n:1}] */
  function collapseRepeats(labels) {
    const out = [];
    for (const label of labels) {
      const last = out[out.length - 1];
      if (last && last.label === label) last.n += 1;
      else out.push({ label, n: 1 });
    }
    return out;
  }

  /** The chain shown in the collapsed pill. */
  function chainHTML(labels, t) {
    const parts = collapseRepeats(labels).map(({ label, n }) =>
      `<span class="stepper-step">${esc(label)}${n > 1 ? `<span class="stepper-x">×${n}</span>` : ''}</span>`);
    return parts.join(`<span class="stepper-sep" aria-hidden="true">${SEP}</span>`);
  }

  /* ----------------------------------------------------------------------
     Line diff (LCS) for the approval viewer
     ---------------------------------------------------------------------- */
  function splitLines(text) {
    return String(text == null ? '' : text).replace(/\r\n/g, '\n').split('\n');
  }

  /**
   * A compact line diff: [{type:'ctx'|'add'|'del', text, a, b}].
   * Falls back to "everything is new" when either side is empty.
   */
  function diffLines(oldText, newText, context) {
    const ctx = context == null ? 2 : context;
    const A = splitLines(oldText), B = splitLines(newText);
    if (!oldText) return B.map((text, i) => ({ type: 'add', text, b: i + 1 }));
    if (!newText) return A.map((text, i) => ({ type: 'del', text, a: i + 1 }));

    // LCS table (guard the size — approval payloads are small)
    const n = Math.min(A.length, 400), m = Math.min(B.length, 400);
    const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    const rows = [];
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (A[i] === B[j]) { rows.push({ type: 'ctx', text: A[i], a: i + 1, b: j + 1 }); i++; j++; }
      else if (dp[i + 1][j] >= dp[i][j + 1]) { rows.push({ type: 'del', text: A[i], a: i + 1 }); i++; }
      else { rows.push({ type: 'add', text: B[j], b: j + 1 }); j++; }
    }
    while (i < n) rows.push({ type: 'del', text: A[i], a: i + 1 }), i++;
    while (j < m) rows.push({ type: 'add', text: B[j], b: j + 1 }), j++;

    // trim to changed regions ± ctx
    const keep = new Set();
    rows.forEach((r, k) => {
      if (r.type === 'ctx') return;
      for (let d = -ctx; d <= ctx; d++) if (rows[k + d]) keep.add(k + d);
    });
    if (!keep.size) return rows.slice(0, ctx * 2 + 1);
    return rows.filter((_, k) => keep.has(k));
  }

  /* ----------------------------------------------------------------------
     1. ToolStepper
     ---------------------------------------------------------------------- */
  const SENSITIVE = /(secret|token|password|passwd|api[_-]?key|authorization|cookie)/i;

  class ToolStepper {
    /**
     * @param {object} o
     *   chat      — container element (#chat)
     *   t         — translator(key, vars)
     *   details   — technical mode (show tool names, args, timings)
     *   icon      — avatar/emoji for the agent
     *   onScroll  — called after the DOM grows
     */
    constructor(o) {
      this.t = o.t || defaultT;
      this.details = !!o.details;
      this.chat = o.chat;
      this.onScroll = o.onScroll || function () {};
      this.steps = [];              // [{id, name, args, label, el, ok, ms, preview, error}]
      this.open = false;
      this.node = null;
      // the very first run of a session shows its steps, so a newcomer is never
      // left guessing; after that the pill stays collapsed unless asked
      this.autoOpen = !NB._openedOnce;
      NB._openedOnce = true;
      this._build();
    }

    _build() {
      const node = document.createElement('div');
      node.className = 'msg stepper-msg';
      node.innerHTML =
        `<div class="avatar">${esc(this.icon || '🛠️')}</div>
         <div class="body">
           <div class="stepper" data-state="idle">
             <button class="stepper-head" type="button" aria-expanded="false">
               <span class="stepper-pulse" aria-hidden="true"></span>
               <span class="stepper-title"></span>
               <span class="stepper-chevron" aria-hidden="true"></span>
             </button>
             <div class="stepper-body hidden"><div class="stepper-inner"></div></div>
           </div>
         </div>`;
      this.chat.appendChild(node);
      this.node = node;
      this.head = node.querySelector('.stepper-head');
      this.title = node.querySelector('.stepper-title');
      this.body = node.querySelector('.stepper-body');
      this.inner = node.querySelector('.stepper-inner');
      this.head.onclick = () => this.toggle();
      this._renderTitle();
    }

    /** A tool call has started. */
    add(ev) {
      const step = {
        id: ev.call_id, name: ev.name, args: ev.args || {},
        icon: ev.icon, label: stepLabel(ev.name, ev.args || {}),
        ok: null, ms: null, preview: '', error: '', el: null,
      };
      this.steps.push(step);
      this.inner.appendChild(this._stepNode(step));
      this.node.dataset.state = 'running';
      this._renderTitle();
      this.onScroll();
      if (this.autoOpen && this.steps.length === 1) this.setOpen(true, { silent: true });
      return step;
    }

    /** That tool finished. */
    finish(ev) {
      const step = this.steps.find(s => s.id === ev.call_id);
      if (!step) return;
      step.ok = ev.ok !== false;
      step.ms = ev.ms;
      step.preview = ev.preview || ev.display || '';
      step.error = ev.error || '';
      if (step.el) this._paintStep(step);
      this._renderTitle();
      if (this.steps.every(s => s.ok !== null)) this.node.dataset.state = 'done';
      this.onScroll();
    }

    /** Assistant text (or a new run) arrived → this group is closed. */
    close() {
      if (!this.node || this.node.dataset.state === 'closed') return;
      const pending = this.steps.filter(s => s.ok === null).length;
      this.steps.forEach(s => { if (s.ok === null) { s.ok = true; s.preview = s.preview || ''; if (s.el) this._paintStep(s); } });
      this.node.dataset.state = 'closed';
      if (pending) this._renderTitle();
    }

    toggle() { this.setOpen(!this.open); }

    setOpen(open, { silent } = {}) {
      this.open = !!open;
      this.body.classList.toggle('hidden', !this.open);
      this.head.setAttribute('aria-expanded', String(this.open));
      this.node.querySelector('.stepper').dataset.open = this.open ? '1' : '0';
      if (!silent) this.onScroll();
    }

    get failed() { return this.steps.filter(s => s.ok === false).length; }

    _renderTitle() {
      if (!this.node) return;
      const n = this.steps.length;
      const running = this.steps.some(s => s.ok === null);
      const head = !n ? this.t('chat.workingOn')
        : running ? this.t('step.running', { n })
          : n === 1 ? this.t('step.one') : this.t('step.executed', { n });
      const labels = this.steps.map(s => s.label);
      this.title.innerHTML =
        `<span class="stepper-count">${esc(head)}</span>` +
        (labels.length ? `<span class="stepper-sep stepper-colon" aria-hidden="true">:</span>${chainHTML(labels, this.t)}` : '');
      const failed = this.failed;
      const badge = this.node.querySelector('.stepper-fail');
      if (failed && !badge) {
        const b = document.createElement('span');
        b.className = 'badge bad stepper-fail';
        b.textContent = this.t('step.failed', { n: failed });
        this.title.appendChild(b);
      } else if (badge && !failed) badge.remove();
      this.node.querySelector('.stepper-pulse').classList.toggle('on', running);
      this.head.title = this.t(this.open ? 'step.hideSteps' : 'step.showSteps');
    }

    _stepNode(step) {
      const el = document.createElement('div');
      el.className = 'step-item';
      el.id = 'chip-' + step.id;          // stable anchor for late SSE events
      el.dataset.state = 'running';
      el.innerHTML =
        `<button class="step-head" type="button" aria-expanded="false">
           <span class="step-icon">${esc(step.icon || '•')}</span>
           <span class="step-name">${esc(step.label)}</span>
           <span class="step-spin" aria-hidden="true"></span>
           <span class="step-meta"></span>
           <span class="step-chevron" aria-hidden="true"></span>
         </button>
         <div class="step-detail hidden">
           ${this.details ? `<div class="step-kv"><span>${esc(this.t('step.tool'))}</span><code>${esc(step.name)}</code></div>` : ''}
           <div class="step-section">${esc(this.t('step.args'))}</div>
           <div class="step-args"></div>
           <div class="step-section step-out-title hidden">${esc(this.t('step.output'))}</div>
           <pre class="step-out hidden"></pre>
         </div>`;
      step.el = el;
      const head = el.querySelector('.step-head');
      head.onclick = () => {
        const detail = el.querySelector('.step-detail');
        const open = detail.classList.toggle('hidden') === false;
        head.setAttribute('aria-expanded', String(open));
      };
      el.querySelector('.step-args').innerHTML = argRows(step.args, this.t);
      this._paintStep(step);
      return el;
    }

    _paintStep(step) {
      const el = step.el; if (!el) return;
      const running = step.ok === null;
      el.dataset.state = running ? 'running' : (step.ok ? 'done' : 'error');
      el.querySelector('.step-spin').classList.toggle('on', running);
      el.querySelector('.step-icon').textContent = running ? (step.icon || '•') : (step.ok ? '✓' : '⚠');
      const meta = el.querySelector('.step-meta');
      meta.textContent = running ? '' : (this.details && step.ms != null ? `${step.ms} ms` : '');
      const out = el.querySelector('.step-out');
      const title = el.querySelector('.step-out-title');
      const text = step.error || step.preview || '';
      if (text) {
        out.textContent = clamp(text, 4000);
        out.classList.toggle('err', !!step.error);
        out.classList.remove('hidden');
        title.classList.remove('hidden');
      }
    }
  }

  /** Argument rows: key / value with sensitive values masked. */
  function argRows(args, t) {
    const rows = Object.entries(args || {});
    if (!rows.length) return `<div class="arg-empty">${esc((t || defaultT)('step.noArgs'))}</div>`;
    return rows.map(([k, v]) => {
      const sensitive = SENSITIVE.test(k);
      const value = typeof v === 'string' ? v : JSON.stringify(v);
      const long = String(value).length > 180;
      return `<div class="arg-row${sensitive ? ' sensitive' : ''}">
          <span class="arg-key">${esc(k)}</span>
          <span class="arg-val${long ? ' long' : ''}">${sensitive && v ? '••••••••' : esc(clamp(value, 600))}</span>
        </div>`;
    }).join('');
  }

  /* ----------------------------------------------------------------------
     2. Approval banner
     ---------------------------------------------------------------------- */
  const RISK_KEY = { low: 'appr.risk.low', medium: 'appr.risk.medium', high: 'appr.risk.high' };

  /** Work out what to show in the "changes" panel. */
  function changeView(tool, args) {
    args = args || {};
    if (tool === 'edit_file' && (args.old_text || args.new_text)) {
      return { kind: 'diff', rows: diffLines(args.old_text || '', args.new_text || ''),
               consumed: ['old_text', 'new_text'] };
    }
    if (typeof args.content === 'string' && args.content.length) {
      return { kind: 'diff', rows: diffLines('', args.content), allNew: true, consumed: ['content'] };
    }
    if (typeof args.command === 'string' && args.command.length) {
      return { kind: 'command', text: args.command, consumed: ['command'] };
    }
    if (typeof args.new_text === 'string' && args.new_text.length) {
      return { kind: 'diff', rows: diffLines('', args.new_text), allNew: true, consumed: ['new_text'] };
    }
    return null;
  }

  function diffHTML(rows, t) {
    const body = rows.map(r => {
      const sign = r.type === 'add' ? '+' : r.type === 'del' ? '−' : ' ';
      const no = r.type === 'del' ? r.a : r.b;
      return `<div class="diff-line ${r.type}"><span class="diff-no">${no || ''}</span>` +
             `<span class="diff-sign">${sign}</span><span class="diff-text">${esc(r.text) || '&nbsp;'}</span></div>`;
    }).join('');
    return `<div class="diff" role="group" aria-label="${esc(t('appr.changes'))}">${body}</div>`;
  }

  /** The banner template. `a` is the approval row from /api/approvals. */
  function approvalTemplate(a, t) {
    t = t || defaultT;
    const risk = (a.risk || 'medium').toLowerCase();
    const riskClass = 'risk-' + risk;
    const view = changeView(a.tool, a.args);
    const args = Object.fromEntries(Object.entries(a.args || {})
      .filter(([k]) => !(view && view.consumed.includes(k))));
    const changes = view
      ? `<div class="step-section">${esc(view.kind === 'command' ? t('appr.command') : t('appr.changes'))}</div>` +
        (view.kind === 'command'
          ? `<pre class="appr-cmd"><span class="appr-cmd-prompt">$</span> ${esc(view.text)}</pre>`
          : diffHTML(view.rows, t))
      : '';
    return `
      <div class="appr ${esc(riskClass)}" data-risk="${esc(risk)}" role="alertdialog" aria-labelledby="appr-t-${esc(a.id)}">
        <div class="appr-stripe" aria-hidden="true"></div>
        <header class="appr-head">
          <span class="appr-shield" aria-hidden="true">⚠︎</span>
          <div class="appr-titles">
            <b id="appr-t-${esc(a.id)}">${esc(t('appr.banner'))}</b>
            <span class="appr-tool">${esc(a.tool)}</span>
          </div>
          <span class="appr-risk ${esc(risk)}">
            <i class="appr-meter"><i></i><i></i><i></i></i>
            ${esc(t(RISK_KEY[risk] || RISK_KEY.medium))}
          </span>
        </header>
        <p class="appr-note">${esc(a.reason || t('appr.noReason'))}</p>
        <div class="appr-body">
          ${changes}
          ${Object.keys(args).length
            ? `<div class="step-section">${esc(t('appr.args'))}</div>
               <div class="appr-args">${argRows(args, t)}</div>`
            : ''}
        </div>
        <div class="appr-status hidden"></div>
        <div class="appr-actions">
          <button class="btn primary" data-allow>${esc(t('appr.allowOnce'))}</button>
          <button class="btn" data-always title="${esc(t('appr.alwaysHint', { tool: a.tool }))}">${esc(t('appr.always'))}</button>
          <button class="btn danger" data-reject>${esc(t('appr.reject'))}</button>
          <span class="appr-hint">${esc(t('appr.hint'))}</span>
        </div>
      </div>`;
  }

  /** Compact strip shown after a decision. */
  function approvalResolvedTemplate(a, t, status, when) {
    t = t || defaultT;
    const map = { approved: 'appr.allowed', always: 'appr.allowedAlways', denied: 'appr.rejected', expired: 'appr.expired' };
    const kind = status === 'denied' ? 'bad' : status === 'expired' ? 'warn' : 'ok';
    return `<span class="badge ${kind}">${esc(t(map[status] || 'appr.decided'))}</span>
            <span class="appr-resolved-tool">${esc(a.tool)}</span>
            <span class="appr-resolved-when">${esc(when || '')}</span>
            <button class="btn sm ghost" data-reopen>${esc(t('appr.details'))}</button>`;
  }

  /* ----------------------------------------------------------------------
     3. Typer — smooth streaming + cursor + conditional auto-scroll
     ---------------------------------------------------------------------- */
  /** Is the reader already at the bottom? (slack ≈ two lines) */
  function atBottom(el, slack) {
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight <= (slack == null ? 90 : slack);
  }

  class Typer {
    /**
     * @param {object} o
     *   scroller — the scrolling container (#chat)
     *   render   — (prefixText) → HTML for the bubble contents
     *   onFrame  — optional hook (used to keep the cursor in place)
     */
    constructor(o) {
      this.scroller = o.scroller;
      this.render = o.render;
      this.raw = '';
      this.shown = 0;
      this.renderedLen = 0;
      this.el = null;               // wrapper holding the rendered bubble
      this.bubble = null;
      this.stick = true;
      this._raf = null;
      this._onScroll = () => { this.stick = atBottom(this.scroller); this._emitStick(); };
      if (this.scroller) this.scroller.addEventListener('scroll', this._onScroll, { passive: true });
    }

    _emitStick() {
      if (typeof this.onStick === 'function') this.onStick(this.stick);
    }

    attach(bubble) {
      this.bubble = bubble;
      this.bubble.classList.add('streaming');
      this._cursor();
      this.stick = atBottom(this.scroller);
    }

    push(text) {
      this.raw += text;
      if (!this._raf) this._raf = requestAnimationFrame(() => this._frame());
    }

    _frame() {
      this._raf = null;
      if (!this.bubble) return;
      const gap = this.raw.length - this.shown;
      // catch up fast when far behind, gently when close: reads like typing, not lag
      this.shown = gap > 0 ? Math.min(this.raw.length, this.shown + Math.max(2, Math.ceil(gap / 6))) : this.raw.length;
      const prefix = this.raw.slice(0, this.shown);
      const prevLen = this.renderedLen;
      this.bubble.innerHTML = this.render(prefix);
      const text = this.bubble.textContent || '';
      this.renderedLen = text.length;
      const added = Math.min(Math.max(this.renderedLen - prevLen, 0), 240);
      if (added > 0) wrapTail(this.bubble, this.renderedLen - added, this.renderedLen);
      this._cursor();
      if (this.stick) this.scrollToBottom();
      if (this.shown < this.raw.length) this._raf = requestAnimationFrame(() => this._frame());
    }

    /** Finish: reveal everything, drop the cursor, stop following. */
    finish(finalText) {
      if (this._raf) { cancelAnimationFrame(this._raf); this._raf = null; }
      if (finalText != null) this.raw = finalText;
      this.shown = this.raw.length;
      if (this.bubble) {
        this.bubble.classList.remove('streaming');
        this.bubble.innerHTML = this.render(this.raw);
        this.bubble.querySelectorAll('.cursor, .chunk').forEach(n => {
          const parent = n.parentNode;
          while (n.firstChild) parent.insertBefore(n.firstChild, n);
          parent.removeChild(n);
          parent.normalize();
        });
        this.renderedLen = (this.bubble.textContent || '').length;
      }
      if (this.stick) this.scrollToBottom();
      if (this.scroller) this.scroller.removeEventListener('scroll', this._onScroll);
      this.done = true;
    }

    scrollToBottom() {
      const el = this.scroller;
      if (!el) return;
      el.scrollTop = el.scrollHeight;          // smooth via CSS scroll-behavior
      this.stick = true;
      this._emitStick();
    }

    _cursor() {
      if (!this.bubble || this.done) return;
      if (!this.bubble.querySelector('.cursor')) {
        const c = document.createElement('span');
        c.className = 'cursor';
        c.setAttribute('aria-hidden', 'true');
        this.bubble.appendChild(c);
      }
    }
  }

  /** Wrap the characters between [from, to) of the bubble's text in `.chunk`. */
  function wrapTail(root, from, to) {
    if (to <= from) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => {
        if (n.parentNode && n.parentNode.classList &&
            (n.parentNode.classList.contains('cursor') || n.parentNode.classList.contains('chunk'))) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    let pos = 0;
    const edits = [];
    let node;
    while ((node = walker.nextNode())) {
      const start = pos, end = pos + node.nodeValue.length;
      pos = end;
      if (end <= from) continue;
      if (start >= to) break;
      edits.push({
        node,
        localStart: Math.max(0, from - start),
        localEnd: Math.min(node.nodeValue.length, to - start),
      });
    }
    edits.reverse().forEach(({ node, localStart, localEnd }) => {
      if (localEnd <= localStart) return;
      const range = document.createRange();
      range.setStart(node, localStart);
      range.setEnd(node, localEnd);
      const span = document.createElement('span');
      span.className = 'chunk';
      try { range.surroundContents(span); } catch { /* never fatal */ }
    });
  }

  /* ----------------------------------------------------------------------
     Export
     ---------------------------------------------------------------------- */
  global.NB = {
    defaultT,
    esc,
    stepLabel,
    stepTarget,
    collapseRepeats,
    chainHTML,
    diffLines,
    argRows,
    changeView,
    atBottom,
    wrapTail,
    ToolStepper,
    Typer,
    tpl: { approval: approvalTemplate, resolved: approvalResolvedTemplate, diff: diffHTML },
  };
})(typeof window !== 'undefined' ? window : globalThis);
