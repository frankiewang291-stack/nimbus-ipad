/* ==========================================================================
   Nimbus rich chat composer — vanilla JS, no dependencies
   --------------------------------------------------------------------------
   Four pieces of behaviour in one mount point (the app's `.composer` block):

     1. Auto-expanding textarea — starts at exactly 44px (one line), grows to
        at most 200px, then scrolls. Uses `field-sizing: content` where the
        browser supports it and a measured fallback everywhere else; the height
        is only written when it actually changes, so nothing jitters.
     2. Attachments — a 📎 button and a drag-and-drop overlay over the whole
        chat area; files stream to the agent workspace over XHR (the one API
        that reports upload progress), with a per-file progress bar, cancel,
        and a `[Uploaded: name.ext]` chip inserted into the text.
     3. Slash commands — typing “/” opens a floating popover with /delegate
        [agent] · /skill [name] · /routine · /clear, filtered as you type,
        navigable with ↑ ↓ Enter Tab, dismissed with Esc.
     4. Keyboard model — Enter sends, Shift+Enter breaks the line, Esc closes
        whatever is open, and the footer shows those keys as <kbd> chips.

   The app mounts it, it does not mount itself:
       state.composer = new NB.Composer({ mount: $('#composer'), onSend, … });
   `upload` is injectable, so the standalone demo page runs it offline.
   ========================================================================== */
(function (global) {
  'use strict';

  const MIN_H = 44;            // one line, exactly — matches the CSS min-height
  const MAX_H = 200;           // beyond this the textarea scrolls instead
  const esc = (global.NB && NB.esc) || ((s) => String(s == null ? '' : s));
  const defaultT = (global.NB && NB.defaultT) || ((k) => k);

  const fmtSize = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB'
    : b > 1024 ? (b / 1024).toFixed(1) + ' KB' : (b || 0) + ' B';

  /* ----------------------------------------------------------------------
     The command catalogue — exactly the four shortcuts from the brief
     ---------------------------------------------------------------------- */
  const COMMANDS = [
    { id: 'delegate', arg: 'agent', takes: 'agents', desc: 'cmp.cmd.delegate', tpl: 'cmp.tpl.delegate' },
    { id: 'skill', arg: 'name', takes: 'skills', desc: 'cmp.cmd.skill', tpl: 'cmp.tpl.skill' },
    { id: 'routine', arg: '', desc: 'cmp.cmd.routine', tpl: 'cmp.tpl.routine' },
    { id: 'clear', arg: '', desc: 'cmp.cmd.clear', action: 'clear' },
  ];
  const BY_ID = Object.fromEntries(COMMANDS.map((c) => [c.id, c]));
  const search = (list, q) => {
    const needle = String(q || '').toLowerCase();
    if (!needle) return list;
    return list.filter((c) => c.id.startsWith(needle)
      || (c.hint || '').toLowerCase().includes(needle));
  };

  /** Clamp a measured content height to the composer's range. */
  function fitHeight(scrollHeight) {
    return Math.max(MIN_H, Math.min(Math.round(scrollHeight || MIN_H), MAX_H));
  }

  /**
   * What, if anything, is the caret sitting in? Pure text maths, no DOM.
   * Returns {open:false} or
   *   {open:true, mode:'commands', query, start, end}
   *   {open:true, mode:'args', command, query, start, end}
   * A command only opens at the start of a line, so “and/or” never triggers it.
   */
  function slashState(text, caret) {
    text = String(text || '');
    caret = caret == null ? text.length : caret;
    const before = text.slice(0, caret);
    const lineStart = before.lastIndexOf('\n') + 1;
    const line = before.slice(lineStart);
    let m = /^\/(\w*)$/.exec(line);
    if (m) return { open: true, mode: 'commands', query: m[1], start: lineStart, end: caret };
    m = /^\/(\w+)[ \t]+(.*)$/.exec(line);
    if (m && BY_ID[m[1]] && BY_ID[m[1]].takes) {
      return { open: true, mode: 'args', command: BY_ID[m[1]], query: m[2], start: lineStart, end: caret };
    }
    return { open: false };
  }

  /** The token handed to the agent once a file is safely in its workspace. */
  const uploadToken = (name) => `[Uploaded: ${name}]`;

  /* ----------------------------------------------------------------------
     Default upload transport: XHR, because fetch cannot report *upload*
     progress — and a progress bar is the whole point here.
     ---------------------------------------------------------------------- */
  function xhrUpload(url, file, path, { onProgress, signal } = {}) {
    return new Promise((resolve, reject) => {
      const fd = new FormData();
      fd.append('file', file, file.name);
      if (path) fd.append('path', path);
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total, e.loaded, e.total);
      };
      xhr.onload = () => {
        let body = {};
        try { body = JSON.parse(xhr.responseText || '{}'); } catch { /* keep {} */ }
        if (xhr.status >= 200 && xhr.status < 300) resolve(body);
        else reject(new Error(body.detail || ('HTTP ' + xhr.status)));
      };
      xhr.onerror = () => reject(new Error('network error'));
      xhr.onabort = () => { const e = new Error('cancelled'); e.aborted = true; reject(e); };
      if (signal) signal.addEventListener('abort', () => xhr.abort(), { once: true });
      xhr.send(fd);
    });
  }

  /** The default transport, adapted to the injectable signature. */
  const defaultTransport = (file, opts) => xhrUpload(opts.url, file, opts.path, opts);

  /* ----------------------------------------------------------------------
     The composer
     ---------------------------------------------------------------------- */
  class Composer {
    /**
     * @param {object} o
     *   mount        container element (the app's `.composer`)
     *   t            translator(key, vars)
     *   agentId      workspace owner for uploads
     *   placeholder  textarea placeholder
     *   sendLabel    send button label
     *   dropRoot     element the drop overlay covers (default: mount)
     *   upload       transport override (file, {onProgress, signal}) → Promise
     *   uploadUrl    URL override for the default transport
     *   providers    {agents: fn|array, skills: async fn|array} for command args
     *   onSend       called with the trimmed text when the user sends
     *   onCommand    called with ('clear') etc. for commands with an action
     *   onUploaded   called with (file, response) after a successful upload
     *   onResize     called after the textarea's height changes
     *   history      array of previous messages (↑ recalls them)
     */
    constructor(o = {}) {
      this.o = o;
      this.t = o.t || defaultT;
      this.mount = o.mount;
      this.agentId = o.agentId || '';
      this.dropRoot = o.dropRoot || o.mount;
      this.history = o.history || [];
      this.histIndex = -1;
      this.files = [];                 // rows kept in the attachment strip
      this.menu = null;                // the open popover
      this.active = -1;
      this.dragDepth = 0;
      this.height = MIN_H;
      this.fieldSizing = !!(global.CSS && CSS.supports && CSS.supports('field-sizing', 'content'));
      this._off = [];                  // teardown list, so re-renders don't stack handlers
      this._build();
      this._wire();
    }

    /** Remove every listener that outlives the markup (document, window, drop root). */
    destroy() {
      this._off.forEach(([target, type, fn, opts]) => target.removeEventListener(type, fn, opts));
      this._off = [];
      if (this.drop && this.drop.parentNode) this.drop.parentNode.removeChild(this.drop);
      this.mount.innerHTML = '';
    }

    on(target, type, fn, opts) {
      target.addEventListener(type, fn, opts);
      this._off.push([target, type, fn, opts]);
    }

    /* ------------------------------- markup ------------------------------ */
    _build() {
      const t = this.t;
      this.mount.innerHTML = `
        <div class="att-strip hidden"></div>
        <div class="composer-box">
          <div class="slashpop hidden" role="listbox" aria-label="${esc(t('cmp.commands'))}"></div>
          <div class="composer-inner">
            <button class="attach-btn" id="attachBtn" type="button"
                    title="${esc(t('cmp.attach'))}" aria-label="${esc(t('cmp.attach'))}">📎</button>
            <textarea id="input" rows="1" spellcheck="true"></textarea>
            <button class="btn primary" id="send" type="button">${esc(this.o.sendLabel || t('chat.send'))}</button>
          </div>
        </div>
        <div class="hintrow">
          <span id="modeHint"></span>
          <div class="spacer"></div>
          <span class="pill mono hidden" id="modelPill"></span>
        </div>
        <div class="keyrow">
          <span class="key"><kbd>Enter</kbd> ${esc(t('cmp.hSend'))}</span>
          <span class="key"><kbd>Shift</kbd><span class="key-plus">+</span><kbd>Enter</kbd> ${esc(t('cmp.hNewline'))}</span>
          <span class="key"><kbd>/</kbd> ${esc(t('cmp.hCommands'))}</span>
          <span class="key"><kbd>Esc</kbd> ${esc(t('cmp.hEsc'))}</span>
        </div>
        <input type="file" id="cmp-file" multiple hidden>`;
      this.ta = this.mount.querySelector('#input');
      this.sendBtn = this.mount.querySelector('#send');
      this.attachBtn = this.mount.querySelector('#attachBtn');
      this.fileInput = this.mount.querySelector('#cmp-file');
      this.strip = this.mount.querySelector('.att-strip');
      this.pop = this.mount.querySelector('.slashpop');
      this.footHint = this.mount.querySelector('#modeHint');
      this.modelPill = this.mount.querySelector('#modelPill');
      this.ta.placeholder = this.o.placeholder || '';
      this.ta.value = this.o.value || '';
      this.autoGrow();

      /* the overlay lives over the whole chat area, not just the input */
      const root = this.dropRoot;
      if (root) {
        if (getComputedStyle(root).position === 'static') root.style.position = 'relative';
        this.drop = document.createElement('div');
        this.drop.className = 'dropzone';
        this.drop.setAttribute('aria-hidden', 'true');
        this.drop.innerHTML = `<div class="dz-card">📥
            <b>${esc(this.t('cmp.dropTitle'))}</b>
            <span>${esc(this.t('cmp.dropHint', { name: this.o.agentName || 'the agent' }))}</span></div>`;
        root.appendChild(this.drop);
      }
    }

    /* ------------------------------- wiring ------------------------------ */
    _wire() {
      const ta = this.ta;
      ta.addEventListener('input', () => { this.autoGrow(); this.updateMenu(); this.markIdle(); });
      ta.addEventListener('keydown', (e) => this.onKeyDown(e));
      ta.addEventListener('blur', () => setTimeout(() => this.closeMenu(), 120));
      ta.addEventListener('paste', (e) => {
        const files = Array.from((e.clipboardData && e.clipboardData.files) || []);
        if (files.length) { e.preventDefault(); files.forEach((f) => this.uploadFile(f)); }
      });
      this.sendBtn.addEventListener('click', () => this.send());
      this.attachBtn.addEventListener('click', () => this.fileInput.click());
      this.fileInput.addEventListener('change', () => {
        Array.from(this.fileInput.files || []).forEach((f) => this.uploadFile(f));
        this.fileInput.value = '';
      });
      this.on(document, 'mousedown', (e) => {
        if (!this.pop.contains(e.target) && e.target !== ta) this.closeMenu();
      });
      this._wireDrop();
      this.markIdle();
    }

    /** Drag a file anywhere over the chat area; the overlay is a depth counter,
     *  so entering a child element never flickers it off. */
    _wireDrop() {
      const root = this.dropRoot;
      if (!root) return;
      const hasFiles = (e) => {
        const dt = e.dataTransfer;
        return !!dt && Array.from(dt.types || []).includes('Files');
      };
      this.on(root, 'dragenter', (e) => {
        if (!hasFiles(e)) return;
        e.preventDefault();
        this.dragDepth += 1;
        this.drop.classList.add('on');
      });
      this.on(root, 'dragover', (e) => {
        if (!hasFiles(e)) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
      });
      this.on(root, 'dragleave', () => {
        this.dragDepth = Math.max(0, this.dragDepth - 1);
        if (!this.dragDepth) this.drop.classList.remove('on');
      });
      this.on(root, 'drop', (e) => {
        if (!hasFiles(e)) return;
        e.preventDefault();
        this.dragDepth = 0;
        this.drop.classList.remove('on');
        Array.from(e.dataTransfer.files || []).forEach((f) => this.uploadFile(f));
      });
      this.on(global, 'dragend', () => { this.dragDepth = 0; this.drop.classList.remove('on'); });
      this.on(global, 'keydown', (e) => {
        if (e.key === 'Escape' && this.drop && this.drop.classList.contains('on')) {
          this.dragDepth = 0; this.drop.classList.remove('on');
        }
      });
    }

    /* --------------------------- 1. auto-expanding ----------------------- */
    /** Grow to fit the content, between 44px and 200px — never a pixel more.
     *  Nothing is written when the height is unchanged, which is what keeps
     *  the chat above it from twitching on every keystroke. */
    autoGrow() {
      const ta = this.ta;
      if (!ta) return;
      let next;
      if (!ta.value) {
        /* An empty composer is *exactly* one line. The placeholder must never
           size the box: it is longer in some languages, longer again on wide
           screens, and `field-sizing: content` would grow the textarea to fit
           it — which re-flowed the whole chat the moment you switched modes or
           resized. Pinning the height here closes that off for good. */
        next = MIN_H;
        if (ta.style.height !== MIN_H + 'px') ta.style.height = MIN_H + 'px';
      } else if (this.fieldSizing) {
        if (ta.style.height) ta.style.height = '';  // hand sizing back to the browser
        next = fitHeight(ta.scrollHeight);
      } else {
        ta.style.height = '0px';                 // measure from scratch (no feedback loop)
        next = fitHeight(ta.scrollHeight);
        if (ta.style.height !== next + 'px') ta.style.height = next + 'px';
      }
      const capped = next >= MAX_H;
      const changed = next !== this.height || capped !== this._capped;
      this.height = next;
      this._capped = capped;
      ta.classList.toggle('capped', capped);
      if (changed) this.resizeFire();            // only then does the chat need re-pinning
    }

    resizeFire() {
      if (this.o.onResize) this.o.onResize(this.height);
    }

    /** Put the textarea back to one line (after sending, clearing, …). */
    reset() {
      this.ta.value = '';
      this.height = MIN_H;
      this.ta.style.height = MIN_H + 'px';
      this.ta.classList.remove('capped');
      this.closeMenu();
      this.markIdle();
      this.resizeFire();
    }

    get value() { return this.ta ? this.ta.value : ''; }
    setValue(text, { focus = true } = {}) {
      this.ta.value = text == null ? '' : String(text);
      this.autoGrow();
      this.markIdle();
      if (focus) this.focus();
    }
    focus() {
      this.ta.focus();
      const end = this.ta.value.length;
      try { this.ta.setSelectionRange(end, end); } catch { /* not selectable */ }
    }
    markIdle() { this.sendBtn.classList.toggle('is-idle', !this.value.trim()); }

    /* ------------------------- 2. attachments ---------------------------- */
    async uploadFile(file, { path } = {}) {
      if (!file) return;
      if (this.o.maxBytes && file.size > this.o.maxBytes) {      // fail politely, before the wire
        const row = this.addRow(file);
        row.set(0, 'error');
        row.error(this.t('cmp.tooBig', {
          name: file.name, size: fmtSize(file.size), mb: Math.round(this.o.maxBytes / 1048576),
        }));
        if (this.o.onTooBig) this.o.onTooBig(file);
        return;
      }
      const row = this.addRow(file);
      const controller = new AbortController();
      row.cancel = () => controller.abort();
      const url = this.o.uploadUrl || `/api/agents/${encodeURIComponent(this.agentId)}/upload`;
      const transport = this.o.upload || defaultTransport;   // injectable: the demo runs offline
      row.set(0.01, 'uploading');
      try {
        const res = await transport(file, {
          url, path, signal: controller.signal,
          onProgress: (p, loaded, total) => row.set(p, 'uploading', loaded, total),
        });
        row.set(1, 'done', file.size, file.size);
        this.insertToken(uploadToken(res && res.stored ? res.stored : file.name));
        if (this.o.onUploaded) this.o.onUploaded(file, res || {});
      } catch (err) {
        row.set(row.pct, err && err.aborted ? 'cancelled' : 'error');
        if (!(err && err.aborted)) {
          row.error(err && err.message ? err.message : String(err));
          if (this.o.onError) this.o.onError(file, err || new Error('upload failed'));
        }
      }
    }

    /** One row in the attachment strip with its own progress bar. */
    addRow(file) {
      this.strip.classList.remove('hidden');
      const el = document.createElement('div');
      el.className = 'att-row';
      el.dataset.state = 'uploading';
      el.innerHTML = `
        <span class="att-icon">📄</span>
        <span class="att-name">${esc(file.name)}<span class="att-size">${fmtSize(file.size)}</span></span>
        <span class="att-bar"><i></i></span>
        <span class="att-pct">0%</span>
        <button class="att-x" type="button" title="${esc(this.t('cmp.cancel'))}" aria-label="${esc(this.t('cmp.cancel'))}">✕</button>`;
      const bar = el.querySelector('.att-bar i');
      const pct = el.querySelector('.att-pct');
      const x = el.querySelector('.att-x');
      const row = {
        file, el, pct: 0, cancel: null,
        set(p, state, loaded, total) {
          row.pct = Math.max(0, Math.min(1, p || 0));
          bar.style.width = Math.round(row.pct * 100) + '%';
          el.dataset.state = state;
          pct.textContent = state === 'done' ? '✓' : state === 'error' ? '⚠' : state === 'cancelled' ? '✕'
            : Math.round(row.pct * 100) + '%';
          if (state === 'done') pct.classList.add('ok');
          if (loaded && total) el.querySelector('.att-size').textContent = fmtSize(total);
        },
        error(msg) {
          el.dataset.state = 'error';
          const span = document.createElement('span');
          span.className = 'att-err';
          span.textContent = msg;
          el.appendChild(span);
        },
      };
      x.onclick = () => {
        if (el.dataset.state === 'uploading') { if (row.cancel) row.cancel(); }
        else { el.remove(); if (!this.strip.children.length) this.strip.classList.add('hidden'); }
      };
      this.strip.appendChild(el);
      this.files.push(row);
      return row;
    }

    /** Put `[Uploaded: name.ext]` where the caret is (or replace the selection). */
    insertToken(token) {
      const ta = this.ta;
      const start = ta.selectionStart == null ? ta.value.length : ta.selectionStart;
      const end = ta.selectionEnd == null ? start : ta.selectionEnd;
      const needsSpace = !!ta.value && !/\s$/.test(ta.value.slice(0, start));
      const text = (needsSpace ? ' ' : '') + token + ' ';
      ta.value = ta.value.slice(0, start) + text + ta.value.slice(end);
      const caret = start + text.length;
      this.autoGrow();
      this.markIdle();
      this.focus();
      try { ta.setSelectionRange(caret, caret); } catch { /* ignore */ }
    }

    /* ------------------------ 3. slash commands -------------------------- */
    updateMenu() {
      const state = slashState(this.ta.value, this.ta.selectionStart);
      if (!state.open) return this.closeMenu();
      if (this.menu && this.menu.mode === state.mode && this.menu.start === state.start
          && this.menu.query === state.query && this.menu.commandId === (state.command || {}).id) {
        return;                                       // nothing changed — keep the DOM
      }
      if (state.mode === 'commands') {
        const items = search(COMMANDS.map((c) => ({
          id: c.id, cmd: '/' + c.id, arg: c.arg ? `[${c.arg}]` : '', desc: this.t(c.desc),
        })), state.query);
        this.openMenu({ mode: 'commands', items, start: state.start, end: state.end });
      } else {
        const cmd = state.command;
        Promise.resolve(this.provider(cmd.takes, state.query)).then((list) => {
          const needle = String(state.query || '').toLowerCase();
          const items = (list || [])
            .filter((it) => !needle || String(it.name || it.id || '').toLowerCase().includes(needle)
              || String(it.hint || it.description || '').toLowerCase().includes(needle))
            .map((it) => ({
              id: it.id || it.name, cmd: String(it.name || it.id || ''), arg: it.hint || '',
              desc: it.description || '', value: it.name || it.id || '',
            }));
          if (!items.length) return this.closeMenu();
          this.openMenu({ mode: 'args', items, start: state.start, end: state.end,
                          commandId: cmd.id, tpl: cmd.tpl });
        });
      }
    }

    provider(kind, query) {
      const p = (this.o.providers || {})[kind];
      if (!p) return [];
      return typeof p === 'function' ? p(query) : p;
    }

    openMenu(menu) {
      this.menu = menu;
      this.active = 0;
      this.pop.classList.remove('hidden');
      this.renderMenu();
    }

    closeMenu() {
      if (!this.menu && this.pop.classList.contains('hidden')) return;
      this.menu = null;
      this.active = -1;
      this.pop.classList.add('hidden');
      this.pop.innerHTML = '';
    }

    renderMenu() {
      if (!this.menu) return;
      const head = this.menu.mode === 'commands'
        ? `<div class="slash-hint">${esc(this.t('cmp.hint'))}</div>` : '';
      const rows = this.menu.items.map((it, i) => `
        <button class="slash-item${i === this.active ? ' active' : ''}" type="button" role="option"
                aria-selected="${i === this.active}" data-i="${i}">
          <span class="slash-cmd">${esc(it.cmd)}</span>
          ${it.arg ? `<span class="slash-arg">${esc(it.arg)}</span>` : ''}
          <span class="slash-desc">${esc(it.desc || '')}</span>
        </button>`).join('');
      this.pop.innerHTML = head + rows;
      this.pop.querySelectorAll('.slash-item').forEach((b) => {
        b.onmouseenter = () => this.highlight(Number(b.dataset.i));
        b.onclick = () => this.accept(Number(b.dataset.i));
      });
    }

    highlight(i) {
      if (!this.menu || i < 0 || i >= this.menu.items.length) return;
      this.active = i;
      this.pop.querySelectorAll('.slash-item').forEach((b, k) => {
        b.classList.toggle('active', k === i);
        b.setAttribute('aria-selected', String(k === i));
      });
      const el = this.pop.querySelector('.slash-item.active');
      if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    }

    /** Accept the highlighted entry: run an action, drill into arguments, or insert. */
    accept(i) {
      const menu = this.menu;
      if (!menu) return;
      const item = menu.items[i == null ? this.active : i];
      if (!item) return;
      if (menu.mode === 'commands') {
        const cmd = BY_ID[item.id];
        if (cmd.takes) {                       // second level: pick the agent / skill
          this.replaceRange(menu.start, menu.end, '/' + cmd.id + ' ');
          this.focus();
          this.menu = null;
          this.updateMenu();
          return;
        }
        this.replaceRange(menu.start, menu.end, cmd.tpl ? this.t(cmd.tpl) : '');
        this.closeMenu();
        if (cmd.action === 'clear' && this.o.onCommand) this.o.onCommand(cmd.id);
        else this.focus();
        return;
      }
      this.replaceRange(menu.start, menu.end, this.t(menu.tpl, { value: item.value }));
      this.closeMenu();
      this.focus();
    }

    /** Replace [start, end) and keep the caret at the end of what was written. */
    replaceRange(start, end, text) {
      const ta = this.ta;
      const rest = ta.value.slice(end);
      ta.value = ta.value.slice(0, start) + text + rest;
      const caret = start + text.length;
      this.autoGrow();
      this.markIdle();
      try { ta.setSelectionRange(caret, caret); } catch { /* ignore */ }
    }

    /* ------------------------- 4. keyboard model ------------------------- */
    onKeyDown(e) {
      const menuOpen = !!this.menu;
      if (e.key === 'Escape') {
        if (menuOpen) { e.preventDefault(); this.closeMenu(); return; }
        if (this.drop && this.drop.classList.contains('on')) {
          this.dragDepth = 0; this.drop.classList.remove('on');
        }
        return;
      }
      if (menuOpen) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          this.highlight((this.active + 1) % this.menu.items.length);
          return;
        }
        if (e.key === 'ArrowUp' || (e.key === 'Tab' && e.shiftKey)) {
          e.preventDefault();
          this.highlight((this.active - 1 + this.menu.items.length) % this.menu.items.length);
          return;
        }
        if (e.key === 'Tab') { e.preventDefault(); this.accept(); return; }   // Tab accepts, like Enter
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.accept(); return; }
        if (e.key === 'Home' || e.key === 'End' || e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
          this.closeMenu();
        }
      }
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.send(); return; }
      if (e.key === 'ArrowUp' && this.history.length && this.ta.selectionStart === 0) {
        this.histIndex = Math.min(this.histIndex + 1, this.history.length - 1);
        e.preventDefault();
        this.setValue(this.history[this.histIndex], { focus: true });
        this.ta.setSelectionRange(0, 0);
        return;
      }
      if (e.key === 'ArrowDown' && this.histIndex > -1) {
        e.preventDefault();
        this.histIndex -= 1;
        this.setValue(this.histIndex >= 0 ? this.history[this.histIndex] : '', { focus: true });
      }
    }

    send() {
      const text = this.value.trim();
      if (!text) return;
      this.history.unshift(text);
      if (this.history.length > 50) this.history.pop();
      this.histIndex = -1;
      this.closeMenu();
      if (this.o.onSend) this.o.onSend(text);
    }

  }

  /* ----------------------------------------------------------------------
     Export
     ---------------------------------------------------------------------- */
  global.NB = global.NB || {};
  global.NB.Composer = Composer;
  global.NB.composer = { MIN_H, MAX_H, COMMANDS, fitHeight, slashState, uploadToken, fmtSize, xhrUpload };
})(typeof window !== 'undefined' ? window : globalThis);
