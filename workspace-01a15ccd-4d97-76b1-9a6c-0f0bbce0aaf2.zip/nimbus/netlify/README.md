# Nimbus Standalone for Netlify

This is a **pure browser-based version of Nimbus** that uses **localStorage** for persistence. All your data (agents, threads, messages, settings) will be saved in your browser and will never be forgotten.

## Features

✅ **Full localStorage persistence** - All data is saved in your browser
✅ **Multi-language support** - English, Chinese, and Spanish
✅ **Chat interface** - Send messages and receive AI responses (simulated)
✅ **Agent management** - Create, edit, and delete AI agents
✅ **Thread management** - Organize conversations into threads
✅ **Rich text composer** - Auto-expanding textarea with slash commands
✅ **Responsive design** - Works on desktop, tablet, and mobile
✅ **Glass theme toggle** - Modern glassmorphism UI

## Quick Start

### Deploy to Netlify

1. **Drag and drop** the `nimbus_netlify.zip` file to [Netlify Drop](https://app.netlify.com/drop)
2. Or **upload manually**:
   - Go to your Netlify dashboard
   - Click "Add new site" → "Deploy manually"
   - Upload the zip file
   - Click "Deploy site"

3. **Access your site** - Once deployed, visit your Netlify URL

### Use Locally

You can also run it locally:

```bash
# Unzip the file
unzip nimbus_netlify.zip

# Open index.html in your browser
open index.html  # or double-click the file
```

## How It Works

This version replaces the backend API with **localStorage-based operations**:

- **No server required** - Everything runs in your browser
- **Data persistence** - All data is stored in localStorage
- **Instant loading** - No waiting for API calls
- **Offline capable** - Works without internet connection

## Limitations

This is a **standalone demo version** with some limitations:

- ❌ **No real AI** - Responses are simulated (for demo purposes)
- ❌ **No file uploads** - File attachments are mocked
- ❌ **No multi-device sync** - Data stays in your browser only
- ❌ **No real-time features** - Activity and approvals are placeholders

For the full Nimbus experience with real AI, you need to run the backend server.

## Browser Support

Works on all modern browsers:
- Chrome / Edge (recommended)
- Firefox
- Safari
- Mobile browsers (iOS Safari, Chrome for Android)

## Data Storage

All data is stored under these localStorage keys:
- `nimbus_system` - System settings
- `nimbus_agents` - Your AI agents
- `nimbus_threads` - Conversation threads
- `nimbus_messages` - Chat messages
- `nimbus_settings` - UI preferences
- `nimbus_init` - Initialization flag
- `nimbus_current_agent` - Currently selected agent
- `nimbus_current_thread` - Currently selected thread

## Clearing Data

To reset everything:
1. Open browser DevTools (F12)
2. Go to Application → Local Storage
3. Delete all `nimbus_*` keys
4. Refresh the page

## Customization

You can customize the app by editing the files:

- **`index.html`** - Main HTML structure
- **`styles.css`** - All styling and theming
- **`app_standalone.js`** - Main application logic
- **`composer.js`** - Rich text input component
- **`components.js`** - UI components
- **`i18n.js`** - Internationalization strings

## License

This is part of the Nimbus project. See the main repository for licensing details.
