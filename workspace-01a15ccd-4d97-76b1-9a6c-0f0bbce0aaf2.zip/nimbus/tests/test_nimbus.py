"""End-to-end-ish tests for Nimbus. Run:  pytest -q"""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# isolate test data before importing nimbus
os.environ["NIMBUS_DATA_DIR"] = str(ROOT / "data_test")
os.environ.setdefault("NIMBUS_DEFAULT_PROVIDER", "mock")
os.environ["GOOGLE_DEMO_MODE"] = "1"

from nimbus import db, google_api, scheduler  # noqa: E402
from nimbus.agent import Runner, build_system_prompt, run_agent  # noqa: E402
from nimbus.approvals import needs_approval  # noqa: E402
from nimbus.store import create_agent, create_thread, list_messages, resolve_in_workspace  # noqa: E402
from nimbus.tools import REGISTRY, get_tool, schemas  # noqa: E402
from nimbus.tools.base import ToolContext  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def _clean():
    d = ROOT / "data_test"
    if d.exists():
        import shutil
        shutil.rmtree(d)
    d.mkdir(parents=True, exist_ok=True)
    yield


# --------------------------------------------------------------------- tools
def test_registry_loads():
    assert len(REGISTRY) > 30
    names = set(REGISTRY)
    for expected in ("write_file", "run_command", "web_search", "gdrive_search", "gdocs_create",
                     "gsheets_read", "gmail_send_email", "gcal_list_events", "remember",
                     "delegate_task", "spawn_agent", "create_routine", "browser_open"):
        assert expected in names, expected
    specs = schemas()
    assert all(s["parameters"].get("type") == "object" for s in specs)


def test_workspace_jail():
    agent = create_agent("JailTest", provider="mock", model="nimbus-offline")
    with pytest.raises(ValueError):
        resolve_in_workspace(agent["id"], "../../etc/passwd")
    p = resolve_in_workspace(agent["id"], "notes/a.md")
    assert str(p).startswith(agent["workspace"])


@pytest.mark.asyncio
async def test_workspace_tools_roundtrip():
    agent = create_agent("FileTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, thread_id="t1", workspace=Path(agent["workspace"]))
    w = get_tool("write_file")
    r = await w.run({"path": "reports/q1.md", "content": "# Q1\nhello"}, ctx)
    assert r.ok, r.error
    rd = await get_tool("read_file").run({"path": "reports/q1.md"}, ctx)
    assert "hello" in rd.data["content"]
    ls = await get_tool("list_files").run({"path": "reports"}, ctx)
    assert ls.data["count"] == 1
    grep = await get_tool("search_files").run({"query": "hello"}, ctx)
    assert grep.data["count"] == 1
    ed = await get_tool("edit_file").run({"path": "reports/q1.md", "find": "hello", "replace": "bye"}, ctx)
    assert ed.ok
    assert "bye" in (await get_tool("read_file").run({"path": "reports/q1.md"}, ctx)).data["content"]


@pytest.mark.asyncio
async def test_shell_tool_jailed_and_guarded():
    agent = create_agent("ShellTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, thread_id="t2", workspace=Path(agent["workspace"]))
    # Use simple commands without shell features (no >, &&, etc.)
    r = await get_tool("run_command").run({"command": "echo hi"}, ctx)
    assert r.ok and "hi" in r.data["stdout"]
    # Test that network commands are blocked
    blocked = await get_tool("run_command").run({"command": "curl http://example.com"}, ctx)
    assert not blocked.ok and ("not allowed" in blocked.error.lower() or "requires approval" in blocked.error.lower())
    # Test that destructive commands are blocked
    refused = await get_tool("run_command").run({"command": "rm -rf /"}, ctx)
    assert not refused.ok


# ------------------------------------------------------------------- memory
@pytest.mark.asyncio
async def test_memory_roundtrip():
    agent = create_agent("MemTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, thread_id="t3", workspace=Path(agent["workspace"]))
    await get_tool("remember").run({"key": "tone", "value": "be brief"}, ctx)
    got = await get_tool("recall").run({"query": "tone"}, ctx)
    assert got.data["memories"][0]["key"] == "tone"
    await get_tool("forget").run({"key": "tone"}, ctx)
    assert (await get_tool("recall").run({}, ctx)).data["count"] == 0


# ------------------------------------------------------------- google demo
@pytest.mark.asyncio
async def test_google_demo_full_cycle():
    agent = create_agent("GoogleTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, thread_id="t4", workspace=Path(agent["workspace"]))

    files = await get_tool("gdrive_search").run({"query": "review"}, ctx)
    assert files.ok and files.data["count"] >= 1

    doc = await get_tool("gdocs_create").run(
        {"title": "Test Brief", "markdown": "# Title\n\n## Section\n- one\n- two\n\n**bold** and `code`\n"}, ctx)
    assert doc.ok, doc.error
    same = await get_tool("gdocs_read").run({"doc_id": doc.data["id"]}, ctx)
    assert "Section" in same.data["text"]

    sheet = await get_tool("gsheets_create").run(
        {"title": "Test Sheet", "values": [["a", "b"], [1, 2]]}, ctx)
    assert sheet.ok
    read = await get_tool("gsheets_read").run({"spreadsheet_id": sheet.data["id"]}, ctx)
    assert read.data["rows"][0] == ["a", "b"]
    wrote = await get_tool("gsheets_write").run(
        {"spreadsheet_id": sheet.data["id"], "range": "A3", "values": [["appended", "row"]]}, ctx)
    assert wrote.ok

    mail = await get_tool("gmail_list_messages").run({"query": "pricing"}, ctx)
    assert mail.ok and mail.data["count"] >= 1
    sent = await get_tool("gmail_send_email").run(
        {"to": "someone@example.com", "subject": "hi", "body": "test"}, ctx)
    assert sent.ok and sent.data["source"] == "demo"

    events = await get_tool("gcal_list_events").run({}, ctx)
    assert events.ok and events.data["count"] >= 1
    made = await get_tool("gcal_create_event").run(
        {"summary": "Test", "start": "2026-11-01T10:00:00+08:00", "end": "2026-11-01T10:30:00+08:00"}, ctx)
    assert made.ok

    upload = await get_tool("gdrive_upload").run({"path": "notes.md", "convert": True}, ctx)
    assert upload.ok or upload.error  # file may not exist in this workspace; either is fine


def test_markdown_to_docs_requests():
    md = "# H1\n\nText with **bold** here.\n\n- a\n- b\n\n```\ncode block\n```\n"
    reqs, length = google_api.markdown_to_docs_requests(md)
    assert length > 0
    assert any("insertText" in r for r in reqs)
    assert any("createParagraphBullets" in r for r in reqs)
    assert any("updateParagraphStyle" in r for r in reqs)
    for r in reqs:
        rng = r.get("updateParagraphStyle", {}).get("range") or r.get("updateTextStyle", {}).get("range") or \
              r.get("createParagraphBullets", {}).get("range")
        if rng:
            assert rng["endIndex"] > rng["startIndex"] >= 1
            assert rng["endIndex"] <= length + 2


# --------------------------------------------------------------- approvals
def test_approval_policy():
    strict = create_agent("Strict", provider="mock", model="nimbus-offline", approval_mode="risky")
    auto = create_agent("Auto", provider="mock", model="nimbus-offline", approval_mode="auto")
    every = create_agent("Every", provider="mock", model="nimbus-offline", approval_mode="all")
    send = get_tool("gmail_send_email")
    read = get_tool("list_files")
    assert needs_approval(strict, send, {"to": "x@y.com"}) is not None
    assert needs_approval(strict, read, {}) is None
    assert needs_approval(auto, send, {"to": "x@y.com"}) is None
    assert needs_approval(every, read, {}) is not None
    dangerous = get_tool("run_command")
    assert needs_approval(strict, dangerous, {"command": "rm -rf build"}) is not None
    assert needs_approval(strict, dangerous, {"command": "ls -la"}) is None


# ------------------------------------------------------------------- agent
@pytest.mark.asyncio
async def test_agent_runs_offline_with_tools():
    agent = create_agent("Offline", provider="mock", model="nimbus-offline")
    thread = create_thread(agent["id"], "test")
    events = []

    async def sink(ev):
        events.append(ev)

    runner = Runner(agent, thread["id"], sink=sink)
    answer = await runner.send("please write a file with my notes about launch planning")
    assert answer
    msgs = list_messages(thread["id"])
    roles = [m["role"] for m in msgs]
    assert "user" in roles and "assistant" in roles and "tool" in roles
    kinds = {e["type"] for e in events}
    assert {"run_start", "tool_start", "tool_end", "message", "run_end"} <= kinds
    assert (Path(agent["workspace"]) / "notes.md").exists()


def test_system_prompt_mentions_environment():
    a = create_agent("Prompt", provider="mock", model="nimbus-offline", title="Tester")
    prompt = build_system_prompt(a)
    assert "Prompt" in prompt and "workspace" in prompt.lower() and "Approval policy" in prompt


@pytest.mark.asyncio
async def test_delegation_and_spawn():
    boss = create_agent("Boss", provider="mock", model="nimbus-offline", description="orchestrator")
    create_agent("Worker", provider="mock", model="nimbus-offline", description="does the work")
    ctx = ToolContext(agent=boss, thread_id=create_thread(boss["id"], "d")["id"], workspace=Path(boss["workspace"]))
    team = await get_tool("list_team").run({}, ctx)
    assert team.data["count"] >= 2
    res = await get_tool("delegate_task").run({"agent_name": "Worker", "task": "say hi"}, ctx)
    assert res.ok and "result" in res.data
    spawn = await get_tool("spawn_agent").run({"name": "Sprout", "description": "new helper"}, ctx)
    assert spawn.ok and db.q1("SELECT id FROM agents WHERE name='Sprout'")


@pytest.mark.asyncio
async def test_skills_and_routines():
    agent = create_agent("SkillTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, thread_id="x", workspace=Path(agent["workspace"]))
    made = await get_tool("create_skill").run(
        {"name": "Weekly report", "description": "build the weekly report",
         "instructions": "1. gather numbers\n2. write doc\n3. email it"}, ctx)
    assert made.ok
    read = await get_tool("read_skill").run({"name": "Weekly report"}, ctx)
    assert "gather numbers" in read.data["instructions"]
    run = await get_tool("run_skill").run({"name": "Weekly report", "inputs": {"week": 41}}, ctx)
    assert run.ok
    rt = await get_tool("create_routine").run(
        {"name": "Every morning", "prompt": "do the brief", "kind": "cron", "schedule": "0 8 * * *"}, ctx)
    assert rt.ok and rt.data["kind"] == "cron"
    assert scheduler.compute_next_run("cron", "0 8 * * *", None) > 0
    assert scheduler.compute_next_run("interval", "60", None) > 0


@pytest.mark.asyncio
async def test_scheduler_trigger_fires_routine():
    agent = create_agent("CronTest", provider="mock", model="nimbus-offline")
    rid = db.insert("routines", {
        "id": db.new_id(), "agent_id": agent["id"], "name": "Event routine", "kind": "event",
        "schedule": "", "event_filter": "file.upload", "prompt": "summarise the new file",
        "skill_id": "", "enabled": 1, "last_run_at": None, "next_run_at": None, "run_count": 0,
        "created_at": db.now()})
    fired = await scheduler.emit_event("file.upload", {"path": "x.csv"})
    assert "Event routine" in fired
    await asyncio.sleep(2.5)  # let the background run finish
    row = db.q1("SELECT * FROM routines WHERE id=?", (rid,))
    assert row["run_count"] >= 1


# -------------------------------------------------------------- API layer
# ------------------------------------------------- chat component contract
def test_tool_stepper_shapes():
    """The stepper's data rules: labels, run collapsing, chain rendering."""
    import json
    import shutil
    import subprocess

    node = shutil.which("node")
    if not node:
        return
    script = """
      global.window = global;
      require('./nimbus/web/components.js');
      const NB = global.NB;
      const out = {
        label: NB.stepLabel('write_file', { path: 'summary.md' }),
        drive: NB.stepLabel('gdrive_search', {}),
        run: NB.stepLabel('run_command', { command: 'ls -la' }),
        collapsed: NB.collapseRepeats(['Searched Drive', 'Searched Drive', 'Wrote summary.md']),
        chain: NB.chainHTML(['Searched Drive', 'Read 1 file', 'Wrote summary.md'], (k) => k),
        diff: NB.diffLines('one\\ntwo', 'one\\nTWO').map(r => r.type),
        atBottom: typeof NB.atBottom === 'function',
        stepper: typeof NB.ToolStepper === 'function',
        typer: typeof NB.Typer === 'function',
        approvalHasThreeChoices: ['data-allow', 'data-always', 'data-reject'].every(
          k => NB.tpl.approval({ id: 'x', tool: 'delete_file', risk: 'high', reason: 'r',
                                 args: { path: 'a.txt' } }, (k) => k).includes(k)),
        // the diff viewer replaces the raw before/after arguments
        approvalDiffers: (() => {
          const h = NB.tpl.approval({ id: 'x', tool: 'edit_file', risk: 'high', reason: 'r',
            args: { path: 'app/config.py', old_text: 'a = 1', new_text: 'a = 2' } }, (k) => k);
          return ['risk-high', 'diff', 'appr-args', 'app/config.py'].every(k => h.includes(k))
                 && !h.includes('old_text') && !h.includes('new_text');
        })(),
        approvalCommand: (() => {
          const h = NB.tpl.approval({ id: 'x', tool: 'run_command', risk: 'medium', reason: 'r',
            args: { command: 'rm -rf ./build' } }, (k) => k);
          return h.includes('appr-cmd') && h.split('rm -rf ./build').length === 2;   // shown once, in the viewer
        })(),
      };
      console.log(JSON.stringify(out));
    """
    raw = subprocess.run([node, "-e", script], cwd=str(ROOT), capture_output=True, text=True, check=True)
    out = json.loads(raw.stdout.strip().splitlines()[-1])
    assert out["label"] == "Wrote summary.md"
    assert out["drive"] == "Searched Drive"
    assert out["run"] == "Ran `ls -la`"
    assert out["collapsed"] == [{"label": "Searched Drive", "n": 2},
                               {"label": "Wrote summary.md", "n": 1}]
    assert out["chain"].count("stepper-sep") == 2 and "Wrote summary.md" in out["chain"]
    assert out["diff"] == ["ctx", "del", "add"]
    assert out["atBottom"] and out["stepper"] and out["typer"]
    assert out["approvalHasThreeChoices"] and out["approvalDiffers"]
    assert out["approvalCommand"]


def test_chat_component_wiring():
    """app.js must route the stream into the three new components."""
    src = (ROOT / "nimbus" / "web" / "app.js").read_text(encoding="utf-8")
    html = (ROOT / "nimbus" / "web" / "index.html").read_text(encoding="utf-8")
    css = (ROOT / "nimbus" / "web" / "styles.css").read_text(encoding="utf-8")
    # the module loads before the app that uses it
    assert html.index("components.js") < html.index("app.js")
    # stepper for tool runs, typer for streaming, banner for approvals
    for needle in ("new NB.ToolStepper(", "new NB.Typer(", "NB.tpl.approval(", "NB.tpl.resolved(",
                   "closeStepper()", "follow.stick", "updateJump()"):
        assert needle in src, f"app.js no longer integrates {needle}"
    assert "scrollTop = c.scrollHeight" not in src           # the old blind scroll is gone
    for needle in (".stepper", ".step-item", ".arg-row", ".appr {", ".appr-risk", ".diff-line",
                   ".cursor", ".chunk", ".jump-latest", "@keyframes caret", "@keyframes pulse-dot"):
        assert needle in css, f"styles.css is missing {needle}"


def test_demo_page_matches_sources():
    """The reference page is generated — the inlined copies must not drift."""
    import importlib.util

    spec = importlib.util.spec_from_file_location("build_demo", ROOT / "tools" / "build_demo.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    page = (ROOT / "nimbus" / "web" / "components-demo.html").read_text(encoding="utf-8")

    assert page == mod.build(), "run: python3 tools/build_demo.py"
    # it carries the real component code, the real component CSS and all three languages
    assert mod.component_css().strip() in page
    assert (ROOT / "nimbus" / "web" / "components.js").read_text(encoding="utf-8").rstrip() in page
    for lang in ("en", "zh", "es"):
        assert f'"{lang}":' in page
    for needle in ("NB.ToolStepper", "NB.tpl.approval", "NB.Typer", "jump-latest"):
        assert needle in page


def test_demo_route_is_served():
    from fastapi.testclient import TestClient
    from nimbus.server import app
    with TestClient(app) as c:
        r = c.get("/demo")
        assert r.status_code == 200 and ("chat components" in r.text or "聊天组件" in r.text)
        assert c.get("/static/components.js").status_code == 200
        layout = c.get("/layout")
        assert layout.status_code == 200 and ("layout chrome" in layout.text or "布局参考" in layout.text)


def test_composer_empty_box_cannot_be_sized_by_the_placeholder():
    """An empty composer is exactly one line, whatever the placeholder says.

    `field-sizing: content` sizes the textarea to its placeholder too, so a
    longer translation (or the wide-screen hint) used to re-flow the whole
    chat — and left a stale taller box behind after a resize."""
    web = ROOT / "nimbus" / "web"
    js = (web / "composer.js").read_text(encoding="utf-8")
    css = (web / "styles.css").read_text(encoding="utf-8")
    assert ".composer textarea:not(:placeholder-shown) { field-sizing: content; height: auto; }" in css
    grow = js[js.index("autoGrow() {"):js.index("autoGrow() {") + 900]
    assert "if (!ta.value) {" in grow and "next = MIN_H;" in grow
    assert "ta.style.height = MIN_H + 'px';" in grow          # empty → pinned
    assert "if (ta.style.height) ta.style.height = '';" in grow  # text → browser sizes it
    assert "this.ta.style.height = MIN_H + 'px';" in js        # reset() clears to one line


def test_rerender_keeps_the_composer_draft():
    """A mode flip rebuilds the composer; the half-typed task has to survive it."""
    app = (ROOT / "nimbus" / "web" / "app.js").read_text(encoding="utf-8")
    mount = app[app.index("function mountComposer(pane) {"):app.index("/** Slash commands that do something instead of typing a prompt. */")]
    assert "const draft = state.composer ? state.composer.value : '';" in mount
    assert "const wasFocused = !!(state.composer && document.activeElement === $('#input'));" in mount
    assert "if (draft) state.composer.setValue(draft, { focus: false });" in mount
    assert "if (wasFocused || draft) state.composer.focus();" in mount


def test_layout_demo_matches_sources():
    """The chrome reference page is generated too — it cannot drift either."""
    import importlib.util

    spec = importlib.util.spec_from_file_location("build_layout_demo", ROOT / "tools" / "build_layout_demo.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    page = (ROOT / "nimbus" / "web" / "layout_demo.html").read_text(encoding="utf-8")

    assert page == mod.build(), "run: python3 tools/build_layout_demo.py"
    # the real stylesheet: §1–§7 verbatim, §10 verbatim, and no second copy of §8–§9
    css = mod.chrome_css()
    assert css.strip() in page
    assert ".agent-chip {" in page and "body.sheet-open #drawer" in page
    # §8–§9 belong to the other page: no stepper, no slash popover, no dropzone here
    for token in (".slashpop", ".dropzone", ".att-row", ".appr {", ".tool-stepper"):
        assert token not in page, token
    for lang in ("en", "zh", "es"):
        assert f'"{lang}":' in page
    # and the four behaviours are wired on the page, not just styled
    for needle in ("function toggleMenu(menu, btn)", "function wireSheetDrag()",
                   "function wireSidebarDrag()", "function captureScrollAnchor()",
                   "function reconcileChrome()", "const isSheet = () => window.innerWidth < 768;"):
        assert needle in page, needle


def test_topbar_glass_is_not_a_containing_block():
    """`backdrop-filter` on the bar itself would trap position:fixed descendants
    (the phone bottom-sheet menus). The glass lives on a child layer instead."""
    web = ROOT / "nimbus" / "web"
    css = (web / "styles.css").read_text(encoding="utf-8")
    html = (web / "index.html").read_text(encoding="utf-8")
    assert 'class="topbar-bg"' in html
    assert ".topbar-bg {" in css and "backdrop-filter: blur(12px) saturate(1.2);" in css
    rules = re.sub(r"/\*.*?\*/", "", css, flags=re.S)      # comments are not declarations
    topbar = rules[rules.index(".topbar {"):rules.index(".topbar-bg {")]
    assert "backdrop-filter" not in topbar, "the glass must not sit on .topbar itself"


def test_layout_chrome_structure():
    """Topbar consolidation, scrim, slide-over and bottom sheet are all present
    and wired — measured live in tests/../tmp verification, asserted here."""
    web = ROOT / "nimbus" / "web"
    html = (web / "index.html").read_text(encoding="utf-8")
    css = (web / "styles.css").read_text(encoding="utf-8")
    app = (web / "app.js").read_text(encoding="utf-8")

    # ---- 1. one profile chip instead of loose badges, in a centred grid ----
    assert 'id="agentChip"' in html and 'id="agentPop"' in html
    for badge in ('id="agentEmoji"', 'id="agentName"', 'id="agentModel"', 'id="agentStatus"'):
        assert badge in html
    # the connection badge lives inside the popover, and the chip mirrors it as a dot
    assert html.index('id="agentPop"') < html.index('id="connBadge"') < html.index('</div>\n      </div>')
    assert 'id="connDot"' in html
    assert "grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);" in css
    assert "--topbar-h: 56px" in css and "--chip-h: 38px" in css

    # ---- 2. secondary actions fold into an overflow menu on medium screens ----
    assert 'id="btnOverflow"' in html and 'id="overflowMenu"' in html
    assert html.count('data-mirror="') == 4
    assert "@media (max-width:1200px)" in css and ".act-inline { display: none; }" in css
    assert "function wireMirrors()" in app and "data-mirror" in app

    # ---- 3. tabs scroll as a filmstrip: no scrollbar, faded edges ----
    assert "scrollbar-width: none" in css and ".tabs::-webkit-scrollbar { display: none; }" in css
    assert "mask-image: linear-gradient(90deg, transparent 0" in css
    assert ".tabs.scrollable" in css and "function markTabsScrollable()" in app
    assert "scroll-snap-type: x proximity" in css and "function scrollTabIntoView(" in app

    # ---- 4. one blurred, tappable scrim behind slide-overs ----
    assert 'id="scrim"' in html
    assert "backdrop-filter: blur(8px) saturate(1.1);" in css
    assert "body.scrim-on #scrim { opacity: 1; visibility: visible; }" in css
    assert "$('#scrim').onclick = () => { closeSidebar(); setDrawer(false); };" in app
    assert "function updateScrim()" in app

    # ---- 5. sidebar slide-over: tap-to-dismiss + swipe-to-dismiss ----
    assert "@media (max-width:1080px)" in css
    assert "body.side-open #sidebar { transform: none; visibility: visible; box-shadow: var(--e4); }" in css
    assert "0 0 0 100vmax" not in css            # the old un-blurrable scrim hack is gone
    assert "function wireSidebarDrag()" in app and "function toggleSidebar(" in app

    # ---- 6. drawer becomes a swipeable bottom sheet under 768px ----
    assert "@media (max-width:767px)" in css
    assert "body.sheet-open #drawer { transform: none; visibility: visible;" in css
    assert "body.sheet-open.sheet-full #drawer { height: 92vh; }" in css
    assert ".sheet-grip" in css and 'class="sheet-grip"' in html
    assert "function wireSheetDrag()" in app and "pointerdown" in app and "setPointerCapture" in app
    assert "rubber band upward" in app and "flick or pull down" in app


def test_details_toggle_cannot_shift_the_chrome():
    """Simple ↔ Details must be a zero-layout-shift toggle: the bar keeps its
    height, the model badge appears inside the fixed chip, and the transcript
    keeps the reader's scroll position."""
    web = ROOT / "nimbus" / "web"
    css = (web / "styles.css").read_text(encoding="utf-8")
    app = (web / "app.js").read_text(encoding="utf-8")

    # mode is carried by a body class, not by mutating geometry in JS
    assert "document.body.classList.toggle('details-on', state.details)" in app
    assert "style.display = state.details" not in app          # no inline show/hide left
    # the chip holds identity + state only: nothing inside it is mode-dependent
    assert ".chip-meta" not in css and "chip-meta" not in app
    assert 'id="agentModel"' in (ROOT / "nimbus" / "web" / "index.html").read_text(encoding="utf-8")
    # …and the boxes are pinned, so the bar cannot resize
    assert "height: var(--chip-h);" in css and "height: var(--topbar-h);" in css
    # the two label lengths of the Details button occupy one box
    assert "#btnDetails, #chipDetails { min-width: 78px; justify-content: center; }" in css
    # the composer hint row keeps one line whatever the mode says
    assert re.search(r"\.hintrow \{[^}]*height: 16px;", css, re.S)
    # a re-render may add tool chips; the reading position has to survive it
    assert "function captureScrollAnchor()" in app and "function restoreScrollAnchor(" in app
    assert "const anchor = captureScrollAnchor();" in app and "restoreScrollAnchor(anchor);" in app
    # details-aware copy is switched, never inserted/removed, in the chrome
    assert "syncAgentChip()" in app and "syncPolicy()" in app


def test_composer_component_shapes():
    """The composer's pure rules: height clamp, slash parsing, upload token."""
    import json
    import shutil
    import subprocess

    node = shutil.which("node")
    if not node:
        return
    script = """
      global.window = global;
      require('./nimbus/web/components.js');
      require('./nimbus/web/composer.js');
      const C = global.NB.composer;
      const s = (text, caret) => C.slashState(text, caret);
      console.log(JSON.stringify({
        min: C.MIN_H, max: C.MAX_H,
        fit: [20, 44, 45, 120, 200, 320].map(h => C.fitHeight(h)),
        token: C.uploadToken('quarterly report.pdf'),
        cmds: C.COMMANDS.map(c => c.id + (c.arg ? ':' + c.arg : '')),
        empty: s('/', 1),
        filtered: s('/de', 3),
        args: s('/delegate ', 10),
        argsQuery: s('/delegate Sc', 12).query,
        prose: s('and/or', 7).open,
        midLine: s('check /de', 9).open,
        skill: s('/skill ', 7).command.id,
      }));
    """
    raw = subprocess.run([node, "-e", script], cwd=str(ROOT), capture_output=True, text=True, check=True)
    out = json.loads(raw.stdout.strip().splitlines()[-1])
    assert (out["min"], out["max"]) == (44, 200)
    assert out["fit"] == [44, 44, 45, 120, 200, 200]
    assert out["token"] == "[Uploaded: quarterly report.pdf]"
    assert out["cmds"] == ["delegate:agent", "skill:name", "routine", "clear"]
    assert out["empty"]["open"] and out["empty"]["mode"] == "commands" and out["empty"]["query"] == ""
    assert out["filtered"]["query"] == "de" and out["filtered"]["mode"] == "commands"
    assert out["args"]["mode"] == "args" and out["args"]["command"]["id"] == "delegate"
    assert out["argsQuery"] == "Sc" and out["skill"] == "skill"
    assert out["prose"] is False and out["midLine"] is False      # “and/or” never triggers it


def test_composer_structure_and_wiring():
    """Self-contained markup + CSS, mounted by app.js, loaded before it."""
    web = ROOT / "nimbus" / "web"
    js = (web / "composer.js").read_text(encoding="utf-8")
    css = (web / "styles.css").read_text(encoding="utf-8")
    app = (web / "app.js").read_text(encoding="utf-8")
    html = (web / "index.html").read_text(encoding="utf-8")

    # 1. auto-expanding input — the exact range from the brief
    assert "min-height: 44px; max-height: 200px;" in css
    assert "field-sizing: content" in css and "textarea.capped" in css
    assert "const MIN_H = 44" in js and "const MAX_H = 200" in js
    assert "style.height = '0px'" in js                       # measure from scratch, then clamp

    # 2. attachments: 📎, overlay, progress bar, the [Uploaded: …] chip
    for needle in ('class="attach-btn"', 'id="cmp-file"', 'class="att-strip hidden"',
                   'class="att-bar"><i></i>', "className = 'dropzone'", "insertToken(uploadToken(",
                   "new XMLHttpRequest()", "xhr.upload.onprogress"):
        assert needle in js, needle
    for needle in (".attach-btn {", ".dropzone {", ".att-row {", ".att-bar i {", ".att-pct"):
        assert needle in css, needle
    assert app.index("new NB.Composer(") and "dropRoot: pane" in app

    # 3. slash popover with the four shortcuts, keyboard-driven
    assert 'class="slashpop hidden"' in js and "updateMenu()" in js
    assert "ArrowDown" in js and "this.accept(" in js
    for className in (".slashpop {", ".slash-item {", ".slash-cmd {", ".slash-desc {"):
        assert className in css, className

    # 4. keyboard model + visible shortcut footer
    assert "e.key === 'Enter' && !e.shiftKey" in js and "this.send()" in js
    assert "e.key === 'Escape'" in js
    for kbd in ("<kbd>Enter</kbd>", "<kbd>Shift</kbd>", "<kbd>/</kbd>", "<kbd>Esc</kbd>"):
        assert kbd in js, kbd
    assert "kbd {" in css and ".keyrow {" in css

    # loaded before the app, and mounted inside renderChat
    assert html.index("composer.js") < html.index("app.js")
    assert "mountComposer(pane)" in app and "state.composer.reset()" in app
    assert "input.style.height = Math.min(input.scrollHeight, 210)" not in app   # old inline resize gone


def test_always_allow_rule_suppresses_approval():
    """'Always allow' writes a per-agent rule that skips the gate from then on."""
    from fastapi.testclient import TestClient
    from nimbus import approvals as approvals_mod
    from nimbus.server import app
    from nimbus.store import get_tool_rule

    with TestClient(app) as c:
        aid = c.post("/api/demo/team").json()["agents"][0] if False else c.get("/api/agents").json()[0]["id"]

        class T:                       # stand-in for nimbus.tools.Tool
            name = "delete_file"
            risk = "high"

        agent = {"id": aid, "approval_mode": "risky"}
        assert approvals_mod.needs_approval(agent, T(), {"path": "x.txt"})   # asks by default
        assert approvals_mod.policy_for(agent) == "risky"

        # the banner's third button
        r = c.post(f"/api/agents/{aid}/tool-rules", json={"tool": "delete_file", "action": "allow"})
        assert r.status_code == 200 and r.json()["tool"] == "delete_file"
        assert get_tool_rule(aid, "delete_file")["action"] == "allow"
        assert approvals_mod.needs_approval(agent, T(), {"path": "x.txt"}) is None

        # an 'ask' rule re-enables the gate even for a policy of 'auto'
        c.post(f"/api/agents/{aid}/tool-rules", json={"tool": "delete_file", "action": "allow"})
        assert len(c.get(f"/api/agents/{aid}/tool-rules").json()) == 1    # idempotent per tool
        d = c.delete(f"/api/agents/{aid}/tool-rules/delete_file")
        assert d.json()["removed"] is True
        assert approvals_mod.needs_approval(agent, T(), {"path": "x.txt"})

        assert c.post(f"/api/agents/{aid}/tool-rules", json={}).status_code == 400
        assert c.post(f"/api/agents/{aid}/tool-rules",
                      json={"tool": "read_file", "action": "nonsense"}).status_code == 400
        assert c.post("/api/agents/nope/tool-rules", json={"tool": "read_file"}).status_code == 404
        # every rule change is on the record
        actions = {row["action"] for row in db.q("SELECT action FROM audit WHERE actor='user' LIMIT 20")}
        assert "rule.allow" in actions and "rule.removed" in actions


def test_api_smoke():
    from fastapi.testclient import TestClient
    from nimbus.server import app
    with TestClient(app) as c:
        assert c.get("/health").json()["ok"] is True
        sysinfo = c.get("/api/system").json()
        assert sysinfo["tools"] and sysinfo["providers"]
        assert c.get("/").status_code == 200
        agents = c.get("/api/agents").json()
        assert isinstance(agents, list)
        team = c.post("/api/demo/team").json()
        assert "created" in team
        agents = c.get("/api/agents").json()
        assert len(agents) >= 1
        aid = agents[0]["id"]
        t = c.post(f"/api/agents/{aid}/threads", json={"title": "api test"}).json()
        assert c.get(f"/api/threads/{t['id']}").status_code == 200
        r = c.post("/api/task", json={"agent_id": aid, "text": "list the files in the workspace",
                                      "wait": True, "force_provider": "mock"})
        assert r.status_code == 200 and "result" in r.json()
        assert c.get("/api/skills").status_code == 200
        assert c.get("/api/routines").status_code == 200
        assert c.get("/api/audit").status_code == 200
        assert c.get("/api/stats").status_code == 200
        assert c.get("/api/google/status").json()["google"]["connected"] is True
        ev = c.post("/api/events", json={"kind": "custom.hello", "payload": {"a": 1}}).json()
        assert ev["kind"] == "custom.hello"


# ------------------------------------------------------- approval gate flow
@pytest.mark.asyncio
async def test_approval_request_roundtrip():
    import asyncio
    from nimbus import approvals

    agent = create_agent("GateTest", provider="mock", model="nimbus-offline", approval_mode="risky")
    thread = create_thread(agent["id"], "gate")
    tool = get_tool("gmail_send_email")

    task = asyncio.create_task(approvals.request_approval(
        agent, thread["id"], tool, {"to": "a@b.com", "subject": "x", "body": "y"}, "test gate"))
    await asyncio.sleep(0.3)
    pending = db.list_approvals("pending")
    assert pending and pending[0]["tool"] == "gmail_send_email"
    approvals.resolve(pending[0]["id"], "approved", "looks fine")
    decision = await asyncio.wait_for(task, timeout=5)
    assert decision["status"] == "approved"
    assert db.q1("SELECT status FROM approvals WHERE id=?", (pending[0]["id"],))["status"] == "approved"
    assert db.q1("SELECT id FROM audit WHERE action='approval.approved'")


@pytest.mark.asyncio
async def test_denied_approval_stops_tool_execution():
    """A denied approval must reach the model as a refusal, not run the tool."""
    import asyncio
    from nimbus import approvals
    from nimbus.agent import Runner

    agent = create_agent("DenyTest", provider="mock", model="nimbus-offline", approval_mode="risky")
    thread = create_thread(agent["id"], "deny")
    runner = Runner(agent, thread["id"])
    ctx = runner.ctx()

    async def deny_soon():
        for _ in range(40):
            await asyncio.sleep(0.05)
            rows = db.list_approvals("pending")
            if rows:
                approvals.resolve(rows[0]["id"], "denied", "no thanks")
                return
    asyncio.create_task(deny_soon())

    payload = await runner._execute(
        {"id": "call_x", "name": "gmail_send_email",
         "arguments": {"to": "a@b.com", "subject": "s", "body": "b"}}, ctx)
    assert "denied" in payload
    # nothing was sent: demo store has no new SENT message from this agent
    assert not db.q1("SELECT id FROM audit WHERE action='tool.gmail_send_email'")
    assert db.q1("SELECT id FROM audit WHERE action='approval.denied'")


# ------------------------------------------------------------------ i18n
def test_language_config_and_normalisation():
    from nimbus.config import LANGUAGES, _lang, language_info
    assert [l["id"] for l in LANGUAGES] == ["en", "zh", "es", "auto"]
    # locale tags normalise onto the three translations
    assert _lang("zh-CN") == "zh" and _lang("zh_TW") == "zh"
    assert _lang("es-MX") == "es" and _lang("es") == "es"
    assert _lang("en-GB") == "en" and _lang("fr") == "en" and _lang("auto") == "auto"
    for lang in LANGUAGES:
        assert language_info(lang["id"])["id"] == lang["id"]


def test_agent_prompt_follows_language_setting():
    import os
    from nimbus import config as cfg
    from nimbus.agent import build_system_prompt

    original = cfg.settings.language
    try:
        agent = create_agent("LangBot", provider="mock", model="nimbus-offline")
        cfg.settings.language = "zh"
        prompt = build_system_prompt(agent)
        assert "## Language" in prompt and "Simplified Chinese" in prompt

        cfg.settings.language = "es"
        assert "Spanish" in build_system_prompt(agent)

        cfg.settings.language = "auto"
        assert "same language the user writes in" in build_system_prompt(agent)

        # per-agent override beats the global setting
        cfg.settings.language = "es"
        agent["language"] = "zh"
        assert "Simplified Chinese" in build_system_prompt(agent)
    finally:
        cfg.settings.language = original


def test_mock_model_localisation():
    from nimbus.llm import l10n, mock_lang
    import os
    from nimbus import config as cfg
    original = cfg.settings.language
    try:
        cfg.settings.language = "zh"
        assert mock_lang("hi") == "zh"
        assert "gdrive_search" in l10n("will_use", "hi", tool="gdrive_search")
        assert l10n("will_use", "hi", tool="x").startswith("我会用")

        cfg.settings.language = "es"
        assert l10n("will_use", "hi", tool="x").startswith("Usaré")

        cfg.settings.language = "en"
        assert l10n("offline_title").startswith("**Offline")

        # auto mode detects from the user's text
        cfg.settings.language = "auto"
        assert mock_lang("请帮我总结一下") == "zh"
        assert mock_lang("¿puedes resumir esto?") == "es"
        assert mock_lang("summarise this") == "en"
    finally:
        cfg.settings.language = original



def test_ui_simple_mode_structure():
    """The first-run UI stays minimal: 4 primary tabs, the rest behind More,
    simple mode on by default, and a friendly label for every tool."""
    import re
    web = ROOT / "nimbus" / "web"
    html = (web / "index.html").read_text(encoding="utf-8")
    js = (web / "app.js").read_text(encoding="utf-8")

    tabs_block = re.search(r'<div class="tabs" id="tabs">(.*?)<div class="tab-more">', html, re.S).group(1)
    primary = re.findall(r'<button data-tab="(\w+)"', tabs_block)
    behind_more = re.findall(r'<button data-tab="(\w+)"', re.search(r'id="moreMenu"(.*?)</div>', html, re.S).group(1))
    assert primary == ["chat", "files", "routines", "settings"], primary
    assert behind_more == ["skills", "memory", "activity", "audit"], behind_more
    assert 'id="btnDetails"' in html and 'id="btnMore"' in html

    # simple mode is the default; Details is opt-in and remembered
    assert "details: localStorage.getItem('nimbus.details') === '1'" in js
    # a tool run is summarised in plain language; raw names and timings only in Details
    comp = (web / "components.js").read_text(encoding="utf-8")
    assert "function stepLabel(" in comp and "NB.ToolStepper" in comp
    assert "details: state.details" in js and "friendlyTool(" not in js
    # onboarding checklist is dismissible and re-openable
    assert "localStorage.setItem('nimbus.onboarded', '1')" in js
    assert "onboardingSteps()" in js
    # routines + skills ship as one Automations tab with a segmented switch
    assert "function automationsSeg(" in js and "wireAutomationsSeg(" in js
    # narrow screens can still reach the sidebar
    assert "@media (max-width:1080px)" in (web / "styles.css").read_text(encoding="utf-8")


def test_stylesheet_design_system():
    """styles.css is a small design system: surface ladder, AA contrast, one motion pair."""
    import re
    css = (ROOT / "nimbus" / "web" / "styles.css").read_text(encoding="utf-8")

    # ---- tokens: the surface ladder, the hairline, the motion pair ----
    for token, value in (("--s0", "#080b11"), ("--s1", "#0f1420"), ("--s2", "#161d2e"), ("--s3", "#1e273e"),
                         ("--hair", "rgba(255, 255, 255, .06)"), ("--dim", "#94a3b8"),
                         ("--ease", "cubic-bezier(.16, 1, .3, 1)"), ("--t", "150ms")):
        assert f"{token}: {value}" in css, f"missing token {token}"

    # ---- WCAG AA: every text colour on every surface ----
    def lum(hexcol: str) -> float:
        h = hexcol.lstrip("#")
        parts = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        parts = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in parts]
        return 0.2126 * parts[0] + 0.7152 * parts[1] + 0.0722 * parts[2]

    def ratio(a: str, b: str) -> float:
        la, lb = lum(a), lum(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

    surfaces = ("#080b11", "#0f1420", "#161d2e", "#1e273e")
    text_colours = ("#e9eef8", "#cbd5e6", "#a7b3c6", "#94a3b8", "#8fa8ff", "#6ee7b7", "#fcd34d", "#fca5a5", "#c4b5fd")
    for fg in text_colours:
        for bg in surfaces:
            r = ratio(fg, bg)
            assert r >= 4.5, f"{fg} on {bg} is only {r:.2f}:1 (AA needs 4.5)"

    # the old washed-out greys must not come back
    for stale in ("#5f6a85", "#8d97b0", "var(--panel2)", "#0b0e14"):
        assert stale not in css, f"stale colour {stale}"

    # ---- every class the app renders is actually styled ----
    js = (ROOT / "nimbus" / "web" / "app.js").read_text(encoding="utf-8")
    html = (ROOT / "nimbus" / "web" / "index.html").read_text(encoding="utf-8")
    js += (ROOT / "nimbus" / "web" / "components.js").read_text(encoding="utf-8")
    js += (ROOT / "nimbus" / "web" / "composer.js").read_text(encoding="utf-8")
    used: set[str] = set()
    for raw in re.findall(r'class="([^"]*)"', js) + re.findall(r'class="([^"]*)"', html):
        for tok in re.sub(r"\$\{[^}]*\}", " ", raw).split():
            if re.fullmatch(r"[a-zA-Z][\w-]*", tok):
                used.add(tok)
    styled = set(re.findall(r"\.([a-zA-Z][\w-]*)", css))
    assert not (used - styled), f"unstyled classes: {sorted(used - styled)}"

    # ---- one shared motion vocabulary, and an escape hatch ----
    assert css.count("var(--t) var(--ease)") >= 25
    assert ":focus-visible" in css
    assert "@media (prefers-reduced-motion: reduce)" in css
    assert "font-variant-numeric: tabular-nums" in css


def test_i18n_dictionary_completeness():
    """Every key used by the UI must exist in all three languages, with matching placeholders."""
    import re
    web = ROOT / "nimbus" / "web"
    js = (web / "app.js").read_text(encoding="utf-8") + (web / "components.js").read_text(encoding="utf-8") \
        + (web / "composer.js").read_text(encoding="utf-8")
    html = (web / "index.html").read_text(encoding="utf-8")
    i18n_src = (web / "i18n.js").read_text(encoding="utf-8")

    def table(lang: str) -> dict:
        m = re.search(rf"\n  {lang}: \{{(.*?)\n  \}},", i18n_src, re.S)
        body = m.group(1)
        out = {}
        for k, v in re.findall(r"'([^']+)':\s*'((?:[^'\\]|\\.)*)',", body):
            out[k] = v
        return out

    tables = {lang: table(lang) for lang in ("en", "zh", "es")}
    used = set(re.findall(r"\bT\('([^']+)'", js)) | set(re.findall(r"\bt\('([^']+)'", js))
    used |= set(re.findall(r'data-i18n(?:-title)?="([^"]+)"', html))
    for group in ("Web", "Workspace", "Google Workspace", "Browser", "Memory", "Skills",
                  "Routines", "Team", "MCP"):
        used.add(f"tool.group.{group}")

    for lang, tbl in tables.items():
        assert tbl, f"{lang} table parsed empty"
        missing = sorted(k for k in used if k not in tbl)
        assert not missing, f"{lang} is missing UI keys: {missing}"

    # placeholders must match across languages so nothing renders as {raw}
    for key in used:
        en_ph = set(re.findall(r"\{(\w+)\}", tables["en"].get(key, "")))
        for lang in ("zh", "es"):
            ph = set(re.findall(r"\{(\w+)\}", tables[lang].get(key, "")))
            assert ph == en_ph, f"{lang}.{key} placeholders {ph} != en {en_ph}"


def test_language_setting_api_and_persistence():
    from fastapi.testclient import TestClient
    from nimbus.server import app
    with TestClient(app) as c:
        info = c.get("/api/system").json()
        assert [l["id"] for l in info["languages"]] == ["en", "zh", "es", "auto"]

        for code in ("zh", "es", "auto", "en"):
            r = c.post("/api/settings", json={"language": code})
            assert r.status_code == 200 and r.json()["language"] == code

        assert c.post("/api/settings", json={"language": "klingon"}).status_code == 400
        # persisted for the next boot
        assert db.get_setting("language") in ("zh", "es", "auto", "en")
        assert c.get("/api/system").json()["language_info"]["native"] in (
            "English", "中文（简体）", "Español", "Auto · 自动 · Automático")


def test_agent_language_patch_roundtrip():
    from fastapi.testclient import TestClient
    from nimbus.server import app
    with TestClient(app) as c:
        a = c.post("/api/agents", json={"name": "LangPatch", "provider": "mock", "model": "nimbus-offline"}).json()
        assert a["language"] == "inherit"
        patched = c.patch(f"/api/agents/{a['id']}", json={"language": "zh"}).json()
        assert patched["language"] == "zh"
        assert c.get(f"/api/agents/{a['id']}").json()["language"] == "zh"
