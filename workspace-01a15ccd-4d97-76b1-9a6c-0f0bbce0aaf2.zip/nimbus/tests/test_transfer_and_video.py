"""
YouTube links + file-transfer limits.

Everything here is offline: the YouTube network calls are monkeypatched with
canned payloads (captions, player JSON), so the parsing logic is what gets
tested — plus a real localhost HTTP server for the download-size guard.
"""
from __future__ import annotations

import asyncio
import json
import os
import socket
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("NIMBUS_DATA_DIR", str(ROOT / "data_test"))
os.environ["GOOGLE_DEMO_MODE"] = "1"

from nimbus import youtube  # noqa: E402
from nimbus.config import settings  # noqa: E402
from nimbus.llm import MockModel  # noqa: E402
from nimbus.store import create_agent  # noqa: E402
from nimbus.tools import get_tool  # noqa: E402
from nimbus.tools.base import ToolContext  # noqa: E402

PLAYER = {
    "videoDetails": {"title": "Shipping agents", "author": "Nimbus Labs", "lengthSeconds": "754",
                     "shortDescription": "A talk about always-on agents.", "viewCount": "12345"},
    "captions": {"playerCaptionsTracklistRenderer": {"captionTracks": [
        {"baseUrl": "https://www.youtube.com/api/timedtext?v=abcdefghijk&lang=de", "languageCode": "de",
         "name": {"simpleText": "German"}},
        {"baseUrl": "https://www.youtube.com/api/timedtext?v=abcdefghijk&lang=en", "languageCode": "en",
         "name": {"simpleText": "English"}, "kind": "asr"},
        {"baseUrl": "https://www.youtube.com/api/timedtext?v=abcdefghijk&lang=en", "languageCode": "en",
         "name": {"simpleText": "English (manual)"}},
    ]}},
}

JSON3 = json.dumps({"events": [
    {"tStartMs": 0, "segs": [{"utf8": "Welcome to the talk."}]},
    {"tStartMs": 5000, "segs": [{"utf8": "Agents"}, {"utf8": " run"}, {"utf8": " overnight.\n"}]},
    {"tStartMs": 12000, "segs": [{"utf8": "Welcome to the talk."}]},
    {"tStartMs": 95000, "segs": [{"utf8": "Here is the closing thought."}]},
]})

XML = ('<?xml version="1.0" encoding="utf-8"?><transcript>'
       '<text start="0" dur="3000">Hello &amp; welcome</text>'
       '<text start="3" dur="2000">to the demo</text></transcript>')

SRV3 = ('<timedtext format="3"><body>'
        '<p t="0" d="3000"><s>First</s><s> part</s></p>'
        '<p t="3000" d="3000"><s>Second</s><s> part</s></p></body></timedtext>')

VTT = ("WEBVTT\nKind: captions\nLanguage: en\n\n"
       "00:00:00.000 --> 00:00:03.000\nHello there.\n\n"
       "00:00:03.000 --> 00:00:06.000\nHello there.\n\n"
       "<c.colorE5E5E5>General</c> Kenobi.\n")


# ------------------------------------------------------------------ url shapes
def test_video_id_from_every_url_shape():
    expected = "dQw4w9WgXcQ"
    for url in ("https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                "http://m.youtube.com/watch?v=dQw4w9WgXcQ&t=42s",
                "https://youtu.be/dQw4w9WgXcQ?si=abc",
                "youtu.be/dQw4w9WgXcQ",
                "https://www.youtube.com/shorts/dQw4w9WgXcQ",
                "https://www.youtube.com/embed/dQw4w9WgXcQ",
                "https://www.youtube.com/live/dQw4w9WgXcQ",
                "https://music.youtube.com/watch?v=dQw4w9WgXcQ",
                "https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ",
                "dQw4w9WgXcQ"):
        assert youtube.extract_video_id(url) == expected, url
    for bad in ("https://example.com/watch?v=dQw4w9WgXcQ", "https://vimeo.com/12345",
                "https://www.youtube.com/watch?v=tooshort", "", "not a link"):
        assert youtube.extract_video_id(bad) == "", bad
    assert youtube.is_youtube_url("https://youtu.be/dQw4w9WgXcQ")
    assert not youtube.is_youtube_url("https://example.com")


# ------------------------------------------------------------------- payloads
def test_caption_payloads_become_plain_text():
    assert youtube.json3_to_text(JSON3).startswith("Welcome to the talk. Agents run overnight.")
    assert youtube.parse_caption_payload(JSON3) == youtube.json3_to_text(JSON3)
    assert youtube.parse_caption_payload(XML) == "Hello & welcome to the demo"
    assert youtube.parse_caption_payload(SRV3) == "First part Second part"
    vtt = youtube.parse_caption_payload(VTT)
    assert vtt.startswith("Hello there.") and "General Kenobi." in vtt
    assert youtube.parse_caption_payload("") == ""
    assert youtube.parse_caption_payload("plain text already") == "plain text already"


def test_clean_transcript_drops_rolling_duplicates():
    raw = "So the plan is this. So the plan is this. Then we ship it."
    assert youtube.clean_transcript(raw) == "So the plan is this. Then we ship it."
    assert youtube.clean_transcript("") == ""


def test_timestamps_and_slicing():
    timed = youtube.with_timestamps(JSON3)
    assert timed.splitlines()[0].startswith("[00:00] Welcome to the talk.")
    assert any(line.startswith("[01:35]") for line in timed.splitlines())
    part = youtube.slice_timed(timed, youtube.parse_time("1:00"), youtube.parse_time("2:00"))
    assert "closing thought" in part and "Welcome to the talk" not in part
    assert youtube.parse_time("1:02:30") == 3750
    assert youtube.parse_time("5:00") == 300
    assert youtube.parse_time(90) == 90
    assert youtube.parse_time("") == 0


def test_track_choice_prefers_language_then_human_captions():
    tracks = youtube.caption_tracks(PLAYER)
    assert [t["lang"] for t in tracks] == ["de", "en", "en"]
    assert youtube.pick_track(tracks, "en")["auto"] is False      # manual English wins
    assert youtube.pick_track(tracks, "de")["lang"] == "de"
    assert youtube.pick_track(tracks, "ja")["lang"] == "en"       # closest fallback
    assert youtube.pick_track([], "en") is None


def test_player_response_parsing_survives_json_in_html():
    page = f'<html><script>var ytInitialPlayerResponse = {json.dumps(PLAYER)};</script></html>'
    player = youtube.parse_player_response(page)
    assert player["videoDetails"]["title"] == "Shipping agents"
    details = youtube.video_details(player)
    assert details["channel"] == "Nimbus Labs"
    assert details["duration_seconds"] == 754
    assert youtube.fmt_duration(754) == "12:34"
    assert youtube.fmt_duration(3750) == "1:02:30"
    assert youtube.parse_player_response("<html>nothing here</html>") == {}


# --------------------------------------------------------------- the pipeline
def test_fetch_video_uses_the_watch_page_then_captions(monkeypatch):
    async def fake_watch(client, video_id, accept_language="en"):
        return {"page": "", "player": PLAYER, "details": youtube.video_details(PLAYER),
                "tracks": youtube.caption_tracks(PLAYER)}

    used = {}

    async def fake_caption(client, track):
        used["lang"] = track["lang"]
        used["auto"] = track["auto"]
        return youtube.json3_to_text(JSON3)

    monkeypatch.setattr(youtube, "_watch_page", fake_watch)
    monkeypatch.setattr(youtube, "_download_caption", fake_caption)
    data = asyncio.run(youtube.fetch_video("https://youtu.be/abcdefghijk", lang="en", max_chars=5000))
    assert data["ok"] and data["source"] == "captions"
    assert data["video_id"] == "abcdefghijk"
    assert data["title"] == "Shipping agents" and data["channel"] == "Nimbus Labs"
    assert data["duration"] == "12:34" and data["caption_languages"] == ["de", "en", "en"]
    assert "Welcome to the talk" in data["transcript"]
    assert data["range"] == "full video"
    assert used == {"lang": "en", "auto": False}          # manual track preferred


def test_fetch_video_falls_back_then_reports_missing_captions(monkeypatch):
    async def fake_watch(client, video_id, accept_language="en"):
        return {"page": "", "player": PLAYER, "details": youtube.video_details(PLAYER),
                "tracks": youtube.caption_tracks(PLAYER)}

    async def no_captions(client, track):
        return ""

    async def no_yt_dlp(video_id, lang="", timeout=150):
        return "", "", ""

    monkeypatch.setattr(youtube, "_watch_page", fake_watch)
    monkeypatch.setattr(youtube, "_download_caption", no_captions)
    monkeypatch.setattr(youtube, "_yt_dlp_subtitles", no_yt_dlp)
    data = asyncio.run(youtube.fetch_video("abcdefghijk"))
    assert data["ok"] is False
    assert "no captions" in data["error"] and data["title"] == "Shipping agents"

    # a link that isn't YouTube never touches the network
    bad = asyncio.run(youtube.fetch_video("https://vimeo.com/12345"))
    assert bad["ok"] is False and "doesn't look like a YouTube link" in bad["error"]


def test_yt_dlp_path_is_used_and_respects_slices(monkeypatch):
    async def fake_watch(client, video_id, accept_language="en"):
        return {"page": "", "player": PLAYER, "details": youtube.video_details(PLAYER),
                "tracks": youtube.caption_tracks(PLAYER)}

    async def no_captions(client, track):
        return ""

    async def from_yt_dlp(video_id, lang="", timeout=150):
        return youtube.json3_to_text(JSON3), "en", JSON3

    monkeypatch.setattr(youtube, "_watch_page", fake_watch)
    monkeypatch.setattr(youtube, "_download_caption", no_captions)
    monkeypatch.setattr(youtube, "_yt_dlp_subtitles", from_yt_dlp)
    data = asyncio.run(youtube.fetch_video("abcdefghijk", start="1:00", end="2:00"))
    assert data["ok"] and data["source"] == "yt-dlp"
    assert data["range"] == "1:00–2:00" and "closing thought" in data["transcript"]


# ------------------------------------------------------------------ the tools
def test_youtube_tool_and_fetch_url_share_one_path(monkeypatch):
    tool = get_tool("youtube_transcript")
    assert tool and tool.group == "Web" and tool.name in {t["name"] for t in __import__("nimbus.tools", fromlist=["schemas"]).schemas()}

    async def fake_fetch(url_or_id, **kw):
        return {"ok": True, "video_id": youtube.extract_video_id(url_or_id), "title": "Shipping agents",
                "channel": "Nimbus Labs", "duration": "12:34", "transcript": "Welcome to the talk.",
                "chars": 20, "words": 4, "language": "en", "source": "captions"}

    monkeypatch.setattr(youtube, "fetch_video", fake_fetch)
    ctx = ToolContext(agent={"id": "a1"})
    out = asyncio.run(tool.run({"url": "https://youtu.be/abcdefghijk"}, ctx))
    assert out.ok and json.loads(out.to_model())["title"] == "Shipping agents"

    # fetch_url must not return YouTube's HTML shell — it reads the captions instead
    fetched = asyncio.run(get_tool("fetch_url").run({"url": "https://www.youtube.com/watch?v=abcdefghijk"}, ctx))
    assert fetched.ok and "transcript" in json.loads(fetched.to_model())


def test_mock_model_routes_video_links_to_the_transcript_tool():
    model = MockModel()
    tools = [{"name": "youtube_transcript", "description": "", "parameters": {}},
             {"name": "fetch_url", "description": "", "parameters": {}}]

    async def run(text):
        calls, said = [], ""
        async for ev in model.stream([{"role": "user", "content": text}], tools):
            if ev["type"] == "tool_calls":
                calls += ev["calls"]
            elif ev["type"] == "text":
                said += ev["text"]
        return calls, said

    calls, _ = asyncio.run(run("summarise this video for me: https://youtu.be/dQw4w9WgXcQ"))
    assert calls and calls[0]["name"] == "youtube_transcript"
    assert calls[0]["arguments"]["url"] == "https://youtu.be/dQw4w9WgXcQ"

    calls2, _ = asyncio.run(run("give me a talk about agents"))
    assert not calls2 or calls2[0]["name"] != "youtube_transcript"

    # and the offline reply describes a transcript instead of dumping JSON
    summary = model._summarize({"name": "youtube_transcript", "content": json.dumps({
        "title": "Shipping agents", "channel": "Nimbus Labs", "duration": "12:34",
        "transcript": "Welcome to the talk. Agents run overnight."})}, "summarise this video")
    assert "Shipping agents" in summary and "Agents run overnight." in summary


def test_caption_language_follows_the_agent_setting(monkeypatch):
    from nimbus import config
    from nimbus.tools.web import preferred_caption_lang

    ctx = ToolContext(agent={"id": "a1"})
    monkeypatch.setattr(config, "current_language", lambda: "zh")
    assert preferred_caption_lang(ctx) == "zh"
    assert preferred_caption_lang(ToolContext(agent={"id": "a1", "language": "es"})) == "es"
    assert preferred_caption_lang(ToolContext(agent={"id": "a1", "language": "inherit"})) == "zh"
    monkeypatch.setattr(config, "current_language", lambda: "auto")
    assert preferred_caption_lang(ctx) == ""          # auto → let the video decide


def test_yt_dlp_command_falls_back_to_the_module(monkeypatch):
    from nimbus import youtube as yt
    monkeypatch.setattr(yt.shutil, "which", lambda name: "")
    cmd = yt.yt_dlp_command()
    assert cmd and cmd[-2:] == ["-m", "yt_dlp"], cmd       # yt-dlp is installed here
    monkeypatch.setattr(yt.shutil, "which", lambda name: "/usr/bin/yt-dlp")
    assert yt.yt_dlp_command() == ["/usr/bin/yt-dlp"]      # the script wins when present


# ------------------------------------------------------------ transfer limits
def test_transfer_limits_are_configurable_and_above_25mb():
    assert settings.max_upload_mb >= 25, "the upload ceiling must never be the blocker"
    assert settings.max_download_mb >= 25
    assert settings.max_preview_mb >= 1
    assert settings.gmail_attachment_mb == 25          # Google's own hard limit
    assert settings.drive_resumable_mb >= 1

    from fastapi.testclient import TestClient
    from nimbus.server import app
    with TestClient(app) as c:
        limits = c.get("/api/system").json()["limits"]
    for key in ("upload_mb", "download_mb", "preview_mb", "gmail_attachment_mb"):
        assert limits[key] >= 25 if key != "preview_mb" else limits[key] >= 1


def test_upload_streams_and_enforces_the_limit(monkeypatch):
    from fastapi.testclient import TestClient
    from nimbus import server as server_mod

    agent = create_agent("UploadTest", provider="mock", model="nimbus-offline")
    monkeypatch.setattr(server_mod.settings, "max_upload_mb", 1, raising=False)
    blob = b"x" * (2 * 1024 * 1024)                    # 2 MB against a 1 MB ceiling
    with TestClient(server_mod.app) as c:
        r = c.post(f"/api/agents/{agent['id']}/upload",
                   files={"file": ("big.bin", blob, "application/octet-stream")},
                   data={"path": "big.bin"})
        assert r.status_code == 413
        assert "upload limit" in r.json()["detail"]
        assert not (Path(agent["workspace"]) / "big.bin").exists()
        assert not list(Path(agent["workspace"]).glob("*.part"))

        small = b"y" * 4096
        ok = c.post(f"/api/agents/{agent['id']}/upload",
                    files={"file": ("small.txt", small, "text/plain")}, data={"path": "small.txt"})
        assert ok.status_code == 200 and ok.json()["bytes"] == 4096
        assert (Path(agent["workspace"]) / "small.txt").read_bytes() == small

        # the in-app viewer accepts bigger files than it used to
        big_text = b"z" * (2 * 1024 * 1024)
        (Path(agent["workspace"]) / "wide.txt").write_bytes(big_text)
        view = c.get(f"/api/agents/{agent['id']}/file-text", params={"path": "wide.txt"})
        assert view.status_code == 200 and view.json()["bytes"] == len(big_text)


def test_download_file_refuses_over_the_limit(monkeypatch):
    """A real localhost server: the tool must stop, delete the partial file and say why."""
    from nimbus.tools.workspace import DownloadFileTool

    payload = b"d" * (3 * 1024 * 1024)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def log_message(self, *a):  # silence
            return

    srv = HTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    monkeypatch.setattr(settings, "max_download_mb", 1, raising=False)
    agent = create_agent("DownloadTest", provider="mock", model="nimbus-offline")
    ctx = ToolContext(agent=agent, workspace=Path(agent["workspace"]))
    try:
        res = asyncio.run(DownloadFileTool().run({"url": f"http://127.0.0.1:{port}/big.bin",
                                                  "path": "big.bin"}, ctx))
        assert res.ok is False and "download limit" in res.error
        assert not (Path(agent["workspace"]) / "big.bin").exists()
    finally:
        srv.shutdown()


def test_gmail_attachment_ceiling_is_google_side():
    import nimbus.google_api as g
    assert "gmail_attachment_mb" in settings.__dict__
    agent = create_agent("MailTest", provider="mock", model="nimbus-offline")
    ws = Path(agent["workspace"])
    huge = ws / "huge.bin"
    huge.write_bytes(b"0" * (settings.gmail_attachment_mb * 1024 * 1024 + 1024))
    with pytest.raises(g.GoogleError) as err:
        asyncio.run(g.gmail_send("a@b.c", "s", "b", attachments=[huge]))
    assert "Drive" in str(err.value)
