"""
Security tests for Nimbus authentication and CORS.

These tests verify:
1. Unauthenticated requests to /api/* return 401
2. Valid token allows access
3. Invalid token returns 401
4. Health check and static UI don't require auth
5. CORS/Origin checks work correctly
6. Token generation and storage is secure
7. Host binding defaults to loopback
"""
import os
import sys
import tempfile
from pathlib import Path

import pytest


@pytest.fixture(scope="session")
def init_server():
    """Initialize server module once for all tests."""
    # Import server module to trigger initialization
    from nimbus import server
    return server


@pytest.fixture
def test_client(init_server):
    """Create a test client with auth token."""
    from fastapi.testclient import TestClient
    from nimbus import server
    
    client = TestClient(server.app)
    return client, server.AUTH_TOKEN


class TestAuthentication:
    """Test bearer token authentication."""

    def test_unauthenticated_api_request_returns_401(self, test_client):
        """Unauthenticated requests to /api/* should return 401."""
        client, token = test_client
        
        # Try to access system info without auth
        response = client.get("/api/system")
        assert response.status_code == 401
        assert "Missing" in response.json()["detail"] or "Invalid" in response.json()["detail"]

    def test_unauthenticated_agents_request_returns_401(self, test_client):
        """Unauthenticated requests to /api/agents should return 401."""
        client, token = test_client
        
        response = client.get("/api/agents")
        assert response.status_code == 401

    def test_valid_token_allows_access(self, test_client):
        """Valid token should allow access to API endpoints."""
        client, token = test_client
        
        # Access system info with valid token
        response = client.get("/api/system", headers={"Authorization": f"Bearer {token}"})
        assert response.status_code == 200
        assert "version" in response.json()

    def test_invalid_token_returns_401(self, test_client):
        """Invalid token should return 401."""
        client, token = test_client
        
        response = client.get(
            "/api/system",
            headers={"Authorization": "Bearer invalid_token"}
        )
        assert response.status_code == 401
        assert "Invalid" in response.json()["detail"]

    def test_missing_token_returns_401(self, test_client):
        """Missing token should return 401."""
        client, token = test_client
        
        response = client.get("/api/agents")
        assert response.status_code == 401

    def test_health_endpoint_no_auth_required(self, test_client):
        """Health check endpoint should not require authentication."""
        client, token = test_client
        
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["ok"] is True

    def test_static_ui_no_auth_required(self, test_client):
        """Static UI endpoints should not require authentication."""
        client, token = test_client
        
        response = client.get("/")
        assert response.status_code == 200
        assert "Nimbus" in response.text

    def test_demo_page_no_auth_required(self, test_client):
        """Demo page should not require authentication."""
        client, token = test_client
        
        response = client.get("/demo")
        assert response.status_code == 200

    def test_layout_page_no_auth_required(self, test_client):
        """Layout page should not require authentication."""
        client, token = test_client
        
        response = client.get("/layout")
        assert response.status_code == 200


class TestCORS:
    """Test CORS and origin validation."""

    def test_cors_preflight_without_origin(self, test_client):
        """CORS preflight without origin should work."""
        client, token = test_client
        
        # OPTIONS request without origin
        response = client.options("/api/system")
        # Should either return 200/401 (not 403 for CORS preflight)
        assert response.status_code in (200, 401)

    def test_state_changing_without_origin_allowed_when_no_allowlist(self, test_client):
        """When no allowed origins configured, state-changing requests should work."""
        client, token = test_client
        
        # POST without origin header - should work when no allowlist
        response = client.post(
            "/api/demo/team",
            headers={"Authorization": f"Bearer {token}"},
            json={}
        )
        # Should either succeed or fail with non-403 error
        assert response.status_code != 403


class TestTokenGeneration:
    """Test token generation and storage."""

    def test_token_file_permissions(self):
        """Auth token file should have 0600 permissions."""
        from nimbus.config import settings
        
        if settings.auth_token_path.exists():
            import stat
            
            file_stat = os.stat(settings.auth_token_path)
            mode = file_stat.st_mode
            
            # Check that only owner can read/write
            assert mode & stat.S_IRUSR  # Owner read
            assert mode & stat.S_IWUSR  # Owner write
            assert not (mode & stat.S_IRGRP)  # Group cannot read
            assert not (mode & stat.S_IWGRP)  # Group cannot write
            assert not (mode & stat.S_IROTH)  # Others cannot read
            assert not (mode & stat.S_IWOTH)  # Others cannot write

    def test_token_is_strong(self):
        """Generated token should be strong (at least 32 characters)."""
        from nimbus.config import generate_auth_token
        
        token = generate_auth_token()
        assert len(token) >= 32
        # Should contain alphanumeric and special characters
        assert any(c.isalnum() for c in token)


class TestHostBinding:
    """Test host binding restrictions."""

    def test_default_host_is_loopback(self):
        """Default host should be 127.0.0.1 when NIMBUS_HOST is not set."""
        # This test checks the default in config.py
        from nimbus.config import Settings
        
        # Create a new settings instance without NIMBUS_HOST
        original_env = os.environ.get("NIMBUS_HOST")
        if "NIMBUS_HOST" in os.environ:
            del os.environ["NIMBUS_HOST"]
        
        try:
            test_settings = Settings()
            assert test_settings.host == "127.0.0.1"
        finally:
            if original_env:
                os.environ["NIMBUS_HOST"] = original_env