"""
Validates the OpenAI-compatible streaming path (SSE parsing, tool-call
accumulation, multi-turn tool loop) against a real local HTTP endpoint.
This is the same code path used for xAI, OpenAI, OpenRouter, Groq, DeepSeek,
Ollama and any custom endpoint.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path

import pytest
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("NIMBUS_DATA_DIR", str(ROOT / "data_test"))
os.environ["GOOGLE_DEMO_MODE"] = "1"

PORT = 8899
BASE = f"http://127.0.0.1:{PORT}/v1"

fake = FastAPI()
calls: list[dict] = []


@fake.post("/v1/chat/completions")
async def completions(request: Request):
    body = await request.json()
    calls.append(body)
    has_tool_result = any(m.get("role") == "tool" for m in body.get("messages", []))

    def sse(payload: dict) -> str:
        return f"data: {json.dumps(payload)}\n\n"

    async def gen():
        if not has_tool_result:
            yield sse({"choices": [{"delta": {"content": "Let me check "}}]})
            yield sse({"choices": [{"delta": {"content": "the workspace."}}]})
            # tool call delivered in fragments, like real providers do
            yield sse({"choices": [{"delta": {"tool_calls": [
                {"index": 0, "id": "call_abc", "function": {"name": "write_file", "arguments": '{"path": "fake'}}]}}]})
            yield sse({"choices": [{"delta": {"tool_calls": [
                {"index": 0, "function": {"arguments": '.txt", "content": "written by the fake provider"}'}}]}}]})
            yield sse({"choices": [{"delta": {}, "finish_reason": "tool_calls"}]})
        else:
            for word in ["The file ", "`fake.txt` ", "was created."]:
                yield sse({"choices": [{"delta": {"content": word}}]})
            yield sse({"choices": [{"delta": {}, "finish_reason": "stop"}], "usage": {"total_tokens": 42}})
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream")


@pytest.fixture(scope="module", autouse=True)
def server():
    config = uvicorn.Config(fake, host="127.0.0.1", port=PORT, log_level="error")
    srv = uvicorn.Server(config)
    t = threading.Thread(target=srv.run, daemon=True)
    t.start()
    for _ in range(100):
        time.sleep(0.05)
        if srv.started:
            break
    os.environ["CUSTOM_BASE_URL"] = BASE
    from nimbus import config as cfg
    cfg.settings.runtime["CUSTOM_BASE_URL"] = BASE
    cfg.PROVIDERS["custom"]["base_url"] = BASE
    yield srv
    srv.should_exit = True


@pytest.mark.asyncio
async def test_streaming_provider_full_loop():
    from nimbus.agent import Runner
    from nimbus.store import create_agent, create_thread, list_messages

    calls.clear()
    agent = create_agent("Streamer", provider="custom", model="fake-model", temperature=0.0)
    thread = create_thread(agent["id"], "stream test")
    events = []

    async def sink(ev):
        events.append(ev)

    answer = await Runner(agent, thread["id"], sink=sink).send("write the fake file")
    assert "fake.txt" in answer, answer

    # the fake provider saw two calls: one with tools, one with the tool result
    assert len(calls) == 2
    assert calls[0]["tools"] and calls[0]["stream"] is True
    assert any(m.get("role") == "tool" for m in calls[1]["messages"])
    tool_msg = next(m for m in calls[1]["messages"] if m.get("role") == "tool")
    assert "fake.txt" in tool_msg["content"]  # tool result fed back to the model
    # the fragmented tool-call arguments were reassembled correctly
    assistant = next(m for m in calls[1]["messages"] if m.get("role") == "assistant" and m.get("tool_calls"))
    args = json.loads(assistant["tool_calls"][0]["function"]["arguments"])
    assert args == {"path": "fake.txt", "content": "written by the fake provider"}

    # persisted + executed for real in the agent workspace
    assert (Path(agent["workspace"]) / "fake.txt").read_text() == "written by the fake provider"
    roles = [m["role"] for m in list_messages(thread["id"])]
    assert roles == ["user", "assistant", "tool", "assistant"]
    deltas = "".join(e["text"] for e in events if e["type"] == "delta")
    assert "Let me check" in deltas


@pytest.mark.asyncio
async def test_anthropic_shape_conversion():
    """The Anthropic adapter must produce valid message/tool blocks."""
    from nimbus.llm import _as_anthropic, _anthropic_tools
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "calling", "tool_calls": [
            {"id": "t1", "name": "write_file", "arguments": {"path": "a.txt", "content": "x"}}]},
        {"role": "tool", "tool_call_id": "t1", "name": "write_file", "content": '{"ok":true}'},
        {"role": "user", "content": "thanks"},
    ]
    system, out = _as_anthropic(msgs)
    assert system == "sys"
    assert out[0]["role"] == "user"
    assistant = out[1]
    assert assistant["role"] == "assistant"
    assert assistant["content"][1]["type"] == "tool_use"
    assert assistant["content"][1]["input"] == {"path": "a.txt", "content": "x"}
    tool_result_msg = out[2]
    assert tool_result_msg["role"] == "user"
    assert tool_result_msg["content"][0]["type"] == "tool_result"
    assert tool_result_msg["content"][0]["tool_use_id"] == "t1"
    tools = _anthropic_tools([{"name": "x", "description": "d", "parameters": {"type": "object", "properties": {}}}])
    assert tools[0]["input_schema"]["type"] == "object"


@pytest.mark.asyncio
async def test_error_surfacing():
    """A dead endpoint must produce a friendly error, not a crash."""
    from nimbus.llm import stream_chat
    from nimbus import config as cfg
    cfg.PROVIDERS["custom"]["base_url"] = "http://127.0.0.1:9"
    cfg.settings.runtime["CUSTOM_BASE_URL"] = "http://127.0.0.1:9"
    with pytest.raises(Exception) as exc:
        async for _ in stream_chat("custom", "m", [{"role": "user", "content": "x"}], []):
            pass
    assert "connection failed" in str(exc.value).lower() or "connect" in str(exc.value).lower()
    cfg.PROVIDERS["custom"]["base_url"] = BASE
    cfg.settings.runtime["CUSTOM_BASE_URL"] = BASE
