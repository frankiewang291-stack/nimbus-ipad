"""
Nimbus Multi-Channel Publishing Feature

This feature allows Nimbus agents to be published and accessed through multiple channels:
- Discord
- Telegram
- Slack
- WhatsApp
- Email
- Web widgets
- APIs

Similar to Coze's multi-channel deployment capabilities.

Features:
- Publish agents to external platforms
- Two-way communication (receive messages, send responses)
- Channel-specific configurations
- Webhook support
- Authentication management

Usage:
1. Configure a publishing channel
2. Deploy an agent to that channel
3. Users interact with the agent through their preferred platform
4. Agent responses are sent back through the same channel

Dependencies:
- Channel-specific SDKs (Discord.py, python-telegram-bot, etc.)
- Webhook handling
- Authentication management
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable, Awaitable, Union
from dataclasses import dataclass, field
from pathlib import Path
from enum import Enum

logger = logging.getLogger(__name__)


class ChannelType(Enum):
    """Supported channel types."""
    DISCORD = "discord"
    TELEGRAM = "telegram"
    SLACK = "slack"
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    WEB = "web"
    API = "api"
    TWITTER = "twitter"
    MESSENGER = "messenger"
    LINE = "line"


@dataclass
class ChannelConfig:
    """Configuration for a publishing channel."""
    id: str
    name: str
    channel_type: ChannelType
    agent_id: str
    credentials: Dict[str, Any]
    settings: Dict[str, Any] = field(default_factory=dict)
    webhook_url: Optional[str] = None
    enabled: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "channel_type": self.channel_type.value,
            "agent_id": self.agent_id,
            "credentials": self.credentials,
            "settings": self.settings,
            "webhook_url": self.webhook_url,
            "enabled": self.enabled,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChannelConfig":
        return cls(
            id=data["id"],
            name=data["name"],
            channel_type=ChannelType(data["channel_type"]),
            agent_id=data["agent_id"],
            credentials=data.get("credentials", {}),
            settings=data.get("settings", {}),
            webhook_url=data.get("webhook_url"),
            enabled=data.get("enabled", True),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )


@dataclass
class PublishedMessage:
    """Represents a message published to a channel."""
    id: str
    channel_id: str
    message_id: str  # Channel-specific message ID
    content: str
    sender: str  # User or agent
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "channel_id": self.channel_id,
            "message_id": self.message_id,
            "content": self.content,
            "sender": self.sender,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata
        }


class MultiChannelPublishing:
    """
    Multi-channel publishing feature for Nimbus.
    
    Allows agents to be published to various messaging platforms and channels.
    """
    
    def __init__(self, agent_manager, storage_path: str = "data/published_agents"):
        """
        Initialize the multi-channel publishing feature.
        
        Args:
            agent_manager: Nimbus agent manager
            storage_path: Path to store publishing configurations
        """
        self.agent_manager = agent_manager
        self.storage_path = Path(storage_path)
        
        # Channel handlers
        self._channel_handlers: Dict[ChannelType, Any] = {}
        
        # Published channels
        self._published_channels: Dict[str, ChannelConfig] = {}
        
        # Message queues
        self._message_queues: Dict[str, asyncio.Queue] = {}
        
        # Ensure storage directory exists
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.name = "multi_channel_publishing"
        self.display_name = "Multi-Channel Publishing"
        self.description = "Publish agents to Discord, Telegram, Slack, and more"
        self.icon = "🌐"
        
    async def initialize(self) -> bool:
        """Initialize the multi-channel publishing feature."""
        try:
            # Load published channels from storage
            await self._load_published_channels()
            
            # Initialize channel handlers
            await self._initialize_channel_handlers()
            
            # Start message processors for each channel
            await self._start_message_processors()
            
            logger.info("Multi-channel publishing feature initialized")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize multi-channel publishing: {e}")
            return False
    
    async def shutdown(self) -> None:
        """Shutdown the multi-channel publishing feature."""
        # Stop all message processors
        for channel_id, queue in self._message_queues.items():
            # Put a poison pill to stop the processor
            await queue.put(None)
        
        self._message_queues.clear()
        
        # Save published channels
        await self._save_published_channels()
        
        logger.info("Multi-channel publishing feature shutdown")
    
    async def _load_published_channels(self) -> None:
        """Load published channels from storage."""
        # In a real implementation, load from database
        # For now, just initialize empty
        self._published_channels = {}
    
    async def _save_published_channels(self) -> None:
        """Save published channels to storage."""
        # In a real implementation, save to database
        pass
    
    async def _initialize_channel_handlers(self) -> None:
        """Initialize handlers for each channel type."""
        # Discord handler
        try:
            from .discord_handler import DiscordHandler
            self._channel_handlers[ChannelType.DISCORD] = DiscordHandler(self)
            logger.info("Discord handler initialized")
        except ImportError as e:
            logger.warning(f"Discord handler not available: {e}")
        
        # Telegram handler
        try:
            from .telegram_handler import TelegramHandler
            self._channel_handlers[ChannelType.TELEGRAM] = TelegramHandler(self)
            logger.info("Telegram handler initialized")
        except ImportError as e:
            logger.warning(f"Telegram handler not available: {e}")
        
        # Slack handler (use existing connector)
        try:
            from connectors.slack import slack_connector
            self._channel_handlers[ChannelType.SLACK] = slack_connector
            logger.info("Slack handler initialized")
        except Exception as e:
            logger.warning(f"Slack handler not available: {e}")
        
        # Other handlers would be added similarly
    
    async def _start_message_processors(self) -> None:
        """Start message processors for each published channel."""
        for channel_id, config in self._published_channels.items():
            if config.enabled:
                await self._start_channel_processor(channel_id, config)
    
    async def _start_channel_processor(self, channel_id: str, config: ChannelConfig) -> None:
        """Start a message processor for a specific channel."""
        queue = asyncio.Queue()
        self._message_queues[channel_id] = queue
        
        # Start the processor task
        handler = self._channel_handlers.get(config.channel_type)
        if handler:
            asyncio.create_task(
                self._process_channel_messages(channel_id, config, queue, handler)
            )
    
    async def _process_channel_messages(self, channel_id: str, config: ChannelConfig,
                                        queue: asyncio.Queue, handler: Any) -> None:
        """Process messages from a channel's queue."""
        while True:
            message = await queue.get()
            
            # Poison pill to stop
            if message is None:
                break
            
            try:
                # Process the message through the handler
                await handler.process_message(config, message)
            except Exception as e:
                logger.error(f"Error processing message for channel {channel_id}: {e}")
    
    async def publish_agent(self, agent_id: str, channel_type: str, 
                           config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Publish an agent to a channel.
        
        Args:
            agent_id: ID of the agent to publish
            channel_type: Type of channel (discord, telegram, slack, etc.)
            config: Channel-specific configuration
            
        Returns:
            Publishing configuration
        """
        # Validate agent exists
        agent = await self.agent_manager.get_agent(agent_id)
        if not agent:
            return {"error": f"Agent {agent_id} not found"}
        
        # Validate channel type
        try:
            channel_type_enum = ChannelType(channel_type)
        except ValueError:
            return {"error": f"Invalid channel type: {channel_type}"}
        
        # Check if handler exists
        if channel_type_enum not in self._channel_handlers:
            return {"error": f"Channel type {channel_type} not supported"}
        
        # Create channel configuration
        channel_config = ChannelConfig(
            id=str(uuid.uuid4()),
            name=config.get("name", f"{agent['name']} on {channel_type}"),
            channel_type=channel_type_enum,
            agent_id=agent_id,
            credentials=config.get("credentials", {}),
            settings=config.get("settings", {}),
            webhook_url=config.get("webhook_url")
        )
        
        # Store the configuration
        self._published_channels[channel_config.id] = channel_config
        
        # Start the message processor
        await self._start_channel_processor(channel_config.id, channel_config)
        
        # Initialize the channel (e.g., start webhook server, connect to API)
        handler = self._channel_handlers[channel_type_enum]
        await handler.initialize_channel(channel_config)
        
        logger.info(f"Agent {agent_id} published to {channel_type} channel {channel_config.id}")
        
        return {
            "channel_id": channel_config.id,
            "agent_id": agent_id,
            "channel_type": channel_type,
            "status": "published",
            "webhook_url": channel_config.webhook_url
        }
    
    async def unpublish_agent(self, channel_id: str) -> Dict[str, Any]:
        """
        Unpublish an agent from a channel.
        
        Args:
            channel_id: ID of the publishing channel
            
        Returns:
            Result of unpublishing
        """
        if channel_id not in self._published_channels:
            return {"error": f"Channel {channel_id} not found"}
        
        config = self._published_channels[channel_id]
        
        # Stop the message processor
        if channel_id in self._message_queues:
            await self._message_queues[channel_id].put(None)
            del self._message_queues[channel_id]
        
        # Clean up with the handler
        handler = self._channel_handlers.get(config.channel_type)
        if handler:
            await handler.cleanup_channel(config)
        
        # Remove from published channels
        del self._published_channels[channel_id]
        
        logger.info(f"Channel {channel_id} unpublished")
        
        return {"status": "unpublished", "channel_id": channel_id}
    
    async def list_published_channels(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all published channels.
        
        Args:
            agent_id: Optional filter by agent ID
            
        Returns:
            List of published channels
        """
        channels = []
        
        for channel_id, config in self._published_channels.items():
            if agent_id is None or config.agent_id == agent_id:
                channels.append({
                    "id": config.id,
                    "name": config.name,
                    "channel_type": config.channel_type.value,
                    "agent_id": config.agent_id,
                    "enabled": config.enabled,
                    "created_at": config.created_at.isoformat()
                })
        
        return channels
    
    async def get_channel_info(self, channel_id: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a published channel.
        
        Args:
            channel_id: ID of the channel
            
        Returns:
            Channel information, or None if not found
        """
        if channel_id not in self._published_channels:
            return None
        
        config = self._published_channels[channel_id]
        
        # Get message statistics
        handler = self._channel_handlers.get(config.channel_type)
        stats = {}
        if handler:
            stats = await handler.get_channel_stats(config)
        
        return {
            "id": config.id,
            "name": config.name,
            "channel_type": config.channel_type.value,
            "agent_id": config.agent_id,
            "enabled": config.enabled,
            "created_at": config.created_at.isoformat(),
            "updated_at": config.updated_at.isoformat(),
            "webhook_url": config.webhook_url,
            "stats": stats
        }
    
    async def send_message(self, channel_id: str, content: str, 
                           metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Send a message through a published channel.
        
        Args:
            channel_id: ID of the channel
            content: Message content
            metadata: Optional metadata
            
        Returns:
            Result of sending the message
        """
        if channel_id not in self._published_channels:
            return {"error": f"Channel {channel_id} not found"}
        
        config = self._published_channels[channel_id]
        
        # Create a message object
        message = {
            "id": str(uuid.uuid4()),
            "channel_id": channel_id,
            "content": content,
            "sender": "agent",
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        # Get the handler and send the message
        handler = self._channel_handlers.get(config.channel_type)
        if handler:
            result = await handler.send_message(config, message)
            return result
        
        return {"error": "No handler for channel type"}
    
    async def receive_message(self, channel_id: str, message: Dict[str, Any]) -> Dict[str, Any]:
        """
        Receive a message from a channel and queue it for processing.
        
        Args:
            channel_id: ID of the channel
            message: The received message
            
        Returns:
            Result of receiving the message
        """
        if channel_id not in self._message_queues:
            return {"error": f"Channel {channel_id} not found or not enabled"}
        
        # Add to queue for processing
        await self._message_queues[channel_id].put(message)
        
        return {"status": "queued", "message_id": message.get("id")}
    
    async def update_channel(self, channel_id: str, 
                            updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update a published channel's configuration.
        
        Args:
            channel_id: ID of the channel
            updates: Dictionary of updates
            
        Returns:
            Result of the update
        """
        if channel_id not in self._published_channels:
            return {"error": f"Channel {channel_id} not found"}
        
        config = self._published_channels[channel_id]
        
        # Update fields
        if "name" in updates:
            config.name = updates["name"]
        if "enabled" in updates:
            config.enabled = updates["enabled"]
        if "credentials" in updates:
            config.credentials.update(updates["credentials"])
        if "settings" in updates:
            config.settings.update(updates["settings"])
        if "webhook_url" in updates:
            config.webhook_url = updates["webhook_url"]
        
        config.updated_at = datetime.now()
        
        # Restart processor if enabled state changed
        if "enabled" in updates:
            await self._restart_channel_processor(channel_id, config)
        
        return {"status": "updated", "channel_id": channel_id}
    
    async def _restart_channel_processor(self, channel_id: str, config: ChannelConfig) -> None:
        """Restart the message processor for a channel."""
        # Stop existing processor
        if channel_id in self._message_queues:
            await self._message_queues[channel_id].put(None)
            del self._message_queues[channel_id]
        
        # Start new processor if enabled
        if config.enabled:
            await self._start_channel_processor(channel_id, config)
    
    # Public API for Nimbus integration
    async def publish(self, agent_id: str, channel_type: str, 
                     config: Dict[str, Any]) -> Dict[str, Any]:
        """Publish an agent to a channel."""
        return await self.publish_agent(agent_id, channel_type, config)
    
    async def unpublish(self, channel_id: str) -> Dict[str, Any]:
        """Unpublish an agent from a channel."""
        return await self.unpublish_agent(channel_id)
    
    async def list_channels(self, agent_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List published channels."""
        return await self.list_published_channels(agent_id)
    
    async def get_channel(self, channel_id: str) -> Optional[Dict[str, Any]]:
        """Get channel information."""
        return await self.get_channel_info(channel_id)
    
    async def send(self, channel_id: str, content: str, 
                  metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Send a message through a channel."""
        return await self.send_message(channel_id, content, metadata)
    
    async def receive(self, channel_id: str, message: Dict[str, Any]) -> Dict[str, Any]:
        """Receive a message from a channel."""
        return await self.receive_message(channel_id, message)


# Channel handler base class
class BaseChannelHandler:
    """Base class for channel handlers."""
    
    def __init__(self, publisher: MultiChannelPublishing):
        self.publisher = publisher
    
    async def initialize_channel(self, config: ChannelConfig) -> None:
        """Initialize a channel (start webhook, connect, etc.)."""
        raise NotImplementedError
    
    async def cleanup_channel(self, config: ChannelConfig) -> None:
        """Clean up a channel (stop webhook, disconnect, etc.)."""
        raise NotImplementedError
    
    async def process_message(self, config: ChannelConfig, message: Dict[str, Any]) -> None:
        """Process a message from the channel."""
        raise NotImplementedError
    
    async def send_message(self, config: ChannelConfig, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send a message to the channel."""
        raise NotImplementedError
    
    async def get_channel_stats(self, config: ChannelConfig) -> Dict[str, Any]:
        """Get statistics for the channel."""
        return {}


# Factory function for Nimbus integration
def create_multi_channel_publisher(agent_manager, storage_path: str = "data/published_agents"):
    """Create a multi-channel publishing instance for Nimbus."""
    return MultiChannelPublishing(agent_manager, storage_path)
