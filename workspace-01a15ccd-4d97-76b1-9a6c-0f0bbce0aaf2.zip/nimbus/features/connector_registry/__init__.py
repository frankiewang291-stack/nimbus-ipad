"""
Nimbus Connector Registry - 400+ Connectors Framework

This module provides a framework for managing 400+ connectors for Nimbus,
similar to Coze's extensive plugin ecosystem.

Features:
- Connector registration and discovery
- Categorization and tagging
- Version management
- Dependency tracking
- Community connector support
- Connector marketplace

Connector Types:
1. MCP Servers - Model Context Protocol servers
2. API Connectors - REST/GraphQL API integrations
3. Webhook Connectors - Webhook-based integrations
4. OAuth Connectors - OAuth 2.0 integrations
5. Custom Connectors - User-defined connectors

Categories:
- Communication (Slack, Teams, Discord, Email, etc.)
- Productivity (Notion, Trello, Asana, etc.)
- Development (GitHub, GitLab, Bitbucket, etc.)
- Cloud Services (AWS, GCP, Azure, etc.)
- Databases (PostgreSQL, MySQL, MongoDB, etc.)
- File Storage (S3, Google Drive, Dropbox, etc.)
- CRM (Salesforce, HubSpot, Pipedrive, etc.)
- Marketing (Mailchimp, SendGrid, etc.)
- Analytics (Google Analytics, Mixpanel, etc.)
- Payment (Stripe, PayPal, Square, etc.)
- Social Media (Twitter, Facebook, Instagram, etc.)
- AI Services (OpenAI, Anthropic, Google, etc.)
- Utilities (Weather, News, Translate, etc.)

Usage:
1. Register connectors: register_connector(connector_class)
2. Discover connectors: list_connectors(category=category)
3. Load connectors: load_connector(connector_id)
4. Search connectors: search_connectors(query)
"""

import asyncio
import importlib
import json
import logging
import os
import pkgutil
import sys
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional, List, Dict, Any, Type, Callable, Awaitable, Union

logger = logging.getLogger(__name__)


class ConnectorStatus(Enum):
    """Status of a connector."""
    AVAILABLE = "available"
    LOADING = "loading"
    LOADED = "loaded"
    ERROR = "error"
    DISABLED = "disabled"


class ConnectorType(Enum):
    """Type of connector."""
    MCP = "mcp"  # Model Context Protocol
    API = "api"  # REST/GraphQL API
    WEBHOOK = "webhook"  # Webhook-based
    OAUTH = "oauth"  # OAuth 2.0
    CUSTOM = "custom"  # User-defined
    PLUGIN = "plugin"  # Plugin-based


@dataclass
class ConnectorMetadata:
    """Metadata for a connector."""
    id: str
    name: str
    description: str
    version: str = "1.0.0"
    connector_type: ConnectorType = ConnectorType.API
    category: str = "Other"
    tags: List[str] = field(default_factory=list)
    author: str = "Nimbus Team"
    license: str = "MIT"
    homepage: Optional[str] = None
    repository: Optional[str] = None
    documentation: Optional[str] = None
    icon: str = "🔗"
    
    # Dependencies
    dependencies: List[str] = field(default_factory=list)
    python_dependencies: List[str] = field(default_factory=list)
    
    # Configuration
    config_schema: Dict[str, Any] = field(default_factory=dict)
    
    # Capabilities
    capabilities: List[str] = field(default_factory=list)
    
    # Status
    status: ConnectorStatus = ConnectorStatus.AVAILABLE
    error_message: Optional[str] = None
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "connector_type": self.connector_type.value,
            "category": self.category,
            "tags": self.tags,
            "author": self.author,
            "license": self.license,
            "homepage": self.homepage,
            "repository": self.repository,
            "documentation": self.documentation,
            "icon": self.icon,
            "dependencies": self.dependencies,
            "python_dependencies": self.python_dependencies,
            "config_schema": self.config_schema,
            "capabilities": self.capabilities,
            "status": self.status.value,
            "error_message": self.error_message,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConnectorMetadata":
        return cls(
            id=data["id"],
            name=data["name"],
            description=data["description"],
            version=data.get("version", "1.0.0"),
            connector_type=ConnectorType(data.get("connector_type", "api")),
            category=data.get("category", "Other"),
            tags=data.get("tags", []),
            author=data.get("author", "Nimbus Team"),
            license=data.get("license", "MIT"),
            homepage=data.get("homepage"),
            repository=data.get("repository"),
            documentation=data.get("documentation"),
            icon=data.get("icon", "🔗"),
            dependencies=data.get("dependencies", []),
            python_dependencies=data.get("python_dependencies", []),
            config_schema=data.get("config_schema", {}),
            capabilities=data.get("capabilities", []),
            status=ConnectorStatus(data.get("status", "available")),
            error_message=data.get("error_message"),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )


@dataclass
class ConnectorConfig:
    """Configuration for a connector instance."""
    connector_id: str
    name: str = ""
    config: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "connector_id": self.connector_id,
            "name": self.name,
            "config": self.config,
            "enabled": self.enabled
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConnectorConfig":
        return cls(
            connector_id=data["connector_id"],
            name=data.get("name", ""),
            config=data.get("config", {}),
            enabled=data.get("enabled", True)
        )


class ConnectorRegistry:
    """
    Registry for managing Nimbus connectors.
    
    Provides functionality for:
    - Registering connectors
    - Discovering connectors
    - Loading connectors
    - Managing connector configurations
    """
    
    def __init__(self, storage_path: str = "data/connectors", 
                 connector_dirs: List[str] = None):
        """
        Initialize the connector registry.
        
        Args:
            storage_path: Path to store connector configurations
            connector_dirs: List of directories to search for connectors
        """
        self.storage_path = Path(storage_path)
        self.connector_dirs = connector_dirs or [
            "connectors",
            "nimbus/connectors",
            "nimbus/features/connector_registry/connectors"
        ]
        
        # Connector metadata registry
        self._connectors: Dict[str, ConnectorMetadata] = {}
        
        # Connector instances
        self._instances: Dict[str, Any] = {}
        
        # Connector configurations
        self._configs: Dict[str, ConnectorConfig] = {}
        
        # Load built-in connectors
        self._load_builtin_connectors()
        
        # Ensure storage directory exists
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.name = "connector_registry"
        self.display_name = "Connector Registry"
        self.description = "Manage 400+ connectors for Nimbus"
        self.icon = "🔌"
        
    def _load_builtin_connectors(self) -> None:
        """Load built-in connectors from the registry."""
        # This will be populated by connector modules that register themselves
        pass
    
    def register_connector(self, connector_class: Type, 
                          metadata: Optional[ConnectorMetadata] = None) -> None:
        """
        Register a connector class.
        
        Args:
            connector_class: The connector class to register
            metadata: Optional metadata for the connector
        """
        # Extract metadata from class if not provided
        if metadata is None:
            metadata = ConnectorMetadata(
                id=getattr(connector_class, "CONNECTOR_ID", connector_class.__name__.lower()),
                name=getattr(connector_class, "CONNECTOR_NAME", connector_class.__name__),
                description=getattr(connector_class, "CONNECTOR_DESCRIPTION", ""),
                connector_type=getattr(connector_class, "CONNECTOR_TYPE", ConnectorType.API),
                category=getattr(connector_class, "CONNECTOR_CATEGORY", "Other"),
                tags=getattr(connector_class, "CONNECTOR_TAGS", []),
                author=getattr(connector_class, "CONNECTOR_AUTHOR", "Nimbus Team"),
                version=getattr(connector_class, "CONNECTOR_VERSION", "1.0.0"),
                icon=getattr(connector_class, "CONNECTOR_ICON", "🔗"),
                capabilities=getattr(connector_class, "CONNECTOR_CAPABILITIES", []),
                config_schema=getattr(connector_class, "CONNECTOR_CONFIG_SCHEMA", {}),
                python_dependencies=getattr(connector_class, "CONNECTOR_DEPENDENCIES", [])
            )
        
        # Store the connector
        self._connectors[metadata.id] = metadata
        
        logger.info(f"Registered connector: {metadata.id} ({metadata.name})")
    
    def register_connectors_from_module(self, module_name: str) -> int:
        """
        Register all connectors from a module.
        
        Args:
            module_name: Name of the module to scan
            
        Returns:
            Number of connectors registered
        """
        count = 0
        
        try:
            module = importlib.import_module(module_name)
            
            # Look for connector classes
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                
                # Check if it's a class and has connector metadata
                if (isinstance(attr, type) and 
                    hasattr(attr, "CONNECTOR_ID") and
                    not attr_name.startswith("_")):
                    
                    self.register_connector(attr)
                    count += 1
            
        except Exception as e:
            logger.error(f"Error loading connectors from {module_name}: {e}")
        
        return count
    
    def scan_connectors(self) -> int:
        """
        Scan for and register all available connectors.
        
        Returns:
            Number of connectors registered
        """
        total = 0
        
        # Scan built-in connector directories
        for connector_dir in self.connector_dirs:
            full_path = Path(connector_dir)
            if full_path.exists():
                for module_file in full_path.glob("*/__init__.py"):
                    module_path = str(module_file.parent)
                    module_name = module_path.replace("/", ".")
                    total += self.register_connectors_from_module(module_name)
        
        # Also scan installed packages
        total += self._scan_installed_packages()
        
        logger.info(f"Scanned and registered {total} connectors")
        return total
    
    def _scan_installed_packages(self) -> int:
        """Scan installed Python packages for connectors."""
        count = 0
        
        # This would scan for packages with nimbus.connector entry points
        # For now, just return 0
        return count
    
    def list_connectors(self, category: Optional[str] = None,
                       tags: Optional[List[str]] = None,
                       search: Optional[str] = None,
                       limit: int = 100) -> List[ConnectorMetadata]:
        """
        List available connectors.
        
        Args:
            category: Optional filter by category
            tags: Optional filter by tags
            search: Optional search query
            limit: Maximum number of connectors to return
            
        Returns:
            List of connector metadata
        """
        connectors = list(self._connectors.values())
        
        # Filter by category
        if category:
            connectors = [c for c in connectors if c.category.lower() == category.lower()]
        
        # Filter by tags
        if tags:
            connectors = [
                c for c in connectors
                if any(tag.lower() in [t.lower() for t in c.tags] for tag in tags)
            ]
        
        # Filter by search
        if search:
            search_lower = search.lower()
            connectors = [
                c for c in connectors
                if (search_lower in c.name.lower() or 
                    search_lower in c.description.lower() or
                    search_lower in c.id.lower())
            ]
        
        # Sort by name
        connectors.sort(key=lambda c: c.name.lower())
        
        return connectors[:limit]
    
    def get_connector(self, connector_id: str) -> Optional[ConnectorMetadata]:
        """
        Get connector metadata by ID.
        
        Args:
            connector_id: ID of the connector
            
        Returns:
            Connector metadata, or None if not found
        """
        return self._connectors.get(connector_id)
    
    def get_categories(self) -> List[str]:
        """
        Get all available connector categories.
        
        Returns:
            List of category names
        """
        categories = set()
        for connector in self._connectors.values():
            categories.add(connector.category)
        return sorted(categories)
    
    def get_tags(self) -> List[str]:
        """
        Get all available connector tags.
        
        Returns:
            List of tag names
        """
        tags = set()
        for connector in self._connectors.values():
            tags.update(connector.tags)
        return sorted(tags)
    
    async def load_connector(self, connector_id: str, 
                           config: Optional[Dict[str, Any]] = None) -> Any:
        """
        Load and initialize a connector instance.
        
        Args:
            connector_id: ID of the connector to load
            config: Optional configuration for the connector
            
        Returns:
            Initialized connector instance
        """
        if connector_id not in self._connectors:
            raise ValueError(f"Connector {connector_id} not found")
        
        metadata = self._connectors[connector_id]
        
        # Check if already loaded
        if connector_id in self._instances:
            return self._instances[connector_id]
        
        # Import the connector module
        try:
            # Try to import from the registry
            module_name = f"connectors.{connector_id}"
            try:
                module = importlib.import_module(module_name)
            except ImportError:
                # Try other paths
                for connector_dir in self.connector_dirs:
                    module_path = f"{connector_dir}.{connector_id}"
                    try:
                        module = importlib.import_module(module_path)
                        break
                    except ImportError:
                        continue
                else:
                    raise ImportError(f"Cannot import connector {connector_id}")
            
            # Get the connector class
            connector_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and 
                    hasattr(attr, "CONNECTOR_ID") and
                    attr.CONNECTOR_ID == connector_id):
                    connector_class = attr
                    break
            
            if connector_class is None:
                raise ValueError(f"Cannot find connector class for {connector_id}")
            
            # Create and initialize the instance
            instance = connector_class()
            
            # Initialize if it has an initialize method
            if hasattr(instance, 'initialize'):
                if asyncio.iscoroutinefunction(instance.initialize):
                    await instance.initialize()
                else:
                    instance.initialize()
            
            # Store the instance
            self._instances[connector_id] = instance
            metadata.status = ConnectorStatus.LOADED
            
            logger.info(f"Loaded connector: {connector_id}")
            return instance
            
        except Exception as e:
            logger.error(f"Error loading connector {connector_id}: {e}")
            metadata.status = ConnectorStatus.ERROR
            metadata.error_message = str(e)
            raise
    
    async def unload_connector(self, connector_id: str) -> None:
        """
        Unload a connector instance.
        
        Args:
            connector_id: ID of the connector to unload
        """
        if connector_id in self._instances:
            instance = self._instances.pop(connector_id)
            
            # Clean up if it has a cleanup method
            if hasattr(instance, 'cleanup'):
                if asyncio.iscoroutinefunction(instance.cleanup):
                    await instance.cleanup()
                else:
                    instance.cleanup()
            
            # Update metadata
            if connector_id in self._connectors:
                self._connectors[connector_id].status = ConnectorStatus.AVAILABLE
                self._connectors[connector_id].error_message = None
            
            logger.info(f"Unloaded connector: {connector_id}")
    
    def configure_connector(self, connector_id: str, 
                           config: ConnectorConfig) -> None:
        """
        Configure a connector instance.
        
        Args:
            connector_id: ID of the connector
            config: Configuration for the connector
        """
        self._configs[connector_id] = config
        
        # If the connector is loaded, reinitialize it with the new config
        if connector_id in self._instances:
            instance = self._instances[connector_id]
            if hasattr(instance, 'configure'):
                if asyncio.iscoroutinefunction(instance.configure):
                    asyncio.create_task(instance.configure(config.config))
                else:
                    instance.configure(config.config)
        
        logger.info(f"Configured connector: {connector_id}")
    
    def get_connector_config(self, connector_id: str) -> Optional[ConnectorConfig]:
        """
        Get configuration for a connector.
        
        Args:
            connector_id: ID of the connector
            
        Returns:
            Connector configuration, or None if not found
        """
        return self._configs.get(connector_id)
    
    def get_connector_instance(self, connector_id: str) -> Optional[Any]:
        """
        Get a loaded connector instance.
        
        Args:
            connector_id: ID of the connector
            
        Returns:
            Connector instance, or None if not loaded
        """
        return self._instances.get(connector_id)
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get registry statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            "total_connectors": len(self._connectors),
            "loaded_connectors": len(self._instances),
            "configured_connectors": len(self._configs),
            "categories": len(self.get_categories()),
            "tags": len(self.get_tags())
        }
    
    def get_connector_by_capability(self, capability: str) -> List[ConnectorMetadata]:
        """
        Get connectors that have a specific capability.
        
        Args:
            capability: The capability to search for
            
        Returns:
            List of connectors with the capability
        """
        return [
            c for c in self._connectors.values()
            if capability.lower() in [cap.lower() for cap in c.capabilities]
        ]
    
    def get_popular_connectors(self, limit: int = 10) -> List[ConnectorMetadata]:
        """
        Get the most popular connectors.
        
        Args:
            limit: Maximum number of connectors to return
            
        Returns:
            List of popular connectors
        """
        # In a real implementation, this would be based on usage statistics
        # For now, just return the first N connectors
        connectors = list(self._connectors.values())
        return sorted(connectors, key=lambda c: c.name)[:limit]
    
    def get_recently_added(self, limit: int = 10) -> List[ConnectorMetadata]:
        """
        Get recently added connectors.
        
        Args:
            limit: Maximum number of connectors to return
            
        Returns:
            List of recently added connectors
        """
        connectors = list(self._connectors.values())
        return sorted(connectors, key=lambda c: c.created_at, reverse=True)[:limit]
    
    def search_connectors(self, query: str, limit: int = 10) -> List[ConnectorMetadata]:
        """
        Search for connectors by name, description, or ID.
        
        Args:
            query: Search query
            limit: Maximum number of connectors to return
            
        Returns:
            List of matching connectors
        """
        return self.list_connectors(search=query, limit=limit)


# Decorator for registering connectors
def register_connector(connector_class: Type, **metadata_kwargs) -> Type:
    """
    Decorator to register a connector class.
    
    Args:
        connector_class: The connector class to register
        **metadata_kwargs: Metadata for the connector
        
    Returns:
        The decorated class
    """
    # Get the global registry (singleton)
    registry = get_registry()
    
    # Create metadata from kwargs
    metadata = ConnectorMetadata(
        id=metadata_kwargs.get("id", connector_class.__name__.lower()),
        name=metadata_kwargs.get("name", connector_class.__name__),
        description=metadata_kwargs.get("description", ""),
        version=metadata_kwargs.get("version", "1.0.0"),
        connector_type=metadata_kwargs.get("connector_type", ConnectorType.API),
        category=metadata_kwargs.get("category", "Other"),
        tags=metadata_kwargs.get("tags", []),
        author=metadata_kwargs.get("author", "Nimbus Team"),
        license=metadata_kwargs.get("license", "MIT"),
        homepage=metadata_kwargs.get("homepage"),
        repository=metadata_kwargs.get("repository"),
        documentation=metadata_kwargs.get("documentation"),
        icon=metadata_kwargs.get("icon", "🔗"),
        capabilities=metadata_kwargs.get("capabilities", []),
        config_schema=metadata_kwargs.get("config_schema", {}),
        python_dependencies=metadata_kwargs.get("python_dependencies", [])
    )
    
    # Register the connector
    registry.register_connector(connector_class, metadata)
    
    return connector_class


# Singleton registry instance
_registry: Optional[ConnectorRegistry] = None


def get_registry() -> ConnectorRegistry:
    """
    Get the global connector registry instance.
    
    Returns:
        The global connector registry
    """
    global _registry
    if _registry is None:
        _registry = ConnectorRegistry()
    return _registry


def reset_registry() -> None:
    """Reset the global connector registry (for testing)."""
    global _registry
    if _registry is not None:
        _registry = None


# Factory function for Nimbus integration
def create_connector_registry(storage_path: str = "data/connectors",
                               connector_dirs: List[str] = None) -> ConnectorRegistry:
    """Create a connector registry instance for Nimbus."""
    return ConnectorRegistry(storage_path, connector_dirs)
