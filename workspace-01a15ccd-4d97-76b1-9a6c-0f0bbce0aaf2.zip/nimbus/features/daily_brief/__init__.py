"""
Nimbus Daily Brief Feature

This feature provides proactive daily digests to users, similar to Today AI and Meta Muse.

Features:
- Morning brief: Summary of what's coming up today
- Evening close-out: Summary of what happened and what needs attention
- Proactive notifications for important changes
- Configurable briefing times
- Support for multiple delivery methods (in-app, email, Slack, etc.)

The daily brief is generated based on:
- Calendar events
- Thread updates
- Agent activity
- Pending approvals
- Important messages
- Deadlines and reminders

Usage:
1. Enable daily brief in settings
2. Configure preferred delivery time and method
3. Receive automatic briefs

Dependencies:
- Nimbus memory system
- Agent activity tracking
- Thread management
- Approval system
"""

import asyncio
import json
import logging
from datetime import datetime, time, timedelta
from typing import Optional, List, Dict, Any, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)


class DailyBrief:
    """
    Daily brief feature for Nimbus.
    
    Generates and delivers proactive daily summaries to users.
    """
    
    def __init__(self, state_manager, agent_manager, thread_manager, approval_manager):
        """
        Initialize the daily brief feature.
        
        Args:
            state_manager: Nimbus state manager
            agent_manager: Agent manager
            thread_manager: Thread manager
            approval_manager: Approval manager
        """
        self.state_manager = state_manager
        self.agent_manager = agent_manager
        self.thread_manager = thread_manager
        self.approval_manager = approval_manager
        
        self.name = "daily_brief"
        self.display_name = "Daily Brief"
        self.description = "Proactive daily summaries and notifications"
        self.icon = "📅"
        
        # Default briefing times
        self.default_morning_time = time(8, 0)  # 8:00 AM
        self.default_evening_time = time(18, 0)  # 6:00 PM
        
        # Scheduled tasks
        self._scheduled_tasks = {}
        self._running = False
        
    async def initialize(self) -> bool:
        """Initialize the daily brief feature."""
        try:
            # Load user preferences
            self._load_preferences()
            
            # Start the briefing scheduler
            await self._start_scheduler()
            
            logger.info("Daily brief feature initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize daily brief: {e}")
            return False
    
    async def shutdown(self) -> None:
        """Shutdown the daily brief feature."""
        self._running = False
        for task in self._scheduled_tasks.values():
            task.cancel()
        self._scheduled_tasks.clear()
        logger.info("Daily brief feature shutdown")
    
    def _load_preferences(self) -> None:
        """Load user preferences for daily brief."""
        # In a real implementation, this would load from database
        # For now, we'll use defaults
        self.preferences = {
            "enabled": True,
            "morning_time": self.default_morning_time,
            "evening_time": self.default_evening_time,
            "delivery_method": "in_app",  # in_app, email, slack, etc.
            "include_calendar": True,
            "include_threads": True,
            "include_agents": True,
            "include_approvals": True,
            "include_reminders": True,
            "max_items": 10
        }
    
    def _save_preferences(self, preferences: Dict[str, Any]) -> None:
        """Save user preferences for daily brief."""
        self.preferences.update(preferences)
        # In a real implementation, save to database
        logger.info(f"Daily brief preferences saved: {preferences}")
    
    async def _start_scheduler(self) -> None:
        """Start the daily briefing scheduler."""
        if self._running:
            return
        
        self._running = True
        
        # Schedule morning brief
        morning_task = asyncio.create_task(
            self._schedule_brief("morning", self.preferences.get("morning_time", self.default_morning_time))
        )
        self._scheduled_tasks["morning"] = morning_task
        
        # Schedule evening brief
        evening_task = asyncio.create_task(
            self._schedule_brief("evening", self.preferences.get("evening_time", self.default_evening_time))
        )
        self._scheduled_tasks["evening"] = evening_task
        
        logger.info("Daily brief scheduler started")
    
    async def _schedule_brief(self, brief_type: str, brief_time: time) -> None:
        """Schedule a daily brief for a specific time."""
        while self._running:
            now = datetime.now()
            target_time = datetime.combine(now.date(), brief_time)
            
            # If target time already passed today, schedule for tomorrow
            if now > target_time:
                target_time += timedelta(days=1)
            
            # Wait until target time
            wait_seconds = (target_time - now).total_seconds()
            if wait_seconds > 0:
                await asyncio.sleep(wait_seconds)
            
            # Generate and deliver the brief
            if self._running and self.preferences.get("enabled", True):
                await self._generate_and_deliver_brief(brief_type)
            
            # Wait until next day
            now = datetime.now()
            tomorrow = now.date() + timedelta(days=1)
            target_time = datetime.combine(tomorrow, brief_time)
            wait_seconds = (target_time - now).total_seconds()
            await asyncio.sleep(max(0, wait_seconds))
    
    async def _generate_and_deliver_brief(self, brief_type: str) -> None:
        """Generate and deliver a daily brief."""
        try:
            logger.info(f"Generating {brief_type} brief...")
            
            # Get all users who have daily brief enabled
            users = await self._get_users_with_brief_enabled()
            
            for user in users:
                # Generate brief for this user
                brief_content = await self._generate_brief_for_user(user, brief_type)
                
                if brief_content:
                    # Deliver the brief
                    await self._deliver_brief(user, brief_type, brief_content)
                    logger.info(f"Delivered {brief_type} brief to user {user.get('id')}")
                
        except Exception as e:
            logger.error(f"Error generating {brief_type} brief: {e}")
    
    async def _get_users_with_brief_enabled(self) -> List[Dict[str, Any]]:
        """Get all users who have daily brief enabled."""
        # In a real implementation, query the database
        # For now, return a mock list
        return [
            {"id": "user_1", "name": "Test User", "email": "test@example.com"},
            {"id": "user_2", "name": "Another User", "email": "another@example.com"}
        ]
    
    async def _generate_brief_for_user(self, user: Dict[str, Any], brief_type: str) -> Optional[Dict[str, Any]]:
        """Generate a daily brief for a specific user."""
        try:
            # Get user's data
            user_state = await self.state_manager.get_user_state(user["id"])
            
            # Collect information for the brief
            brief_data = {}
            
            if self.preferences.get("include_calendar", True):
                brief_data["calendar"] = await self._get_calendar_events(user["id"])
            
            if self.preferences.get("include_threads", True):
                brief_data["threads"] = await self._get_thread_updates(user["id"])
            
            if self.preferences.get("include_agents", True):
                brief_data["agents"] = await self._get_agent_activity(user["id"])
            
            if self.preferences.get("include_approvals", True):
                brief_data["approvals"] = await self._get_pending_approvals(user["id"])
            
            if self.preferences.get("include_reminders", True):
                brief_data["reminders"] = await self._get_reminders(user["id"])
            
            # Generate the brief content
            if brief_type == "morning":
                content = self._generate_morning_brief(user, brief_data)
            else:  # evening
                content = self._generate_evening_brief(user, brief_data)
            
            return content
            
        except Exception as e:
            logger.error(f"Error generating brief for user {user.get('id')}: {e}")
            return None
    
    async def _get_calendar_events(self, user_id: str) -> List[Dict[str, Any]]:
        """Get calendar events for a user."""
        # In a real implementation, query calendar API or database
        # For now, return mock data
        return [
            {
                "id": "event_1",
                "title": "Team Meeting",
                "start": "2026-10-22T09:00:00",
                "end": "2026-10-22T10:00:00",
                "location": "Conference Room A"
            },
            {
                "id": "event_2",
                "title": "Project Review",
                "start": "2026-10-22T14:00:00",
                "end": "2026-10-22T15:30:00",
                "location": "Online"
            }
        ]
    
    async def _get_thread_updates(self, user_id: str) -> List[Dict[str, Any]]:
        """Get recent thread updates for a user."""
        # In a real implementation, query thread manager
        threads = await self.thread_manager.get_recent_threads(user_id, limit=5)
        
        updates = []
        for thread in threads:
            updates.append({
                "id": thread.get("id"),
                "title": thread.get("title"),
                "last_updated": thread.get("updated_at"),
                "agent": thread.get("agent_name"),
                "status": thread.get("status")
            })
        
        return updates
    
    async def _get_agent_activity(self, user_id: str) -> List[Dict[str, Any]]:
        """Get recent agent activity for a user."""
        # In a real implementation, query agent manager
        agents = await self.agent_manager.get_user_agents(user_id)
        
        activity = []
        for agent in agents:
            activity.append({
                "id": agent.get("id"),
                "name": agent.get("name"),
                "status": agent.get("status"),
                "last_active": agent.get("last_active")
            })
        
        return activity
    
    async def _get_pending_approvals(self, user_id: str) -> List[Dict[str, Any]]:
        """Get pending approvals for a user."""
        approvals = await self.approval_manager.get_pending_approvals(user_id)
        return [
            {
                "id": a.get("id"),
                "title": a.get("title"),
                "type": a.get("type"),
                "created_at": a.get("created_at"),
                "priority": a.get("priority", "normal")
            }
            for a in approvals
        ]
    
    async def _get_reminders(self, user_id: str) -> List[Dict[str, Any]]:
        """Get reminders for a user."""
        # In a real implementation, query reminders from database
        return [
            {
                "id": "reminder_1",
                "title": "Submit quarterly report",
                "due": "2026-10-25",
                "priority": "high"
            },
            {
                "id": "reminder_2",
                "title": "Review pull request",
                "due": "2026-10-23",
                "priority": "medium"
            }
        ]
    
    def _generate_morning_brief(self, user: Dict[str, Any], brief_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a morning brief."""
        sections = []
        
        # Calendar section
        if "calendar" in brief_data and brief_data["calendar"]:
            today = datetime.now().date()
            today_events = [
                e for e in brief_data["calendar"]
                if datetime.fromisoformat(e["start"]).date() == today
            ]
            
            if today_events:
                sections.append({
                    "title": "📅 Today's Calendar",
                    "items": [
                        {
                            "time": datetime.fromisoformat(e["start"]).strftime("%H:%M"),
                            "title": e["title"],
                            "location": e.get("location", "")
                        }
                        for e in sorted(today_events, key=lambda x: x["start"])
                    ]
                })
        
        # Threads section
        if "threads" in brief_data and brief_data["threads"]:
            sections.append({
                "title": "💬 Thread Updates",
                "items": [
                    {
                        "title": t["title"],
                        "agent": t.get("agent", "Unknown"),
                        "time": t["last_updated"]
                    }
                    for t in brief_data["threads"][:self.preferences.get("max_items", 10)]
                ]
            })
        
        # Approvals section
        if "approvals" in brief_data and brief_data["approvals"]:
            high_priority = [a for a in brief_data["approvals"] if a.get("priority") == "high"]
            if high_priority:
                sections.append({
                    "title": "⚠️ Pending Approvals (High Priority)",
                    "items": [
                        {
                            "title": a["title"],
                            "type": a["type"],
                            "time": a["created_at"]
                        }
                        for a in high_priority
                    ]
                })
        
        # Reminders section
        if "reminders" in brief_data and brief_data["reminders"]:
            due_soon = [
                r for r in brief_data["reminders"]
                if (datetime.fromisoformat(r["due"]) - datetime.now()).days <= 3
            ]
            if due_soon:
                sections.append({
                    "title": "🔔 Upcoming Reminders",
                    "items": [
                        {
                            "title": r["title"],
                            "due": r["due"],
                            "priority": r["priority"]
                        }
                        for r in sorted(due_soon, key=lambda x: x["due"])
                    ]
                })
        
        # Generate the brief
        brief = {
            "type": "morning",
            "timestamp": datetime.now().isoformat(),
            "user_id": user["id"],
            "sections": sections,
            "summary": self._generate_morning_summary(sections)
        }
        
        return brief
    
    def _generate_evening_brief(self, user: Dict[str, Any], brief_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate an evening brief."""
        sections = []
        
        # Today's completed items
        if "threads" in brief_data and brief_data["threads"]:
            completed_today = [
                t for t in brief_data["threads"]
                if t.get("status") == "completed"
            ]
            if completed_today:
                sections.append({
                    "title": "✅ Completed Today",
                    "items": [
                        {
                            "title": t["title"],
                            "agent": t.get("agent", "Unknown")
                        }
                        for t in completed_today
                    ]
                })
        
        # Pending items
        if "threads" in brief_data and brief_data["threads"]:
            pending = [
                t for t in brief_data["threads"]
                if t.get("status") != "completed"
            ]
            if pending:
                sections.append({
                    "title": "🔄 Still In Progress",
                    "items": [
                        {
                            "title": t["title"],
                            "agent": t.get("agent", "Unknown"),
                            "last_updated": t["last_updated"]
                        }
                        for t in pending
                    ]
                })
        
        # Approvals section
        if "approvals" in brief_data and brief_data["approvals"]:
            sections.append({
                "title": "⏳ Pending Approvals",
                "items": [
                    {
                        "title": a["title"],
                        "type": a["type"],
                        "time": a["created_at"]
                    }
                    for a in brief_data["approvals"]
                ]
            })
        
        # Tomorrow's calendar
        if "calendar" in brief_data and brief_data["calendar"]:
            tomorrow = datetime.now().date() + timedelta(days=1)
            tomorrow_events = [
                e for e in brief_data["calendar"]
                if datetime.fromisoformat(e["start"]).date() == tomorrow
            ]
            
            if tomorrow_events:
                sections.append({
                    "title": "📅 Tomorrow's Calendar",
                    "items": [
                        {
                            "time": datetime.fromisoformat(e["start"]).strftime("%H:%M"),
                            "title": e["title"],
                            "location": e.get("location", "")
                        }
                        for e in sorted(tomorrow_events, key=lambda x: x["start"])
                    ]
                })
        
        # Generate the brief
        brief = {
            "type": "evening",
            "timestamp": datetime.now().isoformat(),
            "user_id": user["id"],
            "sections": sections,
            "summary": self._generate_evening_summary(sections)
        }
        
        return brief
    
    def _generate_morning_summary(self, sections: List[Dict[str, Any]]) -> str:
        """Generate a text summary for morning brief."""
        if not sections:
            return "Good morning! You have no scheduled events or updates today."
        
        lines = ["Good morning! Here's what's coming up today:"]
        
        for section in sections:
            lines.append(f"\n**{section['title']}**")
            for item in section["items"]:
                if "time" in item:
                    lines.append(f"  • {item['time']}: {item['title']}")
                elif "agent" in item:
                    lines.append(f"  • {item['title']} ({item['agent']})")
                else:
                    lines.append(f"  • {item['title']}")
        
        return "\n".join(lines)
    
    def _generate_evening_summary(self, sections: List[Dict[str, Any]]) -> str:
        """Generate a text summary for evening brief."""
        if not sections:
            return "Good evening! You have no updates from today."
        
        lines = ["Good evening! Here's a summary of your day:"]
        
        for section in sections:
            lines.append(f"\n**{section['title']}**")
            for item in section["items"]:
                if "time" in item:
                    lines.append(f"  • {item['time']}: {item['title']}")
                elif "agent" in item and "last_updated" in item:
                    lines.append(f"  • {item['title']} ({item['agent']}) - last updated: {item['last_updated']}")
                elif "agent" in item:
                    lines.append(f"  • {item['title']} ({item['agent']})")
                else:
                    lines.append(f"  • {item['title']}")
        
        return "\n".join(lines)
    
    async def _deliver_brief(self, user: Dict[str, Any], brief_type: str, brief: Dict[str, Any]) -> bool:
        """Deliver a brief to a user via their preferred method."""
        delivery_method = self.preferences.get("delivery_method", "in_app")
        
        try:
            if delivery_method == "in_app":
                # Store in user's inbox/feed
                await self._store_in_app_brief(user["id"], brief_type, brief)
            elif delivery_method == "email":
                await self._send_email_brief(user, brief_type, brief)
            elif delivery_method == "slack":
                await self._send_slack_brief(user, brief_type, brief)
            else:
                # Default to in-app
                await self._store_in_app_brief(user["id"], brief_type, brief)
            
            return True
            
        except Exception as e:
            logger.error(f"Error delivering brief to user {user.get('id')}: {e}")
            return False
    
    async def _store_in_app_brief(self, user_id: str, brief_type: str, brief: Dict[str, Any]) -> bool:
        """Store a brief in the user's in-app feed."""
        # In a real implementation, store in database
        logger.info(f"Storing {brief_type} brief in app for user {user_id}")
        return True
    
    async def _send_email_brief(self, user: Dict[str, Any], brief_type: str, brief: Dict[str, Any]) -> bool:
        """Send a brief via email."""
        # In a real implementation, send via email service
        logger.info(f"Sending {brief_type} brief via email to {user.get('email')}")
        return True
    
    async def _send_slack_brief(self, user: Dict[str, Any], brief_type: str, brief: Dict[str, Any]) -> bool:
        """Send a brief via Slack."""
        # In a real implementation, use Slack connector to send message
        from connectors.slack import slack_connector
        
        # Get user's Slack DM channel
        # For now, just log
        logger.info(f"Sending {brief_type} brief via Slack to {user.get('id')}")
        return True
    
    # Public API
    async def enable_daily_brief(self, user_id: str) -> bool:
        """Enable daily brief for a user."""
        self.preferences["enabled"] = True
        self._save_preferences({"enabled": True})
        return True
    
    async def disable_daily_brief(self, user_id: str) -> bool:
        """Disable daily brief for a user."""
        self.preferences["enabled"] = False
        self._save_preferences({"enabled": False})
        return True
    
    async def set_brief_time(self, brief_type: str, hour: int, minute: int) -> bool:
        """Set the time for a brief type."""
        if brief_type not in ["morning", "evening"]:
            return False
        
        time_key = f"{brief_type}_time"
        self.preferences[time_key] = time(hour, minute)
        self._save_preferences({time_key: time(hour, minute)})
        
        # Restart scheduler
        await self.shutdown()
        await self.initialize()
        
        return True
    
    async def set_delivery_method(self, method: str) -> bool:
        """Set the delivery method for briefs."""
        if method not in ["in_app", "email", "slack"]:
            return False
        
        self.preferences["delivery_method"] = method
        self._save_preferences({"delivery_method": method})
        return True
    
    async def get_brief_history(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get brief history for a user."""
        # In a real implementation, query from database
        return []
    
    async def trigger_brief_now(self, user_id: str, brief_type: str) -> bool:
        """Trigger a brief immediately (for testing)."""
        user = {"id": user_id}
        brief_content = await self._generate_brief_for_user(user, brief_type)
        if brief_content:
            await self._deliver_brief(user, brief_type, brief_content)
            return True
        return False


# Factory function for Nimbus integration
def create_daily_brief(state_manager, agent_manager, thread_manager, approval_manager):
    """Create a daily brief instance for Nimbus."""
    return DailyBrief(state_manager, agent_manager, thread_manager, approval_manager)
