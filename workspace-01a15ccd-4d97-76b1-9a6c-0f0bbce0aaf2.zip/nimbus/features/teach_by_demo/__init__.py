"""
Nimbus Teach-by-Demonstration Feature

This feature allows users to teach Nimbus agents new workflows by demonstrating them.
Similar to GrokBot's "teach-a-task" feature.

How it works:
1. User starts recording a demonstration
2. User performs actions in the UI (or via API)
3. System records all actions, inputs, and outputs
4. System extracts patterns and creates a reusable skill
5. User can save the skill and reuse it later

Features:
- Screen recording (optional, for UI demonstrations)
- API action recording
- Pattern extraction
- Skill creation from demonstration
- Skill testing and validation

Usage:
1. Start recording: POST /api/teach/start
2. Perform actions (UI or API)
3. Stop recording: POST /api/teach/stop
4. Review and name the skill
5. Save the skill
6. Use the skill in future workflows

Dependencies:
- Action logging system
- Pattern recognition
- Skill management
"""

import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any, Callable, Awaitable
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class RecordedAction:
    """Represents a single recorded action during demonstration."""
    timestamp: datetime
    action_type: str  # e.g., "api_call", "ui_click", "tool_use"
    action_name: str  # e.g., "send_message", "create_thread"
    arguments: Dict[str, Any]
    result: Dict[str, Any]
    context: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp.isoformat(),
            "action_type": self.action_type,
            "action_name": self.action_name,
            "arguments": self.arguments,
            "result": self.result,
            "context": self.context,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RecordedAction":
        return cls(
            timestamp=datetime.fromisoformat(data["timestamp"]),
            action_type=data["action_type"],
            action_name=data["action_name"],
            arguments=data["arguments"],
            result=data["result"],
            context=data.get("context", {}),
            metadata=data.get("metadata", {})
        )


@dataclass
class Demonstration:
    """Represents a complete demonstration session."""
    id: str
    user_id: str
    name: str = ""
    description: str = ""
    actions: List[RecordedAction] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None
    status: str = "recording"  # recording, processing, completed, failed
    skill_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "description": self.description,
            "actions": [a.to_dict() for a in self.actions],
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "status": self.status,
            "skill_id": self.skill_id,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Demonstration":
        actions = [RecordedAction.from_dict(a) for a in data.get("actions", [])]
        return cls(
            id=data["id"],
            user_id=data["user_id"],
            name=data.get("name", ""),
            description=data.get("description", ""),
            actions=actions,
            start_time=datetime.fromisoformat(data["start_time"]),
            end_time=datetime.fromisoformat(data["end_time"]) if data.get("end_time") else None,
            status=data.get("status", "recording"),
            skill_id=data.get("skill_id"),
            metadata=data.get("metadata", {})
        )


class TeachByDemonstration:
    """
    Teach-by-demonstration feature for Nimbus.
    
    Allows users to create skills by demonstrating workflows.
    """
    
    def __init__(self, skill_manager, action_logger, storage_path: str = "data/teach_demos"):
        """
        Initialize the teach-by-demonstration feature.
        
        Args:
            skill_manager: Nimbus skill manager
            action_logger: Action logging system
            storage_path: Path to store demonstration recordings
        """
        self.skill_manager = skill_manager
        self.action_logger = action_logger
        self.storage_path = Path(storage_path)
        
        # In-memory storage for active demonstrations
        self._active_demonstrations: Dict[str, Demonstration] = {}
        
        # Hook for intercepting actions
        self._original_handlers: Dict[str, Callable] = {}
        self._recording_hooks: Dict[str, Callable] = {}
        
        # Ensure storage directory exists
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.name = "teach_by_demo"
        self.display_name = "Teach by Demonstration"
        self.description = "Create skills by demonstrating workflows"
        self.icon = "🎥"
        
    async def initialize(self) -> bool:
        """Initialize the teach-by-demonstration feature."""
        try:
            # Load any pending demonstrations from storage
            await self._load_pending_demonstrations()
            
            # Set up action interceptors
            await self._setup_action_interceptors()
            
            logger.info("Teach-by-demonstration feature initialized")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize teach-by-demonstration: {e}")
            return False
    
    async def shutdown(self) -> None:
        """Shutdown the teach-by-demonstration feature."""
        # Save any active demonstrations
        for demo_id, demo in self._active_demonstrations.items():
            await self._save_demonstration(demo)
        
        # Remove action interceptors
        self._restore_original_handlers()
        
        logger.info("Teach-by-demonstration feature shutdown")
    
    async def _load_pending_demonstrations(self) -> None:
        """Load pending demonstrations from storage."""
        # In a real implementation, scan storage directory
        # and load any demonstrations with status "recording"
        pass
    
    async def _setup_action_interceptors(self) -> None:
        """Set up interceptors for recording actions."""
        # This would hook into Nimbus's action dispatch system
        # For now, we'll just log that interceptors are set up
        logger.info("Action interceptors set up for teach-by-demo")
    
    def _restore_original_handlers(self) -> None:
        """Restore original action handlers."""
        # Remove any interceptors we added
        self._original_handlers.clear()
        self._recording_hooks.clear()
    
    async def start_demonstration(self, user_id: str, name: str = "", 
                                   description: str = "") -> Demonstration:
        """
        Start a new demonstration recording.
        
        Args:
            user_id: ID of the user creating the demonstration
            name: Optional name for the demonstration
            description: Optional description
            
        Returns:
            Demonstration object
        """
        # Create new demonstration
        demo = Demonstration(
            id=str(uuid.uuid4()),
            user_id=user_id,
            name=name,
            description=description,
            start_time=datetime.now()
        )
        
        # Store in active demonstrations
        self._active_demonstrations[demo.id] = demo
        
        # Set up recording hooks
        await self._setup_recording_hooks(demo.id)
        
        logger.info(f"Started demonstration {demo.id} for user {user_id}")
        
        return demo
    
    async def _setup_recording_hooks(self, demo_id: str) -> None:
        """Set up hooks to record actions for a demonstration."""
        # In a real implementation, this would hook into:
        # - API call handler
        # - Tool execution handler
        # - UI action handler
        # - Agent message handler
        
        # For now, we'll just log
        logger.info(f"Recording hooks set up for demonstration {demo_id}")
    
    async def record_action(self, demo_id: str, action: RecordedAction) -> bool:
        """
        Record an action for a demonstration.
        
        Args:
            demo_id: ID of the demonstration
            action: Action to record
            
        Returns:
            True if recorded successfully
        """
        if demo_id not in self._active_demonstrations:
            logger.warning(f"Demonstration {demo_id} not found")
            return False
        
        demo = self._active_demonstrations[demo_id]
        demo.actions.append(action)
        
        logger.debug(f"Recorded action {action.action_name} for demonstration {demo_id}")
        
        return True
    
    async def stop_demonstration(self, demo_id: str) -> Optional[Demonstration]:
        """
        Stop a demonstration recording.
        
        Args:
            demo_id: ID of the demonstration to stop
            
        Returns:
            The completed demonstration, or None if not found
        """
        if demo_id not in self._active_demonstrations:
            logger.warning(f"Demonstration {demo_id} not found")
            return None
        
        demo = self._active_demonstrations.pop(demo_id)
        demo.end_time = datetime.now()
        demo.status = "completed"
        
        # Remove recording hooks
        await self._remove_recording_hooks(demo_id)
        
        # Save to storage
        await self._save_demonstration(demo)
        
        logger.info(f"Stopped demonstration {demo_id}")
        
        return demo
    
    async def _remove_recording_hooks(self, demo_id: str) -> None:
        """Remove recording hooks for a demonstration."""
        logger.info(f"Recording hooks removed for demonstration {demo_id}")
    
    async def _save_demonstration(self, demo: Demonstration) -> None:
        """Save a demonstration to storage."""
        file_path = self.storage_path / f"{demo.id}.json"
        
        with open(file_path, 'w') as f:
            json.dump(demo.to_dict(), f, indent=2)
        
        logger.info(f"Demonstration {demo.id} saved to {file_path}")
    
    async def load_demonstration(self, demo_id: str) -> Optional[Demonstration]:
        """
        Load a demonstration from storage.
        
        Args:
            demo_id: ID of the demonstration to load
            
        Returns:
            The demonstration, or None if not found
        """
        file_path = self.storage_path / f"{demo_id}.json"
        
        if not file_path.exists():
            return None
        
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        return Demonstration.from_dict(data)
    
    async def list_demonstrations(self, user_id: str, limit: int = 100) -> List[Demonstration]:
        """
        List demonstrations for a user.
        
        Args:
            user_id: ID of the user
            limit: Maximum number of demonstrations to return
            
        Returns:
            List of demonstrations
        """
        demonstrations = []
        
        # Load from storage
        for file_path in self.storage_path.glob("*.json"):
            with open(file_path, 'r') as f:
                data = json.load(f)
            
            demo = Demonstration.from_dict(data)
            if demo.user_id == user_id:
                demonstrations.append(demo)
        
        # Sort by start time (newest first)
        demonstrations.sort(key=lambda d: d.start_time, reverse=True)
        
        return demonstrations[:limit]
    
    async def delete_demonstration(self, demo_id: str) -> bool:
        """
        Delete a demonstration.
        
        Args:
            demo_id: ID of the demonstration to delete
            
        Returns:
            True if deleted successfully
        """
        file_path = self.storage_path / f"{demo_id}.json"
        
        if file_path.exists():
            file_path.unlink()
            logger.info(f"Demonstration {demo_id} deleted")
            return True
        
        return False
    
    async def create_skill_from_demonstration(self, demo_id: str, skill_name: str, 
                                            skill_description: str = "",
                                            skill_category: str = "custom") -> Optional[str]:
        """
        Create a skill from a demonstration.
        
        This analyzes the recorded actions and creates a reusable skill.
        
        Args:
            demo_id: ID of the demonstration
            skill_name: Name for the new skill
            skill_description: Description of the skill
            skill_category: Category for the skill
            
        Returns:
            ID of the created skill, or None if failed
        """
        # Load the demonstration
        demo = await self.load_demonstration(demo_id)
        if not demo:
            logger.error(f"Demonstration {demo_id} not found")
            return None
        
        # Analyze the actions and extract patterns
        skill_definition = await self._analyze_demonstration(demo)
        
        # Add metadata
        skill_definition.update({
            "name": skill_name,
            "description": skill_description,
            "category": skill_category,
            "source": "demonstration",
            "source_id": demo_id,
            "created_at": datetime.now().isoformat()
        })
        
        # Create the skill
        skill_id = await self.skill_manager.create_skill(skill_definition)
        
        # Update demonstration with skill ID
        demo.skill_id = skill_id
        demo.status = "processed"
        await self._save_demonstration(demo)
        
        logger.info(f"Created skill {skill_id} from demonstration {demo_id}")
        
        return skill_id
    
    async def _analyze_demonstration(self, demo: Demonstration) -> Dict[str, Any]:
        """
        Analyze a demonstration and extract a skill definition.
        
        Args:
            demo: The demonstration to analyze
            
        Returns:
            Skill definition dictionary
        """
        if not demo.actions:
            return {"error": "No actions recorded in demonstration"}
        
        # Extract the workflow pattern
        workflow = self._extract_workflow(demo.actions)
        
        # Extract parameters
        parameters = self._extract_parameters(demo.actions)
        
        # Extract inputs/outputs
        inputs, outputs = self._extract_io(demo.actions)
        
        # Create skill definition
        skill_definition = {
            "workflow": workflow,
            "parameters": parameters,
            "inputs": inputs,
            "outputs": outputs,
            "actions": [
                {
                    "type": a.action_type,
                    "name": a.action_name,
                    "arguments_template": self._template_arguments(a.arguments)
                }
                for a in demo.actions
            ]
        }
        
        return skill_definition
    
    def _extract_workflow(self, actions: List[RecordedAction]) -> List[Dict[str, Any]]:
        """Extract workflow structure from actions."""
        workflow = []
        
        for action in actions:
            step = {
                "id": str(uuid.uuid4()),
                "type": action.action_type,
                "name": action.action_name,
                "description": self._generate_step_description(action)
            }
            
            # Add conditions if there are branching actions
            if self._has_conditions(action):
                step["conditions"] = self._extract_conditions(action)
            
            workflow.append(step)
        
        return workflow
    
    def _generate_step_description(self, action: RecordedAction) -> str:
        """Generate a human-readable description for an action."""
        if action.action_name == "send_message":
            return f"Send message to {action.arguments.get('channel', 'channel')}"
        elif action.action_name == "create_thread":
            return f"Create new thread with title: {action.arguments.get('title', 'Untitled')}"
        elif action.action_name == "api_call":
            return f"Call API: {action.arguments.get('path', 'unknown')}"
        else:
            return f"Execute {action.action_name}"
    
    def _has_conditions(self, action: RecordedAction) -> bool:
        """Check if an action has conditional logic."""
        # In a real implementation, analyze the context and metadata
        # to determine if this action is conditional
        return False
    
    def _extract_conditions(self, action: RecordedAction) -> Dict[str, Any]:
        """Extract conditional logic from an action."""
        return {}
    
    def _extract_parameters(self, actions: List[RecordedAction]) -> Dict[str, Dict[str, Any]]:
        """Extract parameters from actions."""
        parameters = {}
        
        # Look for variable patterns in arguments
        for action in actions:
            for key, value in action.arguments.items():
                if isinstance(value, str) and self._is_variable(value):
                    param_name = self._extract_variable_name(value)
                    if param_name not in parameters:
                        parameters[param_name] = {
                            "type": self._infer_type(value),
                            "description": f"Parameter extracted from {action.action_name}"
                        }
        
        return parameters
    
    def _is_variable(self, value: str) -> bool:
        """Check if a value is a variable reference."""
        # Simple check for variable patterns like {variable} or $variable
        return "{" in value and "}" in value or value.startswith("$")
    
    def _extract_variable_name(self, value: str) -> str:
        """Extract variable name from a variable reference."""
        if "{" in value and "}" in value:
            return value.strip("{}")
        elif value.startswith("$"):
            return value[1:]
        return value
    
    def _infer_type(self, value: str) -> str:
        """Infer the type of a parameter from its usage."""
        # Simple type inference
        if value.isdigit():
            return "integer"
        try:
            float(value)
            return "number"
        except ValueError:
            pass
        
        if value.lower() in ["true", "false"]:
            return "boolean"
        
        return "string"
    
    def _template_arguments(self, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """Convert concrete arguments to templated arguments."""
        templated = {}
        
        for key, value in arguments.items():
            if isinstance(value, str) and self._is_variable(value):
                # Keep as variable
                templated[key] = value
            else:
                # Replace with placeholder
                templated[key] = f"{{{key}}}"
        
        return templated
    
    def _extract_io(self, actions: List[RecordedAction]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Extract inputs and outputs from actions."""
        inputs = {}
        outputs = {}
        
        for i, action in enumerate(actions):
            # First action's inputs are skill inputs
            if i == 0:
                for key, value in action.arguments.items():
                    if not self._is_variable(value):
                        inputs[key] = {
                            "type": self._infer_type(str(value)),
                            "description": f"Input from {action.action_name}"
                        }
            
            # Last action's outputs are skill outputs
            if i == len(actions) - 1:
                if action.result:
                    outputs = {
                        "type": "object",
                        "properties": self._flatten_result(action.result)
                    }
        
        return inputs, outputs
    
    def _flatten_result(self, result: Dict[str, Any], prefix: str = "") -> Dict[str, Dict[str, Any]]:
        """Flatten a nested result dictionary."""
        flat = {}
        
        for key, value in result.items():
            full_key = f"{prefix}{key}" if prefix else key
            if isinstance(value, dict):
                flat.update(self._flatten_result(value, f"{full_key}."))
            else:
                flat[full_key] = {
                    "type": self._infer_type(str(value)),
                    "description": f"Output from result: {full_key}"
                }
        
        return flat
    
    async def test_skill_from_demonstration(self, demo_id: str, test_inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Test a skill created from a demonstration.
        
        Args:
            demo_id: ID of the demonstration
            test_inputs: Inputs to test with
            
        Returns:
            Test results
        """
        # Load the demonstration
        demo = await self.load_demonstration(demo_id)
        if not demo or not demo.skill_id:
            return {"error": "Demonstration not found or not processed"}
        
        # Run the skill with test inputs
        result = await self.skill_manager.run_skill(demo.skill_id, test_inputs)
        
        return {
            "demo_id": demo_id,
            "skill_id": demo.skill_id,
            "inputs": test_inputs,
            "result": result
        }
    
    async def get_demonstration_status(self, demo_id: str) -> Dict[str, Any]:
        """
        Get the status of a demonstration.
        
        Args:
            demo_id: ID of the demonstration
            
        Returns:
            Demonstration status
        """
        if demo_id in self._active_demonstrations:
            demo = self._active_demonstrations[demo_id]
            return {
                "status": demo.status,
                "start_time": demo.start_time.isoformat(),
                "action_count": len(demo.actions)
            }
        
        # Try loading from storage
        demo = await self.load_demonstration(demo_id)
        if demo:
            return {
                "status": demo.status,
                "start_time": demo.start_time.isoformat(),
                "end_time": demo.end_time.isoformat() if demo.end_time else None,
                "action_count": len(demo.actions),
                "skill_id": demo.skill_id
            }
        
        return {"error": "Demonstration not found"}
    
    # Public API for Nimbus integration
    async def start_recording(self, user_id: str, name: str = "", description: str = "") -> Dict[str, Any]:
        """Start a demonstration recording."""
        demo = await self.start_demonstration(user_id, name, description)
        return {
            "demo_id": demo.id,
            "status": demo.status,
            "start_time": demo.start_time.isoformat()
        }
    
    async def stop_recording(self, demo_id: str) -> Dict[str, Any]:
        """Stop a demonstration recording."""
        demo = await self.stop_demonstration(demo_id)
        if demo:
            return {
                "demo_id": demo.id,
                "status": demo.status,
                "action_count": len(demo.actions),
                "end_time": demo.end_time.isoformat()
            }
        return {"error": "Demonstration not found"}
    
    async def create_skill(self, demo_id: str, name: str, description: str = "", 
                         category: str = "custom") -> Dict[str, Any]:
        """Create a skill from a demonstration."""
        skill_id = await self.create_skill_from_demonstration(
            demo_id, name, description, category
        )
        if skill_id:
            return {"skill_id": skill_id, "demo_id": demo_id}
        return {"error": "Failed to create skill"}
    
    async def list_recordings(self, user_id: str, limit: int = 100) -> Dict[str, Any]:
        """List demonstration recordings for a user."""
        demos = await self.list_demonstrations(user_id, limit)
        return {
            "recordings": [
                {
                    "id": d.id,
                    "name": d.name,
                    "description": d.description,
                    "status": d.status,
                    "start_time": d.start_time.isoformat(),
                    "end_time": d.end_time.isoformat() if d.end_time else None,
                    "action_count": len(d.actions),
                    "skill_id": d.skill_id
                }
                for d in demos
            ]
        }
    
    async def get_recording(self, demo_id: str) -> Dict[str, Any]:
        """Get details of a demonstration recording."""
        demo = await self.load_demonstration(demo_id)
        if demo:
            return {
                "id": demo.id,
                "name": demo.name,
                "description": demo.description,
                "status": demo.status,
                "start_time": demo.start_time.isoformat(),
                "end_time": demo.end_time.isoformat() if demo.end_time else None,
                "action_count": len(demo.actions),
                "actions": [
                    {
                        "timestamp": a.timestamp.isoformat(),
                        "action_type": a.action_type,
                        "action_name": a.action_name,
                        "arguments": a.arguments,
                        "result": a.result
                    }
                    for a in demo.actions
                ],
                "skill_id": demo.skill_id
            }
        return {"error": "Recording not found"}
    
    async def delete_recording(self, demo_id: str) -> Dict[str, Any]:
        """Delete a demonstration recording."""
        success = await self.delete_demonstration(demo_id)
        if success:
            return {"status": "deleted", "demo_id": demo_id}
        return {"error": "Recording not found"}


# Factory function for Nimbus integration
def create_teach_by_demo(skill_manager, action_logger, storage_path: str = "data/teach_demos"):
    """Create a teach-by-demonstration instance for Nimbus."""
    return TeachByDemonstration(skill_manager, action_logger, storage_path)
