# 🛰️ Nimbus — a self-hosted, always-on agent platform

Nimbus is a working, open, self-hosted take on **xAI/Cursor's Grok Bot**: a team of named AI
agents that each get their own cloud computer (filesystem + shell + browser), connect to your
real apps (Google Drive, Docs, Sheets, Gmail, Calendar), remember things, learn reusable skills,
run on schedules and triggers, delegate to each other — and ask you before doing anything risky.

Nothing here is a mock-up: the tools really execute, the connectors really talk to Google, and
the whole thing runs from `./run.sh` with **zero API keys** (it falls back to a local demo model
plus a demo Google backend) and upgrades to real power the moment you paste a key.

```
┌──────────────────────────── you ────────────────────────────┐
│  web UI · REST API · SSE live activity · approvals          │
└───────────────────────────┬─────────────────────────────────┘
                            │
        ┌───────────────────▼───────────────────┐
        │  Runner: model → tools → model → …    │
        │  memory · skills · routines · review  │
        └───┬─────────┬─────────┬─────────┬─────┘
            │         │         │         │
     ┌──────▼──┐ ┌────▼────┐ ┌──▼─────┐ ┌─▼──────────────┐
     │ Agent A │ │ Agent B │ │ Agent C│ │ … each with its │
     │workspace│ │workspace│ │workspace│ │ own cloud dir   │
     └─────────┘ └─────────┘ └────────┘ └────────────────┘
            │         │         │         │
   ┌────────▼─────────▼─────────▼─────────▼───────────────┐
   │ 59 tools: files/shell · web · browser · Google · MCP  │
   └───────────────────────────────────────────────────────┘
```

---

## Interface design system

The UI is built on a small, enforced design system (`nimbus/web/styles.css`) — not a pile of one-off rules.

| Layer | Rule |
|---|---|
| **Surfaces** | A four-step ladder — `--s0 #080b11` (page) · `--s1 #0f1420` (shell) · `--s2 #161d2e` (content) · `--s3 #1e273e` (popovers, insets). Elevation comes from that lightness step plus a **1px top highlight** (`--hair`, `rgba(255,255,255,.06)`), never from a heavy outer border. |
| **Glow** | Soft radial gradients (page ambience, modal light, onboarding card, selected rows) sit *behind* content at low alpha. |
| **Contrast** | WCAG AA is a hard floor: `--dim #94a3b8` is the dimmest text in the product (5.8:1 worst case) — secondary/muted tones are #a7b3c6 and #cbd5e6. A test measures every text colour against every surface and fails below 4.5:1. |
| **Type** | One scale (`--fs-micro 11` → `--fs-3xl 32`), crisp tracking (`.08em` on uppercase labels, `-.014em` on headings), and `font-variant-numeric: tabular-nums` on stats, sizes, timestamps, badges and table cells so columns line up. |
| **Motion** | Every interactive transition is `150ms cubic-bezier(.16, 1, .3, 1)` (`--t`/`--ease`), with a 260ms variant for entrances. Hover lifts 1px, press settles back. `prefers-reduced-motion` disables all of it. |
| **Focus** | `:focus-visible` rings only for keyboard users, never clipped. |
| **Guardrails** | A test asserts every class the app renders is styled, that the four surface tokens and motion pair exist, and that no washed-out legacy grey (`#5f6a85`) can return. |

### The chrome — one bar that folds to the screen

The top bar is a three-column grid (`1fr auto 1fr`), so the tab strip stays in the optical centre no matter how wide the profile chip or the actions grow. It is one 56px row (`--topbar-h`) and it never changes height — that is what makes the mode switch a true zero-shift.

| Ask | How it is built |
|---|---|
| **Identity + status, merged into one chip** | The loose `name · model · status · connection` badges became a single **`.agent-chip`**: mark, name, live state and a connection dot in one `<button>` with `aria-haspopup`/`aria-expanded`. It opens `.chip-pop` — **Model · Google connection · approval policy** — plus *Edit agent* and *Details*. Everything technical moved into the popover, so nothing inside the 38px chip (`--chip-h`) ever grows. |
| **Secondary actions, folded** | `#btnDetails` and 📡 sit in `.act-inline`; below **1200px** that row disappears and **⋯** (`#btnOverflow`) takes its place with **Details · Live activity · Approvals · Agents** — the same actions, wired through `[data-mirror]` buttons, so nothing is ever unreachable on a phone. |
| **Tabs that scroll cleanly** | `#tabs` is a filmstrip: `overflow-x: auto` with `scrollbar-width: none` and `::-webkit-scrollbar { display: none }`. The soft edge fade (`mask-image`) is applied **only while the strip really overflows** — `.scrollable`, set by a `ResizeObserver` — so it never looks half-cut, and `scroll-snap-type: x proximity` plus `scrollTabIntoView()` bring the active tab into view when you pick one from *More*. |
| **Zero layout shift** | Details mode swaps the two label lengths (*Details* ⇄ *Simple*), so `#btnDetails`/`#chipDetails` are pinned to `min-width: 78px` — one box, two labels. `.hintrow` is nailed to 16px, the chip's contents do not depend on the mode, and the chat re-render is re-anchored to **the message that was at the top of the viewport** (`captureScrollAnchor`/`restoreScrollAnchor`), not to a scroll offset — so adding developer telemetry moves nothing you can see. |

| Width | What changes |
|---|---|
| **> 1200px** | Everything inline; the activity drawer docks at 400px beside the transcript. |
| **≤ 1200px** | `.act-inline` → overflow menu **⋯**. |
| **≤ 1080px** | Two deterministic rows (`left + actions`, then `tabs`); **☰** appears and the sidebar becomes a **slide-over** above the blurred `#scrim`; menus become bottom sheets; the scrim closes on any outside tap. |
| **≤ 900px / ≤ 560px** | The chip sheds label width first, then its status text and dot — always inside the same 38px box. |
| **≤ 767px** | `#drawer` becomes a **bottom sheet**: grip + header drag (`setPointerCapture`), a `62vh` peek, `92vh` when expanded, rubber-band upward, dismiss on `dy > height × 0.3` or a downward flick past `0.65 px/ms`, tap the scrim to close. |

The sidebar can also be swiped away horizontally (≥70px or 0.5 px/ms) — with a `|dx| > |dy| × 1.4` gate, so vertical scrolling inside it still works.

Open **`/layout`** — or `nimbus/web/layout_demo.html` straight from disk, it needs no server — for the chrome reference page: the production stylesheet (§1–§7 + §10–§11) inlined verbatim, EN/中文/ES labels, and a read-out panel that measures its own geometry and reports every box that moved. Generated by `python3 tools/build_layout_demo.py`; a test rebuilds it like the other demo, so it cannot drift.

### The composer — one box, four behaviours

`nimbus/web/composer.js` (vanilla, ~600 lines) owns everything below the transcript; `app.js` only hands it the agent, the workspace and the things only the app knows (`send`, `/delegate` list, `/skill` list, `/clear`).

| Behaviour | How it works |
|---|---|
| **Auto-expanding input** | Starts at exactly **44px** (one line) and grows to **200px**, then scrolls — `min-height: 44px; max-height: 200px` in CSS plus `field-sizing: content` where the browser supports it. Elsewhere the component measures `scrollHeight` from `0px` on each input, clamps with `fitHeight()`, writes the height only when it changed (so the transcript never jitters) and adds `.capped` once the cap is hit. The chat stays pinned to the bottom while it grows. An **empty** box is pinned by hand (`autoGrow` writes `MIN_H`, and `field-sizing` only applies to `:not(:placeholder-shown)`), because a longer placeholder — another language, a wider window — would otherwise size the textarea. And a re-render (a new message, a mode flip) carries the draft and the caret with it. |
| **Attachments** | 📎 button, **drag-and-drop over the whole chat area** (`.dropzone` overlay, depth-counted so it can't flicker), and paste-to-upload. Files stream to the agent workspace through `XMLHttpRequest` — the only API that reports *upload* progress — with a per-file row: name, size, **progress bar**, percentage, cancel (✕). On success the row turns green and `[Uploaded: name.ext]` is inserted at the caret. Over-limit files are refused before they touch the wire; the 512 MB cap is the same one the Files tab enforces. |
| **Slash commands** | Typing `/` at the start of a line opens a floating popover listing **/delegate [agent] · /skill [name] · /routine · /clear**. It filters as you type, ↑↓ walks the list, Enter or Tab accepts, and the argument commands drill into a second list (your agents, the team's skills) before inserting a prompt template. `/clear` starts a fresh thread instead of typing anything. |
| **Keyboard model** | Enter sends, Shift+Enter breaks the line, Esc closes the popover (or the drag overlay) without eating your text, ↑ recalls earlier messages from an empty caret. The footer shows all of it as `<kbd>` chips so nothing is a hidden trick. |

Open **`/demo`** §4 for a live playground of the composer (uploads are simulated there so the page still works offline).

### Chat components — how the three renderers are built

Everything the chat draws lives in `nimbus/web/components.js` (vanilla JS, no framework, ~500 lines) and §8 of `styles.css`. `nimbus/web/app.js` only wires SSE events into them.

| Component | What it does | Where it lives |
|---|---|---|
| **Expandable tool stepper** | Consecutive tool calls collapse into one pill — *“Executed 3 tools: Searched Drive “Q3 revenue” › Read Q3-revenue.xlsx › Wrote summary.md”*. It pulses while a call is in flight and expands into a per-step transcript of arguments and outputs (secrets masked, results clipped to 4 KB). Runs of the same action collapse to `Searched Drive ×2`. | `NB.ToolStepper` · `.stepper*`, `.step-item`, `.arg-row`, `.step-out` |
| **Approval card** | Glass banner (`backdrop-filter: blur(16px) saturate(1.3)`) with a Low/Medium/High badge carrying a 3-bar meter, a change viewer (line diff for edits, `$ command` block for shell), an argument list, and exactly three choices: **Allow once · Always allow · Reject**. After a decision the body collapses into a status strip with a *Details* link. | `NB.tpl.approval()` / `NB.tpl.resolved()` · `.appr*`, `.diff`, `.appr-cmd` |
| **Rich streaming bubble** | Text is revealed a few characters per animation frame with a blinking caret, and the newest characters fade in once (`.chunk`). The view follows only while the reader is already at the bottom — scroll up and it stays exactly where you left it, with a *Jump to newest* chip to come back. | `NB.Typer` · `.cursor`, `.chunk`, `.jump-latest` |

Two extra safety behaviours come with them: **Always allow** writes a per-agent rule (`POST /api/agents/{id}/tool-rules`) that `needs_approval()` consults *before* the policy — so the next call with that tool runs without asking, even if it is high-risk; and every rule change is written to the audit log.

Open **`/demo`** (or `nimbus/web/components-demo.html` straight from disk — it runs offline) for a live, trilingual playground of all three: replay a tool run, try the three risk banners, stream a reply while scrolled up. That page is generated by `python3 tools/build_demo.py`, which inlines `components.js`, §8 of the stylesheet and the sample strings from `i18n.js` — a test rebuilds it on every run, so the reference page can never drift from the shipped code.

---

## Simple by default — you don't need to learn the platform first

Nimbus opens in **Simple mode**: four tabs, plain-language labels, and a three-step
*Get started* checklist. Everything advanced is one click away, never in the way.

| What you see | Where the detail went |
|---|---|
| **4 tabs** — Chat, Files, Automations, Setup | Skills, Memory, Activity and Audit live under **⋯ More** (Automations holds Routines *and* Skills behind a Routines/Skills switch) |
| **Plain words for work** — “Searched Google Drive”, “Wrote a file”, “Sent an email” | The **Details** button (top-right, remembered per browser) shows raw tool names, arguments, timings and output |
| **A short thread list** (5 most recent) | “Show all N” expands it |
| **A 3-step checklist** in the first empty chat | ✕ Hide dismisses it; *Show getting started* brings it back |
| **Settings** — language, Google, one API key, one safety question | **Advanced** (collapsed) holds MCP servers, the data folder, tool inventory and provider endpoints |
| **A hint line under the composer**, no approval/MCP chatter | Details mode restores the policy line and model badge |

On a phone the sidebar becomes a ☰ slide-over and the tabs scroll horizontally, so the same
simple layout works at 380 px.

```text
Get started →  1. Give your agents a brain        [Add an AI model]
               2. Connect your Google account     [Connect Google]
               3. Try your first task            (type it, or tap an example)
```

Every label above is translated — Simple mode and the checklist render in English, 中文 and Español.

---

## Languages — English · 中文（简体）· Español

The whole platform is localised, not just the buttons. One setting (**Settings → Language**, or
`NIMBUS_LANGUAGE` in `.env`) controls two things:

| Layer | What the setting does |
|---|---|
| **Interface** | Every screen — chat, files, skills, routines, memory, activity, audit, setup — plus toasts, modals, relative times and validation messages. |
| **Your agents** | The language agents *work in*: chat replies, document content, email bodies, summaries and file contents. Tool names, file names, URLs, IDs and code stay untouched. |

Four options: **English**, **中文（简体）**, **Español**, and **Auto** — match whatever language the user
writes in, per message.

* **Per-agent override** — click an agent's name in the top bar (or create a new agent) to give it its
  own language; e.g. the UI in Chinese while your English-writing agent keeps producing English docs.
* **Offline demo model included** — the built-in mock model is localised too (including Chinese and
  Spanish trigger phrases like *搜尋 / 总结 / resumen / correo*), so you can try both languages with no API key.
* **Shipped translations** — `nimbus/web/i18n.js` (≈395 UI keys × 3 languages, including friendly
  labels for all 59 tools in Simple mode). A test asserts every key
  the UI uses exists in every language with matching `{placeholders}`, so translations can't silently rot.

```bash
# in .env, or just click it in the UI
NIMBUS_LANGUAGE=zh        # en | zh | es | auto
```

Add a language by dropping a block into `nimbus/web/i18n.js` and an entry into `LANGUAGES` in
`nimbus/config.py` — the agent prompt rule follows automatically.

---

## 1. Quickstart (60 seconds)

```bash
cd nimbus
./run.sh                 # creates .venv, installs deps, starts on http://localhost:8000
```

Open <http://localhost:8000>. The first launch auto-creates a starter fleet
(**Scout** research · **Quill** docs · **Ledger** inbox · **Ops** automation), a morning-brief
routine and an inbox-triage skill.

Everything works immediately with **no keys**: the offline demo model drives the real tools
(including multi-step chains like *search → write a file*), and the Google connector runs against a
local demo Drive/Docs/Sheets/Gmail/Calendar.

Add a real brain whenever you want — either in **Settings → Model providers** (saved, encrypted) or in `.env`:

```bash
cp .env.example .env
# XAI_API_KEY=xai-…            # or OPENAI_/ANTHROPIC_/OPENROUTER_/GROQ_/DEEPSEEK_…
```

Other ways to run:

```bash
docker compose up --build          # Docker
python -m nimbus.server            # plain python (after pip install -r requirements.txt)
pytest -q                          # 57 tests: tools, Google, uploads, YouTube, approvals, tool rules, streaming, composer, chrome, layout, i18n, API, design system
```

Real browser control (optional, ~300 MB):

```bash
pip install playwright && playwright install chromium
```

---

## File size limits — and yes, you can hand it a link

### How big can a file be?

Everything about transfers is explicit and configurable (`.env`, then restart):

| Path | Default ceiling | Notes |
|---|---|---|
| **Upload into an agent's workspace** (Files tab, `POST /api/agents/{id}/upload`) | **512 MB per file** (`NIMBUS_MAX_UPLOAD_MB`) | Streamed to disk in 4 MB chunks — a 400 MB upload never has to fit in memory — and it never leaves your machine. The Files tab shows the current limit; a bigger file is rejected with a friendly message, not a broken upload. |
| **Download into the workspace** (`download_file` tool, web → workspace) | **1024 MB** (`NIMBUS_MAX_DOWNLOAD_MB`) | Refuses up front when `Content-Length` is over the limit, and deletes the partial file if the server lied. |
| **In-app text viewer** | **4 MB** (`NIMBUS_MAX_PREVIEW_MB`) | The agent itself reads files with `read_file` (paged with `offset`/`limit`), so this only affects the preview pane. |
| **Upload to Google Drive** (`gdrive_upload`) | Files over **5 MB** automatically switch to Drive's **resumable** upload (`NIMBUS_DRIVE_RESUMABLE_MB`), so large files work over flaky connections. | Drive itself allows up to 5 TB per file. |
| **Gmail attachment** (`gmail_send_email`) | **25 MB** — Google's own hard limit | Nimbus checks before sending and tells the agent to upload to Drive and send the link instead. |

```bash
# .env
NIMBUS_MAX_UPLOAD_MB=512        # raise for media work
NIMBUS_MAX_DOWNLOAD_MB=1024
```

### "Summarise this video for me" — yes

Paste any YouTube link (or a bare video id) into chat and the agent reads the **transcript** —
`youtube_transcript` in the tool list, plus `fetch_url` hands video URLs to it automatically:

```text
Summarise this video: https://youtu.be/dQw4w9WgXcQ
Pull the 3 main arguments from https://www.youtube.com/watch?v=… and save them to a Google Doc
What does the video say between 12:00 and 18:30?   → start/end slicing
Quote the exact lines about pricing                  → timestamps=true gives [mm:ss] markers
```

It works in three layers: the watch page's caption tracks → `yt-dlp` (`--skip-download`, subtitles
only — no audio or video is ever downloaded) → metadata only (title, channel, duration,
description) when a video has captions disabled, which the agent reports honestly instead of
inventing a summary. Every request takes a `lang` argument, so a Chinese or Spanish video can be
read in its own language and summarised in yours.

Ordinary links work too: `fetch_url` for pages and APIs, `browser_open` when a page needs a real
browser (logins, infinite scroll, JS-only content).

---

## 2. Capability parity with Grok Bot

| Grok Bot capability | Nimbus | Where |
|---|---|---|
| Named agents, each with its own cloud computer | ✅ per-agent jailed workspace `data/workspaces/<id>/` + shell + browser | `store.workspace_path`, `tools/workspace.py` |
| Persistent cloud VM that keeps working when your laptop is off | ✅ runs as a local/remote service; routines fire in the background | `scheduler.py` |
| Browser / computer use on sites with no API | ✅ real Playwright control: open, snapshot elements, click, type, scroll, screenshot | `tools/browser.py` |
| Google Drive / Docs / Sheets connectors | ✅ real OAuth2 + native Docs/Sheets REST (markdown → real Docs styles) | `google_api.py` |
| Gmail + Calendar (incl. attachments) | ✅ list/read/send/draft with attachments; events list/create | `tools/google.py` |
| OneDrive / Outlook / Teams / SharePoint / Salesforce | ⚠️ by design out of scope — add via MCP or a connector module | `mcp_client.py` |
| MCP servers (stdio + HTTP) | ✅ tools auto-registered as `mcp__server__tool` | `mcp_client.py` |
| Skills learned from a demonstrated task | ✅ “🎓 Teach from this thread” → model writes the SOP; agents can also `update_skill` themselves | `/api/agents/{id}/teach`, `tools/skills.py` |
| Routines on schedules **and** events | ✅ cron, interval, event triggers + `POST /api/events` webhook | `scheduler.py` |
| Agent-to-agent delegation by description | ✅ `list_team` / `delegate_task` with linked handoff threads | `tools/delegation.py` |
| Agent can spawn new teammates | ✅ `spawn_agent` (build a whole fleet from a prompt) | `tools/delegation.py` |
| Approvals + “Auto Review” layer | ✅ risky/all/auto policies + optional reviewer-model gate that can allow/ask/block | `approvals.py` |
| Link & video reading | ✅ `fetch_url` / `browser_open` for pages, `youtube_transcript` for videos (transcript, slices, timestamps) | `nimbus/youtube.py`, `tools/web.py` |
| Big files | ✅ 512 MB uploads (streamed, configurable), 1 GB tool downloads, Drive resumable uploads | `NIMBUS_MAX_UPLOAD_MB`, `/api/upload` |
| Inspectable memory | ✅ `remember` / `recall` / `forget`, per-agent or team scope, editable in the UI | `tools/memory.py`, ⋯ More → Memory |
| Audit trail | ✅ every tool call, approval, delegation, routine run in `data/nimbus.db` | `/api/audit`, ⋯ More → Audit |
| Model choice | ✅ **better than Grok Bot**: xAI, OpenAI, Anthropic, OpenRouter, Groq, DeepSeek, any OpenAI-compatible endpoint, local Ollama/LM Studio — per agent | `llm.py`, `config.PROVIDERS` |
| Multi-channel command surface | ✅ web UI + REST + SSE; no email/Slack/phone channels (yet) | `server.py` |
| Cost / lock-in | ✅ free, open, self-hosted, bring-your-own-model, your data stays in `data/` | — |

**Deliberate gaps:** Nimbus is single-user (no multi-tenant accounts/SSO), it has no mobile app,
and it does not ship Microsoft/Salesforce connectors — those are reachable through MCP.

---

## 3. What an agent can actually do

* **Research & write** — `web_search` (Tavily/Brave key optional, DuckDuckGo fallback), `fetch_url`,
  then produce a Google Doc with real headings/bullets/bold, or a file in its workspace.
* **Files & code** — read/write/edit/search files, download URLs, run shell commands (jailed to its
  workspace, destructive/network commands blocked or gated), inspect results, iterate.
* **Google Workspace** — search Drive, read Docs/Sheets/Slides as text, create folders, upload with
  optional conversion to native Docs, append to Docs, read/write/append Sheets, triage Gmail and
  draft/send replies with attachments, create calendar events.
* **Websites** — drive a real headless browser when there’s no API: open → snapshot numbered
  elements → click/type → screenshot (screenshots appear inline in the chat).
* **Memory** — remembers preferences and decisions across threads, and can share them team-wide.
* **Skills** — replays a learned SOP, and self-improves it when a run reveals a better way.
* **Schedules & triggers** — “every weekday 08:00 write me a brief”, or “when `file.upload` happens,
  summarise the new file”.
* **Teamwork** — a boss agent can brief a specialist, a spawned agent can join the fleet, and the
  UI shows the handoff threads.

### Try these prompts

Start with one of the four examples on the empty chat screen — they work with **zero setup**:

```
What changed in my Google Drive this week?
Research today's AI news and save a short note.
Plan my week in a Google Doc.
Summarise this video: https://youtu.be/dQw4w9WgXcQ
```

Then, once you have a real model key or a live Google account:

```
Read the Q3 Business Review doc in my Drive and create a one-page exec summary in Google Docs.
Check my inbox for anything urgent this week, draft replies, and append a triage row to a new Sheet.
Research what's new in AI agents, then write a sourced brief into a Doc and email me the link.
Open Hacker News in the browser, screenshot the front page, and save the top 5 titles to a CSV.
Build a team: a researcher, a writer and an engineer. Have them produce a launch plan together.
Every weekday at 8am, send me a brief: calendar for today + inbox highlights. (routine)
```

---

## 4. Connect your real Google account

The connectors run in **demo mode** until you add OAuth credentials.

1. <https://console.cloud.google.com> → create/pick a project.
2. **APIs & Services → Library** → enable: *Google Drive API*, *Google Docs API*, *Google Sheets
   API*, *Gmail API*, *Google Calendar API*.
3. **APIs & Services → OAuth consent screen** → External → add yourself as a *Test user*
   (apps in “Testing” don’t need verification).
4. **Credentials → Create credentials → OAuth client ID → Web application**, and add the redirect URI:
   `http://localhost:8000/api/google/callback`
5. In Nimbus → **Settings → Connectors → Google Workspace**: paste `GOOGLE_CLIENT_ID` and
   `GOOGLE_CLIENT_SECRET`, **Save**, then click **Connect Google account** and approve.

Tokens are encrypted at rest (Fernet key in `data/.secret_key`); revoke any time with
**Disconnect**, or from your Google account’s third-party access page.

---

## 5. API in 30 seconds

```bash
# run a task on an agent and get the answer back
curl -X POST localhost:8000/api/task -H 'content-type: application/json' \
  -d '{"agent_id":"<id>","text":"Summarise my Drive changes this week into a Doc","wait":true}'

# fire an event that event-routines react to (webhooks, CI, mail rules…)
curl -X POST localhost:8000/api/events -H 'content-type: application/json' \
  -d '{"kind":"invoice.received","payload":{"amount":12480}}'

# watch everything live (SSE)
curl -N localhost:8000/api/stream?all=1
```

Full OpenAPI docs: <http://localhost:8000/api/docs>

| Method | Path | Purpose |
|---|---|---|
| GET/POST/PATCH/DELETE | `/api/agents` | manage agents (model, tools, persona, approval policy) |
| POST | `/api/threads/{id}/messages` | send a message; live events arrive over SSE |
| POST | `/api/task` | one-shot task (wait or fire-and-forget) |
| GET/POST | `/api/approvals` | the human side of the approval gate |
| GET/POST/PATCH/DELETE | `/api/skills`, `/api/routines` | learned procedures & schedules |
| POST | `/api/agents/{id}/teach` | turn a finished thread into a skill |
| GET/PATCH/DELETE | `/api/agents/{id}/files…` | browse/download/upload the agent workspace |
| GET/POST/DELETE | `/api/memory`, `/api/mcp` | long-term memory, MCP servers |
| GET/POST | `/api/settings` | approval policy, language, provider keys |
| GET | `/api/system` | versions, providers, tool catalogue, `language` + `languages` |
| GET | `/api/audit`, `/api/stats`, `/api/runs` | audit log, fleet stats, routine history |
| POST | `/api/events` | external triggers for event routines |

---

## 6. Architecture

```
nimbus/
  agent.py         the reasoning loop (system prompt, tool execution, approvals, streaming)
  llm.py           multi-provider streaming + tool calls (OpenAI-shaped, Anthropic, offline mock)
  approvals.py     policy engine + Auto Review (reviewer model) + human approval futures
  scheduler.py     cron/interval/event routines, background execution
  mcp_client.py    MCP stdio + HTTP client, dynamic tool bridging
  google_api.py    OAuth2 + Drive/Docs/Sheets/Gmail/Calendar, and the demo backend
  tools/           workspace · web · browser · google · memory · skills · delegation
  server.py        FastAPI: REST, SSE, static UI
  db.py / store.py SQLite persistence, jails, typed helpers
  crypto.py        encrypted secrets at rest
  web/             zero-build web UI + i18n.js (English / 中文 / Español dictionaries)
data/
  nimbus.db        agents, threads, messages, audit, skills, routines, approvals, memories
  workspaces/<id>/ each agent's cloud computer
  demo_google/     demo Drive/Docs/Sheets/Gmail/Calendar (used until you connect real Google)
```

**Safety model**

* Every file/shell operation is confined to the agent’s workspace (`resolve_in_workspace` refuses
  traversal); shell network commands are blocked by default.
* `run_command` refuses destructive patterns; risky tools (sending mail, deleting, clicking in the
  browser, spawning agents) trigger the approval gate; policies are per-agent
  (`risky` default, `all`, or `auto`).
* Optional **Auto Review**: mark an agent as reviewer and its model adjudicates high-risk actions
  before you’re asked — allow / ask / block — with the verdict written to the audit log.
* Everything is logged: tool, arguments, risk, actor, result — in one SQLite file you own.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|---|
| Agents answer in the wrong language | Check **Settings → Language**, then check that agent's own language override (click its name in the top bar). |
|---|---|
| “Model error — connection failed” | The agent is pointed at a provider without a key/endpoint. Settings → Model providers, or switch the agent’s model to the offline demo model. |
| Google actions “recorded locally” | You’re in demo mode — add OAuth credentials (§4) to go live. |
| “browser control needs Playwright” | `pip install playwright && playwright install chromium` |
| Search returns nothing | Add `TAVILY_API_KEY` or `BRAVE_API_KEY` — the keyless DuckDuckGo endpoint rate-limits. |
| Agent seems to ignore a tool | Check the agent’s tool list (Agents → edit) — tools are per-agent. |
| Want a harder approval gate | Set the agent’s policy to `all`, or make a reviewer agent for Auto Review. |

---

Built to be extended: add a tool by dropping a `Tool` subclass into `nimbus/tools/`, add a
provider by adding an entry to `PROVIDERS` in `config.py`, add a connector by wrapping an API in a
module like `google_api.py`. MIT-style: it’s your code now.
