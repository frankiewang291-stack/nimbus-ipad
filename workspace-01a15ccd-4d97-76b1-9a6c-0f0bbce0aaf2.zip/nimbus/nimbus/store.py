"""
Typed helpers over the SQLite layer + per-agent virtual workspaces.

Every agent gets its own jailed workspace directory:
    data/workspaces/<agent_id>/
File, shell and download tools can never escape it.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from . import db
from .config import settings

# --------------------------------------------------------------------- helpers


def _dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)


def slugify(text: str, fallback: str = "agent") -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "-", (text or "").strip().lower()).strip("-")
    return s[:40] or fallback


# ---------------------------------------------------------------------- agents

FIELDS = ("name", "title", "description", "provider", "model", "persona", "emoji",
          "tools", "approval_mode", "temperature", "max_iterations", "can_delegate",
          "is_reviewer", "status", "language")


def hydrate_agent(row: dict | None) -> dict | None:
    if not row:
        return None
    row["tools"] = db.json_load(row.get("tools"), [])
    row["can_delegate"] = bool(row.get("can_delegate"))
    row["is_reviewer"] = bool(row.get("is_reviewer"))
    row["workspace"] = str(workspace_path(row["id"]))
    return row


def create_agent(
    name: str,
    *,
    title: str = "",
    description: str = "",
    provider: str = "",
    model: str = "",
    persona: str = "",
    emoji: str = "🤖",
    tools: list[str] | None = None,
    approval_mode: str = "inherit",
    temperature: float = 0.3,
    max_iterations: int = 12,
    can_delegate: bool = True,
    language: str = "inherit",
) -> dict:
    from .config import default_model, default_provider
    from .tools import all_tool_names

    agent_id = db.new_id()
    ts = db.now()
    db.insert(
        "agents",
        {
            "id": agent_id,
            "name": name,
            "title": title,
            "description": description,
            "provider": provider or default_provider(),
            "model": model or default_model(),
            "persona": persona,
            "emoji": emoji,
            "tools": _dumps(list(tools) if tools is not None else all_tool_names()),
            "approval_mode": approval_mode,
            "temperature": float(temperature),
            "max_iterations": int(max_iterations),
            "can_delegate": 1 if can_delegate else 0,
            "is_reviewer": 0,
            "language": language or "inherit",
            "status": "idle",
            "created_at": ts,
            "updated_at": ts,
        },
    )
    workspace_path(agent_id)  # create dir
    return get_agent(agent_id)  # type: ignore[return-value]


def get_agent(agent_id: str) -> dict | None:
    return hydrate_agent(db.q1("SELECT * FROM agents WHERE id=?", (agent_id,)))


def list_agents() -> list[dict]:
    return [hydrate_agent(r) for r in db.q("SELECT * FROM agents ORDER BY created_at")]  # type: ignore[misc]


def update_agent(agent_id: str, patch: dict) -> dict | None:
    clean = {k: v for k, v in patch.items() if k in FIELDS}
    if "tools" in clean:
        clean["tools"] = _dumps(clean["tools"])
    if "can_delegate" in clean:
        clean["can_delegate"] = 1 if clean["can_delegate"] else 0
    if "is_reviewer" in clean:
        clean["is_reviewer"] = 1 if clean["is_reviewer"] else 0
    if clean:
        sets = ", ".join(f"{k}=?" for k in clean)
        db.x(f"UPDATE agents SET {sets}, updated_at=? WHERE id=?", list(clean.values()) + [db.now(), agent_id])
    return get_agent(agent_id)


def delete_agent(agent_id: str) -> None:
    for table in ("agents", "threads", "skills", "routines", "memories"):
        col = "id" if table == "agents" else "agent_id"
        db.x(f"DELETE FROM {table} WHERE {col}=?", (agent_id,))
    for row in db.q("SELECT id FROM threads WHERE agent_id=?", (agent_id,)):
        db.x("DELETE FROM messages WHERE thread_id=?", (row["id"],))
    db.x("DELETE FROM approvals WHERE agent_id=?", (agent_id,))


def agent_by_name(name: str) -> dict | None:
    row = db.q1("SELECT * FROM agents WHERE lower(name)=lower(?)", (name.strip(),))
    return hydrate_agent(row)


# --------------------------------------------------------------------- threads


def create_thread(agent_id: str, title: str = "New thread", kind: str = "chat",
                  parent_thread_id: str | None = None) -> dict:
    tid = db.new_id()
    ts = db.now()
    db.insert("threads", {
        "id": tid, "agent_id": agent_id, "title": title[:120], "kind": kind,
        "parent_thread_id": parent_thread_id or "", "status": "idle", "meta": "{}",
        "created_at": ts, "updated_at": ts,
    })
    return get_thread(tid)  # type: ignore[return-value]


def get_thread(thread_id: str) -> dict | None:
    row = db.q1("SELECT * FROM threads WHERE id=?", (thread_id,))
    if row:
        row["meta"] = db.json_load(row.get("meta"), {})
    return row


def list_threads(agent_id: str | None = None, limit: int = 200) -> list[dict]:
    if agent_id:
        rows = db.q("SELECT * FROM threads WHERE agent_id=? ORDER BY updated_at DESC LIMIT ?", (agent_id, limit))
    else:
        rows = db.q("SELECT * FROM threads ORDER BY updated_at DESC LIMIT ?", (limit,))
    for r in rows:
        r["meta"] = db.json_load(r.get("meta"), {})
    return rows


def update_thread(thread_id: str, patch: dict) -> None:
    patch = dict(patch)
    if "meta" in patch:
        patch["meta"] = _dumps(patch["meta"])
    if not patch:
        return
    sets = ", ".join(f"{k}=?" for k in patch)
    db.x(f"UPDATE threads SET {sets}, updated_at=? WHERE id=?", list(patch.values()) + [db.now(), thread_id])


def delete_thread(thread_id: str) -> None:
    db.x("DELETE FROM messages WHERE thread_id=?", (thread_id,))
    db.x("DELETE FROM threads WHERE id=?", (thread_id,))


def latest_thread(agent_id: str) -> dict | None:
    rows = list_threads(agent_id, limit=1)
    return rows[0] if rows else None


# -------------------------------------------------------------------- messages


def add_message(thread_id: str, role: str, content: str = "", *,
                tool_calls: list | None = None, tool_call_id: str = "",
                name: str = "", meta: dict | None = None) -> dict:
    mid = db.new_id()
    db.insert("messages", {
        "id": mid, "thread_id": thread_id, "role": role, "content": content or "",
        "tool_calls": _dumps(tool_calls or []), "tool_call_id": tool_call_id or "",
        "name": name or "", "meta": _dumps(meta or {}), "created_at": db.now(),
    })
    db.x("UPDATE threads SET updated_at=? WHERE id=?", (db.now(), thread_id))
    return get_message(mid)  # type: ignore[return-value]


def get_message(message_id: str) -> dict | None:
    row = db.q1("SELECT * FROM messages WHERE id=?", (message_id,))
    return hydrate_message(row)


def hydrate_message(row: dict | None) -> dict | None:
    if not row:
        return None
    row["tool_calls"] = db.json_load(row.get("tool_calls"), [])
    row["meta"] = db.json_load(row.get("meta"), {})
    return row


def list_messages(thread_id: str, limit: int = 500) -> list[dict]:
    rows = db.q("SELECT * FROM messages WHERE thread_id=? ORDER BY created_at, rowid LIMIT ?", (thread_id, limit))
    return [hydrate_message(r) for r in rows]  # type: ignore[misc]


def delete_message(message_id: str) -> None:
    db.x("DELETE FROM messages WHERE id=?", (message_id,))


# ------------------------------------------------------------------------ runs


def create_run(routine_id: str, agent_id: str, thread_id: str) -> str:
    return db.insert("runs", {
        "id": db.new_id(), "routine_id": routine_id, "agent_id": agent_id,
        "thread_id": thread_id, "status": "running", "result": "", "error": "",
        "started_at": db.now(), "finished_at": None,
    })


def finish_run(run_id: str, status: str, result: str = "", error: str = "") -> None:
    db.x("UPDATE runs SET status=?, result=?, error=?, finished_at=? WHERE id=?",
         (status, (result or "")[:8000], (error or "")[:2000], db.now(), run_id))


def list_runs(limit: int = 100) -> list[dict]:
    return db.q("SELECT * FROM runs ORDER BY started_at DESC LIMIT ?", (limit,))


# ------------------------------------------------------------------- approvals


def create_approval(agent_id: str, thread_id: str, tool: str, args: dict,
                    reason: str = "", risk: str = "medium") -> dict:
    aid = db.new_id()
    db.insert("approvals", {
        "id": aid, "agent_id": agent_id, "thread_id": thread_id, "tool": tool,
        "args": _dumps(args), "reason": reason, "risk": risk, "status": "pending",
        "note": "", "created_at": db.now(), "decided_at": None,
    })
    return get_approval(aid)  # type: ignore[return-value]


def get_approval(approval_id: str) -> dict | None:
    row = db.q1("SELECT * FROM approvals WHERE id=?", (approval_id,))
    if row:
        row["args"] = db.json_load(row.get("args"), {})
    return row


def list_approvals(status: str | None = "pending", limit: int = 100) -> list[dict]:
    if status:
        rows = db.q("SELECT * FROM approvals WHERE status=? ORDER BY created_at DESC LIMIT ?", (status, limit))
    else:
        rows = db.q("SELECT * FROM approvals ORDER BY created_at DESC LIMIT ?", (limit,))
    for r in rows:
        r["args"] = db.json_load(r.get("args"), {})
    return rows


def decide_approval(approval_id: str, status: str, note: str = "") -> dict | None:
    db.x("UPDATE approvals SET status=?, note=?, decided_at=? WHERE id=?",
         (status, note, db.now(), approval_id))
    return get_approval(approval_id)


# ----------------------------------------------------------------- tool rules


def get_tool_rule(agent_id: str, tool: str) -> dict | None:
    return db.q1("SELECT * FROM tool_rules WHERE agent_id=? AND tool=?", (agent_id or "", tool))


def has_tool_rule(agent_id: str, tool: str) -> bool:
    """True when the user said 'Always allow' for this agent + tool."""
    row = get_tool_rule(agent_id, tool)
    return bool(row and (row.get("action") or "allow") == "allow")


def list_tool_rules(agent_id: str = "", limit: int = 200) -> list[dict]:
    if agent_id:
        return db.q("SELECT * FROM tool_rules WHERE agent_id=? ORDER BY created_at DESC LIMIT ?",
                    (agent_id, limit))
    return db.q("SELECT * FROM tool_rules ORDER BY created_at DESC LIMIT ?", (limit,))


def add_tool_rule(agent_id: str, tool: str, action: str = "allow", note: str = "") -> dict:
    """Idempotent: one row per agent + tool, updated in place."""
    existing = get_tool_rule(agent_id, tool)
    if existing:
        db.x("UPDATE tool_rules SET action=?, note=?, created_at=? WHERE id=?",
             (action, note, db.now(), existing["id"]))
    else:
        db.insert("tool_rules", {"id": db.new_id(), "agent_id": agent_id or "", "tool": tool,
                                 "action": action, "note": note, "created_at": db.now()})
    return get_tool_rule(agent_id, tool)  # type: ignore[return-value]


def remove_tool_rule(agent_id: str, tool: str) -> bool:
    row = get_tool_rule(agent_id, tool)
    if not row:
        return False
    db.x("DELETE FROM tool_rules WHERE id=?", (row["id"],))
    return True


# ----------------------------------------------------------------------- audit


def audit(agent_id: str | None, thread_id: str | None, action: str,
          detail: dict | None = None, risk: str = "low", actor: str = "agent") -> str:
    return db.insert("audit", {
        "id": db.new_id(), "agent_id": agent_id or "", "thread_id": thread_id or "",
        "actor": actor, "action": action, "detail": _dumps(detail or {}), "risk": risk,
        "created_at": db.now(),
    })


def list_audit(limit: int = 200, agent_id: str | None = None, risk: str | None = None) -> list[dict]:
    sql = "SELECT * FROM audit WHERE 1=1"
    params: list[Any] = []
    if agent_id:
        sql += " AND agent_id=?"
        params.append(agent_id)
    if risk:
        sql += " AND risk=?"
        params.append(risk)
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    rows = db.q(sql, params)
    for r in rows:
        r["detail"] = db.json_load(r.get("detail"), {})
    return rows


# -------------------------------------------------------------------- memories


def remember(agent_id: str, key: str, value: str, tags: str = "", scope: str = "agent",
             source: str = "agent") -> str:
    existing = db.q1("SELECT id FROM memories WHERE agent_id=? AND key=? AND scope=?", (agent_id, key, scope))
    if existing:
        db.x("UPDATE memories SET value=?, tags=?, source=?, created_at=? WHERE id=?",
             (value, tags, source, db.now(), existing["id"]))
        return existing["id"]
    return db.insert("memories", {
        "id": db.new_id(), "agent_id": agent_id, "scope": scope, "key": key,
        "value": value, "tags": tags, "source": source, "created_at": db.now(),
    })


def recall(agent_id: str, query: str = "", limit: int = 30) -> list[dict]:
    sql = "SELECT * FROM memories WHERE (agent_id=? OR scope='team')"
    params: list[Any] = [agent_id]
    if query:
        sql += " AND (key LIKE ? OR value LIKE ? OR tags LIKE ?)"
        like = f"%{query}%"
        params += [like, like, like]
    sql += " ORDER BY created_at DESC LIMIT ?"
    params.append(limit)
    return db.q(sql, params)


def forget(agent_id: str, key: str) -> int:
    rows = db.q("SELECT id FROM memories WHERE agent_id=? AND key=?", (agent_id, key))
    db.x("DELETE FROM memories WHERE agent_id=? AND key=?", (agent_id, key))
    return len(rows)


# ---------------------------------------------------------------------- oauth


def save_oauth(provider: str, account: str, token_encrypted: str, scopes: str) -> None:
    db.x(
        """INSERT INTO oauth (id, provider, account, token, scopes, updated_at)
           VALUES (?,?,?,?,?,?)
           ON CONFLICT(provider) DO UPDATE SET account=excluded.account, token=excluded.token,
             scopes=excluded.scopes, updated_at=excluded.updated_at""",
        (db.new_id(), provider, account, token_encrypted, scopes, db.now()),
    )


def get_oauth(provider: str) -> dict | None:
    return db.q1("SELECT * FROM oauth WHERE provider=?", (provider,))


def delete_oauth(provider: str) -> None:
    db.x("DELETE FROM oauth WHERE provider=?", (provider,))


# -------------------------------------------------------------------- mcp rows


def list_mcp_servers() -> list[dict]:
    rows = db.q("SELECT * FROM mcp_servers ORDER BY created_at")
    for r in rows:
        r["args"] = db.json_load(r.get("args"), [])
        r["env"] = db.json_load(r.get("env"), {})
        r["tools"] = db.json_load(r.get("tools"), [])
        r["enabled"] = bool(r["enabled"])
    return rows


# ------------------------------------------------------------------ workspaces


def workspace_path(agent_id: str) -> Path:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", agent_id) or "unknown"
    path = settings.workspaces_dir / safe
    path.mkdir(parents=True, exist_ok=True)
    return path


def resolve_in_workspace(agent_id: str, rel_path: str) -> Path:
    """Resolve a path inside the agent workspace, refusing traversal escapes."""
    root = workspace_path(agent_id).resolve()
    raw = (rel_path or "").strip().lstrip("/")
    candidate = (root / raw).resolve() if raw else root
    if candidate != root and root not in candidate.parents:
        raise ValueError(f"path escapes the agent workspace: {rel_path!r}")
    return candidate


def rel_in_workspace(agent_id: str, path: Path) -> str:
    root = workspace_path(agent_id).resolve()
    try:
        return str(path.resolve().relative_to(root)).replace("\\", "/")
    except Exception:
        return str(path)


def workspace_listing(agent_id: str, sub: str = "") -> list[dict]:
    root = workspace_path(agent_id).resolve()
    target = resolve_in_workspace(agent_id, sub)
    out: list[dict] = []
    if target.is_file():
        st = target.stat()
        return [{"name": target.name, "path": rel_in_workspace(agent_id, target), "dir": False,
                 "size": st.st_size, "modified": st.st_mtime}]
    if not target.exists():
        return []
    for p in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        try:
            st = p.stat()
            out.append({
                "name": p.name, "path": rel_in_workspace(agent_id, p), "dir": p.is_dir(),
                "size": 0 if p.is_dir() else st.st_size, "modified": st.st_mtime,
                "children": len(list(p.iterdir())) if p.is_dir() else 0,
            })
        except Exception:
            continue
    return out


def workspace_stats(agent_id: str) -> dict:
    root = workspace_path(agent_id)
    files = 0
    size = 0
    for p in root.rglob("*"):
        if p.is_file():
            files += 1
            try:
                size += p.stat().st_size
            except Exception:
                pass
    return {"files": files, "bytes": size}
