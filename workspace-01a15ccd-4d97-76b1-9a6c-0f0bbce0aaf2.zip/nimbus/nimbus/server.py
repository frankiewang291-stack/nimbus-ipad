"""
Nimbus HTTP API + UI server (FastAPI).

Run:  python -m nimbus.server      (or ./run.sh)
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, UploadFile, File, Form, Header, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import agent as agent_mod
from . import approvals as approvals_mod
from . import bus, db, google_api, mcp_client, scheduler
from .config import (LANGUAGES, PROVIDERS, available_providers, constant_time_compare, default_model, 
                     default_provider, generate_auth_token, get_key, language_info, 
                     provider_ready, read_auth_token, settings, write_auth_token)
from .llm import LLMError, stream_chat
from .store import (add_message, add_tool_rule, create_agent, create_thread, delete_agent,
                    delete_thread, get_agent, get_thread, hydrate_message, list_agents, list_messages,
                    list_threads, list_tool_rules, remember, remove_tool_rule, resolve_in_workspace,
                    update_agent, update_thread, workspace_listing, workspace_path, workspace_stats)
from .tools import grouped as tools_grouped
from .tools import all_tool_names

WEB_DIR = Path(__file__).parent / "web"

app = FastAPI(title="Nimbus", version=settings.version, docs_url="/api/docs", redoc_url=None)

# ==========================================================================
#  Security: Authentication & CORS
# ==========================================================================

# Initialize auth token
AUTH_TOKEN = settings.auth_token or read_auth_token(settings.auth_token_path)
if not AUTH_TOKEN:
    AUTH_TOKEN = generate_auth_token()
    write_auth_token(AUTH_TOKEN, settings.auth_token_path)

# Parse allowed origins
ALLOWED_ORIGINS = [o.strip() for o in settings.allowed_origins.split(",") if o.strip()] if settings.allowed_origins else []

# CORS middleware with explicit origin list
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS or ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    allow_credentials=True,
)


def get_token_header(x_token: str = Header(None)) -> str:
    """FastAPI dependency to extract and validate bearer token."""
    if not x_token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication token",
        )
    # Remove "Bearer " prefix if present
    token = x_token.replace("Bearer ", "").strip()
    if not constant_time_compare(token, AUTH_TOKEN):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token",
        )
    return token


async def verify_origin(request: Request) -> None:
    """Verify Origin header matches allowed origins for state-changing requests."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return  # Read-only requests don't need origin check
    
    origin = request.headers.get("origin", "")
    host = request.headers.get("host", "")
    
    # If no allowed origins configured, allow all
    if not ALLOWED_ORIGINS:
        return
    
    # Check if origin is in allowed list
    if origin and not any(constant_time_compare(origin, allowed) for allowed in ALLOWED_ORIGINS):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Origin not allowed",
        )
    
    # Also check Host header for DNS rebinding protection
    if host and not any(
        constant_time_compare(host, allowed) or 
        constant_time_compare(f"http://{host}", allowed) or
        constant_time_compare(f"https://{host}", allowed)
        for allowed in ALLOWED_ORIGINS
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Host not allowed",
        )


def check_host_binding() -> None:
    """Check if running on loopback or if token is set for non-loopback."""
    # Check if host is loopback
    is_loopback = settings.host in ("127.0.0.1", "localhost", "::1", "0.0.0.0")
    
    # If not loopback and no token, refuse to start
    if not is_loopback and not AUTH_TOKEN:
        print("\nERROR: Refusing to bind to non-loopback address without NIMBUS_AUTH_TOKEN.", file=sys.stderr)
        print(f"  Host: {settings.host}", file=sys.stderr)
        print(f"  Set NIMBUS_AUTH_TOKEN environment variable or use 127.0.0.1/localhost.", file=sys.stderr)
        sys.exit(1)


# Apply host binding check at startup (sync function, no await needed)
check_host_binding()


async def require_auth(
    request: Request,
    token: str = Depends(get_token_header),
) -> str:
    """Dependency that requires valid auth token and checks origin for state-changing requests."""
    # Check origin for state-changing requests
    if request.method in STATE_CHANGING_METHODS:
        await verify_origin(request)
    return token


# Middleware for auth on /api routes
@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """Apply auth requirement to all /api/* routes. Allow /health and static UI without auth."""
    # Routes that don't require auth
    public_routes = {"/", "/demo", "/layout", "/health"}
    
    # Check if this is a public route
    if request.url.path in public_routes:
        return await call_next(request)
    
    # Check if this is an API route (starts with /api/)
    if request.url.path.startswith("/api/"):
        # Extract token from header
        auth_header = request.headers.get("authorization", "")
        token = auth_header.replace("Bearer ", "").strip()
        
        if not token:
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Missing authentication token"},
            )
        
        if not constant_time_compare(token, AUTH_TOKEN):
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"detail": "Invalid authentication token"},
            )
        
        # Check origin for state-changing requests
        if request.method in STATE_CHANGING_METHODS:
            origin = request.headers.get("origin", "")
            host = request.headers.get("host", "")
            
            if ALLOWED_ORIGINS:
                if origin and not any(constant_time_compare(origin, allowed) for allowed in ALLOWED_ORIGINS):
                    return JSONResponse(
                        status_code=status.HTTP_403_FORBIDDEN,
                        content={"detail": "Origin not allowed"},
                    )
                
                if host and not any(
                    constant_time_compare(host, allowed) or 
                    constant_time_compare(f"http://{host}", allowed) or
                    constant_time_compare(f"https://{host}", allowed)
                    for allowed in ALLOWED_ORIGINS
                ):
                    return JSONResponse(
                        status_code=status.HTTP_403_FORBIDDEN,
                        content={"detail": "Host not allowed"},
                    )
    
    return await call_next(request)

RUNTIME_SETTING_KEYS = {"language","XAI_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENROUTER_API_KEY",
                        "GROQ_API_KEY", "DEEPSEEK_API_KEY", "LOCAL_BASE_URL", "LOCAL_API_KEY",
                        "CUSTOM_BASE_URL", "CUSTOM_API_KEY", "TAVILY_API_KEY", "BRAVE_API_KEY",
                        "NIMBUS_APPROVAL_MODE", "NIMBUS_ALLOW_SHELL", "NIMBUS_ALLOW_SHELL_NETWORK",
                        "GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_REDIRECT_URI"}


# State-changing methods that require origin check
STATE_CHANGING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}


# ==========================================================================
#  helpers
# ==========================================================================
def apply_runtime_settings() -> None:
    """Settings saved through the UI (encrypted where they're secrets) win over .env."""
    from . import crypto
    stored = db.all_settings()
    for key, raw in stored.items():
        if key not in RUNTIME_SETTING_KEYS:
            continue
        value = crypto.decrypt(raw) if key.endswith(("_KEY", "_SECRET")) or raw.startswith(("enc:", "obf:")) else raw
        settings.runtime[key] = value
        if key == "NIMBUS_APPROVAL_MODE" and value:
            settings.approval_mode = value
        elif key == "NIMBUS_ALLOW_SHELL":
            settings.allow_shell = value.strip().lower() in ("1", "true", "yes")
        elif key == "NIMBUS_ALLOW_SHELL_NETWORK":
            settings.allow_shell_network = value.strip().lower() in ("1", "true", "yes")
        elif key == "GOOGLE_CLIENT_ID" and value:
            settings.google_client_id = value
        elif key == "GOOGLE_CLIENT_SECRET" and value:
            settings.google_client_secret = value
        elif key == "GOOGLE_REDIRECT_URI" and value:
            settings.google_redirect_uri = value
    settings.google_demo_mode = not (settings.google_client_id and settings.google_client_secret)
    stored_lang = db.get_setting("language")
    if stored_lang:
        from .config import _lang
        settings.language = _lang(stored_lang)


def save_runtime_setting(key: str, value: str) -> None:
    from . import crypto
    stored = crypto.encrypt(value) if (key.endswith(("_KEY", "_SECRET"))) and value else value
    db.set_setting(key, stored)


@app.on_event("startup")
async def _startup() -> None:
    apply_runtime_settings()
    db.connect()
    scheduler.start()
    try:
        await mcp_client.connect_all()
    except Exception as exc:
        print(f"[nimbus] MCP startup: {exc}")
    
    # Print auth token if it was just generated
    if not settings.auth_token:
        print(f"[nimbus] Auth token: {AUTH_TOKEN}")
        print(f"[nimbus] Store this token securely. It will not be printed again.")
    
    print(f"[nimbus] ready — provider={default_provider()} model={default_model()} "
          f"google={'demo' if google_api.demo_mode() else 'live'} data={settings.data_dir}")


@app.on_event("shutdown")
async def _shutdown() -> None:
    """Graceful shutdown handler."""
    from . import approvals as approvals_mod
    
    # Log shutdown start
    print("[nimbus] Shutting down gracefully...")
    
    # Resolve pending approvals
    resolved = await approvals_mod.graceful_shutdown()
    if resolved > 0:
        print(f"[nimbus] Resolved {resolved} pending approvals")
    
    # Stop MCP clients
    await mcp_client.stop_all()
    
    # Stop scheduler tasks
    await scheduler.stop_all()
    
    print("[nimbus] Shutdown complete")


def agent_or_404(agent_id: str) -> dict:
    a = get_agent(agent_id)
    if not a:
        raise HTTPException(404, "agent not found")
    return a


# ==========================================================================
#  system / settings / connectors
# ==========================================================================
@app.get("/api/system")
async def system_info() -> dict:
    return {
        "version": settings.version,
        "providers": available_providers(),
        "default_provider": default_provider(),
        "default_model": default_model(),
        "tools": tools_grouped(),
        "all_tools": all_tool_names(),
        "google": google_api.status(),
        "mcp": mcp_client.client_status(),
        "language": settings.language,
        "languages": LANGUAGES,
        "language_info": language_info(),
        "settings": {
            "approval_mode": settings.approval_mode,
            "allow_shell": settings.allow_shell,
            "allow_shell_network": settings.allow_shell_network,
            "data_dir": str(settings.data_dir),
        },
        "counts": {
            "agents": len(list_agents()),
            "threads": len(list_threads(limit=1000)),
            "pending_approvals": len(approvals_mod.PENDING),
            "skills": len(db.q("SELECT id FROM skills")),
            "routines": len(db.q("SELECT id FROM routines")),
        },
        "browser_tool": _playwright_ok(),
        "keys_set": {p["id"]: provider_ready(p["id"]) for p in available_providers()},
        "limits": {
            "upload_mb": settings.max_upload_mb,
            "download_mb": settings.max_download_mb,
            "preview_mb": settings.max_preview_mb,
            "gmail_attachment_mb": settings.gmail_attachment_mb,
            "drive_resumable_mb": settings.drive_resumable_mb,
        },
    }


def _playwright_ok() -> bool:
    try:
        import playwright  # noqa: F401
        return True
    except Exception:
        return False


@app.post("/api/settings")
async def update_settings(body: dict) -> dict:
    if "language" in (body or {}):
        from .config import LANGUAGES as _LANGS, _lang
        want = str(body["language"])
        if want not in [l["id"] for l in _LANGS]:
            raise HTTPException(400, f"unsupported language {want!r}")
        settings.language = _lang(want)
        save_runtime_setting("language", settings.language)
        db.audit(None, None, "settings.language", {"language": settings.language}, actor="user")
    for key, value in (body or {}).items():
        if key == "language":
            continue
        if key in RUNTIME_SETTING_KEYS:
            save_runtime_setting(key, str(value))
        elif key == "approval_mode":
            settings.approval_mode = str(value)
            save_runtime_setting("NIMBUS_APPROVAL_MODE", str(value))
    apply_runtime_settings()
    db.audit(None, None, "settings.update", {"keys": list((body or {}).keys())}, actor="user")
    return await system_info()


@app.post("/api/providers/test")
async def test_provider(body: dict) -> dict:
    provider = (body or {}).get("provider", "")
    model = (body or {}).get("model", "") or (PROVIDERS.get(provider, {}).get("models") or [""])[0]
    if provider not in PROVIDERS:
        raise HTTPException(400, "unknown provider")
    try:
        chunks = []
        async for ev in stream_chat(provider, model, [{"role": "user", "content": "Reply with the single word: ready"}],
                                    tools=[], max_tokens=40):
            if ev["type"] == "text":
                chunks.append(ev["text"])
        return {"ok": True, "provider": provider, "model": model, "reply": "".join(chunks)[:200]}
    except Exception as exc:
        return {"ok": False, "provider": provider, "model": model, "error": str(exc)}


# ---------- Google ----------
@app.get("/api/google/status")
async def google_status() -> dict:
    return google_api.status()


@app.get("/api/google/authorize")
async def google_authorize():
    if google_api.demo_mode():
        return JSONResponse({"demo": True, "message": "Demo mode is active — nothing to authorize. "
                                                     "Set GOOGLE_CLIENT_ID/SECRET to connect a real account.",
                             "hint": "Google Cloud console → APIs & Services → Credentials → OAuth client ID "
                                     "(Web application). Redirect URI: " + settings.google_redirect_uri})
    return RedirectResponse(google_api.authorize_url("nimbus"))


@app.get("/api/google/callback")
async def google_callback(code: str = "", error: str = "", state: str = ""):
    if error:
        return HTMLResponse(f"<h3>Google returned an error</h3><pre>{error}</pre>", status_code=400)
    if not code:
        return HTMLResponse("<h3>Missing ?code</h3>", status_code=400)
    try:
        result = await google_api.exchange_code(code)
    except Exception as exc:
        return HTMLResponse(f"<h3>Token exchange failed</h3><pre>{exc}</pre>", status_code=400)
    return HTMLResponse(f"""<html><body style="font-family:system-ui;padding:40px">
        <h2>✅ Google connected</h2><p>{result['account']}</p>
        <p><a href="/">Back to Nimbus</a></p></body></html>""")


@app.post("/api/google/disconnect")
async def google_disconnect() -> dict:
    google_api.disconnect()
    return google_api.status()


@app.post("/api/google/demo-reset")
async def google_demo_reset() -> dict:
    if google_api.DEMO_PATH.exists():
        google_api.DEMO_PATH.unlink()
    google_api._demo()
    return {"ok": True, "path": str(google_api.DEMO_PATH)}


# ---------- MCP ----------
@app.get("/api/mcp")
async def mcp_list() -> list[dict]:
    return mcp_client.client_status()


@app.post("/api/mcp")
async def mcp_create(body: dict) -> dict:
    name = (body or {}).get("name", "").strip()
    if not name:
        raise HTTPException(400, "name required")
    sid = db.insert("mcp_servers", {
        "id": db.new_id(), "name": name, "transport": body.get("transport", "stdio"),
        "command": body.get("command", ""), "args": json.dumps(body.get("args") or []),
        "url": body.get("url", ""), "env": json.dumps(body.get("env") or {}),
        "enabled": 1 if body.get("enabled", True) else 0, "status": "unknown", "tools": "[]",
        "created_at": db.now()})
    if body.get("connect", True):
        try:
            return await mcp_client.connect(sid)
        except Exception as exc:
            return {"server": name, "error": str(exc)}
    return {"id": sid, "name": name}


@app.delete("/api/mcp/{server_id}")
async def mcp_delete(server_id: str) -> dict:
    row = db.q1("SELECT * FROM mcp_servers WHERE id=?", (server_id,))
    if not row:
        raise HTTPException(404, "not found")
    await mcp_client.disconnect(row["name"])
    db.x("DELETE FROM mcp_servers WHERE id=?", (server_id,))
    return {"deleted": row["name"]}


@app.post("/api/mcp/{server_id}/connect")
async def mcp_connect(server_id: str) -> dict:
    try:
        return await mcp_client.connect(server_id)
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/mcp/{name}/disconnect")
async def mcp_disconnect(name: str) -> dict:
    await mcp_client.disconnect(name)
    return {"disconnected": name}


# ==========================================================================
#  agents
# ==========================================================================
@app.get("/api/agents")
async def agents_list() -> list[dict]:
    out = []
    for a in list_agents():
        threads = list_threads(a["id"], limit=1)
        out.append({**a, "skills": len(db.q("SELECT id FROM skills WHERE agent_id=?", (a["id"],))),
                    "routines": len(db.q("SELECT id FROM routines WHERE agent_id=?", (a["id"],))),
                    "last_thread": threads[0]["id"] if threads else None,
                    "stats": workspace_stats(a["id"])})
    return out


@app.post("/api/agents")
async def agents_create(body: dict) -> dict:
    if not (body or {}).get("name"):
        raise HTTPException(400, "name required")
    a = create_agent(
        body["name"], title=body.get("title", ""), description=body.get("description", ""),
        provider=body.get("provider", ""), model=body.get("model", ""), persona=body.get("persona", ""),
        emoji=body.get("emoji", "🤖") or "🤖", tools=body.get("tools"),
        approval_mode=body.get("approval_mode", "inherit"),
        temperature=float(body.get("temperature", 0.3)),
        max_iterations=int(body.get("max_iterations", 12)),
        can_delegate=body.get("can_delegate", True))
    thread = create_thread(a["id"], "New thread")
    db.audit(a["id"], thread["id"], "agent.create", {"name": a["name"]}, actor="user")
    return {**a, "last_thread": thread["id"]}


@app.get("/api/agents/{agent_id}")
async def agent_get(agent_id: str) -> dict:
    a = agent_or_404(agent_id)
    return {**a, "skills": db.q("SELECT * FROM skills WHERE agent_id=?", (agent_id,)),
            "routines": db.q("SELECT * FROM routines WHERE agent_id=?", (agent_id,)),
            "memories": db.q("SELECT * FROM memories WHERE agent_id=? ORDER BY created_at DESC LIMIT 100",
                             (agent_id,)),
            "stats": workspace_stats(agent_id)}


@app.patch("/api/agents/{agent_id}")
async def agent_patch(agent_id: str, body: dict) -> dict:
    agent_or_404(agent_id)
    a = update_agent(agent_id, body or {})
    db.audit(agent_id, None, "agent.update", {"fields": list((body or {}).keys())}, actor="user")
    return a  # type: ignore[return-value]


@app.delete("/api/agents/{agent_id}")
async def agent_delete(agent_id: str) -> dict:
    agent_or_404(agent_id)
    delete_agent(agent_id)
    db.audit(agent_id, None, "agent.delete", {}, actor="user")
    return {"deleted": agent_id}


@app.post("/api/agents/{agent_id}/threads")
async def thread_create(agent_id: str, body: dict | None = None) -> dict:
    agent_or_404(agent_id)
    return create_thread(agent_id, (body or {}).get("title") or "New thread")


@app.get("/api/agents/{agent_id}/files")
async def agent_files(agent_id: str, path: str = "") -> dict:
    agent_or_404(agent_id)
    try:
        items = workspace_listing(agent_id, path)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"path": path, "items": items, "stats": workspace_stats(agent_id),
            "root": str(workspace_path(agent_id))}


@app.get("/api/agents/{agent_id}/file")
async def agent_file(agent_id: str, path: str):
    agent_or_404(agent_id)
    try:
        p = resolve_in_workspace(agent_id, path)
    except ValueError:
        raise HTTPException(400, "bad path")
    if not p.is_file():
        raise HTTPException(404, "not found")
    return FileResponse(p, filename=p.name)


@app.get("/api/agents/{agent_id}/file-text")
async def agent_file_text(agent_id: str, path: str, max_bytes: int = 0) -> dict:
    """Return a text file for the in-app viewer (default cap: NIMBUS_MAX_PREVIEW_MB)."""
    agent_or_404(agent_id)
    try:
        p = resolve_in_workspace(agent_id, path)
    except ValueError:
        raise HTTPException(400, "bad path")
    if not p.is_file():
        raise HTTPException(404, "not found")
    cap = min(int(max_bytes) if max_bytes else settings.max_preview_mb * 1024 * 1024,
              64 * 1024 * 1024)
    if p.stat().st_size > cap:
        raise HTTPException(413, f"file is {p.stat().st_size // 1024} KB — larger than the "
                                 f"{cap // (1024 * 1024) or 1} MB preview limit")
    try:
        return {"path": path, "content": p.read_text(encoding="utf-8", errors="replace"),
                "bytes": p.stat().st_size, "limit_mb": cap // (1024 * 1024)}
    except Exception as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/agents/{agent_id}/upload")
async def agent_upload(agent_id: str, file: UploadFile = File(...), path: str = Form("")) -> dict:
    """Store an uploaded file in an agent's workspace.

    Streamed to disk in 4 MB chunks and capped by NIMBUS_MAX_UPLOAD_MB (default 512),
    so a big upload never has to fit in memory.
    """
    agent_or_404(agent_id)
    name = path or file.filename or "upload.bin"
    target = resolve_in_workspace(agent_id, name)
    target.parent.mkdir(parents=True, exist_ok=True)
    limit = settings.max_upload_mb * 1024 * 1024
    tmp = target.with_name(target.name + ".part")
    total = 0
    try:
        with open(tmp, "wb") as fh:
            while True:
                chunk = await file.read(4 * 1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    fh.close()
                    tmp.unlink(missing_ok=True)
                    raise HTTPException(413, f"file is larger than the {settings.max_upload_mb} MB upload limit "
                                             f"(raise NIMBUS_MAX_UPLOAD_MB to change it)")
                fh.write(chunk)
        tmp.replace(target)
    except HTTPException:
        raise
    except Exception as exc:
        tmp.unlink(missing_ok=True)
        raise HTTPException(400, f"upload failed: {exc}")
    finally:
        await file.close()
    db.audit(agent_id, None, "workspace.upload", {"path": name, "bytes": total}, actor="user")
    await scheduler.emit_event("file.upload", {"agent_id": agent_id, "path": name, "bytes": total})
    return {"stored": name, "bytes": total, "limit_mb": settings.max_upload_mb}


@app.delete("/api/agents/{agent_id}/file")
async def agent_file_delete(agent_id: str, path: str) -> dict:
    agent_or_404(agent_id)
    p = resolve_in_workspace(agent_id, path)
    if p.is_file():
        p.unlink()
        return {"deleted": path}
    raise HTTPException(404, "not found")


@app.post("/api/agents/{agent_id}/teach")
async def agent_teach(agent_id: str, body: dict) -> dict:
    """Teach a task: turn a completed thread into a reusable skill."""
    a = agent_or_404(agent_id)
    thread_id = (body or {}).get("thread_id", "")
    name = (body or {}).get("name", "").strip()
    msgs = list_messages(thread_id)[-30:] if thread_id else []
    if not msgs:
        raise HTTPException(400, "thread has no messages to learn from")
    transcript = "\n\n".join(
        f"[{m['role']}{'/' + (m.get('name') or '') if m['role'] == 'tool' else ''}] "
        f"{(m.get('content') or '')[:1200]}" for m in msgs)[-16000:]
    prompt = [
        {"role": "system", "content": "You turn a completed agent transcript into a crisp, reusable SOP. "
                                      "Reply ONLY with JSON: {\"name\":str,\"description\":str,"
                                      "\"instructions\":str,\"inputs\":[str],\"output_format\":str}. "
                                      "Instructions must be step-by-step, generalised (no one-off values), "
                                      "and reference the tools by name."},
        {"role": "user", "content": f"Skill name hint: {name or 'auto'}\n\nTranscript:\n{transcript}"},
    ]
    try:
        raw = await approvals_mod.llm_complete(a.get("provider", "mock"), a.get("model", ""), prompt, max_tokens=1500)
        start, end = raw.find("{"), raw.rfind("}")
        data = json.loads(raw[start:end + 1]) if start >= 0 else {}
    except Exception as exc:
        raise HTTPException(400, f"could not summarise the thread: {exc}")
    if not data.get("instructions"):
        raise HTTPException(400, "the model did not return usable instructions")
    sid = db.insert("skills", {
        "id": db.new_id(), "agent_id": agent_id, "name": (name or data.get("name") or "Learned skill")[:120],
        "description": (data.get("description") or "")[:500], "instructions": data.get("instructions", ""),
        "inputs": json.dumps(data.get("inputs") or []), "output_format": data.get("output_format", ""),
        "source": f"taught:{thread_id}", "runs": 0, "created_at": db.now(), "updated_at": db.now()})
    db.audit(agent_id, thread_id, "skill.taught", {"skill": name or data.get("name")}, actor="user")
    return db.q1("SELECT * FROM skills WHERE id=?", (sid,))


# ==========================================================================
#  threads + chat
# ==========================================================================
@app.get("/api/threads")
async def threads_list(agent_id: str = "", limit: int = 100) -> list[dict]:
    rows = list_threads(agent_id or None, limit=limit)
    for r in rows:
        r["agent"] = next(({"id": a["id"], "name": a["name"], "emoji": a["emoji"]} for a in list_agents()
                           if a["id"] == r["agent_id"]), None)
        r["message_count"] = len(db.q("SELECT id FROM messages WHERE thread_id=?", (r["id"],)))
    return rows


@app.get("/api/threads/{thread_id}")
async def thread_get(thread_id: str) -> dict:
    t = get_thread(thread_id)
    if not t:
        raise HTTPException(404, "thread not found")
    msgs = list_messages(thread_id)
    return {**t, "agent": get_agent(t["agent_id"]), "messages": msgs,
            "children": list_threads(limit=50) and [x for x in db.q(
                "SELECT id, title, agent_id, status FROM threads WHERE parent_thread_id=? ORDER BY created_at",
                (thread_id,))],
            "pending_approval": next((a for a in db.q("SELECT * FROM approvals WHERE thread_id=? AND status='pending'",
                                                      (thread_id,))), None)}


@app.patch("/api/threads/{thread_id}")
async def thread_patch(thread_id: str, body: dict) -> dict:
    if not get_thread(thread_id):
        raise HTTPException(404, "not found")
    update_thread(thread_id, body or {})
    return get_thread(thread_id)  # type: ignore[return-value]


@app.delete("/api/threads/{thread_id}")
async def thread_delete(thread_id: str) -> dict:
    delete_thread(thread_id)
    return {"deleted": thread_id}


@app.post("/api/threads/{thread_id}/messages")
async def thread_send(thread_id: str, body: dict) -> dict:
    t = get_thread(thread_id)
    if not t:
        raise HTTPException(404, "thread not found")
    a = get_agent(t["agent_id"])
    if not a:
        raise HTTPException(404, "agent gone")
    text = (body or {}).get("content", "").strip()
    if not text:
        raise HTTPException(400, "content required")
    if agent_mod.thread_lock(thread_id).locked():
        raise HTTPException(409, "this agent is already working on this thread")

    if t["title"] in ("New thread", "", None):
        update_thread(thread_id, {"title": text[:60]})

    async def run() -> None:
        runner = agent_mod.Runner(a, thread_id)
        await runner.send(text)

    asyncio.create_task(run())
    return {"started": True, "thread_id": thread_id}


@app.post("/api/threads/{thread_id}/stop")
async def thread_stop(thread_id: str) -> dict:
    agent_mod.cancel(thread_id)
    return {"stopping": thread_id}


@app.post("/api/task")
async def quick_task(body: dict) -> dict:
    """One-shot API: run a task on an agent and (optionally) wait for the answer."""
    agent_id = (body or {}).get("agent_id") or (list_agents()[0]["id"] if list_agents() else "")
    a = agent_or_404(agent_id)
    text = (body or {}).get("text", "").strip()
    if not text:
        raise HTTPException(400, "text required")
    thread = create_thread(a["id"], title=text[:60], kind="task")
    if body.get("wait", True):
        runner = agent_mod.Runner(a, thread["id"])
        result = await runner.send(text)
        return {"thread_id": thread["id"], "result": result}
    asyncio.create_task(agent_mod.Runner(a, thread["id"]).send(text))
    return {"thread_id": thread["id"], "started": True}


# ---------- live stream ----------
@app.get("/api/stream")
async def stream(request: Request, thread_id: str = "", all: int = 0, token: str = None):
    # Validate token for stream endpoint
    if token:
        if not constant_time_compare(token, AUTH_TOKEN):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication token",
            )
    else:
        # Check Authorization header
        auth_header = request.headers.get("authorization", "")
        header_token = auth_header.replace("Bearer ", "").strip()
        if not constant_time_compare(header_token, AUTH_TOKEN):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing or invalid authentication token",
            )
    
    channel = thread_id or "*"

    async def gen():
        q = bus.subscribe(channel)
        try:
            yield f"data: {json.dumps({'type': 'hello', 'channel': channel})}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(q.get(), timeout=15)
                    yield f"data: {json.dumps(event, default=str)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            bus.unsubscribe(channel, q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ==========================================================================
#  approvals / skills / routines / memory / audit / runs
# ==========================================================================
@app.get("/api/approvals")
async def approvals_list(status: str = "pending") -> list[dict]:
    rows = db.list_approvals(status or None)
    for r in rows:
        a = get_agent(r["agent_id"]) if r["agent_id"] else None
        r["agent_name"] = a["name"] if a else ""
    return rows


@app.post("/api/approvals/{approval_id}")
async def approval_decide(approval_id: str, body: dict) -> dict:
    decision = (body or {}).get("decision", "denied")
    if decision not in ("approved", "denied"):
        raise HTTPException(400, "decision must be approved or denied")
    row = approvals_mod.resolve(approval_id, decision, (body or {}).get("note", ""))
    if not row:
        raise HTTPException(404, "approval not found")
    return row


# --------------------------------------------------------------- tool rules
# The "Always allow" button writes one of these; the agent loop checks it in
# nimbus/approvals.py before it even looks at the policy.


@app.get("/api/agents/{agent_id}/tool-rules")
async def tool_rules_list(agent_id: str) -> list[dict]:
    return list_tool_rules(agent_id)


@app.post("/api/agents/{agent_id}/tool-rules")
async def tool_rules_add(agent_id: str, body: dict) -> dict:
    body = body or {}
    tool = str(body.get("tool", "")).strip()
    action = str(body.get("action", "allow")).strip().lower()
    if not tool:
        raise HTTPException(400, "tool is required")
    if action not in ("allow", "ask"):
        raise HTTPException(400, "action must be 'allow' or 'ask'")
    if not get_agent(agent_id):
        raise HTTPException(404, "agent not found")
    row = add_tool_rule(agent_id, tool, action, str(body.get("note", "")))
    db.audit(agent_id, "", f"rule.{action}", {"tool": tool}, risk="medium", actor="user")
    return row


@app.delete("/api/agents/{agent_id}/tool-rules/{tool}")
async def tool_rules_remove(agent_id: str, tool: str) -> dict:
    removed = remove_tool_rule(agent_id, tool)
    if removed:
        db.audit(agent_id, "", "rule.removed", {"tool": tool}, risk="low", actor="user")
    return {"removed": removed, "tool": tool}


@app.get("/api/skills")
async def skills_list(agent_id: str = "") -> list[dict]:
    if agent_id:
        rows = db.q("SELECT * FROM skills WHERE agent_id=? ORDER BY updated_at DESC", (agent_id,))
    else:
        rows = db.q("SELECT s.*, a.name AS agent_name FROM skills s LEFT JOIN agents a ON a.id=s.agent_id "
                    "ORDER BY s.updated_at DESC")
    for r in rows:
        r["inputs"] = db.json_load(r.get("inputs"), [])
    return rows


@app.post("/api/skills")
async def skill_create(body: dict) -> dict:
    if not (body or {}).get("name"):
        raise HTTPException(400, "name required")
    sid = db.insert("skills", {
        "id": db.new_id(), "agent_id": body.get("agent_id", ""), "name": body["name"][:120],
        "description": body.get("description", ""), "instructions": body.get("instructions", ""),
        "inputs": json.dumps(body.get("inputs") or []), "output_format": body.get("output_format", ""),
        "source": "manual", "runs": 0, "created_at": db.now(), "updated_at": db.now()})
    return db.q1("SELECT * FROM skills WHERE id=?", (sid,))


@app.patch("/api/skills/{skill_id}")
async def skill_patch(skill_id: str, body: dict) -> dict:
    fields = {k: v for k, v in (body or {}).items() if k in ("name", "description", "instructions",
                                                             "output_format", "agent_id")}
    if "inputs" in (body or {}):
        fields["inputs"] = json.dumps(body["inputs"])
    if fields:
        sets = ", ".join(f"{k}=?" for k in fields)
        db.x(f"UPDATE skills SET {sets}, updated_at=? WHERE id=?", list(fields.values()) + [db.now(), skill_id])
    row = db.q1("SELECT * FROM skills WHERE id=?", (skill_id,))
    if not row:
        raise HTTPException(404, "not found")
    row["inputs"] = db.json_load(row.get("inputs"), [])
    return row


@app.delete("/api/skills/{skill_id}")
async def skill_delete(skill_id: str) -> dict:
    db.x("DELETE FROM skills WHERE id=?", (skill_id,))
    return {"deleted": skill_id}


@app.get("/api/routines")
async def routines_list() -> list[dict]:
    rows = db.q("SELECT r.*, a.name AS agent_name FROM routines r LEFT JOIN agents a ON a.id=r.agent_id "
                "ORDER BY r.created_at DESC")
    return rows


@app.post("/api/routines")
async def routine_create(body: dict) -> dict:
    agent_id = (body or {}).get("agent_id")
    if not agent_id:
        raise HTTPException(400, "agent_id required")
    agent_or_404(agent_id)
    kind = body.get("kind", "cron")
    schedule = body.get("schedule", "0 9 * * *")
    rid = db.insert("routines", {
        "id": db.new_id(), "agent_id": agent_id, "name": (body.get("name") or "Routine")[:120],
        "kind": kind, "schedule": schedule, "event_filter": body.get("event_filter", ""),
        "prompt": body.get("prompt", ""), "skill_id": body.get("skill_id", ""),
        "enabled": 1 if body.get("enabled", True) else 0, "last_run_at": None,
        "next_run_at": scheduler.compute_next_run(kind, schedule, None), "run_count": 0,
        "created_at": db.now()})
    db.audit(agent_id, None, "routine.create", {"name": body.get("name")}, actor="user")
    return db.q1("SELECT * FROM routines WHERE id=?", (rid,))


@app.patch("/api/routines/{routine_id}")
async def routine_patch(routine_id: str, body: dict) -> dict:
    row = db.q1("SELECT * FROM routines WHERE id=?", (routine_id,))
    if not row:
        raise HTTPException(404, "not found")
    fields = {k: v for k, v in (body or {}).items() if k in ("name", "kind", "schedule", "event_filter",
                                                             "prompt", "skill_id")}
    if "enabled" in (body or {}):
        fields["enabled"] = 1 if body["enabled"] else 0
    if "schedule" in fields or "kind" in fields:
        fields["next_run_at"] = scheduler.compute_next_run(fields.get("kind", row["kind"]),
                                                           fields.get("schedule", row["schedule"]), None)
    if fields:
        sets = ", ".join(f"{k}=?" for k in fields)
        db.x(f"UPDATE routines SET {sets} WHERE id=?", list(fields.values()) + [routine_id])
    return db.q1("SELECT * FROM routines WHERE id=?", (routine_id,))


@app.delete("/api/routines/{routine_id}")
async def routine_delete(routine_id: str) -> dict:
    db.x("DELETE FROM routines WHERE id=?", (routine_id,))
    return {"deleted": routine_id}


@app.post("/api/routines/{routine_id}/run")
async def routine_run(routine_id: str) -> dict:
    row = db.q1("SELECT * FROM routines WHERE id=?", (routine_id,))
    if not row:
        raise HTTPException(404, "not found")
    scheduler.launch_routine(row, trigger="manual")
    return {"started": row["name"], "note": "watch the activity feed for results"}


@app.get("/api/runs")
async def runs_list(limit: int = 50) -> list[dict]:
    rows = db.list_runs(limit)
    for r in rows:
        a = get_agent(r["agent_id"]) if r["agent_id"] else None
        r["agent_name"] = a["name"] if a else ""
        r["routine_name"] = (db.q1("SELECT name FROM routines WHERE id=?", (r["routine_id"],)) or {}).get("name", "")
    return rows


@app.post("/api/events")
async def post_event(body: dict) -> dict:
    kind = (body or {}).get("kind", "").strip()
    if not kind:
        raise HTTPException(400, "kind required")
    fired = await scheduler.emit_event(kind, body.get("payload") or {})
    return {"kind": kind, "routines_triggered": fired}


@app.get("/api/events")
async def events_list(limit: int = 50) -> list[dict]:
    rows = db.q("SELECT * FROM events ORDER BY created_at DESC LIMIT ?", (limit,))
    for r in rows:
        r["payload"] = db.json_load(r.get("payload"), {})
    return rows


@app.get("/api/memory")
async def memory_list(agent_id: str = "", q: str = "") -> list[dict]:
    if agent_id:
        from .store import recall as recall_fn
        return recall_fn(agent_id, q, 200)
    return db.q("SELECT * FROM memories ORDER BY created_at DESC LIMIT 200")


@app.post("/api/memory")
async def memory_create(body: dict) -> dict:
    agent_id = (body or {}).get("agent_id", "")
    if not agent_id:
        raise HTTPException(400, "agent_id required")
    mid = remember(agent_id, body.get("key", "")[:200], body.get("value", ""), body.get("tags", ""),
                   body.get("scope", "agent"), source="user")
    return db.q1("SELECT * FROM memories WHERE id=?", (mid,))


@app.delete("/api/memory/{memory_id}")
async def memory_delete(memory_id: str) -> dict:
    db.x("DELETE FROM memories WHERE id=?", (memory_id,))
    return {"deleted": memory_id}


@app.get("/api/audit")
async def audit_list(limit: int = 200, agent_id: str = "", risk: str = "") -> list[dict]:
    rows = db.list_audit(limit, agent_id or None, risk or None)
    names = {a["id"]: a["name"] for a in list_agents()}
    for r in rows:
        r["agent_name"] = names.get(r["agent_id"], "")
    return rows


@app.get("/api/stats")
async def stats() -> dict:
    """Small dashboard payload."""
    agents = list_agents()
    return {
        "agents": len(agents),
        "threads": len(db.q("SELECT id FROM threads")),
        "messages": len(db.q("SELECT id FROM messages")),
        "tool_calls": len(db.q("SELECT id FROM audit WHERE action LIKE 'tool.%'")),
        "skills": len(db.q("SELECT id FROM skills")),
        "routines": len(db.q("SELECT id FROM routines WHERE enabled=1")),
        "memories": len(db.q("SELECT id FROM memories")),
        "pending_approvals": len(db.q("SELECT id FROM approvals WHERE status='pending'")),
        "by_agent": [{"id": a["id"], "name": a["name"], "emoji": a["emoji"],
                      "tool_calls": len(db.q("SELECT id FROM audit WHERE agent_id=? AND action LIKE 'tool.%'",
                                             (a["id"],))),
                      "messages": len(db.q("SELECT m.id FROM messages m JOIN threads t ON t.id=m.thread_id "
                                           "WHERE t.agent_id=?", (a["id"],))),
                      "workspace": workspace_stats(a["id"])} for a in agents],
        "recent_audit": db.list_audit(20),
    }


# ==========================================================================
#  ops: seed a demo team
# ==========================================================================
@app.post("/api/demo/team")
async def demo_team() -> dict:
    """Create the classic GrokBot-style starter fleet."""
    specs = [
        ("Scout", "Research analyst", "Finds, verifies and summarises information from the web and Drive. "
                                      "Produces sourced briefs with links.", "🔎", 0.35,
         ["web_search", "fetch_url", "gdrive_search", "gdrive_read", "gdocs_create", "write_file",
          "read_file", "list_files", "remember", "recall", "browser_open", "browser_snapshot",
          "list_team", "web_search"]),
        ("Quill", "Documents & reporting", "Turns raw findings into polished Google Docs, reports and "
                                           "spreadsheets. Owns formatting and delivery.", "📝", 0.4,
         ["gdocs_list", "gdocs_create", "gdocs_read", "gdocs_append", "gdrive_search", "gdrive_read",
          "gsheets_create", "gsheets_read", "gsheets_write", "gdrive_upload", "write_file", "read_file",
          "fetch_url", "youtube_transcript",
          "list_files", "list_skills", "read_skill"]),
        ("Ledger", "Inbox & admin", "Triages Gmail, drafts replies, tracks invoices and keeps the calendar "
                                    "sane. Sends only what you approve.", "📬", 0.25,
         ["gmail_list_messages", "gmail_read_message", "gmail_create_draft", "gmail_send_email",
          "gcal_list_events", "gcal_create_event", "gsheets_append", "remember", "recall", "list_files"]),
        ("Ops", "Automation & engineering", "Runs shell work, builds scripts, automates recurring jobs and "
                                            "wires up connectors. Owns routines.", "🛠️", 0.2,
         ["run_command", "write_file", "read_file", "edit_file", "list_files", "search_files",
          "make_dir", "download_file", "gdrive_upload", "web_search", "fetch_url", "youtube_transcript",
          "create_routine",
          "list_routines", "create_skill", "list_skills", "list_team", "delegate_task"]),
    ]
    created = []
    for name, title, desc, emoji, temp, tools in specs:
        if db.q1("SELECT id FROM agents WHERE lower(name)=lower(?)", (name,)):
            continue
        a = create_agent(name, title=title, description=desc, emoji=emoji,
                         persona="Concise, proactive and concrete. You finish tasks and report results.",
                         tools=[t for t in dict.fromkeys(tools)], temperature=temp)
        create_thread(a["id"], "New thread")
        created.append({"id": a["id"], "name": a["name"]})
    # first real routine: morning brief
    if created:
        scout = next((c for c in created if c["name"] == "Scout"), created[0])
        if not db.q1("SELECT id FROM routines WHERE name='Morning brief'"):
            db.insert("routines", {
                "id": db.new_id(), "agent_id": scout["id"], "name": "Morning brief", "kind": "cron",
                "schedule": "0 8 * * *", "event_filter": "",
                "prompt": ("Produce a morning brief: search for the top 3 developments in AI agents from the "
                           "last 24h, check Google Drive for files modified yesterday, and list my calendar "
                           "events for today. Create a Google Doc titled 'Morning brief — <today>' with the "
                           "findings and report the doc link."),
                "skill_id": "", "enabled": 1, "last_run_at": None,
                "next_run_at": scheduler.compute_next_run("cron", "0 8 * * *", None), "run_count": 0,
                "created_at": db.now()})
        if not db.q1("SELECT id FROM skills WHERE name='Inbox triage'"):
            db.insert("skills", {
                "id": db.new_id(), "agent_id": next((c["id"] for c in created if c["name"] == "Ledger"),
                                                    created[0]["id"]),
                "name": "Inbox triage",
                "description": "Scan the inbox, classify each message, draft replies to the urgent ones.",
                "instructions": ("1. gmail_list_messages with query 'newer_than:2d' (limit 20).\n"
                                 "2. For each message decide: URGENT (needs action today), FYI, or JUNK.\n"
                                 "3. Read the urgent ones with gmail_read_message.\n"
                                 "4. Draft a reply with gmail_create_draft for every URGENT message "
                                 "(match the sender's tone, be brief, never invent facts or commitments).\n"
                                 "5. Summarise in a table: sender | subject | class | action taken | needs me?\n"
                                 "6. Remember any new sender preference you learn."),
                "inputs": json.dumps(["days_back", "max_messages"]),
                "output_format": "Markdown table + list of drafts created",
                "source": "seed", "runs": 0, "created_at": db.now(), "updated_at": db.now()})
    return {"created": created, "agents": len(list_agents())}


# ==========================================================================
#  static UI
# ==========================================================================
@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse((WEB_DIR / "index.html").read_text(encoding="utf-8"))


@app.get("/demo", response_class=HTMLResponse)
async def components_demo():
    """Standalone reference page for the three chat components (also works offline)."""
    page = WEB_DIR / "components-demo.html"
    if not page.exists():
        raise HTTPException(404, "run python3 tools/build_demo.py first")
    return HTMLResponse(page.read_text(encoding="utf-8"))


@app.get("/layout", response_class=HTMLResponse)
async def layout_demo():
    """Standalone reference page for the app chrome (also works offline)."""
    page = WEB_DIR / "layout_demo.html"
    if not page.exists():
        raise HTTPException(404, "run python3 tools/build_layout_demo.py first")
    return HTMLResponse(page.read_text(encoding="utf-8"))


@app.get("/api/health")
async def health() -> dict:
    """
    Health check endpoint.
    
    Checks:
    - Database connectivity
    - Model provider connectivity
    - Pending approvals count
    - Running tasks count
    - Memory usage
    """
    import psutil
    
    # Check database
    db_ok = True
    try:
        db.q("SELECT 1")
    except Exception as e:
        db_ok = False
    
    # Check model providers
    providers_ok = {}
    for provider_id, provider_config in PROVIDERS.items():
        try:
            if provider_id == "mock":
                providers_ok[provider_id] = True
            else:
                providers_ok[provider_id] = provider_ready(provider_id)
        except Exception:
            providers_ok[provider_id] = False
    
    # Check pending approvals
    pending_count = len(approvals_mod.PENDING) if hasattr(approvals_mod, 'PENDING') else 0
    
    # Check running tasks
    tasks_count = len(scheduler._tasks) if hasattr(scheduler, '_tasks') else 0
    
    # Check memory
    memory_usage = 0
    try:
        process = psutil.Process()
        memory_usage = process.memory_info().rss / 1024 / 1024  # MB
    except Exception:
        pass
    
    return {
        "ok": db_ok and all(providers_ok.values()),
        "version": settings.version,
        "database": {"ok": db_ok},
        "providers": providers_ok,
        "default_provider": default_provider(),
        "google_demo": google_api.demo_mode(),
        "agents_count": len(list_agents()),
        "pending_approvals": pending_count,
        "running_tasks": tasks_count,
        "memory_mb": round(memory_usage, 2),
        "timestamp": time.time()
    }


# Keep the old /health endpoint for backward compatibility
@app.get("/health")
async def health_legacy() -> dict:
    return {"ok": True, "version": settings.version, "provider": default_provider(),
            "google_demo": google_api.demo_mode(), "agents": len(list_agents())}


if WEB_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(WEB_DIR)), name="static")


def main() -> None:
    import uvicorn
    uvicorn.run("nimbus.server:app", host=settings.host, port=settings.port, log_level="info")


if __name__ == "__main__":
    main()
