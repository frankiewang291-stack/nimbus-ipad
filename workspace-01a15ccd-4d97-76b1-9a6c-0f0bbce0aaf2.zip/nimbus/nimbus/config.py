"""
Nimbus configuration + provider registry.

Everything is optional. With zero API keys Nimbus still boots into
"offline demo" mode: a local mock model + a file-backed demo Google Drive.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv(path: Path) -> None:
    """Minimal .env loader (no dependency on python-dotenv)."""
    if not path.exists():
        return
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            # strip trailing inline comments that aren't part of a value
            if key and key not in os.environ:
                os.environ[key] = val
    except Exception:
        pass


_load_dotenv(ROOT / ".env")


# --------------------------------------------------------------------------
#  Languages — UI translation + the language agents reply in
# --------------------------------------------------------------------------
LANGUAGES: list[dict] = [
    {"id": "en", "label": "English", "native": "English", "locale": "en-US",
     "prompt": "English"},
    {"id": "zh", "label": "Chinese (Simplified)", "native": "中文（简体）", "locale": "zh-CN",
     "prompt": "Simplified Chinese (简体中文)"},
    {"id": "es", "label": "Spanish", "native": "Español", "locale": "es-ES",
     "prompt": "Spanish (español)"},
    {"id": "auto", "label": "Match the user's language", "native": "Auto · 自动 · Automático",
     "locale": "", "prompt": "the same language the user writes in"},
]

LANGUAGE_IDS = [l["id"] for l in LANGUAGES]


def _lang(value: str) -> str:
    v = (value or "").strip()
    if v in LANGUAGE_IDS:
        return v
    v = v.lower().replace("_", "-")
    if v.startswith(("zh", "cmn", "yue")):
        return "zh"
    if v.startswith("es"):
        return "es"
    if v.startswith(("auto", "")):
        return "zh"
    return "zh"


_language_loaded = False


def current_language() -> str:
    """The active language, picking up the stored setting once per process.

    The web UI writes the choice to the settings table; loading it lazily here
    means CLI runs, scheduled routines and fresh processes all respect it too.
    """
    global _language_loaded
    if not _language_loaded:
        _language_loaded = True
        try:
            from . import db  # lazy import: db imports this module
            stored = db.get_setting("language")
            if stored:
                settings.language = _lang(stored)
        except Exception:
            pass
    return settings.language


def language_info(lang: str | None = None) -> dict:
    want = _lang(lang or current_language())
    return next((l for l in LANGUAGES if l["id"] == want), LANGUAGES[0])


def _flag(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in {"1", "true", "yes", "on"}


def _int_env(name: str, default: int) -> int:
    try:
        return max(1, int(str(os.environ.get(name, default)).strip()))
    except Exception:
        return default


class Settings:
    def __init__(self) -> None:
        self.data_dir = Path(os.environ.get("NIMBUS_DATA_DIR", str(ROOT / "data"))).expanduser()
        if not self.data_dir.is_absolute():
            self.data_dir = (ROOT / self.data_dir).resolve()
        self.host = os.environ.get("NIMBUS_HOST", "127.0.0.1")
        self.port = int(os.environ.get("NIMBUS_PORT", "8000"))
        self.approval_mode = os.environ.get("NIMBUS_APPROVAL_MODE", "risky").strip().lower()
        self.allow_shell = _flag("NIMBUS_ALLOW_SHELL", "1")
        self.allow_shell_network = _flag("NIMBUS_ALLOW_SHELL_NETWORK", "0")
        self.google_client_id = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
        self.google_client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "").strip()
        self.google_redirect_uri = os.environ.get(
            "GOOGLE_REDIRECT_URI", "http://localhost:8000/api/google/callback"
        ).strip()
        self.google_demo_mode = _flag("GOOGLE_DEMO_MODE", "") or not (
            self.google_client_id and self.google_client_secret
        )
        self.language = _lang(os.environ.get("NIMBUS_LANGUAGE", "en"))
        
        # Timezone setting
        self.timezone = os.environ.get("NIMBUS_TIMEZONE", "UTC").strip()
        
        # Security settings
        self.auth_token = os.environ.get("NIMBUS_AUTH_TOKEN", "").strip()
        self.allowed_origins = os.environ.get("NIMBUS_ALLOWED_ORIGINS", "").strip()

        # ---- transfer limits (all configurable; see README "File size limits") ----
        # uploads straight into an agent workspace never leave the machine, so this
        # is generous by default. The browser is the practical bottleneck, not us.
        self.max_upload_mb = _int_env("NIMBUS_MAX_UPLOAD_MB", 512)
        self.max_download_mb = _int_env("NIMBUS_MAX_DOWNLOAD_MB", 1024)   # download_file tool
        self.max_preview_mb = _int_env("NIMBUS_MAX_PREVIEW_MB", 4)        # in-app text viewer
        # Google's own ceilings — we can't raise these, only explain them
        self.gmail_attachment_mb = _int_env("NIMBUS_GMAIL_ATTACHMENT_MB", 25)
        self.drive_resumable_mb = _int_env("NIMBUS_DRIVE_RESUMABLE_MB", 5)
        self.version = "1.0.0"

        # runtime overrides (set from the UI, persisted in the settings table)
        self.runtime: dict[str, str] = {}

        # directories
        self.workspaces_dir = self.data_dir / "workspaces"
        self.demo_google_dir = self.data_dir / "demo_google"
        self.db_path = self.data_dir / "nimbus.db"
        for d in (self.data_dir, self.workspaces_dir, self.demo_google_dir):
            d.mkdir(parents=True, exist_ok=True)
        
        # Auth token file path
        self.auth_token_path = self.data_dir / "auth_token.txt"


settings = Settings()


def generate_auth_token() -> str:
    """Generate a strong random token (32 bytes, base64 encoded)."""
    return secrets.token_urlsafe(32)


def write_auth_token(token: str, path: Path) -> None:
    """Write auth token to file with 0600 permissions."""
    path.write_text(token, encoding="utf-8")
    os.chmod(path, 0o600)


def read_auth_token(path: Path) -> str:
    """Read auth token from file."""
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return ""


def constant_time_compare(a: str, b: str) -> bool:
    """Constant-time string comparison to prevent timing attacks."""
    if len(a) != len(b):
        return False
    return hmac.compare_digest(a, b)


# --------------------------------------------------------------------------
#  Providers
# --------------------------------------------------------------------------
# `api` is either "openai" (Chat Completions shape) or "anthropic" (Messages shape).
PROVIDERS: dict[str, dict] = {
    "xai": {
        "label": "xAI · Grok",
        "api": "openai",
        "base_url": "https://api.x.ai/v1",
        "key_env": "XAI_API_KEY",
        "key_label": "XAI_API_KEY",
        "models": [
            "grok-4-latest",
            "grok-4",
            "grok-4-fast-reasoning",
            "grok-4-fast-non-reasoning",
            "grok-3-latest",
            "grok-3-mini",
            "grok-code-fast-1",
        ],
        "docs": "https://console.x.ai",
    },
    "openai": {
        "label": "OpenAI",
        "api": "openai",
        "base_url": "https://api.openai.com/v1",
        "key_env": "OPENAI_API_KEY",
        "key_label": "OPENAI_API_KEY",
        "models": ["gpt-5", "gpt-5-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4o", "o4-mini"],
        "docs": "https://platform.openai.com/api-keys",
    },
    "anthropic": {
        "label": "Anthropic · Claude",
        "api": "anthropic",
        "base_url": "https://api.anthropic.com/v1",
        "key_env": "ANTHROPIC_API_KEY",
        "key_label": "ANTHROPIC_API_KEY",
        "models": [
            "claude-sonnet-4-5",
            "claude-opus-4-1",
            "claude-haiku-4-5",
            "claude-3-7-sonnet-latest",
        ],
        "docs": "https://console.anthropic.com",
    },
    "openrouter": {
        "label": "OpenRouter (many models)",
        "api": "openai",
        "base_url": "https://openrouter.ai/api/v1",
        "key_env": "OPENROUTER_API_KEY",
        "key_label": "OPENROUTER_API_KEY",
        "models": [
            "x-ai/grok-4",
            "anthropic/claude-sonnet-4.5",
            "openai/gpt-5",
            "google/gemini-3-pro",
            "meta-llama/llama-3.3-70b-instruct",
        ],
        "docs": "https://openrouter.ai/keys",
    },
    "groq": {
        "label": "Groq",
        "api": "openai",
        "base_url": "https://api.groq.com/openai/v1",
        "key_env": "GROQ_API_KEY",
        "key_label": "GROQ_API_KEY",
        "models": ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "qwen/qwen3-32b"],
        "docs": "https://console.groq.com/keys",
    },
    "deepseek": {
        "label": "DeepSeek",
        "api": "openai",
        "base_url": "https://api.deepseek.com/v1",
        "key_env": "DEEPSEEK_API_KEY",
        "key_label": "DEEPSEEK_API_KEY",
        "models": ["deepseek-chat", "deepseek-reasoner"],
        "docs": "https://platform.deepseek.com",
    },
    "local": {
        "label": "Local (Ollama / LM Studio / vLLM)",
        "api": "openai",
        "base_url": os.environ.get("LOCAL_BASE_URL", "http://localhost:11434/v1"),
        "key_env": "LOCAL_API_KEY",
        "key_label": "LOCAL_API_KEY",
        "models": ["qwen3:32b", "llama3.3:70b", "gemma3:27b", "mistral-nemo", "phi4"],
        "docs": "https://ollama.com",
        "key_optional": True,
    },
    "custom": {
        "label": "Custom OpenAI-compatible endpoint",
        "api": "openai",
        "base_url": os.environ.get("CUSTOM_BASE_URL", ""),
        "key_env": "CUSTOM_API_KEY",
        "key_label": "CUSTOM_API_KEY",
        "models": [],
        "docs": "",
        "key_optional": True,
    },
    "mock": {
        "label": "Offline demo model (no API key needed)",
        "api": "mock",
        "base_url": "",
        "key_env": "",
        "key_label": "",
        "models": ["nimbus-offline"],
        "docs": "",
        "key_optional": True,
    },
}


def get_key(provider: str) -> str:
    """Runtime override (set in the UI) wins over environment."""
    spec = PROVIDERS.get(provider)
    if not spec:
        return ""
    env_name = spec.get("key_env") or ""
    if provider == "custom":
        return settings.runtime.get("CUSTOM_API_KEY") or os.environ.get("CUSTOM_API_KEY", "")
    if not env_name:
        return ""
    return settings.runtime.get(env_name) or os.environ.get(env_name, "")


def get_base_url(provider: str) -> str:
    spec = PROVIDERS.get(provider, {})
    if provider == "local":
        return settings.runtime.get("LOCAL_BASE_URL") or spec.get("base_url", "")
    if provider == "custom":
        return settings.runtime.get("CUSTOM_BASE_URL") or os.environ.get("CUSTOM_BASE_URL", "")
    return spec.get("base_url", "")


def provider_ready(provider: str) -> bool:
    spec = PROVIDERS.get(provider)
    if not spec:
        return False
    if provider == "mock":
        return True
    if provider == "local":
        # only "ready" if the user explicitly pointed us at a local server,
        # so a fresh install never defaults to a dead localhost endpoint
        return bool(settings.runtime.get("LOCAL_BASE_URL") or os.environ.get("LOCAL_BASE_URL"))
    if provider == "custom":
        return bool(get_base_url(provider))
    return bool(get_key(provider))


def available_providers() -> list[dict]:
    out = []
    for pid, spec in PROVIDERS.items():
        out.append(
            {
                "id": pid,
                "label": spec["label"],
                "models": spec["models"],
                "key_label": spec.get("key_label", ""),
                "docs": spec.get("docs", ""),
                "ready": provider_ready(pid),
                "base_url": get_base_url(pid),
            }
        )
    return out


def default_provider() -> str:
    want = os.environ.get("NIMBUS_DEFAULT_PROVIDER", "xai").strip()
    if want and provider_ready(want):
        return want
    for pid in ("xai", "anthropic", "openai", "openrouter", "groq", "deepseek", "custom", "local"):
        if provider_ready(pid):
            return pid
    # nothing configured → the offline demo model keeps the whole platform usable
    return "mock"


def default_model() -> str:
    provider = default_provider()
    if provider == "mock":
        return "nimbus-offline"
    want = os.environ.get("NIMBUS_DEFAULT_MODEL", "").strip()
    if want:
        return want
    models = PROVIDERS[provider]["models"]
    return models[0] if models else ""
