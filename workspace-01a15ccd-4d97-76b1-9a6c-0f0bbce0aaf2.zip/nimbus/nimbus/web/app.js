/* ==========================================================================
   Nimbus UI — vanilla JS, no build step.
   ========================================================================== */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtBytes = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : b > 1024 ? (b / 1024).toFixed(1) + ' KB' : (b || 0) + ' B';
const fmtTime = (t) => t ? new Date(t * 1000).toLocaleString() : '—';

/* ------------------------------ i18n --------------------------------- */
const I18N = window.NIMBUS_I18N || { en: {} };
let currentLang = 'zh';          // interface language ('en' | 'zh' | 'es')
let langSetting = 'zh';          // the setting as stored ('en' | 'zh' | 'es' | 'auto')

function T(key, vars) {
  const table = I18N[currentLang] || I18N.en || {};
  let text = table[key];
  if (text === undefined) text = (I18N.en || {})[key];
  if (text === undefined) return key;
  // plural form support: "1 step|2 steps"
  if (typeof text === 'string' && text.includes('|') && vars && vars.n !== undefined) {
    const parts = text.split('|');
    text = Number(vars.n) === 1 ? parts[0] : (parts[1] || parts[0]);
  }
  return String(text).replace(/\{(\w+)\}/g, (_, k) => (vars && vars[k] !== undefined ? vars[k] : '{' + k + '}'));
}
const rel = (t) => {
  if (!t) return '—';
  const s = Date.now() / 1000 - t;
  if (s < 60) return T('rel.now');
  if (s < 3600) return T('rel.min', { n: Math.floor(s / 60) });
  if (s < 86400) return T('rel.hour', { n: Math.floor(s / 3600) });
  return T('rel.day', { n: Math.floor(s / 86400) });
};
function localeTag() {
  const info = (state.system && state.system.language_info) || null;
  const id = langSetting;
  const fromServer = info && info.id === id ? info.locale : '';
  return fromServer || ({ en: 'en-US', zh: 'zh-CN', es: 'es-ES' }[currentLang] || 'en-US');
}
function applyStaticI18n() {
  document.documentElement.lang = currentLang === 'zh' ? 'zh-Hans' : currentLang;
  $$('[data-i18n]').forEach(el => { el.textContent = T(el.dataset.i18n); });
  $$('[data-i18n-title]').forEach(el => { el.title = T(el.dataset.i18nTitle); });
  const ph = $('#input');
  if (ph) ph.placeholder = T(compact() ? 'chat.phShort' : 'chat.placeholder', { name: state.agent ? state.agent.name : T('chat.agent') });
  document.title = currentLang === 'zh' ? 'Nimbus — 常驻智能体平台'
                 : currentLang === 'es' ? 'Nimbus — agentes siempre activos' : 'Nimbus — always-on agents';
}
async function setLanguage(code, { persist = true } = {}) {
  langSetting = code;
  currentLang = code === 'auto'
    ? ((navigator.language || 'en').toLowerCase().startsWith('zh') ? 'zh'
       : (navigator.language || 'en').toLowerCase().startsWith('es') ? 'es' : 'en')
    : code;
  if (persist) await api('/api/settings', { method: 'POST', body: { language: code } });
  applyStaticI18n();
  if (state.system) {
    state.system.language = code;
    const info = (state.system.languages || []).find(l => l.id === code);
    state.system.language_info = info || state.system.language_info;
  }
  renderAgentList(); renderThreadList(); renderConnBadge();
  setTab(state.tab);
  if (state.drawerOpen) renderDrawer();
}

const state = {
  system: null, agents: [], agent: null, threads: [], thread: null, messages: [],
  tab: 'chat', drawerOpen: false, es: null, globalEs: null, streamingEl: null, busy: false,
  composer: null, drawerKind: 'activity',
  filePath: '', approvals: [], feed: [], taskBusy: false,
  showAllThreads: false,
  // simple mode hides technical detail (tool names, arguments, raw output)
  details: localStorage.getItem('nimbus.details') === '1',
  onboarded: localStorage.getItem('nimbus.onboarded') === '1',
};

/* A configured transfer limit, for the copy the UI shows. */
function lim(key) { return ((state.system || {}).limits || {})[key] || ''; }

/* Narrow screens get the short labels (phone keyboards, fewer words). */
function compact() { return window.innerWidth < 620; }

/* Friendly, non-technical names for what an agent just did. */

/* The chip carries the identity and the status; the model badge it reveals in
   Details mode lives *inside* a fixed-height pill, and the tab strip is centred
   by a 1fr/auto/1fr grid — so switching modes moves nothing. */
function syncDetailsChrome() {
  document.body.classList.toggle('details-on', state.details);
  const label = state.details ? T('top.simple') : T('top.details');
  ['#btnDetails', '#chipDetails', '[data-mirror="details"]'].forEach((sel) => {
    const b = $(sel);
    if (!b) return;
    b.classList.toggle('active', state.details);
    const span = $('span', b);
    if (span) span.textContent = label; else if (b.dataset.mirror) b.textContent = label;
    b.title = label;
  });
  syncAgentChip();
  syncPolicy();
}

/** Everything the profile chip shows, in one place. */
function syncAgentChip() {
  const a = state.agent;
  const emoji = $('#agentEmoji'), name = $('#agentName'), model = $('#agentModel');
  if (emoji) emoji.textContent = a ? (a.emoji || '🤖') : '🛰️';
  if (name) name.textContent = a ? a.name : T('top.pick');
  if (model) model.textContent = a ? `${a.provider} · ${a.model}` : '—';
}

/** Approval policy line in the chip's popover. */
function syncPolicy() {
  const el = $('#popPolicy');
  if (!el || !state.system) return;
  const a = state.agent;
  const mode = a ? (a.approval_mode === 'inherit' ? state.system.settings.approval_mode : a.approval_mode) : '';
  el.textContent = mode ? T('chat.approvalPolicy', { mode }) : '—';
}

function setStatus(busy) {
  const el = $('#agentStatus');
  if (!el) return;
  el.textContent = busy ? T('top.working') : T('top.idle');
  el.classList.toggle('busy', !!busy);
}

/* The transcript gains or loses tool chips when the mode flips, so re-rendering
   it changes the height of everything above the fold. We remember *which*
   message sat at the top of the viewport — not just the scroll offset — and put
   that same message back in the same place. Net visible movement: none. */
function captureScrollAnchor() {
  const chat = $('#chat');
  if (!chat) return null;
  const nodes = $$('.msg', chat);
  const top = chat.getBoundingClientRect().top;
  let index = 0, delta = 0;
  for (let i = 0; i < nodes.length; i++) {
    const r = nodes[i].getBoundingClientRect();
    index = i; delta = r.top - top;
    if (r.bottom > top + 2) break;
  }
  return { top: chat.scrollTop, stick: follow.stick, index, delta, count: nodes.length };
}

function restoreScrollAnchor(anchor) {
  const chat = $('#chat');
  if (!chat || !anchor) return;
  if (anchor.stick) { chat.scrollTop = chat.scrollHeight; follow.stick = true; updateJump(); return; }
  const node = $$('.msg', chat)[Math.min(anchor.index, $$('.msg', chat).length - 1)];
  if (node) {
    const top = chat.getBoundingClientRect().top;
    chat.scrollTop = anchor.top + ((node.getBoundingClientRect().top - top) - anchor.delta);
  } else {
    chat.scrollTop = anchor.top;
  }
  follow.stick = false;
  updateJump();
}

function toggleDetails(force) {
  state.details = force === undefined ? !state.details : !!force;
  localStorage.setItem('nimbus.details', state.details ? '1' : '0');
  const anchor = captureScrollAnchor();
  applyStaticI18n();
  syncDetailsChrome();
  if (state.tab === 'chat') renderChat();
  else setTab(state.tab);
  restoreScrollAnchor(anchor);
}
function hideOnboarding() {
  state.onboarded = true;
  localStorage.setItem('nimbus.onboarded', '1');
  renderChat();
}

/* ------------------------------- helpers ------------------------------- */
function getAuthToken() {
  return sessionStorage.getItem('nimbusAuthToken') || '';
}

function setAuthToken(token) {
  sessionStorage.setItem('nimbusAuthToken', token);
}

function promptForToken() {
  const token = prompt('Please enter your Nimbus authentication token:');
  if (token) {
    setAuthToken(token);
    return token;
  }
  return null;
}

async function api(path, opts = {}) {
  const init = { method: opts.method || 'GET', headers: {} };
  
  // Add auth token to headers
  let token = getAuthToken();
  if (!token) {
    token = promptForToken();
    if (!token) {
      throw new Error('Authentication required');
    }
  }
  init.headers['Authorization'] = `Bearer ${token}`;
  
  if (opts.body instanceof FormData) init.body = opts.body;
  else if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
  const res = await fetch(path, init);
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    if (res.status === 401) {
      // Token might be invalid, prompt again
      setAuthToken('');
      throw new Error('Invalid authentication token');
    }
    throw new Error((data && (data.detail || data.error)) || `HTTP ${res.status}`);
  }
  return data;
}
function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toastRoot').appendChild(el);
  setTimeout(() => el.remove(), kind === 'err' ? 7000 : 3800);
}
function modal({ title, body, footer, wide }) {
  const wrap = document.createElement('div');
  wrap.className = 'modal-wrap';
  wrap.innerHTML = `<div class="modal" style="${wide ? 'width:min(880px,100%)' : ''}">
    <header><h3>${esc(title)}</h3><div class="spacer"></div><button class="btn ghost sm" data-x>✕</button></header>
    <div class="content"></div><footer></footer></div>`;
  const content = $('.content', wrap); content.innerHTML = body || '';
  const f = $('footer', wrap);
  (footer || [{ label: T('modal.close') }]).forEach(b => {
    const btn = document.createElement('button');
    btn.className = 'btn ' + (b.kind || '');
    btn.textContent = b.label;
    btn.onclick = async () => { if (b.onClick) { const keep = await b.onClick(content, wrap); if (keep === false) return; } wrap.remove(); };
    f.appendChild(btn);
  });
  wrap.addEventListener('click', e => { if (e.target === wrap || e.target.hasAttribute('data-x')) wrap.remove(); });
  $('#modalRoot').appendChild(wrap);
  return wrap;
}

/* ------------------------------ markdown ------------------------------ */
function md(src) {
  let s = esc(src || '');
  const blocks = [];
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => { blocks.push(code); return `\u0000${blocks.length - 1}\u0000`; });
  s = s.replace(/^###### (.*)$/gm, '<h3>$1</h3>').replace(/^##### (.*)$/gm, '<h3>$1</h3>')
       .replace(/^#### (.*)$/gm, '<h3>$1</h3>').replace(/^### (.*)$/gm, '<h3>$1</h3>')
       .replace(/^## (.*)$/gm, '<h2>$1</h2>').replace(/^# (.*)$/gm, '<h1>$1</h1>');
  s = s.replace(/^\s*[-*+]\s+(.*)$/gm, '<li>$1</li>').replace(/^\s*(\d+)[.)]\s+(.*)$/gm, '<li>$2</li>');
  s = s.replace(/(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g, m => `<ul>${m}</ul>`);
  s = s.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/(^|\W)\*([^*\n]+)\*/g, '$1<em>$2</em>');
  s = s.replace(/(^|\s)_([^_\n]+)_(?=\s|$|[.,!?;:])/g, '$1<em>$2</em>');
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2" style="max-width:100%">');
  s = s.replace(/\[([^\]]+)\]\((https?:[^)\s]+|\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  s = s.replace(/^&gt;\s?(.*)$/gm, '<blockquote>$1</blockquote>');
  s = s.replace(/^\s*(?:---|\*\*\*)\s*$/gm, '<hr>');
  // simple tables
  s = s.replace(/(^\|.*\|\s*$\n^\|[\s:|-]+\|\s*$\n(?:^\|.*\|\s*$\n?)*)/gm, (tbl) => {
    const rows = tbl.trim().split('\n').filter(r => !/^\|[\s:|-]+\|$/.test(r.trim()));
    const cells = rows.map((r, i) => {
      const tds = r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
      const tag = i === 0 ? 'th' : 'td';
      return `<tr>${tds.map(c => `<${tag}>${c}</${tag}>`).join('')}</tr>`;
    }).join('');
    return `<table>${cells}</table>`;
  });
  s = s.replace(/\n{2,}/g, '</p><p>').replace(/\n/g, '<br>');
  s = `<p>${s}</p>`;
  s = s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<pre><code>${blocks[+i]}</code></pre>`);
  return s.replace(/<p>\s*(<(?:h1|h2|h3|ul|ol|pre|table|blockquote|hr)[^>]*>)/g, '$1')
          .replace(/(<\/(?:h1|h2|h3|ul|ol|pre|table|blockquote)>)\s*<\/p>/g, '$1');
}

function toolGroup(name) {
  const key = 'tool.group.' + name;
  const v = T(key);
  return v === key ? name : v;
}

/* ------------------------------- boot -------------------------------- */
async function boot() {
  try { state.system = await api('/api/system'); }
  catch (e) {
    $('#pane').innerHTML = `<div class="empty"><h2>${esc(T('boot.apiDown'))}</h2>
      <p>${esc(e.message)}</p><p>${T('boot.startHint')}</p></div>`;
    return;
  }
  langSetting = state.system.language || 'zh';
  currentLang = langSetting === 'auto'
    ? ((navigator.language || 'zh').toLowerCase().startsWith('zh') ? 'zh'
       : (navigator.language || 'zh').toLowerCase().startsWith('es') ? 'es' : 'zh')
    : langSetting;
  applyStaticI18n();
  syncDetailsChrome();
  renderConnBadge();
  await loadAgents();
  if (!state.agents.length) {
    try { const r = await api('/api/demo/team', { method: 'POST' }); toast(T('boot.seeded', { n: r.created.length })); }
    catch (e) { toast(T('boot.seedFailed', { error: e.message }), 'err'); }
    await loadAgents();
  }
  if (state.agents.length) await selectAgent(state.agents[0].id);
  connectGlobalStream();
  pollApprovals();
  syncDetailsChrome();
  setInterval(pollApprovals, 8000);
  wireChrome();
}

function wireChrome() {
  $('#btnNewAgent').onclick = newAgentModal;
  $('#btnNewThread').onclick = async () => {
    if (!state.agent) return;
    const t = await api(`/api/agents/${state.agent.id}/threads`, { method: 'POST', body: { title: 'New thread' } });
    await loadThreads(); await openThread(t.id);
  };
  $('#drawerClose').onclick = () => setDrawer(false);
  const sideBtn = $('#btnSide');
  if (sideBtn) sideBtn.onclick = (e) => { e.stopPropagation(); toggleSidebar(); };
  // on narrow screens the sidebar is a slide-over: close it as soon as the user picks something
  $('#sidebar').addEventListener('click', (e) => {
    if (e.target.closest('button, .agent-item, a')) closeSidebar();
  });
  $$('#tabs button[data-tab]').forEach(b => b.onclick = () => setTab(b.dataset.tab));
  const more = $('#btnMore');
  if (more) more.onclick = (e) => { e.stopPropagation(); menuToggle('moreMenu', '#btnMore'); };
  const overflow = $('#btnOverflow');
  if (overflow) overflow.onclick = (e) => { e.stopPropagation(); menuToggle('overflowMenu', '#btnOverflow'); };
  wireMirrors();
  wireAgentChip();
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#moreMenu') && !e.target.closest('.tab-more')) closeMoreMenu();
    if (!e.target.closest('#overflowMenu') && e.target.id !== 'btnOverflow') closeOverflowMenu();
    if (!e.target.closest('#agentPop') && !e.target.closest('#agentChip')) closeAgentPop();
  });
  const det = $('#btnDetails');
  if (det) det.onclick = () => toggleDetails();
  $('#drawer').classList.add('hidden');
  $$('[data-panel]').forEach(b => b.onclick = () => setDrawer(true, b.dataset.panel));
  $('#btnDrawer').dataset.panel = 'activity';
  $('#scrim').onclick = () => { closeSidebar(); setDrawer(false); };
  wireSheetDrag();
  wireSidebarDrag();
  wireTabsScroll();
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!$('#agentPop').classList.contains('hidden') || !$('#moreMenu').classList.contains('hidden')
        || !$('#overflowMenu').classList.contains('hidden')) {
      closeAgentPop(); closeMoreMenu(); closeOverflowMenu();
    }
  });
  window.addEventListener('resize', reconcileChrome);
  $('#btnStop').onclick = async () => { if (state.thread) { await api(`/api/threads/${state.thread.id}/stop`, { method: 'POST' }); toast(T('chat.stopping')); } };
}

function closeMoreMenu() { const m = $('#moreMenu'); if (m) m.classList.add('hidden'); }
function closeOverflowMenu() {
  const m = $('#overflowMenu');
  if (m) m.classList.add('hidden');
  const b = $('#btnOverflow');
  if (b) b.setAttribute('aria-expanded', 'false');
}
function closeAgentPop() {
  const p = $('#agentPop');
  if (p) p.classList.add('hidden');
  const c = $('#agentChip');
  if (c) c.setAttribute('aria-expanded', 'false');
}

/** One dropdown at a time, with the trigger's aria state kept honest. */
function menuToggle(menuId, triggerSel) {
  const menu = document.getElementById(menuId);
  if (!menu) return;
  const open = menu.classList.contains('hidden');
  closeMoreMenu(); closeOverflowMenu(); closeAgentPop();
  menu.classList.toggle('hidden', !open);
  const t = $(triggerSel);
  if (t) t.setAttribute('aria-expanded', String(open));
}

function wireAgentChip() {
  const chip = $('#agentChip');
  if (!chip) return;
  chip.onclick = (e) => { e.stopPropagation(); syncAgentChip(); syncPolicy(); menuToggle('agentPop', '#agentChip'); };
  const edit = $('#chipEdit');
  if (edit) edit.onclick = () => { closeAgentPop(); editAgentModal(); };
  const det = $('#chipDetails');
  if (det) det.onclick = () => { closeAgentPop(); toggleDetails(); };
}

/** The overflow items are the same actions, folded away on medium screens. */
function wireMirrors() {
  $$('[data-mirror]').forEach((b) => {
    b.onclick = () => {
      closeOverflowMenu();
      const what = b.dataset.mirror;
      if (what === 'details') toggleDetails();
      else if (what === 'sidebar') toggleSidebar(true);
      else setDrawer(true, what);
    };
  });
}

/* --------------------------- overlays & scrim -------------------------- */
/* One blurred scrim serves both the sidebar slide-over and the activity sheet;
   it is on whenever either of them is, and tapping it dismisses them. */
function updateScrim() {
  const on = document.body.classList.contains('side-open') || document.body.classList.contains('sheet-open');
  document.body.classList.toggle('scrim-on', on);
}

function toggleSidebar(force) {
  const open = force === undefined ? !document.body.classList.contains('side-open') : !!force;
  document.body.classList.toggle('side-open', open);
  if (open) closeAgentPop(), closeMoreMenu(), closeOverflowMenu();
  updateScrim();
}
function closeSidebar() {
  if (!document.body.classList.contains('side-open')) return;
  document.body.classList.remove('side-open');
  updateScrim();
}

/**
 * The activity panel. Wide screens dock it beside the transcript; phones get a
 * bottom sheet with a grip, a half-height peek and an expanded snap point.
 */
function setDrawer(open, kind) {
  if (kind) state.drawerKind = kind;
  state.drawerOpen = !!open;
  const sheet = isSheet();
  const el = $('#drawer');
  if (open) {
    el.classList.remove('hidden');
    if (sheet) document.body.classList.add('sheet-open');
    if (state.drawerKind === 'approvals') { state.drawerOpen = true; }
    renderDrawer();
  } else {
    document.body.classList.remove('sheet-open', 'sheet-full');
    if (!sheet) el.classList.add('hidden');
    el.style.transform = '';
  }
  updateScrim();
}
const isSheet = () => window.innerWidth < 768;

/** Keep the chrome coherent when the viewport crosses a breakpoint. */
function reconcileChrome() {
  if (!isSheet()) {
    document.body.classList.remove('sheet-open', 'sheet-full');
    $('#drawer').classList.remove('dragging');
    $('#drawer').style.transform = '';
    if (!state.drawerOpen) $('#drawer').classList.add('hidden');
  } else {
    $('#drawer').classList.toggle('hidden', false);
    document.body.classList.toggle('sheet-open', state.drawerOpen);
  }
  if (window.innerWidth > 1080) closeSidebar();
  updateScrim();
  markTabsScrollable();
}

/* ------------------------------- gestures ------------------------------ */
const px = (v) => Math.round(v * 100) / 100;

/** Drag the sheet by its grip or header: down closes, up expands. */
function wireSheetDrag() {
  const el = $('#drawer');
  if (!el) return;
  let startY = 0, dy = 0, lastY = 0, lastT = 0, velocity = 0, dragging = false;

  const onDown = (e) => {
    if (!isSheet() || !state.drawerOpen) return;
    if (!e.target.closest('.sheet-grip') && !e.target.closest('.drawer-head')) return;
    dragging = true; dy = 0;
    startY = lastY = e.clientY; lastT = performance.now(); velocity = 0;
    el.classList.add('dragging');
    if (el.setPointerCapture) { try { el.setPointerCapture(e.pointerId); } catch { /* ignore */ } }
  };
  const onMove = (e) => {
    if (!dragging) return;
    dy = e.clientY - startY;
    const t = performance.now();
    velocity = (e.clientY - lastY) / Math.max(1, t - lastT);
    lastY = e.clientY; lastT = t;
    el.style.transform = `translateY(${px(dy < 0 ? dy * 0.35 : dy)}px)`;   // rubber band upward
    e.preventDefault();
  };
  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');
    el.style.transform = '';
    const h = el.getBoundingClientRect().height || 1;
    const full = document.body.classList.contains('sheet-full');
    if (dy > h * 0.3 || velocity > 0.65) { setDrawer(false); return; }      // flick or pull down
    if (dy < -46 || velocity < -0.65) { document.body.classList.add('sheet-full'); return; }
    if (full && dy > 44) document.body.classList.remove('sheet-full');
  };
  el.addEventListener('pointerdown', onDown);
  el.addEventListener('pointermove', onMove);
  el.addEventListener('pointerup', onUp);
  el.addEventListener('pointercancel', onUp);
}

/** Swipe the slide-over away horizontally (vertical scrolling is untouched). */
function wireSidebarDrag() {
  const el = $('#sidebar');
  if (!el) return;
  let x0 = 0, y0 = 0, dx = 0, lastX = 0, lastT = 0, velocity = 0, mode = '', dragging = false;

  const onDown = (e) => {
    if (window.innerWidth > 1080 || !document.body.classList.contains('side-open')) return;
    dragging = true; mode = ''; dx = 0;
    x0 = lastX = e.clientX; y0 = e.clientY; lastT = performance.now(); velocity = 0;
  };
  const onMove = (e) => {
    if (!dragging) return;
    const ax = e.clientX - x0, ay = e.clientY - y0;
    if (!mode) {
      if (Math.abs(ax) < 8 && Math.abs(ay) < 8) return;
      mode = Math.abs(ax) > Math.abs(ay) * 1.4 ? 'x' : 'scroll';   // let vertical scrolls through
      if (mode === 'x') el.classList.add('dragging');
    }
    if (mode !== 'x') return;
    dx = Math.min(0, ax);
    const t = performance.now();
    velocity = (e.clientX - lastX) / Math.max(1, t - lastT);
    lastX = e.clientX; lastT = t;
    el.style.transform = `translateX(${px(dx)}px)`;
  };
  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');
    el.style.transform = '';
    if (mode === 'x' && (dx < -70 || velocity < -0.5)) closeSidebar();
    mode = '';
  };
  el.addEventListener('pointerdown', onDown);
  el.addEventListener('pointermove', onMove);
  el.addEventListener('pointerup', onUp);
  el.addEventListener('pointercancel', onUp);
}

/* ------------------------------ tab strip ------------------------------ */
/** The strip scrolls; the mask only appears when there is something to scroll. */
function markTabsScrollable() {
  const tabs = $('#tabs');
  if (!tabs) return;
  tabs.classList.toggle('scrollable', tabs.scrollWidth > tabs.clientWidth + 2);
}
function scrollTabIntoView(tab) {
  const tabs = $('#tabs');
  const btn = tabs && tabs.querySelector(`button[data-tab="${tab}"]`);
  if (!btn || tabs.scrollWidth <= tabs.clientWidth + 2) return;
  const want = btn.offsetLeft - (tabs.clientWidth - btn.offsetWidth) / 2;
  tabs.scrollTo({ left: Math.max(0, want), behavior: 'smooth' });
}
function wireTabsScroll() {
  const tabs = $('#tabs');
  if (!tabs) return;
  markTabsScrollable();
  if (window.ResizeObserver) new ResizeObserver(markTabsScrollable).observe(tabs);
  tabs.addEventListener('scroll', markTabsScrollable, { passive: true });
}

function renderConnBadge() {
  const g = state.system.google.google;
  const state_ = g.demo ? 'demo' : g.connected ? 'ok' : 'warn';
  const el = $('#connBadge');
  el.className = 'badge ' + state_;
  el.textContent = g.demo ? T('conn.demo') : g.connected ? T('conn.connected', { account: g.account }) : T('conn.none');
  el.title = g.demo ? T('conn.demoTitle') : g.connected ? T('conn.connectedTitle') : T('conn.noneTitle');
  const dot = $('#connDot');                       // the chip shows the same fact as a dot
  if (dot) {
    dot.className = 'chip-dot ' + state_;
    dot.title = el.title;
  }
}

/* ------------------------------ agents ------------------------------ */
async function loadAgents() {
  state.agents = await api('/api/agents');
  renderAgentList();
}
function renderAgentList() {
  const el = $('#agentList');
  el.innerHTML = state.agents.map(a => `<div class="agent-item ${state.agent && state.agent.id === a.id ? 'active' : ''}" data-id="${a.id}">
      <div class="emoji">${esc(a.emoji || '🤖')}</div>
      <div class="meta">
        <div class="name">${esc(a.name)} <span class="dot ${a.status === 'working' ? 'working' : ''}"></span></div>
        <div class="desc">${esc(a.title || a.description || 'agent')}</div>
      </div>
    </div>`).join('') || `<p style="color:var(--dim);padding:8px">${esc(T('side.noAgents'))}</p>`;
  $$('#agentList .agent-item').forEach(n => n.onclick = () => selectAgent(n.dataset.id));
}

async function selectAgent(id) {
  state.agent = await api(`/api/agents/${id}`);
  state.system && renderConnBadge();
  syncAgentChip();
  syncPolicy();
  $('#agentStatus').textContent = state.agent.status === 'working' ? T('top.working') : T('top.idle');
  renderAgentList();
  await loadThreads();
  const last = state.threads.find(t => t.agent_id === id);
  if (last) await openThread(last.id); else { state.thread = null; state.messages = []; setTab(state.tab); }
}

async function loadThreads() {
  state.threads = await api('/api/threads?limit=80');
  renderThreadList();
}
function renderThreadList() {
  const mine = state.threads.filter(t => !state.agent || t.agent_id === state.agent.id);
  const limit = state.showAllThreads ? 60 : 4;
  const list = mine.slice(0, limit).map(t => `<div class="agent-item ${state.thread && state.thread.id === t.id ? 'active' : ''}" data-id="${t.id}">
      <div class="emoji">${t.kind === 'routine' ? '⏰' : t.kind === 'delegation' ? '🤝' : '💬'}</div>
      <div class="meta"><div class="name" style="font-weight:500">${esc(t.title)}</div>
      <div class="desc">${T('thread.msg', { count: t.message_count })} · ${rel(t.updated_at)}</div></div>
    </div>`).join('');
  const more = mine.length > 4
    ? `<button class="btn sm ghost" id="threadMore" style="width:100%;justify-content:center">
         ${state.showAllThreads ? esc(T('thread.showLess')) : esc(T('thread.showAll', { n: mine.length }))}</button>`
    : '';
  $('#threadList').innerHTML = (list || `<p style="color:var(--dim);padding:8px">${esc(T('side.noThreads'))}</p>`) + more;
  const mt = $('#threadMore');
  if (mt) mt.onclick = () => { state.showAllThreads = !state.showAllThreads; renderThreadList(); };
  $$('#threadList .agent-item').forEach(n => n.onclick = () => openThread(n.dataset.id));
}

async function newAgentModal() {
  const tools = state.system.tools.map(g => `<div style="width:100%;margin:6px 0 2px;color:var(--muted);font-size:11.5px;text-transform:uppercase;letter-spacing:.06em">${esc(toolGroup(g.group))}</div>` +
    g.tools.map(t => `<label title="${esc(t.description)}"><input type="checkbox" value="${t.name}" checked>${esc(t.icon || '')} ${esc(t.name)}</label>`).join('')).join('');
  const provOpts = state.system.providers.map(p => `<option value="${p.id}" ${p.id === state.system.default_provider ? 'selected' : ''}>${esc(p.label)}${p.ready ? '' : ' ' + T('agent.noKey')}</option>`).join('');
  const langOpts = (state.system.languages || []).filter(l => l.id !== 'auto')
    .map(l => `<option value="${l.id}" ${state.agent && state.agent.language === l.id ? 'selected' : ''}>${esc(l.native || l.label)}</option>`).join('');
  modal({
    title: T('agent.title'), wide: true,
    body: `<label class="field"><span>${T('agent.name')}</span><input type="text" id="na-name" placeholder="${esc(T('agent.namePh'))}"></label>
      <label class="field"><span>${T('agent.roleTitle')}</span><input type="text" id="na-title" placeholder="${esc(T('agent.roleTitlePh'))}"></label>
      <label class="field"><span>${T('agent.desc')}</span>
        <textarea id="na-desc" rows="2" placeholder="${esc(T('agent.descPh'))}"></textarea></label>
      <label class="field"><span>${T('agent.persona')}</span><input type="text" id="na-persona" placeholder="${esc(T('agent.personaPh'))}"></label>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <label class="field" style="flex:1;min-width:180px"><span>${T('agent.provider')}</span><select id="na-provider">${provOpts}</select></label>
        <label class="field" style="flex:1;min-width:180px"><span>${T('agent.model')}</span><input type="text" id="na-model" value="${esc(state.system.default_model)}"></label>
        <label class="field" style="width:110px"><span>${T('agent.emoji')}</span><input type="text" id="na-emoji" value="🤖"></label>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <label class="field" style="flex:1;min-width:180px"><span>${T('agent.approval')}</span>
          <select id="na-approval"><option value="inherit">${T('agent.inherit')}</option><option value="risky">${T('agent.risky')}</option>
          <option value="all">${T('agent.all')}</option><option value="auto">${T('agent.auto')}</option></select></label>
        <label class="field" style="flex:1;min-width:170px"><span>${T('agent.language')}</span>
          <select id="na-lang"><option value="inherit">${esc(T('agent.languageInherit', { lang: (state.system.language_info || {}).native || 'English' }))}</option>${langOpts}</select></label>
        <label class="field" style="width:140px"><span>${T('agent.temp')}</span><input type="number" id="na-temp" value="0.3" step="0.05" min="0" max="2"></label>
        <label class="field" style="width:140px"><span>${T('agent.steps')}</span><input type="number" id="na-steps" value="12" min="1" max="40"></label>
      </div>
      ${state.details
        ? `<label class="field"><span>${T('agent.tools', { n: state.system.tools.reduce((n, g) => n + g.tools.length, 0) })}</span>
        <div class="toolpick" id="na-tools">${tools}</div></label>`
        : `<input type="hidden" id="na-tools-all" value="all">`}
        <div class="hintrow"><button class="btn sm" type="button" id="na-all">${T('agent.selectAll')}</button>
        <button class="btn sm" type="button" id="na-none">${T('agent.clear')}</button></div></label>`,
    footer: [{ label: T('agent.cancel') }, {
      label: T('agent.create'), kind: 'primary', onClick: async (c) => {
        const tools = state.details ? $$('#na-tools input:checked', c).map(i => i.value)
                                    : state.system.tools.flatMap(g => g.tools.map(t => t.name));
        const body = {
          name: $('#na-name', c).value.trim(), title: $('#na-title', c).value.trim(),
          description: $('#na-desc', c).value.trim(), persona: $('#na-persona', c).value.trim(),
          provider: $('#na-provider', c).value, model: $('#na-model', c).value.trim(),
          emoji: $('#na-emoji', c).value.trim() || '🤖', tools,
          approval_mode: $('#na-approval', c).value, temperature: parseFloat($('#na-temp', c).value || '0.3'),
          max_iterations: parseInt($('#na-steps', c).value || '12', 10),
          language: $('#na-lang', c).value,
        };
        if (!body.name) { toast(T('agent.nameRequired'), 'err'); return false; }
        const a = await api('/api/agents', { method: 'POST', body });
        toast(T('agent.created', { name: a.name }));
        await loadAgents(); await selectAgent(a.id); setTab('chat');
      }
    }]
  });
  setTimeout(() => {
    $('#na-provider').onchange = (e) => {
      const p = state.system.providers.find(x => x.id === e.target.value);
      if (p && p.models && p.models.length) $('#na-model').value = p.models[0];
    };
    $('#na-all').onclick = () => $$('#na-tools input').forEach(i => i.checked = true);
    $('#na-none').onclick = () => $$('#na-tools input').forEach(i => i.checked = false);
  }, 0);
}

function editAgentModal() {
  if (!state.agent) return;
  const a = state.agent;
  const tools = state.system.tools.map(g => `<div style="width:100%;margin:6px 0 2px;color:var(--muted);font-size:11.5px;text-transform:uppercase;letter-spacing:.06em">${esc(toolGroup(g.group))}</div>` +
    g.tools.map(t => `<label title="${esc(t.description)}"><input type="checkbox" value="${t.name}" ${(a.tools || []).includes(t.name) ? 'checked' : ''}>${esc(t.icon || '')} ${esc(t.name)}</label>`).join('')).join('');
  const provOpts = state.system.providers.map(p => `<option value="${p.id}" ${p.id === a.provider ? 'selected' : ''}>${esc(p.label)}${p.ready ? '' : ' ' + T('agent.noKey')}</option>`).join('');
  const langOpts = (state.system.languages || []).filter(l => l.id !== 'auto')
    .map(l => `<option value="${l.id}" ${a.language === l.id ? 'selected' : ''}>${esc(l.native || l.label)}</option>`).join('');
  const inherit = `<option value="inherit" ${(!a.language || a.language === 'inherit') ? 'selected' : ''}>${esc(T('agent.languageInherit', { lang: (state.system.language_info || {}).native || 'English' }))}</option>`;
  modal({
    title: T('agent.edit') + ' — ' + a.name, wide: true,
    body: `<div style="display:flex;gap:10px;flex-wrap:wrap">
        <label class="field" style="flex:2;min-width:200px"><span>${T('agent.name')}</span><input type="text" id="ea-name" value="${esc(a.name)}"></label>
        <label class="field" style="flex:2;min-width:200px"><span>${T('agent.roleTitle')}</span><input type="text" id="ea-title" value="${esc(a.title || '')}"></label>
        <label class="field" style="width:100px"><span>${T('agent.emoji')}</span><input type="text" id="ea-emoji" value="${esc(a.emoji || '🤖')}"></label>
      </div>
      <label class="field"><span>${T('agent.desc')}</span><textarea id="ea-desc" rows="2">${esc(a.description || '')}</textarea></label>
      <label class="field"><span>${T('agent.persona')}</span><input type="text" id="ea-persona" value="${esc(a.persona || '')}"></label>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <label class="field" style="flex:1;min-width:170px"><span>${T('agent.provider')}</span><select id="ea-provider">${provOpts}</select></label>
        <label class="field" style="flex:1;min-width:170px"><span>${T('agent.model')}</span><input type="text" id="ea-model" value="${esc(a.model || '')}"></label>
        <label class="field" style="flex:1;min-width:190px"><span>${T('agent.language')}</span><select id="ea-lang">${inherit}${langOpts}</select></label>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <label class="field" style="flex:1;min-width:170px"><span>${T('agent.approval')}</span>
          <select id="ea-approval">
            <option value="inherit" ${a.approval_mode === 'inherit' ? 'selected' : ''}>${T('agent.inherit')}</option>
            <option value="risky" ${a.approval_mode === 'risky' ? 'selected' : ''}>${T('agent.risky')}</option>
            <option value="all" ${a.approval_mode === 'all' ? 'selected' : ''}>${T('agent.all')}</option>
            <option value="auto" ${a.approval_mode === 'auto' ? 'selected' : ''}>${T('agent.auto')}</option></select></label>
        <label class="field" style="width:140px"><span>${T('agent.temp')}</span><input type="number" id="ea-temp" value="${a.temperature}" step="0.05" min="0" max="2"></label>
        <label class="field" style="width:150px"><span>${T('agent.steps')}</span><input type="number" id="ea-steps" value="${a.max_iterations}" min="1" max="40"></label>
      </div>
      <label class="field"><span>${T('agent.tools', { n: state.system.tools.reduce((n, g) => n + g.tools.length, 0) })}</span>
        <div class="toolpick" id="ea-tools">${tools}</div>
        <div class="hintrow"><button class="btn sm" type="button" id="ea-all">${T('agent.selectAll')}</button>
        <button class="btn sm" type="button" id="ea-none">${T('agent.clear')}</button></div></label>`,
    footer: [{ label: T('agent.cancel') }, {
      label: T('skills.save'), kind: 'primary', onClick: async (c) => {
        const body = {
          name: $('#ea-name', c).value.trim() || a.name, title: $('#ea-title', c).value.trim(),
          description: $('#ea-desc', c).value.trim(), persona: $('#ea-persona', c).value.trim(),
          emoji: $('#ea-emoji', c).value.trim() || '🤖', provider: $('#ea-provider', c).value,
          model: $('#ea-model', c).value.trim(), language: $('#ea-lang', c).value,
          approval_mode: $('#ea-approval', c).value, temperature: parseFloat($('#ea-temp', c).value || '0.3'),
          max_iterations: parseInt($('#ea-steps', c).value || '12', 10),
          tools: $$('#ea-tools input:checked', c).map(i => i.value),
        };
        await api(`/api/agents/${a.id}`, { method: 'PATCH', body });
        toast(T('agent.updated'));
        state.system = await api('/api/system');
        await loadAgents(); await selectAgent(a.id);
        if (state.tab === 'settings') renderSettings();
      }
    }]
  });
  setTimeout(() => {
    $('#ea-provider').onchange = (e) => {
      const p = state.system.providers.find(x => x.id === e.target.value);
      if (p && p.models && p.models.length) $('#ea-model').value = p.models[0];
    };
    $('#ea-all').onclick = () => $$('#ea-tools input').forEach(i => i.checked = true);
    $('#ea-none').onclick = () => $$('#ea-tools input').forEach(i => i.checked = false);
  }, 0);
}

/* ------------------------------ threads ------------------------------ */
async function openThread(id) {
  state.thread = await api(`/api/threads/${id}`);
  state.messages = state.thread.messages || [];
  if (state.thread.agent && (!state.agent || state.agent.id !== state.thread.agent_id)) {
    state.agent = state.thread.agent;
    syncAgentChip();
    syncPolicy();
  }
  state.busy = (state.thread.status === 'running');
  $('#btnStop').style.display = state.busy ? '' : 'none';
  setStatus(state.busy);
  renderThreadList();
  connectThreadStream(id);
  if (state.tab === 'chat') renderChat();
  else setTab(state.tab);
}

/* -------------------------------- SSE -------------------------------- */
function connectThreadStream(threadId) {
  if (state.es) { state.es.close(); state.es = null; }
  const token = getAuthToken();
  if (!token) {
    toast('Please set authentication token in Settings', 'err');
    return;
  }
  const es = new EventSource(`/api/stream?thread_id=${encodeURIComponent(threadId)}&token=${encodeURIComponent(token)}`);
  es.onmessage = (m) => { try { handleEvent(JSON.parse(m.data)); } catch { } };
  es.onerror = () => { /* browser auto-reconnects */ };
  state.es = es;
}
function connectGlobalStream() {
  const token = getAuthToken();
  if (!token) {
    toast('Please set authentication token in Settings', 'err');
    return;
  }
  const es = new EventSource(`/api/stream?all=1&token=${encodeURIComponent(token)}`);
  es.onmessage = (m) => {
    try {
      const ev = JSON.parse(m.data);
      if (ev.type === 'hello') return;
      state.feed.unshift(ev);
      state.feed = state.feed.slice(0, 200);
      if (state.drawerOpen) { if (!$('#drwFeed')) renderDrawer(); appendDrawerEvent(ev); }
      if (state.tab === 'activity') renderActivity();
      if (ev.type === 'agent_spawned' || ev.type === 'routine_end') { loadAgents().catch(() => { }); }
      if (ev.type === 'approval_request') { toast(T('chat.approvalNeeded', { tool: ev.approval.tool })); pollApprovals(); }
    } catch { }
  };
  state.globalEs = es;
}

function handleEvent(ev) {
  switch (ev.type) {
    case 'run_start':
      state.busy = true; $('#btnStop').style.display = ''; setStatus(true);
      state.streamingEl = null; closeStepper(); break;
    case 'delta': appendDelta(ev.text); break;
    case 'message': {
      if (ev.role === 'user') {
        // we render the user's own message optimistically — don't double-render the echo
        const seen = state.messages.some(m => m.role === 'user' && m.content === ev.content);
        if (seen) break;
        state.messages.push({ role: 'user', content: ev.content, created_at: ev.ts });
        renderMessage({ role: 'user', content: ev.content, created_at: ev.ts });
        break;
      }
      if (ev.role === 'assistant' && state.streamingEl) finalizeStreaming(ev.content);
      else if (ev.role === 'assistant') renderMessage({ role: 'assistant', content: ev.content, tool_calls: ev.tool_calls, meta: ev.meta });
      if (ev.role === 'assistant') {
        const last = state.messages[state.messages.length - 1];
        if (!last || last.role !== 'assistant' || last.content !== ev.content)
          state.messages.push({ role: 'assistant', content: ev.content, tool_calls: ev.tool_calls, meta: ev.meta, created_at: ev.ts });
      }
      break;
    }
    case 'tool_start': addToolChip(ev); break;
    case 'tool_end': finishToolChip(ev); break;
    case 'approval_request': renderApprovalCard(ev.approval); break;
    case 'approval_resolved': resolveApprovalCard(ev.approval_id, ev.status); break;
    case 'delegation_start': renderSystemNote(T('chat.delegationOut', { target: esc(ev.target), task: esc(ev.task || '') })); loadThreads().catch(() => { }); break;
    case 'delegation_end': renderSystemNote(T('chat.delegationBack', { target: esc(ev.target) })); loadThreads().catch(() => { }); break;
    case 'agent_spawned': renderSystemNote(T('chat.spawned', { name: esc(ev.agent.name) })); loadAgents().catch(() => { }); break;
    case 'screenshot': renderScreenshot(ev); break;
    case 'browser': renderSystemNote(T('chat.browserAt', { url: esc(ev.url), title: esc(ev.title || ev.url) })); break;
    case 'cancelled': renderSystemNote(T('chat.stopped')); break;
    case 'error': renderSystemNote(`⚠️ ${esc(ev.message)}`); break;
    case 'run_end':
      state.busy = false; $('#btnStop').style.display = 'none'; setStatus(false);
      finalizeStreaming(); closeStepper(); followScroll(); loadAgents().catch(() => { });
      if (state.tab === 'files') renderFiles();
      break;
    case 'routine_start': renderSystemNote(T('chat.routineStarted', { routine: esc(ev.routine), agent: esc(ev.agent) })); break;
  }
}

/* ------------------------------- chat -------------------------------- */
const MAIN_TABS = ['chat', 'files', 'routines', 'settings'];
const MORE_TABS = ['memory', 'activity', 'audit'];

function setTab(tab) {
  state.tab = tab;
  closeMoreMenu();
  closeOverflowMenu();
  closeSidebar();
  document.body.classList.remove('sheet-open', 'sheet-full');
  updateScrim();
  const hl = tab === 'skills' ? 'routines' : tab;
  $$('#tabs button[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === hl));
  const moreBtn = $('#btnMore');
  if (moreBtn) moreBtn.classList.toggle('active', MORE_TABS.includes(tab));
  scrollTabIntoView(hl);
  const pane = $('#pane');
  pane.innerHTML = '';
  if (tab === 'chat') renderChat();
  else if (!state.agent) { pane.innerHTML = `<div class="empty"><h2>${esc(T('chat.noAgents'))}</h2></div>`; }
  else if (tab === 'files') renderFiles();
  else if (tab === 'skills' || tab === 'routines') renderAutomations(tab === 'chat' ? 'routines' : tab);
  else if (tab === 'memory') renderMemory();
  else if (tab === 'activity') renderActivity();
  else if (tab === 'audit') renderAudit();
  else if (tab === 'settings') renderSettings();
}

function renderChat() {
  const pane = $('#pane');
  pane.innerHTML = `<div id="chat"></div><div class="composer" id="composer"></div>`;
  const chat = $('#chat');
  stepper = null; state.streamingEl = null;
  if (!state.messages.length) chat.innerHTML = welcome();
  else state.messages.forEach(m => chat.appendChild(messageNode(m)));
  wireChatScroll(chat);
  scrollChat(true);
  mountComposer(pane);
  const policy = state.agent ? (state.agent.approval_mode === 'inherit' ? state.system.settings.approval_mode : state.agent.approval_mode) : '';
  $('#modeHint').textContent = state.details
    ? (state.agent ? T('chat.approvalPolicy', { mode: policy }) : '')
    : T('chat.simpleHint');
  $$('.suggestions button', chat).forEach(b => b.onclick = () => {
    if (state.composer) state.composer.setValue(b.dataset.p);
  });
  const hideBtn = $('[data-hide-onboard]', chat); if (hideBtn) hideBtn.onclick = hideOnboarding;
  const showBtn = $('[data-show-onboard]', chat); if (showBtn) showBtn.onclick = () => {
    state.onboarded = false; localStorage.removeItem('nimbus.onboarded'); renderChat();
  };
  const sm = $('[data-step-model]', chat); if (sm) sm.onclick = () => setTab('settings');
  const sg = $('[data-step-google]', chat); if (sg) sg.onclick = () => setTab('settings');

  if (state.busy) state.streamingEl = null;
}

/* --------------------------- rich composer --------------------------- */
/* The composer is a self-contained component (nimbus/web/composer.js); this
   wires the four things only the app knows: where to send, where the agent's
   workspace is, the /delegate and /skill lists, and what /clear should do. */
let skillCache = null;

function mountComposer(pane) {
  if (!window.NB || !NB.Composer) return null;
  /* Re-rendering (a new message, a mode flip) rebuilds this box. Carry the
     draft and the caret along, so typing is never interrupted by the chrome. */
  const draft = state.composer ? state.composer.value : '';
  const wasFocused = !!(state.composer && document.activeElement === $('#input'));
  if (state.composer) { state.composer.destroy(); state.composer = null; }
  const agent = state.agent || {};
  const limitMb = Number(lim('upload_mb')) || 512;
  state.composer = new NB.Composer({
    mount: $('#composer'),
    dropRoot: pane,
    t: T,
    agentId: agent.id || '',
    agentName: agent.name || T('chat.agent'),
    placeholder: T(compact() ? 'chat.phShort' : 'chat.placeholder', { name: agent.name || T('chat.agent') }),
    sendLabel: T('chat.send'),
    maxBytes: limitMb * 1024 * 1024,
    onSend: () => sendMessage(),
    onResize: () => { if (follow.stick) followScroll(); },
    onCommand: (name) => runComposerCommand(name),
    onUploaded: (file) => {
      toast(T('chat.uploaded', { name: file.name }));
      if (state.tab === 'files') renderFiles();
      loadAgents().catch(() => { });
    },
    onTooBig: (file) => toast(T('cmp.tooBig', { name: file.name, size: fmtBytes(file.size), mb: limitMb }), 'err'),
    onError: (file, err) => toast(T('chat.uploadFailed', { name: file.name, error: err.message }), 'err'),
    providers: {
      agents: (q) => (state.agents || []).map(a => ({ id: a.id, name: a.name, hint: a.title || '', description: a.description || '' }))
        .filter(a => !q || a.name.toLowerCase().startsWith(String(q).toLowerCase())),
      skills: async () => {
        if (!skillCache) {
          try {
            // every skill on the team, with the owner as the hint — a fresh agent
            // with none of its own can still run the team's playbooks
            skillCache = (await api('/api/skills')).map(s => ({
              id: s.id, name: s.name, hint: s.agent_name || '', description: s.description || '',
            }));
          } catch { skillCache = []; }
          setTimeout(() => { skillCache = null; }, 60000);   // a minute of freshness
        }
        return skillCache || [];
      },
    },
  });
  // the policy hint / model pill keep their old home, now inside the component's footer
  const pill = $('#modelPill');
  if (pill) {
    pill.textContent = (state.details && state.agent) ? `${state.agent.provider} · ${state.agent.model}` : '';
    pill.classList.toggle('hidden', !state.details || !state.agent);
  }
  // put the reader back where they were: same words, same caret, same focus
  if (draft) state.composer.setValue(draft, { focus: false });
  if (wasFocused || draft) state.composer.focus();
  return state.composer;
}

/** Slash commands that do something instead of typing a prompt. */
async function runComposerCommand(name) {
  if (name === 'clear') {
    if (!state.agent) return;
    const t = await api(`/api/agents/${state.agent.id}/threads`, { method: 'POST', body: { title: 'New thread' } });
    await loadThreads();
    await openThread(t.id);
    toast(T('cmp.cleared'));
  }
}

function onboardingSteps() {
  const g = (state.system.google || {}).google || {};
  const modelReady = Object.entries(state.system.keys_set || {}).some(([k, v]) => v && k !== 'mock' && k !== 'auto');
  const usedBefore = state.threads.length > 1 || state.messages.length > 0;
  const step = (n, title, body, done, action) => `<div class="step ${done ? 'done' : ''}">
      <div class="step-num">${done ? '✓' : n}</div>
      <div class="step-body"><b>${esc(title)}</b><p>${esc(body)}</p>
        ${action ? `<div class="step-act">${action}</div>` : ''}</div>
    </div>`;
  const btn = (label, id) => `<button class="btn sm ${id === 'step-model' ? 'primary' : ''}" data-${id}>${esc(label)}</button>`;
  return `<div class="card onboard">
      <h4>${esc(T('chat.getStarted'))}<button class="btn sm ghost" data-hide-onboard>${esc(T('chat.hide'))}</button></h4>
      ${step(1, T('chat.step1'), modelReady ? T('chat.step1done') : T('chat.step1demo'), modelReady,
             modelReady ? '' : btn(T('chat.step1btn'), 'step-model'))}
      ${step(2, T('chat.step2'), g.demo ? T('chat.step2demo') : T('chat.step2done', { account: g.account || '' }),
             !g.demo, g.demo ? btn(T('chat.step2btn'), 'step-google') : '')}
      ${step(3, T('chat.step3'), usedBefore ? T('chat.step3done') : T('chat.step3hint'), usedBefore, '')}
    </div>`;
}

function welcome() {
  const a = state.agent || {};
  const chips = [T('chat.try1'), T('chat.try2'), T('chat.try3'), T('chat.try4'), T('chat.try5')];
  const showOnboard = !state.onboarded && !state.messages.length;
  return `<div class="empty">
    <div style="font-size:38px">${esc(a.emoji || '🛰️')}</div>
    <h2>${esc(T('chat.ready', { name: a.name || 'Nimbus' }))}</h2>
    <p>${esc(a.description || T('chat.readyFallback'))}</p>
    <div class="suggestions">${chips.map(c => `<button data-p="${esc(c)}">${esc(c)}</button>`).join('')}</div>
    ${showOnboard ? onboardingSteps() : `<p style="margin-top:18px">${esc(T('welcome.tip'))}
      <button class="btn sm ghost" data-show-onboard>${esc(T('chat.showAgain'))}</button></p>`}
  </div>`;
}

/* --------------------------- scroll following ------------------------- */
/* The view follows new content only while the reader is already at the bottom.
   Someone reading earlier messages keeps their place, and a small chip offers
   the way back (see .jump-latest). */
const follow = { stick: true };

function updateJump() {
  const chat = $('#chat'); if (!chat) return;
  const btn = document.getElementById('jumpLatest');
  const want = !follow.stick && chat.scrollHeight > chat.clientHeight + 40;
  if (want && !btn) {
    const b = document.createElement('button');
    b.id = 'jumpLatest'; b.type = 'button'; b.className = 'jump-latest';
    b.innerHTML = `↓ <span>${esc(T('chat.jumpLatest'))}</span>`;
    b.onclick = () => scrollChat(true);
    chat.appendChild(b);
  } else if (!want && btn) {
    btn.remove();
  }
}

function followScroll() {
  const chat = $('#chat'); if (!chat) return;
  if (follow.stick) chat.scrollTop = chat.scrollHeight;
  updateJump();
}

/** Scroll to the newest content; `force` re-pins a reader who scrolled up. */
function scrollChat(force) {
  if (force) follow.stick = true;
  followScroll();
}

function wireChatScroll(chat) {
  follow.stick = true;
  chat.addEventListener('scroll', () => {
    follow.stick = NB.atBottom(chat);   // ~two lines of slack
    updateJump();
  }, { passive: true });
  updateJump();
}

function messageNode(m) {
  const node = document.createElement('div');
  node.className = 'msg ' + (m.role === 'user' ? 'user' : 'assistant');
  const avatar = m.role === 'user' ? '🧑' : (state.agent && state.agent.emoji) || '🤖';
  const who = m.role === 'user' ? T('chat.you') : (state.agent && state.agent.name) || T('chat.agent');
  node.innerHTML = `<div class="avatar">${esc(avatar)}</div><div class="body">
      <div class="who">${esc(who)} <span style="color:var(--dim)">${rel(m.created_at)}</span>
        ${m.meta && m.meta.turns ? `<span class="badge">${esc(T('chat.steps', { n: m.meta.turns }))}</span>` : ''}</div>
      <div class="bubble">${md(m.content || '')}</div></div>`;
  if (m.tool_calls && m.tool_calls.length && state.details) {
    const chips = document.createElement('div');
    chips.className = 'chipline';
    chips.innerHTML = m.tool_calls.map(tc => `<span class="toolchip">🔧 ${esc(tc.name)}</span>`).join('');
    $('.body', node).insertBefore(chips, $('.bubble', node));
  }
  return node;
}
function renderMessage(m) {
  const chat = $('#chat'); if (!chat || state.tab !== 'chat') return;
  closeStepper();                    // text ends the current tool run
  const empty = $('.empty', chat); if (empty) empty.remove();
  chat.appendChild(messageNode(m));
  scrollChat();
}
function renderSystemNote(html) {
  const chat = $('#chat'); if (!chat || state.tab !== 'chat') return;
  closeStepper();
  const node = document.createElement('div');
  node.className = 'msg'; node.innerHTML = `<div class="avatar">•</div><div class="body"><div class="who">system</div>
    <div style="color:var(--muted);font-size:13px">${html}</div></div>`;
  chat.appendChild(node); scrollChat();
}
function renderScreenshot(ev) {
  const chat = $('#chat'); if (!chat) return;
  closeStepper();
  const node = document.createElement('div');
  node.className = 'msg';
  node.innerHTML = `<div class="avatar">🖼️</div><div class="body"><div class="who">${esc(T('chat.screenshot'))}</div>
    <img src="/api/agents/${state.agent.id}/file?path=${encodeURIComponent(ev.path)}" style="max-width:100%;border-radius:10px;border:1px solid var(--line)">
    <div class="hintrow"><a href="/api/agents/${state.agent.id}/file?path=${encodeURIComponent(ev.path)}" download>${esc(T('chat.download'))}</a></div></div>`;
  chat.appendChild(node); scrollChat();
}

/* --------------------- 1. expandable tool stepper --------------------- */
/* Consecutive tool executions collapse into one pill:
     "Executed 3 tools: Searched Drive › Read 1 file › Wrote summary.md"
   The pill pulses while a call is in flight and expands into a per-step
   transcript of arguments and outputs (see NB.ToolStepper). */
let stepper = null;              // the open group, or null when text took over

function ensureStepper() {
  const chat = $('#chat'); if (!chat || state.tab !== 'chat') return null;
  const empty = $('.empty', chat); if (empty) empty.remove();
  if (!stepper) {
    stepper = new NB.ToolStepper({
      chat, t: T, details: state.details,
      icon: (state.agent && state.agent.emoji) || '🔧',
      onScroll: followScroll,
    });
  }
  return stepper;
}
function closeStepper() { if (stepper) { stepper.close(); stepper = null; } }

function addToolChip(ev) {
  if (state.tab !== 'chat' || !$('#chat')) return;
  const group = ensureStepper();
  if (group) group.add(ev);
}
function finishToolChip(ev) {
  if (stepper) stepper.finish(ev);
  else if (state.tab === 'chat') {
    // a late event after a re-render: show the single call it belongs to
    const group = ensureStepper();
    if (group) { group.add(ev); group.finish(ev); }
  }
}
function shortArgs(args) {
  try {
    const s = JSON.stringify(args || {});
    return s.length > 260 ? s.slice(0, 260) + '…' : s;
  } catch { return ''; }
}

/* --------------------- 3. rich streaming bubble ----------------------- */
/* While text is still arriving, hide an unclosed bold marker so the user never
   sees a stray "**" mid-stream — the final render uses the complete text. */
function balancedPreview(text) {
  const marks = (text.match(/\*\*/g) || []).length;
  return marks % 2 === 1 ? text.slice(0, text.lastIndexOf('**')) : text;
}
function appendDelta(text) {
  const chat = $('#chat'); if (!chat || state.tab !== 'chat') return;
  closeStepper();                    // the agent moved on to writing
  const empty = $('.empty', chat); if (empty) empty.remove();
  if (!state.streamingEl) {
    const node = document.createElement('div');
    node.className = 'msg assistant';
    node.innerHTML = `<div class="avatar">${esc((state.agent && state.agent.emoji) || '🤖')}</div><div class="body">
      <div class="who">${esc((state.agent && state.agent.name) || T('chat.agent'))} <span class="spin-lg"></span></div>
      <div class="bubble"></div></div>`;
    chat.appendChild(node);
    const bubble = $('.bubble', node);
    const typer = new NB.Typer({
      scroller: chat,
      render: (t) => md(balancedPreview(t)),
    });
    typer.onStick = (stick) => { follow.stick = stick; updateJump(); };
    typer.attach(bubble);
    state.streamingEl = { node, raw: '', typer };
  }
  state.streamingEl.typer.push(text);
}
function finalizeStreaming(finalText) {
  if (!state.streamingEl) return;
  const { node, typer, raw } = state.streamingEl;
  const text = finalText != null ? finalText : raw;
  typer.finish(text);                 // reveals everything, drops the caret
  const who = $('.who', node);
  who.innerHTML = `${esc((state.agent && state.agent.name) || T('chat.agent'))} <span style="color:var(--dim)">${esc(T('chat.justNow'))}</span>`;
  state.streamingEl = null;
  followScroll();
}

async function sendMessage() {
  const input = $('#input'); if (!input) return;
  const text = (state.composer ? state.composer.value : input.value).trim();
  if (!text || !state.agent) return;
  if (state.busy) { toast(T('chat.busy'), 'err'); return; }
  if (!state.thread) {
    const t = await api(`/api/agents/${state.agent.id}/threads`, { method: 'POST', body: { title: text.slice(0, 60) } });
    state.thread = await api(`/api/threads/${t.id}`);
    connectThreadStream(t.id);
    await loadThreads();
  }
  if (state.composer) state.composer.reset(); else input.value = '';
  state.messages.push({ role: 'user', content: text, created_at: Date.now() / 1000 });
  renderMessage({ role: 'user', content: text, created_at: Date.now() / 1000 });
  state.busy = true; $('#btnStop').style.display = ''; setStatus(true);
  // the checklist has done its job once a task is on its way
  if (!state.onboarded) { state.onboarded = true; localStorage.setItem('nimbus.onboarded', '1'); }
  try {
    await api(`/api/threads/${state.thread.id}/messages`, { method: 'POST', body: { content: text } });
  } catch (e) {
    toast(T('chat.cannotSend', { error: e.message }), 'err');
    state.busy = false; $('#btnStop').style.display = 'none';
    if (state.composer) state.composer.setValue(text);      // never lose what was typed
  }
}

/* ---------------------------- approvals ------------------------------ */
function renderApprovalCard(a) {
  const chat = $('#chat');
  if (!chat || state.tab !== 'chat' || document.getElementById('appr-' + a.id)) return;
  closeStepper();
  const empty = $('.empty', chat); if (empty) empty.remove();
  const node = document.createElement('div');
  node.className = 'msg appr-msg'; node.id = 'appr-' + a.id;
  node.dataset.tool = a.tool;
  node.innerHTML = `<div class="avatar">⚠️</div><div class="body">${NB.tpl.approval(a, T)}</div>`;
  chat.appendChild(node);
  $('[data-allow]', node).onclick = () => decide(a.id, 'approved', node);
  $('[data-always]', node).onclick = () => decide(a.id, 'approved', node, { always: true });
  $('[data-reject]', node).onclick = () => decide(a.id, 'denied', node);
  scrollChat(true);                 // a blocking question should be seen
  toast(T('chat.approvalNeeded', { tool: a.tool }));
}

/**
 * Send the decision. "Always allow" writes a rule for this agent first, so the
 * next call with the same tool never asks again (POST .../tool-rules) — the
 * approval itself is still recorded as approved, so the run continues at once.
 */
async function decide(id, decision, node, opts = {}) {
  const el = node || document.getElementById('appr-' + id);
  const tool = (el && el.dataset.tool) || '';
  if (opts.always && tool && state.agent) {
    try {
      await api(`/api/agents/${state.agent.id}/tool-rules`, {
        method: 'POST', body: { tool, action: 'allow' },
      });
      toast(T('appr.allowlistOn', { tool, agent: state.agent.name }));
    } catch (e) {
      toast(String(e.message || e), 'err');
    }
  }
  try {
    await api(`/api/approvals/${id}`, { method: 'POST', body: { decision } });
  } catch (e) {
    toast(String(e.message || e), 'err');
  }
  resolveApprovalCard(id, opts.always ? 'always' : decision, el);
  pollApprovals();
}

function resolveApprovalCard(id, status, node) {
  const el = node || document.getElementById('appr-' + id);
  if (el) {
    const tool = el.dataset.tool || (($('.appr-tool', el) || {}).textContent || '');
    el.dataset.done = '1';
    const banner = $('.appr', el) || el;
    banner.dataset.done = '1';
    const body = $('.appr-body', el);
    if (body) body.classList.add('hidden');       // the banner settles down
    const actions = $('.appr-actions', el);
    if (actions) actions.remove();
    const heading = $('.appr-titles b', el);
    if (heading) heading.textContent = T('appr.settled');
    const slot = $('.appr-status', el);
    if (slot) {
      slot.classList.remove('hidden');
      slot.innerHTML = NB.tpl.resolved({ tool }, T, status, rel(Date.now() / 1000));
      const reopen = $('[data-reopen]', slot);
      if (reopen) reopen.onclick = () => { if (body) body.classList.toggle('hidden'); };
    }
  }
  const d = document.getElementById('drw-appr-' + id);
  if (d) d.remove();
}

async function pollApprovals() {
  try {
    const rows = await api('/api/approvals?status=pending');
    state.approvals = rows;
    $('#approvalCount').textContent = rows.length;
    $('#approvalCount').className = 'badge ' + (rows.length ? 'warn' : '');
    if (state.tab === 'activity' && state.drawerOpen) renderDrawer();
  } catch { }
}

/* ------------------------------ drawer ------------------------------- */
function renderDrawer() {
  $('#drawerTitle').textContent = T('top.liveActivity');
  appendDrawerEvent(null, true);
}
function appendDrawerEvent(ev, reset) {
  const body = $('#drawerBody');
  if (reset) {
    body.innerHTML = `<div class="section-title">${esc(T('drawer.pending'))}</div><div id="drwAppr">${
      state.approvals.length ? '' : `<p style="color:var(--dim);font-size:12.5px">${esc(T('drawer.nothing'))}</p>`}</div>
      <div class="section-title">${esc(T('drawer.eventStream'))}</div><div id="drwFeed"></div>`;
    state.approvals.forEach(a => {
      const el = document.createElement('div');
      el.className = 'card'; el.id = 'drw-appr-' + a.id;
      el.innerHTML = `<h4>${esc(a.tool)} <span class="badge warn">${esc(a.risk)}</span></h4>
        <p>${esc(a.reason || '')}</p>
        <div class="row"><button class="btn sm primary" data-allow>${esc(T('drawer.allow'))}</button><button class="btn sm danger" data-deny>${esc(T('drawer.deny'))}</button></div>`;
      $('[data-allow]', el).onclick = () => decide(a.id, 'approved');
      $('[data-deny]', el).onclick = () => decide(a.id, 'denied');
      $('#drwAppr').appendChild(el);
    });
  }
  if (!ev) return;
  const feed = $('#drwFeed'); if (!feed) return;
  const line = document.createElement('div');
  line.className = 'kv-row';
  line.innerHTML = `<span class="k">${esc((ev.agent_name || T('chat.system')))}</span><span style="flex:1;color:var(--muted);font-size:12px">${
    esc(drawerText(ev))}</span><span class="k">${rel(ev.ts || Date.now() / 1000)}</span>`;
  feed.prepend(line);
  while (feed.children.length > 120) feed.lastChild.remove();
}
function drawerText(ev) {
  switch (ev.type) {
    case 'run_start': return T('feed.runStart');
    case 'tool_start': return `🔧 ${ev.name} ${shortArgs(ev.args).slice(0, 60)}`;
    case 'tool_end': return `${ev.ok ? '✅' : '⚠️'} ${ev.name} (${ev.ms || 0}ms)`;
    case 'message': return `${ev.role === 'user' ? '🧑' : '💬'} ${String(ev.content || '').slice(0, 70)}`;
    case 'approval_request': return `⚠️ ${T('feed.approval')}: ${ev.approval.tool}`;
    case 'run_end': return T('feed.runEnd');
    case 'delegation_start': return `🤝 → ${ev.target}`;
    case 'delegation_end': return `🤝 ${ev.target} ${T('feed.done')}`;
    case 'routine_start': return `⏰ ${T('feed.routine')} ${ev.routine}`;
    case 'agent_spawned': return `🧬 ${T('feed.newAgent')} ${ev.agent.name}`;
    default: return ev.type;
  }
}

/* ------------------------------- files ------------------------------- */
async function renderFiles(path) {
  if (path !== undefined) state.filePath = path;
  const pane = $('#pane');
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    <div class="section-title">${esc(T('files.title', { name: state.agent.name }))} (${fmtBytes(state.agent.stats.bytes)}, ${state.agent.stats.files} files)</div>
    <div class="row" style="margin-bottom:10px">
      <button class="btn sm" id="f-up">${esc(T('chat.upload'))}</button>
      <button class="btn sm" id="f-refresh">${esc(T('chat.refresh'))}</button>
      <span class="pill mono">${esc(state.filePath || '/')}</span>
    </div>
    <p class="tab-hint">${esc(T('files.hint'))} ${esc(T('files.limits', { up: lim('upload_mb'),
        preview: lim('preview_mb'), drive: lim('gmail_attachment_mb') }))}</p>
    <div class="filelist" id="flist"><span class="spin-lg"></span></div></div>
    <input type="file" id="f-file" style="display:none">`;
  $('#f-refresh').onclick = () => renderFiles();
  $('#f-up').onclick = () => $('#f-file').click();
  $('#f-file').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const cap = (state.system.limits || {}).upload_mb || 512;
    if (f.size > cap * 1024 * 1024) {
      toast(T('chat.tooBig', { name: f.name, size: fmtBytes(f.size), mb: cap }), 'err');
      e.target.value = ''; return;
    }
    const fd = new FormData(); fd.append('file', f);
    fd.append('path', (state.filePath ? state.filePath + '/' : '') + f.name);
    try {
      await api(`/api/agents/${state.agent.id}/upload`, { method: 'POST', body: fd });
      toast(T('chat.uploaded', { name: f.name })); renderFiles();
    } catch (err) {
      toast(T('chat.uploadFailed', { name: f.name, error: err.message }), 'err');
    } finally { e.target.value = ''; }
  };
  const data = await api(`/api/agents/${state.agent.id}/files?path=${encodeURIComponent(state.filePath || '')}`);
  const fl = $('#flist');
  fl.innerHTML = '';
  if (state.filePath) {
    const up = document.createElement('div');
    up.className = 'file'; up.innerHTML = '📁 <span class="nm">..</span>';
    up.onclick = () => renderFiles(state.filePath.split('/').slice(0, -1).join('/'));
    fl.appendChild(up);
  }
  if (!data.items.length) fl.innerHTML = `<p style="color:var(--dim)">${esc(T('files.emptyEmpty'))}</p>`;
  data.items.forEach(it => {
    const el = document.createElement('div');
    el.className = 'file';
    el.innerHTML = `${it.dir ? '📁' : fileIcon(it.name)} <span class="nm">${esc(it.name)}</span>
      <span class="sz">${it.dir ? esc(T('files.items', { n: it.children || 0 })) : fmtBytes(it.size)}</span>
      <span class="sz">${rel(it.modified)}</span>
      <a class="btn sm ghost" href="/api/agents/${state.agent.id}/file?path=${encodeURIComponent(it.path)}" download title="download">⬇</a>
      <button class="btn sm ghost" data-del title="delete">🗑</button>`;
    if (it.dir) el.onclick = (e) => { if (e.target.tagName !== 'A' && e.target.tagName !== 'BUTTON') renderFiles(it.path); };
    else el.onclick = (e) => { if (e.target.tagName !== 'A' && e.target.tagName !== 'BUTTON') previewFile(it.path); };
    $('[data-del]', el).onclick = async () => {
      if (!confirm(T('files.deleteConfirm', { name: it.name }))) return;
      await api(`/api/agents/${state.agent.id}/file?path=${encodeURIComponent(it.path)}`, { method: 'DELETE' });
      renderFiles();
    };
    fl.appendChild(el);
  });
}
function fileIcon(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  return { md: '📝', txt: '📄', csv: '📊', json: '🧾', py: '🐍', js: '🟨', html: '🌐', png: '🖼️', jpg: '🖼️', jpeg: '🖼️', pdf: '📕', sh: '⚡', zip: '🗜️' }[ext] || '📄';
}
async function previewFile(path) {
  try {
    const d = await api(`/api/agents/${state.agent.id}/file-text?path=${encodeURIComponent(path)}`);
    const isMd = /\.(md|markdown)$/i.test(path);
    modal({
      title: path, wide: true,
      body: isMd ? `<div class="bubble" style="border:none;padding:0">${md(d.content)}</div>`
                 : `<pre class="tool-result" style="max-height:60vh">${esc(d.content)}</pre>`,
      footer: [{ label: T('chat.download'), onClick: () => { window.open(`/api/agents/${state.agent.id}/file?path=${encodeURIComponent(path)}`); return false; } }, { label: T('modal.close') }]
    });
  } catch (e) { toast(T('files.tooLarge', { error: e.message }), 'err'); }
}

/* ------------------------------ skills ------------------------------- */
function automationsSeg() {
  return `<div class="seg" id="autoSeg">
    <button class="${state.autoView === 'skills' ? '' : 'active'}" data-auto="routines">${esc(T('tab.routines'))}</button>
    <button class="${state.autoView === 'skills' ? 'active' : ''}" data-auto="skills">${esc(T('tab.skills'))}</button>
  </div>`;
}
function wireAutomationsSeg(pane) {
  $$('#autoSeg button', pane).forEach(b => b.onclick = () => {
    state.autoView = b.dataset.auto;
    setTab(b.dataset.auto);
  });
}
function renderAutomations(view) {
  state.autoView = view === 'skills' ? 'skills' : 'routines';
  return state.autoView === 'skills' ? renderSkills() : renderRoutines();
}

async function renderSkills() {
  state.autoView = 'skills';
  const pane = $('#pane');
  const skills = await api(`/api/skills?agent_id=${state.agent.id}`);
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    ${automationsSeg()}
    <div class="section-title">${esc(T('skills.title'))}</div>
    ${state.details ? '' : `<p class="tab-hint">${esc(T('skills.hint'))}</p>`}
    <div class="row" style="margin-bottom:12px">
      <button class="btn sm primary" id="s-new">${esc(T('skills.new'))}</button>
      <button class="btn sm" id="s-teach" ${state.thread ? '' : 'disabled'} title="${esc(state.thread ? T('skills.teachTitle') : T('skills.teachFirst'))}">${esc(T('skills.teach'))}</button>
    </div>
    <div class="grid2">${skills.map(s => `<div class="card">
      <h4>${esc(s.name)} <span class="badge">${esc(s.source || 'manual')}</span></h4>
      <p>${esc(s.description || '')}</p>
      <p class="mono" style="color:var(--dim)">${esc((s.inputs || []).join(', ') || T('skills.noInputs'))} · ${esc(T('skills.runs', { n: s.runs }))}</p>
      <div class="row"><button class="btn sm" data-view="${s.id}">${esc(T('skills.view'))}</button>
      <button class="btn sm" data-edit="${s.id}">${esc(T('skills.edit'))}</button><button class="btn sm danger" data-del="${s.id}">${esc(T('skills.delete'))}</button></div>
    </div>`).join('') || `<p style="color:var(--dim)">${esc(T('skills.empty'))}</p>`}</div></div>`;
  $('#s-new').onclick = () => skillModal(null);
  $('#s-teach').onclick = async () => {
    const name = prompt(T('skills.teachPrompt'), '');
    toast(T('skills.teachStudying'));
    try {
      const s = await api(`/api/agents/${state.agent.id}/teach`, { method: 'POST', body: { thread_id: state.thread.id, name: name || '' } });
      toast(T('skills.teachSaved', { name: s.name })); renderSkills();
    } catch (e) { toast(T('skills.teachFailed', { error: e.message }), 'err'); }
  };
  skills.forEach(s => {
    const view = $(`[data-view="${s.id}"]`, pane), edit = $(`[data-edit="${s.id}"]`, pane), del = $(`[data-del="${s.id}"]`, pane);
    if (view) view.onclick = () => modal({ title: s.name, wide: true, body: `<div class="bubble">${md(s.instructions)}</div>` });
    if (edit) edit.onclick = () => skillModal(s);
    if (del) del.onclick = async () => { if (confirm(T('skills.deleteConfirm', { name: s.name }))) { await api('/api/skills/' + s.id, { method: 'DELETE' }); renderSkills(); } };
  });
  wireAutomationsSeg(pane);
}
function skillModal(s) {
  modal({
    title: s ? T('skills.editTitle') : T('skills.newTitle'),
    body: `<label class="field"><span>${T('skills.name')}</span><input id="sk-name" value="${esc(s ? s.name : '')}"></label>
      <label class="field"><span>${T('skills.desc')}</span><input id="sk-desc" value="${esc(s ? s.description : '')}"></label>
      <label class="field"><span>${T('skills.instr')}</span>
        <textarea id="sk-instr" rows="12">${esc(s ? s.instructions : '1. ')}</textarea></label>
      <label class="field"><span>${T('skills.inputs')}</span><input id="sk-inputs" value="${esc(s ? (s.inputs || []).join(', ') : '')}"></label>
      <label class="field"><span>${T('skills.output')}</span><input id="sk-out" value="${esc(s ? s.output_format : '')}"></label>`,
    footer: [{ label: T('agent.cancel') }, {
      label: T('skills.save'), kind: 'primary', onClick: async (c) => {
        const body = {
          name: $('#sk-name', c).value.trim(), description: $('#sk-desc', c).value.trim(),
          instructions: $('#sk-instr', c).value, output_format: $('#sk-out', c).value.trim(),
          inputs: $('#sk-inputs', c).value.split(',').map(x => x.trim()).filter(Boolean),
          agent_id: state.agent.id,
        };
        if (!body.name) { toast(T('skills.nameRequired'), 'err'); return false; }
        if (s) await api('/api/skills/' + s.id, { method: 'PATCH', body });
        else await api('/api/skills', { method: 'POST', body });
        toast(T('skills.saved')); renderSkills();
      }
    }]
  });
}

/* ----------------------------- routines ------------------------------ */
async function renderRoutines() {
  state.autoView = 'routines';
  const pane = $('#pane');
  const rows = (await api('/api/routines')).filter(r => r.agent_id === state.agent.id || true);
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    ${automationsSeg()}
    <div class="section-title">${esc(T('routines.title'))}</div>
    ${state.details ? '' : `<p class="tab-hint">${esc(T('routines.hint'))}</p>`}
    <div class="row" style="margin-bottom:12px"><button class="btn sm primary" id="r-new">${esc(T('routines.new'))}</button>
      <button class="btn sm" id="r-all">${esc(T('routines.showAll'))}</button></div>
    <table class="data"><thead><tr><th>${T('routines.col.name')}</th><th>${T('routines.col.agent')}</th><th>${T('routines.col.trigger')}</th><th>${T('routines.col.next')}</th><th>${T('routines.col.runs')}</th><th>${T('routines.col.on')}</th><th></th></tr></thead>
    <tbody>${rows.map(r => `<tr><td><b>${esc(r.name)}</b><div class="mono" style="color:var(--dim)">${esc((r.prompt || '').slice(0, 90))}</div></td>
      <td>${esc(r.agent_name || '')}</td><td class="mono">${esc(r.kind)} ${esc(r.schedule || r.event_filter || '')}</td>
      <td class="mono">${r.next_run_at ? new Date(r.next_run_at * 1000).toLocaleString() : '—'}</td><td>${r.run_count}</td>
      <td><input type="checkbox" data-tog="${r.id}" ${r.enabled ? 'checked' : ''}></td>
      <td><button class="btn sm" data-run="${r.id}">${esc(T('routines.run'))}</button> <button class="btn sm danger" data-del="${r.id}">🗑</button></td></tr>`).join('')
      || `<tr><td colspan="7" style="color:var(--dim)">${esc(T('routines.empty'))}</td></tr>`}
    </tbody></table></div>`;
  $('#r-new').onclick = routineModal;
  $('#r-all').onclick = async () => { state.tab = 'routines'; await renderRoutines(); };
  rows.forEach(r => {
    const t = $(`[data-tog="${r.id}"]`, pane);
    if (t) t.onchange = async () => { await api('/api/routines/' + r.id, { method: 'PATCH', body: { enabled: t.checked } }); renderRoutines(); };
    const run = $(`[data-run="${r.id}"]`, pane);
    if (run) run.onclick = async () => { await api(`/api/routines/${r.id}/run`, { method: 'POST' }); toast(T('routines.started')); loadThreads(); };
    const del = $(`[data-del="${r.id}"]`, pane);
    if (del) del.onclick = async () => { if (confirm(T('routines.deleteConfirm'))) { await api('/api/routines/' + r.id, { method: 'DELETE' }); renderRoutines(); } };
  });
  wireAutomationsSeg(pane);
}
async function routineModal() {
  const skills = await api(`/api/skills?agent_id=${state.agent.id}`);
  modal({
    title: T('routines.createTitle'),
    body: `<label class="field"><span>${T('routines.name')}</span><input id="ro-name" placeholder="${esc(T('routines.namePh'))}"></label>
      <label class="field"><span>${T('routines.col.agent')}</span><select id="ro-agent">${state.agents.map(a => `<option value="${a.id}" ${a.id === state.agent.id ? 'selected' : ''}>${esc(a.emoji)} ${esc(a.name)}</option>`).join('')}</select></label>
      <label class="field"><span>${T('routines.triggerType')}</span><select id="ro-kind">
        <option value="cron">${T('routines.cron')}</option><option value="interval">${T('routines.interval')}</option>
        <option value="event">${T('routines.event')}</option></select></label>
      <label class="field"><span>${T('routines.schedule')}</span>
        <input id="ro-sched" value="0 8 * * *"></label>
      <label class="field"><span>${T('routines.prompt')}</span>
        <textarea id="ro-prompt" rows="5" placeholder="${esc(T('routines.promptPh'))}"></textarea></label>
      <label class="field"><span>${T('routines.attachSkill')}</span><select id="ro-skill"><option value="">${esc(T('routines.none'))}</option>
        ${skills.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></label>`,
    footer: [{ label: T('agent.cancel') }, {
      label: T('routines.create'), kind: 'primary', onClick: async (c) => {
        const kind = $('#ro-kind', c).value;
        const body = {
          agent_id: $('#ro-agent', c).value, name: $('#ro-name', c).value.trim() || 'Routine', kind,
          schedule: $('#ro-sched', c).value.trim(), prompt: $('#ro-prompt', c).value.trim(),
          skill_id: $('#ro-skill', c).value, event_filter: kind === 'event' ? $('#ro-sched', c).value.trim() : '',
        };
        await api('/api/routines', { method: 'POST', body });
        toast(T('routines.created')); renderRoutines();
      }
    }]
  });
}

/* ------------------------------ memory ------------------------------- */
async function renderMemory() {
  const pane = $('#pane');
  const rows = await api(`/api/memory?agent_id=${state.agent.id}`);
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    <div class="section-title">${esc(T('memory.title'))}</div>
    ${state.details ? '' : `<p class="tab-hint">${esc(T('memory.hint'))}</p>`}
    <div class="row" style="margin-bottom:12px">
      <input id="m-key" placeholder="${esc(T('memory.key'))}" style="max-width:200px"><input id="m-val" placeholder="${esc(T('memory.value'))}" style="flex:1;min-width:220px">
      <button class="btn sm primary" id="m-add">${esc(T('memory.remember'))}</button></div>
    <table class="data"><thead><tr><th>${T('memory.col.key')}</th><th>${T('memory.col.value')}</th><th>${T('memory.col.scope')}</th><th>${T('memory.col.source')}</th><th>${T('memory.col.when')}</th><th></th></tr></thead>
    <tbody>${rows.map(m => `<tr><td class="mono">${esc(m.key)}</td><td>${esc((m.value || '').slice(0, 400))}</td>
      <td><span class="badge">${esc(m.scope)}</span></td><td>${esc(m.source || '')}</td><td>${rel(m.created_at)}</td>
      <td><button class="btn sm danger" data-del="${m.id}">🗑</button></td></tr>`).join('')
      || `<tr><td colspan="6" style="color:var(--dim)">${esc(T('memory.empty'))}</td></tr>`}
    </tbody></table></div>`;
  $('#m-add').onclick = async () => {
    const key = $('#m-key').value.trim(), value = $('#m-val').value.trim();
    if (!key || !value) return toast(T('memory.required'), 'err');
    await api('/api/memory', { method: 'POST', body: { agent_id: state.agent.id, key, value } });
    renderMemory();
  };
  rows.forEach(m => { const b = $(`[data-del="${m.id}"]`, pane); if (b) b.onclick = async () => { await api('/api/memory/' + m.id, { method: 'DELETE' }); renderMemory(); }; });
}

/* ----------------------------- activity ------------------------------ */
async function renderActivity() {
  const pane = $('#pane');
  const [runs, stats] = await Promise.all([api('/api/runs?limit=25'), api('/api/stats')]);
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    <div class="grid2" style="margin-bottom:14px">
      ${stat(T('stat.agents'), stats.agents)}${stat(T('stat.threads'), stats.threads)}${stat(T('stat.toolCalls'), stats.tool_calls)}
      ${stat(T('stat.skills'), stats.skills)}${stat(T('stat.routines'), stats.routines)}${stat(T('stat.memories'), stats.memories)}
    </div>
    ${state.details ? '' : `<p class="tab-hint">${esc(T('activity.hint'))}</p>`}
    <div class="section-title">${esc(T('activity.liveFeed'))}</div><div id="act-feed" class="card" style="max-height:260px;overflow:auto"></div>
    <div class="section-title">${esc(T('activity.recentRuns'))}</div>
    <table class="data"><thead><tr><th>${T('activity.col.when')}</th><th>${T('activity.col.routine')}</th><th>${T('activity.col.agent')}</th><th>${T('activity.col.status')}</th><th>${T('activity.col.thread')}</th><th>${T('activity.col.result')}</th></tr></thead>
    <tbody>${runs.map(r => `<tr><td>${rel(r.started_at)}</td><td>${esc(r.routine_name || '')}</td><td>${esc(r.agent_name || '')}</td>
      <td><span class="badge ${r.status === 'ok' ? 'ok' : r.status === 'error' ? 'bad' : ''}">${esc(r.status)}</span></td>
      <td><a href="#" data-thr="${r.thread_id}">${esc(T('activity.open'))}</a></td><td>${esc((r.result || r.error || '').slice(0, 160))}</td></tr>`).join('')
      || `<tr><td colspan="6" style="color:var(--dim)">${esc(T('activity.noRuns'))}</td></tr>`}</tbody></table></div>`;
  const feed = $('#act-feed');
  state.feed.slice(0, 60).forEach(ev => {
    const l = document.createElement('div'); l.className = 'kv-row';
    l.innerHTML = `<span class="k">${rel(ev.ts)}</span><span>${esc(ev.agent_name || T('chat.system'))} — ${esc(drawerText(ev))}</span>`;
    feed.appendChild(l);
  });
  $$('[data-thr]', pane).forEach(a => a.onclick = async (e) => { e.preventDefault(); await openThread(a.dataset.thr); setTab('chat'); });
}
const stat = (l, n) => `<div class="stat"><div class="n">${n}</div><div class="l">${esc(l)}</div></div>`;

/* ------------------------------- audit ------------------------------- */
async function renderAudit() {
  const pane = $('#pane');
  const rows = await api('/api/audit?limit=250');
  pane.innerHTML = `<div class="drawer-body" style="flex:1">
    <div class="section-title">${esc(T('audit.title'))}</div>
    ${state.details ? '' : `<p class="tab-hint">${esc(T('audit.hint'))}</p>`}
    <div class="row" style="margin-bottom:10px"><input id="a-filter" placeholder="${esc(T('audit.filter'))}" style="max-width:260px"></div>
    <table class="data"><thead><tr><th>${T('audit.col.when')}</th><th>${T('audit.col.actor')}</th><th>${T('audit.col.agent')}</th><th>${T('audit.col.action')}</th><th>${T('audit.col.risk')}</th><th>${T('audit.col.detail')}</th></tr></thead>
    <tbody id="a-body"></tbody></table></div>`;
  const draw = (q = '') => {
    $('#a-body').innerHTML = rows.filter(r => !q || JSON.stringify(r).toLowerCase().includes(q.toLowerCase()))
      .map(r => `<tr><td>${rel(r.created_at)}</td><td><span class="badge">${esc(r.actor)}</span></td><td>${esc(r.agent_name || '')}</td>
        <td class="mono">${esc(r.action)}</td><td><span class="badge ${r.risk === 'high' ? 'bad' : r.risk === 'medium' ? 'warn' : ''}">${esc(r.risk)}</span></td>
        <td class="mono" style="color:var(--muted)">${esc(JSON.stringify(r.detail || {}).slice(0, 200))}</td></tr>`).join('');
  };
  draw();
  $('#a-filter').oninput = (e) => draw(e.target.value);
}

/* ------------------------------ settings ----------------------------- */
async function renderSettings() {
  const pane = $('#pane');
  state.system = await api('/api/system');
  const p = state.system.providers;
  const g = state.system.google.google;
  const mcp = state.system.mcp;
  const langPicker = (state.system.languages || []).map(l => `<button class="btn ${state.system.language === l.id ? 'primary' : ''}"
      data-lang="${l.id}" style="min-width:150px;justify-content:flex-start">
      <b style="font-size:15px">${esc(l.native || l.label)}</b>
      <span style="color:var(--muted);font-size:11.5px">${esc(l.label)}</span></button>`).join('');
  const pinned = state.agents.filter(a => a.language && a.language !== 'inherit');
  const modelReady = Object.entries(state.system.keys_set || {}).some(([k, v]) => v && k !== 'mock' && k !== 'auto');
  const providerCards = p.map(pr => `<div class="card">
      <h4>${esc(pr.label)} ${pr.ready ? `<span class="badge ok">${T('setup.ready')}</span>` : `<span class="badge warn">${T('setup.needsKey')}</span>`}</h4>
      ${pr.key_label ? `<label class="field"><span>${esc(pr.key_label)}</span><input type="password" data-key="${pr.key_label}" placeholder="${pr.ready ? esc(T('setup.setKey')) : esc(T('setup.pasteKey'))}"></label>` : ''}
      ${pr.id === 'custom' || pr.id === 'local' ? `<label class="field"><span>${T('setup.baseUrl')}</span><input data-base="${pr.id}" value="${esc(pr.base_url || '')}"></label>` : ''}
      <div class="row"><button class="btn sm" data-test="${pr.id}">${esc(T('setup.test'))}</button>
      ${pr.docs ? `<a class="btn sm ghost" href="${esc(pr.docs)}" target="_blank" rel="noopener">${esc(T('setup.getKey'))}</a>` : ''}
      <span class="pill">${esc((pr.models || []).join(', '))}</span></div></div>`).join('');
  const advanced = `
    <details class="adv">
      <summary>${esc(T('setup.advanced'))}<span class="muted">${esc(T('setup.advancedHint'))}</span></summary>
      <div class="section-title">${esc(T('setup.mcp'))}</div>
      <div class="card"><h4>Model Context Protocol <span class="badge">${esc(T('setup.mcpLive', { n: mcp.filter(m => m.live).length }))}</span></h4>
        <p>${esc(T('setup.mcpDesc'))}</p>
        <table class="data"><thead><tr><th>Name</th><th>Transport</th><th>Status</th><th>Tools</th><th></th></tr></thead>
        <tbody>${mcp.map(m => `<tr><td>${esc(m.name)}</td><td class="mono">${esc(m.transport)}</td>
          <td><span class="badge ${m.live ? 'ok' : m.status && m.status.startsWith('error') ? 'bad' : ''}">${esc(m.live ? 'connected' : m.status)}</span></td>
          <td class="mono">${esc((m.tools || []).join(', ').slice(0, 60))}</td>
          <td>${m.live ? `<button class="btn sm" data-mcpdisc="${esc(m.name)}">${esc(T('setup.disconnect'))}</button>`
                       : `<button class="btn sm" data-mcpcon="${m.id}">${esc(T('setup.connect'))}</button>`}
          <button class="btn sm danger" data-mcpdel="${m.id}">🗑</button></td></tr>`).join('')
          || `<tr><td colspan="5" style="color:var(--dim)">${esc(T('setup.mcpNone'))}</td></tr>`}</tbody></table>
        <div class="row" style="margin-top:10px">
          <input id="mcp-name" placeholder="${esc(T('setup.mcpName'))}" style="max-width:150px">
          <select id="mcp-transport" style="max-width:130px"><option value="stdio">stdio</option><option value="http">http</option></select>
          <input id="mcp-cmd" placeholder="npx -y @modelcontextprotocol/server-filesystem /tmp" style="flex:1;min-width:220px">
          <button class="btn sm primary" id="mcp-add">${esc(T('setup.mcpAdd'))}</button></div></div>

      <div class="section-title">${esc(T('setup.workspace'))}</div>
      <div class="card">
        <div class="kv-row"><span class="k">${T('setup.dataDir')}</span><span class="mono">${esc(state.system.settings.data_dir)}</span></div>
        <div class="kv-row"><span class="k">${T('setup.browser')}</span><span>${state.system.browser_tool ? esc(T('setup.browserYes')) : esc(T('setup.browserNo'))}</span></div>
        <div class="kv-row"><span class="k">${T('setup.toolsAvailable')}</span><span>${state.system.all_tools.length}</span></div>
        <div class="row"><button class="btn sm" id="seed-team">${esc(T('setup.seedFleet'))}</button>
        <button class="btn sm" id="sys-refresh">${esc(T('setup.recheck'))}</button></div>
      </div>

      <div class="section-title">${esc(T('setup.tools'))}</div>
      <div class="grid2">${state.system.tools.map(g2 => `<div class="card"><h4>${esc(toolGroup(g2.group))} <span class="badge">${g2.tools.length}</span></h4>
        <p class="mono" style="color:var(--muted);font-size:11.5px">${g2.tools.map(t => esc(t.name)).join(', ')}</p></div>`).join('')}</div>
    </details>`;

  pane.innerHTML = `<div class="drawer-body" style="flex:1;max-width:900px">
    <div class="section-title">${esc(T('setup.language'))}</div>
    <div class="card">
      <div class="row" id="lang-row">${langPicker}</div>
      <p style="color:var(--muted);font-size:12px;margin-top:10px">${esc(T('setup.languageHint'))}</p>
      ${pinned.length ? `<p style="color:var(--warn);font-size:12px">${esc(T('setup.languagePinned'))}
        ${pinned.map(a => `<span class="pill">${esc(a.emoji || '🤖')} ${esc(a.name)}: ${esc(a.language)}</span> `).join('')}</p>` : ''}
    </div>

    <div class="section-title">${esc(T('setup.connectors'))}</div>
    <div class="card"><h4>${esc(T('setup.googleCaps'))}
      <span class="badge ${g.demo ? 'demo' : g.connected ? 'ok' : 'warn'}">${esc(g.demo ? T('setup.googleDemoBadge') : g.connected ? T('setup.googleConnectedBadge') : T('setup.googleNoneBadge'))}</span></h4>
      <p>${g.demo ? esc(T('setup.googleDemoText')) : esc(T('setup.googleLiveText', { account: g.account || '' }))}</p>
      <div class="row">
        <a class="btn sm primary" href="/api/google/authorize" target="_blank">${esc(g.connected && !g.demo ? T('setup.reauthorize') : T('setup.connectGoogle'))}</a>
        ${!g.demo ? `<button class="btn sm danger" id="g-disconnect">${esc(T('setup.disconnect'))}</button>` : ''}
        <button class="btn sm" id="g-reset">${esc(T('setup.resetDemo'))}</button>
      </div>
      <details class="adv" style="margin-top:10px">
        <summary>${esc(T('setup.googleHow'))}</summary>
        <div class="row" style="margin-top:10px">
          <label class="field" style="flex:1"><span>GOOGLE_CLIENT_ID</span><input id="g-id" placeholder="${esc(g.client_configured ? 'configured' : 'xxxx.apps.googleusercontent.com')}"></label>
          <label class="field" style="flex:1"><span>GOOGLE_CLIENT_SECRET</span><input type="password" id="g-secret" placeholder="${esc(g.client_configured ? 'configured' : 'GOCSPX-…')}"></label>
          <label class="field" style="flex:1"><span>${T('setup.redirect')}</span><input id="g-redirect" value="${esc(state.system.google.redirect_uri || 'http://localhost:8000/api/google/callback')}"></label></div>
        <div class="row"><button class="btn sm primary" id="g-save">${esc(T('setup.saveGoogle'))}</button>
          <span class="pill mono">${esc(state.system.google.demo_data_dir)}</span></div>
      </details>
    </div>

    <div class="section-title">${esc(T('setup.providers'))}
      ${modelReady ? '' : `<span class="badge warn">${esc(T('setup.modelMissing'))}</span>`}</div>
    <p class="hint">${esc(T('setup.modelsHint'))}</p>
    ${providerCards}

    <div class="section-title">${esc(T('setup.safety'))}</div>
    <div class="card">
      <label class="field"><span>${T('setup.safetySimple')}</span>
        <select id="set-approval"><option value="risky">${T('setup.modeRisky')}</option>
        <option value="all">${T('setup.modeAll')}</option><option value="auto">${T('setup.modeAuto')}</option></select></label>
      <div class="row">
        <label class="pill"><input type="checkbox" id="set-shell" ${state.system.settings.allow_shell ? 'checked' : ''}> ${esc(T('setup.allowShell'))}</label>
        <label class="pill"><input type="checkbox" id="set-shellnet" ${state.system.settings.allow_shell_network ? 'checked' : ''}> ${esc(T('setup.allowShellNet'))}</label>
        <button class="btn sm primary" id="set-save">${esc(T('setup.save'))}</button></div>
      <p style="color:var(--muted);font-size:12px">${esc(T('setup.secretsNote'))}</p></div>

    ${advanced}
  </div>`;

  $$('[data-lang]', pane).forEach(b => b.onclick = async () => {
    const code = b.dataset.lang;
    await setLanguage(code);
    const info = (state.system.languages || []).find(l => l.id === code) || {};
    toast(T('setup.languageSaved', { lang: info.native || code }));
  });
  $('#set-save').onclick = async () => {
    await api('/api/settings', { method: 'POST', body: {
      approval_mode: $('#set-approval').value,
      NIMBUS_ALLOW_SHELL: $('#set-shell').checked ? '1' : '0',
      NIMBUS_ALLOW_SHELL_NETWORK: $('#set-shellnet').checked ? '1' : '0' } });
    toast(T('setup.saved')); renderSettings();
  };
  $('#set-approval').value = state.system.settings.approval_mode;
  $$('[data-key]', pane).forEach(inp => {
    inp.onchange = async () => {
      if (!inp.value) return;
      await api('/api/settings', { method: 'POST', body: { [inp.dataset.key]: inp.value } });
      inp.value = ''; toast(T('setup.keySaved')); renderSettings();
    };
  });
  $$('[data-base]', pane).forEach(inp => {
    inp.onchange = async () => { await api('/api/settings', { method: 'POST', body: { [inp.dataset.base === 'local' ? 'LOCAL_BASE_URL' : 'CUSTOM_BASE_URL']: inp.value } }); toast(T('skills.saved')); };
  });
  $$('[data-test]', pane).forEach(b => b.onclick = async () => {
    b.innerHTML = '<span class="spin-lg"></span>'; b.disabled = true;
    const r = await api('/api/providers/test', { method: 'POST', body: { provider: b.dataset.test } }).catch(e => ({ ok: false, error: e.message }));
    b.innerHTML = r.ok ? '✅ Works' : '⚠️ Failed'; b.disabled = false;
    toast(r.ok ? T('setup.testOk', { provider: b.dataset.test, reply: (r.reply || '').trim() }) : `${b.dataset.test}: ${r.error}`, r.ok ? '' : 'err');
  });
  const gd = $('#g-disconnect'); if (gd) gd.onclick = async () => { await api('/api/google/disconnect', { method: 'POST' }); toast(T('setup.disconnected')); renderSettings(); };
  $('#g-reset').onclick = async () => { await api('/api/google/demo-reset', { method: 'POST' }); toast(T('setup.demoReset')); };
  $('#g-save').onclick = async () => {
    const body = {};
    if ($('#g-id').value) body.GOOGLE_CLIENT_ID = $('#g-id').value.trim();
    if ($('#g-secret').value) body.GOOGLE_CLIENT_SECRET = $('#g-secret').value.trim();
    if ($('#g-redirect').value) body.GOOGLE_REDIRECT_URI = $('#g-redirect').value.trim();
    await api('/api/settings', { method: 'POST', body });
    toast(T('setup.googleSaveHint')); renderSettings(); renderConnBadge();
  };
  $('#mcp-add').onclick = async () => {
    const name = $('#mcp-name').value.trim(), transport = $('#mcp-transport').value;
    const raw = $('#mcp-cmd').value.trim();
    if (!name || !raw) return toast(T('setup.mcpNeed'), 'err');
    const parts = raw.split(/\s+/);
    const body = transport === 'stdio'
      ? { name, transport, command: parts[0], args: parts.slice(1) }
      : { name, transport, url: raw };
    const r = await api('/api/mcp', { method: 'POST', body }).catch(e => ({ error: e.message }));
    toast(r.error ? T('setup.mcpFailed', { error: r.error }) : T('setup.mcpConnectedCount', { n: (r.tools || []).length }));
    renderSettings();
  };
  $$('[data-mcpcon]', pane).forEach(b => b.onclick = async () => { const r = await api(`/api/mcp/${b.dataset.mcpcon}/connect`, { method: 'POST' }).catch(e => ({ error: e.message })); toast(r.error || T('setup.mcpConnectedCount', { n: (r.tools || []).length })); renderSettings(); });
  $$('[data-mcpdisc]', pane).forEach(b => b.onclick = async () => { await api(`/api/mcp/${b.dataset.mcpdisc}/disconnect`, { method: 'POST' }); renderSettings(); });
  $$('[data-mcpdel]', pane).forEach(b => b.onclick = async () => { await api(`/api/mcp/${b.dataset.mcpdel}`, { method: 'DELETE' }); renderSettings(); });
  $('#seed-team').onclick = async () => { const r = await api('/api/demo/team', { method: 'POST' }); toast(T('setup.seeded', { names: r.created.map(c => c.name).join(', ') || T('setup.alreadyExists') })); await loadAgents(); renderSettings(); };
  $('#sys-refresh').onclick = () => renderSettings();
}

/* --------------------------- Theme Toggle --------------------------- */
function toggleGlassTheme() {
  document.body.classList.toggle('glass-theme');
  const isGlass = document.body.classList.contains('glass-theme');
  localStorage.setItem('nimbus-glass-theme', isGlass ? 'on' : 'off');
  const btn = $('#btnThemeToggle');
  if (btn) btn.textContent = isGlass ? '🎨' : '🏠';
}

function initGlassTheme() {
  const saved = localStorage.getItem('nimbus-glass-theme');
  if (saved === 'on') {
    document.body.classList.add('glass-theme');
    const btn = $('#btnThemeToggle');
    if (btn) btn.textContent = '🎨';
  }
  const toggleBtn = $('#btnThemeToggle');
  if (toggleBtn) {
    toggleBtn.onclick = toggleGlassTheme;
  }
}

/* -------------------------------- go --------------------------------- */
document.addEventListener('DOMContentLoaded', () => {
  state.drawerOpen = false;
  if (!isSheet()) $('#drawer').classList.add('hidden');   // phones keep it off-screen instead
  updateScrim();
  initGlassTheme();
  boot().catch(e => toast(T('toast.bootError', { error: e.message }), 'err'));
});
