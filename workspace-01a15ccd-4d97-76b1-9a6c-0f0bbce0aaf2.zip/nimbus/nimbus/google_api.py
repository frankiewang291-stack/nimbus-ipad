"""
Google Workspace connector: Drive, Docs, Sheets, Gmail, Calendar.

Two backends behind one API:

  • REAL  — OAuth 2.0 (authorization-code + refresh token) against
            googleapis.com. Used as soon as GOOGLE_CLIENT_ID/SECRET are set.
  • DEMO  — a file-backed workspace under data/demo_google/ that behaves like
            Google so every tool, skill, routine and demo works out of the box
            with no credentials.

Tokens are encrypted at rest (see nimbus/crypto.py).
"""
from __future__ import annotations

import base64
import csv
import io
import json
import mimetypes
import re
import time
from email.message import EmailMessage
from pathlib import Path
from urllib.parse import urlencode

import httpx

from . import crypto, db
from .config import settings

SCOPES = [
    "openid",
    "email",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/documents",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/calendar",
]

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
DRIVE = "https://www.googleapis.com/drive/v3"
UPLOAD = "https://www.googleapis.com/upload/drive/v3"
DOCS = "https://docs.googleapis.com/v1"
SHEETS = "https://sheets.googleapis.com/v4"
GMAIL = "https://gmail.googleapis.com/gmail/v1"
CAL = "https://www.googleapis.com/calendar/v3"

MD_DOC = "application/vnd.google-apps.document"
MD_SHEET = "application/vnd.google-apps.spreadsheet"
MD_SLIDE = "application/vnd.google-apps.presentation"
MD_FOLDER = "application/vnd.google-apps.folder"
MD_UPLOAD_DOC = "application/vnd.google-apps.document"
MD_UPLOAD_SHEET = "application/vnd.google-apps.spreadsheet"


class GoogleError(RuntimeError):
    pass


class NotConnected(GoogleError):
    pass


# ==========================================================================
#  Connection / auth state
# ==========================================================================
def client_configured() -> bool:
    return bool(settings.google_client_id and settings.google_client_secret)


def demo_mode() -> bool:
    return settings.google_demo_mode or not client_configured()


def connection() -> dict:
    row = db.get_oauth("google")
    if demo_mode():
        return {"connected": True, "demo": True, "account": "demo@nimbus.local",
                "scopes": SCOPES, "client_configured": client_configured()}
    if not row:
        return {"connected": False, "demo": False, "account": "",
                "client_configured": client_configured()}
    tok = crypto.decrypt_json(row["token"])
    return {"connected": bool(tok.get("refresh_token") or tok.get("access_token")),
            "demo": False, "account": row.get("account", ""),
            "scopes": (row.get("scopes") or "").split(" "), "client_configured": True}


def authorize_url(state: str = "nimbus") -> str:
    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "response_type": "code",
        "scope": " ".join(SCOPES),
        "access_type": "offline",
        "prompt": "consent",
        "include_granted_scopes": "true",
        "state": state,
    }
    return f"{AUTH_URL}?{urlencode(params)}"


async def exchange_code(code: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(TOKEN_URL, data={
            "code": code, "client_id": settings.google_client_id,
            "client_secret": settings.google_client_secret,
            "redirect_uri": settings.google_redirect_uri, "grant_type": "authorization_code"})
    if r.status_code >= 400:
        raise GoogleError(f"token exchange failed ({r.status_code}): {r.text[:300]}")
    tok = r.json()
    tok["expires_at"] = time.time() + int(tok.get("expires_in", 3600)) - 60
    account = await _fetch_email(tok["access_token"])
    db.save_oauth("google", account, crypto.encrypt_json(tok), tok.get("scope", " ".join(SCOPES)))
    db.audit(None, None, "google.connect", {"account": account}, actor="user")
    return {"account": account, "scopes": tok.get("scope", "")}


async def _fetch_email(access_token: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.get("https://www.googleapis.com/oauth2/v3/userinfo",
                                 headers={"Authorization": f"Bearer {access_token}"})
            if r.status_code < 400:
                return r.json().get("email", "")
    except Exception:
        pass
    return ""


def disconnect() -> None:
    db.delete_oauth("google")
    db.audit(None, None, "google.disconnect", {}, actor="user")


async def access_token() -> str:
    if demo_mode():
        raise NotConnected("demo mode")
    row = db.get_oauth("google")
    if not row:
        raise NotConnected("Google is not connected. Open Connectors → Connect Google.")
    tok = crypto.decrypt_json(row["token"])
    if tok.get("access_token") and time.time() < float(tok.get("expires_at") or 0):
        return tok["access_token"]
    if not tok.get("refresh_token"):
        raise NotConnected("Google refresh token missing — reconnect the account.")
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(TOKEN_URL, data={
            "client_id": settings.google_client_id, "client_secret": settings.google_client_secret,
            "refresh_token": tok["refresh_token"], "grant_type": "refresh_token"})
    if r.status_code >= 400:
        raise NotConnected(f"Google token refresh failed ({r.status_code}) — reconnect the account.")
    fresh = r.json()
    tok["access_token"] = fresh["access_token"]
    tok["expires_at"] = time.time() + int(fresh.get("expires_in", 3600)) - 60
    db.save_oauth("google", row.get("account", ""), crypto.encrypt_json(tok), row.get("scopes", ""))
    return tok["access_token"]


async def _call(method: str, url: str, *, params: dict | None = None, json_body: dict | None = None,
                content: bytes | None = None, headers: dict | None = None) -> dict:
    token = await access_token()
    h = {"Authorization": f"Bearer {token}"}
    h.update(headers or {})
    async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=120), follow_redirects=True) as client:
        r = await client.request(method, url, params=params, json=json_body, content=content, headers=h)
    if r.status_code == 401:
        raise NotConnected("Google rejected the token — reconnect the account.")
    if r.status_code >= 400:
        raise GoogleError(f"Google API {r.status_code}: {r.text[:400]}")
    if not r.content:
        return {}
    ctype = r.headers.get("content-type", "")
    if "json" in ctype:
        return r.json()
    return {"raw": r.content, "content_type": ctype}


# ==========================================================================
#  DEMO backend (file-backed)
# ==========================================================================
DEMO_PATH = settings.demo_google_dir / "index.json"

DEMO_SEED = {
    "files": [
        {"id": "drv-1001", "name": "Q3 Business Review", "mime": MD_DOC, "kind": "doc",
         "modified": "2026-09-28T10:12:00Z", "owner": "demo@nimbus.local",
         "content": ("# Q3 Business Review\n\n## Highlights\n"
                     "- Revenue up 24% QoQ to $4.1M\n- Gross margin steady at 71%\n"
                     "- 312 net new accounts, churn down to 1.8%\n\n"
                     "## Watch items\n- Enterprise pipeline conversion slipped 6 points\n"
                     "- Support backlog grew after the September launch\n\n"
                     "## Next quarter\n1. Ship the workspace connectors GA\n"
                     "2. Hire two SREs\n3. Re-price the Team tier\n")},
        {"id": "drv-1002", "name": "Product Sync — Notes", "mime": MD_DOC, "kind": "doc",
         "modified": "2026-10-01T16:40:00Z", "owner": "demo@nimbus.local",
         "content": ("# Product Sync — Oct 1\n\nAttendees: Maya, Dev, Priya\n\n"
                     "## Decisions\n- Ship approvals UI behind a flag\n"
                     "- Browser tool graduates out of experimental\n\n"
                     "## Open questions\n- Do we need per-agent network egress?\n"
                     "- How long do we retain screenshots?\n")},
        {"id": "drv-1003", "name": "Budget 2026", "mime": MD_SHEET, "kind": "sheet",
         "modified": "2026-09-20T09:00:00Z", "owner": "demo@nimbus.local",
         "sheet_name": "Budget",
         "rows": [["Category", "Q1", "Q2", "Q3", "Q4"],
                  ["Engineering", 820000, 845000, 910000, 950000],
                  ["Go-to-market", 340000, 360000, 405000, 430000],
                  ["Infrastructure", 120000, 131000, 158000, 165000],
                  ["Support", 90000, 95000, 102000, 110000],
                  ["Total", 1370000, 1431000, 1575000, 1655000]]},
        {"id": "drv-1004", "name": "Roadmap.km", "mime": "text/markdown", "kind": "file",
         "modified": "2026-09-15T08:30:00Z", "owner": "demo@nimbus.local",
         "content": "# Roadmap\n\n- Q4: connectors GA, approvals, skills marketplace\n- Q1: multi-user accounts, SSO, audit export\n"},
        {"id": "drv-1005", "name": "Contracts", "mime": MD_FOLDER, "kind": "folder",
         "modified": "2026-08-02T12:00:00Z", "owner": "demo@nimbus.local"},
    ],
    "messages": [
        {"id": "msg-2001", "from": "maya.chen@acme-demo.com", "to": "demo@nimbus.local",
         "subject": "Q4 pricing review — can you pull the numbers?",
         "date": "2026-10-02T09:14:00Z", "labels": ["INBOX", "IMPORTANT"],
         "body": ("Hi,\n\nBefore Thursday's pricing review can you pull Q3 revenue by tier and the "
                  "conversion rate for Team → Enterprise? The board deck needs it by Wednesday EOD.\n\n"
                  "Also — did we ever decide on the usage-based add-on?\n\nThanks,\nMaya\n"),
         "attachments": ["pricing_inputs.csv"]},
        {"id": "msg-2002", "from": "billing@vendor-demo.com", "to": "demo@nimbus.local",
         "subject": "Invoice INV-8842 due in 5 days",
         "date": "2026-10-01T14:02:00Z", "labels": ["INBOX"],
         "body": "Invoice INV-8842 for $12,480 is attached and due 2026-10-08.\n", "attachments": ["INV-8842.pdf"]},
        {"id": "msg-2003", "from": "dev.patel@acme-demo.com", "to": "demo@nimbus.local",
         "subject": "Re: Support backlog",
         "date": "2026-09-30T18:22:00Z", "labels": ["INBOX"],
         "body": "Backlog is down to 34 tickets from 61. Two of the remaining ones are the SSO edge cases.\n",
         "attachments": []},
    ],
    "events": [
        {"id": "evt-3001", "summary": "Pricing review", "start": "2026-10-08T15:00:00+08:00",
         "end": "2026-10-08T16:00:00+08:00", "attendees": ["maya.chen@acme-demo.com"], "location": "Zoom",
         "description": "Q4 pricing + usage add-on decision"},
        {"id": "evt-3002", "summary": "1:1 with Dev", "start": "2026-10-06T10:00:00+08:00",
         "end": "2026-10-06T10:30:00+08:00", "attendees": ["dev.patel@acme-demo.com"], "location": "",
         "description": ""},
        {"id": "evt-3003", "summary": "Board deck dry run", "start": "2026-10-13T09:30:00+08:00",
         "end": "2026-10-13T11:00:00+08:00", "attendees": [], "location": "Room 4", "description": ""},
    ],
}


def _demo() -> dict:
    DEMO_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not DEMO_PATH.exists():
        DEMO_PATH.write_text(json.dumps(DEMO_SEED, indent=2, ensure_ascii=False), encoding="utf-8")
    try:
        return json.loads(DEMO_PATH.read_text(encoding="utf-8"))
    except Exception:
        DEMO_PATH.write_text(json.dumps(DEMO_SEED, indent=2, ensure_ascii=False), encoding="utf-8")
        return json.loads(DEMO_PATH.read_text(encoding="utf-8"))


def _demo_save(data: dict) -> None:
    DEMO_PATH.parent.mkdir(parents=True, exist_ok=True)
    DEMO_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _demo_file(data: dict, file_id: str) -> dict:
    for f in data["files"]:
        if f["id"] == file_id or f["name"].lower() == file_id.lower():
            return f
    raise GoogleError(f"no demo file with id/name {file_id!r}")


def _demo_id(prefix: str, data: dict) -> str:
    n = 1
    existing = {f["id"] for f in data["files"]} | {m["id"] for m in data["messages"]} | {e["id"] for e in data["events"]}
    while f"{prefix}-{n:04d}" in existing:
        n += 1
    return f"{prefix}-{n:04d}"


def _sheet_to_text(f: dict) -> str:
    rows = f.get("rows") or []
    return "\n".join(",".join(str(c) for c in row) for row in rows)


# ==========================================================================
#  DRIVE
# ==========================================================================
async def drive_search(query: str = "", limit: int = 20, mime: str = "") -> dict:
    limit = max(1, min(limit, 100))
    if demo_mode():
        data = _demo()
        q = (query or "").lower()
        hits = []
        for f in data["files"]:
            hay = f"{f['name']} {f.get('content','')}".lower()
            if q and q not in hay:
                continue
            if mime and f.get("mime") != mime:
                continue
            hits.append({"id": f["id"], "name": f["name"], "mime": f["mime"], "kind": f.get("kind", "file"),
                         "modified": f.get("modified"), "owner": f.get("owner"),
                         "snippet": (f.get("content") or "")[:160].replace("\n", " ")})
        return {"files": hits[:limit], "count": len(hits), "source": "demo"}
    parts = ["trashed = false"]
    if query:
        esc = query.replace("'", "\\'")
        parts.append(f"(name contains '{esc}' or fullText contains '{esc}')")
    if mime:
        parts.append(f"mimeType = '{mime}'")
    resp = await _call("GET", f"{DRIVE}/files", params={
        "q": " and ".join(parts), "pageSize": limit,
        "fields": "files(id,name,mimeType,size,modifiedTime,owners(emailAddress),webViewLink)",
        "supportsAllDrives": "true", "includeItemsFromAllDrives": "true",
        "orderBy": "modifiedTime desc"})
    files = [{"id": f["id"], "name": f["name"], "mime": f["mimeType"],
              "kind": _kind_of(f["mimeType"]), "modified": f.get("modifiedTime"),
              "owner": ((f.get("owners") or [{}])[0]).get("emailAddress", ""),
              "link": f.get("webViewLink", ""), "size": f.get("size")}
             for f in resp.get("files", [])]
    return {"files": files, "count": len(files), "source": "google"}


def _kind_of(mime: str) -> str:
    return {MD_DOC: "doc", MD_SHEET: "sheet", MD_SLIDE: "slide", MD_FOLDER: "folder"}.get(mime, "file")


async def drive_read(file_id: str, max_chars: int = 40000) -> dict:
    if demo_mode():
        f = _demo_file(_demo(), file_id)
        if f.get("kind") == "folder":
            data = _demo()
            children = [x["name"] for x in data["files"] if x.get("parent") == f["id"]]
            return {"id": f["id"], "name": f["name"], "kind": "folder", "children": children}
        if f.get("kind") == "sheet":
            text = _sheet_to_text(f)
        else:
            text = f.get("content", "")
        return {"id": f["id"], "name": f["name"], "kind": f.get("kind", "file"),
                "mime": f["mime"], "text": text[:max_chars], "truncated": len(text) > max_chars}
    meta = await _call("GET", f"{DRIVE}/files/{file_id}",
                       params={"fields": "id,name,mimeType,size", "supportsAllDrives": "true"})
    mime = meta.get("mimeType", "")
    if mime == MD_DOC:
        raw = await _call("GET", f"{DRIVE}/files/{file_id}/export", params={"mimeType": "text/plain"})
        text = raw.get("raw", b"").decode("utf-8", "replace")
    elif mime == MD_SHEET:
        raw = await _call("GET", f"{DRIVE}/files/{file_id}/export", params={"mimeType": "text/csv"})
        text = raw.get("raw", b"").decode("utf-8", "replace")
    elif mime == MD_SLIDE:
        raw = await _call("GET", f"{DRIVE}/files/{file_id}/export", params={"mimeType": "text/plain"})
        text = raw.get("raw", b"").decode("utf-8", "replace")
    else:
        raw = await _call("GET", f"{DRIVE}/files/{file_id}", params={"alt": "media", "supportsAllDrives": "true"})
        blob = raw.get("raw", b"")
        try:
            text = blob.decode("utf-8")
        except Exception:
            text = f"[binary file, {len(blob)} bytes, content-type {raw.get('content_type')}]"
    return {"id": file_id, "name": meta.get("name"), "mime": mime, "kind": _kind_of(mime),
            "text": text[:max_chars], "truncated": len(text) > max_chars}


async def drive_upload(local_path: Path, name: str = "", folder_id: str = "", convert: bool = False,
                       mime: str = "") -> dict:
    name = name or local_path.name
    blob = local_path.read_bytes()
    if demo_mode():
        data = _demo()
        fid = _demo_id("drv", data)
        kind = "file"
        text = None
        try:
            text = blob.decode("utf-8")
        except Exception:
            text = None
        entry = {"id": fid, "name": name, "mime": mime or (mimetypes.guess_type(name)[0] or "application/octet-stream"),
                 "kind": kind, "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 "owner": "demo@nimbus.local", "content": text or f"[binary {len(blob)} bytes]"}
        if folder_id:
            entry["parent"] = folder_id
        data["files"].append(entry)
        _demo_save(data)
        return {"id": fid, "name": name, "demo": True, "bytes": len(blob)}
    guessed = mime or mimetypes.guess_type(name)[0] or "application/octet-stream"
    target_mime = guessed
    if convert:
        target_mime = MD_UPLOAD_DOC if guessed.startswith("text/") or name.endswith((".md", ".txt")) else guessed
    if blob.__len__() > settings.drive_resumable_mb * 1024 * 1024:
        # Google only accepts small files with a single multipart request; anything
        # bigger must go up in a resumable session (chunked PUTs, survives retries).
        return await _drive_resumable_upload(blob, name, target_mime, guessed, folder_id)
    boundary = "nimbus-boundary-8f3a"
    meta = {"name": name, "mimeType": target_mime}
    if folder_id:
        meta["parents"] = [folder_id]
    body = (
        f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"
        f"{json.dumps(meta)}\r\n"
        f"--{boundary}\r\nContent-Type: {guessed}\r\n\r\n"
    ).encode() + blob + f"\r\n--{boundary}--\r\n".encode()
    resp = await _call("POST", f"{UPLOAD}/files", params={"uploadType": "multipart", "supportsAllDrives": "true"},
                       content=body, headers={"Content-Type": f"multipart/related; boundary={boundary}"})
    return {"id": resp.get("id"), "name": resp.get("name", name), "mime": resp.get("mimeType"), "bytes": len(blob)}


async def _drive_resumable_upload(blob: bytes, name: str, target_mime: str, source_mime: str,
                                  folder_id: str = "") -> dict:
    """Resumable upload for anything over NIMBUS_DRIVE_RESUMABLE_MB (default 5 MB)."""
    token = await access_token()
    meta: dict = {"name": name, "mimeType": target_mime}
    if folder_id:
        meta["parents"] = [folder_id]
    async with httpx.AsyncClient(timeout=httpx.Timeout(60, read=300), follow_redirects=True) as client:
        start = await client.post(f"{UPLOAD}/files",
                                  params={"uploadType": "resumable", "supportsAllDrives": "true",
                                          "fields": "id,name,mimeType,size"},
                                  json=meta,
                                  headers={"Authorization": f"Bearer {token}",
                                           "X-Upload-Content-Type": source_mime,
                                           "X-Upload-Content-Length": str(len(blob))})
        if start.status_code >= 400:
            raise GoogleError(f"Drive resumable upload refused ({start.status_code}): {start.text[:300]}")
        session = start.headers.get("location") or start.headers.get("Location")
        if not session:
            raise GoogleError("Drive did not return an upload session URL")
        chunk_size = max(settings.drive_resumable_mb, 1) * 1024 * 1024 * 2
        sent, out = 0, {}
        while sent < len(blob):
            piece = blob[sent:sent + chunk_size]
            sent += len(piece)
            done = sent >= len(blob)
            r = await client.put(session, content=piece, headers={
                "Authorization": f"Bearer {token}",
                "Content-Range": f"bytes {sent - len(piece)}-{sent - 1}/{len(blob)}",
                "Content-Type": source_mime})
            if r.status_code in (200, 201) and done:
                try:
                    out = r.json()
                except Exception:
                    out = {}
            elif r.status_code == 308:
                continue  # more to send
            elif r.status_code >= 400:
                raise GoogleError(f"Drive upload failed ({r.status_code}): {r.text[:300]}")
        # the final response sometimes lands on the last PUT with 200/201 already handled
        if not out.get("id"):
            final = await client.put(session, content=b"", headers={
                "Authorization": f"Bearer {token}",
                "Content-Range": f"bytes */{len(blob)}"})
            if final.status_code < 400:
                try:
                    out = final.json()
                except Exception:
                    out = {}
        return {"id": out.get("id"), "name": out.get("name", name), "mime": out.get("mimeType", target_mime),
                "bytes": len(blob), "resumable": True}


async def drive_create_folder(name: str, parent: str = "") -> dict:
    if demo_mode():
        data = _demo()
        fid = _demo_id("drv", data)
        data["files"].append({"id": fid, "name": name, "mime": MD_FOLDER, "kind": "folder",
                              "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                              "owner": "demo@nimbus.local", "parent": parent})
        _demo_save(data)
        return {"id": fid, "name": name}
    meta = {"name": name, "mimeType": MD_FOLDER}
    if parent:
        meta["parents"] = [parent]
    resp = await _call("POST", f"{DRIVE}/files", json_body=meta, params={"supportsAllDrives": "true", "fields": "id,name"})
    return {"id": resp.get("id"), "name": resp.get("name", name)}


async def drive_delete(file_id: str) -> dict:
    if demo_mode():
        data = _demo()
        before = len(data["files"])
        data["files"] = [f for f in data["files"] if f["id"] != file_id]
        _demo_save(data)
        return {"deleted": before - len(data["files"]), "id": file_id}
    await _call("DELETE", f"{DRIVE}/files/{file_id}", params={"supportsAllDrives": "true"})
    return {"deleted": 1, "id": file_id}


# ==========================================================================
#  DOCS  (with markdown → native Docs formatting)
# ==========================================================================
def _parse_markdown(md: str) -> list[dict]:
    blocks: list[dict] = []
    in_code = False
    code_buf: list[str] = []
    for raw in (md or "").splitlines():
        if raw.strip().startswith("```"):
            if in_code:
                blocks.append({"type": "code", "text": "\n".join(code_buf)})
                code_buf, in_code = [], False
            else:
                in_code = True
            continue
        if in_code:
            code_buf.append(raw)
            continue
        line = raw.rstrip()
        if not line.strip():
            blocks.append({"type": "blank", "text": ""})
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            blocks.append({"type": f"h{min(len(m.group(1)), 3)}", "text": m.group(2).strip()})
            continue
        m = re.match(r"^\s*[-*+]\s+(.*)$", line)
        if m:
            blocks.append({"type": "bullet", "text": m.group(1).strip()})
            continue
        m = re.match(r"^\s*\d+[.)]\s+(.*)$", line)
        if m:
            blocks.append({"type": "bullet", "text": m.group(1).strip()})
            continue
        m = re.match(r"^>\s?(.*)$", line)
        if m:
            blocks.append({"type": "quote", "text": m.group(1).strip()})
            continue
        blocks.append({"type": "text", "text": line.strip()})
    if in_code and code_buf:
        blocks.append({"type": "code", "text": "\n".join(code_buf)})
    # inline bold parsing
    for b in blocks:
        spans = []
        text = b["text"]
        rebuilt = ""
        i = 0
        while True:
            start = text.find("**", i)
            if start == -1:
                rebuilt += text[i:]
                break
            end = text.find("**", start + 2)
            if end == -1:
                rebuilt += text[i:]
                break
            rebuilt += text[i:start]
            seg_start = len(rebuilt)
            seg = text[start + 2:end]
            rebuilt += seg
            spans.append((seg_start, len(rebuilt)))
            i = end + 2
        b["text"] = rebuilt
        b["bold"] = spans
    return blocks


def markdown_to_docs_requests(md: str, insert_at: int = 1) -> tuple[list[dict], int]:
    blocks = _parse_markdown(md)
    text = ""
    requests: list[dict] = []
    style_reqs: list[dict] = []
    bullet_ranges: list[dict] = []
    text_style_reqs: list[dict] = []

    for b in blocks:
        body = b["text"]
        start = len(text)
        text += body + "\n"
        b["start"], b["end"] = start, len(text)

    if text:
        requests.append({"insertText": {"location": {"index": insert_at}, "text": text}})

    def doc_range(b: dict, include_newline: bool = False) -> dict:
        return {"startIndex": insert_at + b["start"],
                "endIndex": insert_at + (b["end"] if include_newline else b["start"] + len(b["text"]))}

    for b in blocks:
        t = b["type"]
        if t in ("h1", "h2", "h3"):
            style_reqs.append({"updateParagraphStyle": {
                "range": doc_range(b, True),
                "paragraphStyle": {"namedStyleType": {"h1": "HEADING_1", "h2": "HEADING_2", "h3": "HEADING_3"}[t]},
                "fields": "namedStyleType"}})
        elif t == "bullet":
            bullet_ranges.append(doc_range(b, True))
        elif t == "code":
            text_style_reqs.append({"updateTextStyle": {
                "range": doc_range(b),
                "textStyle": {"weightedFontFamily": {"fontFamily": "Courier New"},
                              "backgroundColor": {"color": {"rgbColor": {"red": 0.96, "green": 0.96, "blue": 0.96}}}},
                "fields": "weightedFontFamily,backgroundColor"}})
        elif t == "quote":
            text_style_reqs.append({"updateTextStyle": {
                "range": doc_range(b),
                "textStyle": {"italic": True, "foregroundColor": {"color": {"rgbColor": {
                    "red": 0.35, "green": 0.35, "blue": 0.35}}}},
                "fields": "italic,foregroundColor"}})
        for (s, e) in b.get("bold") or []:
            if e > s:
                text_style_reqs.append({"updateTextStyle": {
                    "range": {"startIndex": insert_at + b["start"] + s, "endIndex": insert_at + b["start"] + e},
                    "textStyle": {"bold": True}, "fields": "bold"}})
    # merge consecutive bullet paragraphs into one range where possible
    merged: list[dict] = []
    for r in bullet_ranges:
        if merged and merged[-1]["endIndex"] == r["startIndex"]:
            merged[-1]["endIndex"] = r["endIndex"]
        else:
            merged.append(dict(r))
    for r in merged:
        requests.append({"createParagraphBullets": {"range": r, "bulletPreset": "BULLET_DISC_CIRCLE_SQUARE"}})
    requests.extend(style_reqs)
    requests.extend(text_style_reqs)
    return requests, len(text)


async def docs_create(title: str, markdown: str = "", folder_id: str = "") -> dict:
    if demo_mode():
        data = _demo()
        fid = _demo_id("drv", data)
        entry = {"id": fid, "name": title, "mime": MD_DOC, "kind": "doc",
                 "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 "owner": "demo@nimbus.local", "content": markdown or f"# {title}\n"}
        if folder_id:
            entry["parent"] = folder_id
        data["files"].append(entry)
        _demo_save(data)
        return {"id": fid, "name": title, "kind": "doc", "source": "demo"}
    created = await _call("POST", f"{DOCS}/documents", json_body={"title": title})
    doc_id = created["documentId"]
    if markdown:
        reqs, _ = markdown_to_docs_requests(markdown)
        if reqs:
            await _call("POST", f"{DOCS}/documents/{doc_id}:batchUpdate", json_body={"requests": reqs})
    if folder_id:
        try:
            await _call("PATCH", f"{DRIVE}/files/{doc_id}", params={"addParents": folder_id,
                                                                    "fields": "id,parents", "supportsAllDrives": "true"},
                        json_body={})
        except Exception:
            pass
    return {"id": doc_id, "name": title, "kind": "doc", "source": "google",
            "link": f"https://docs.google.com/document/d/{doc_id}/edit"}


async def docs_read(doc_id: str, max_chars: int = 40000) -> dict:
    if demo_mode():
        f = _demo_file(_demo(), doc_id)
        text = f.get("content", "")
        return {"id": f["id"], "name": f["name"], "text": text[:max_chars], "chars": len(text)}
    doc = await _call("GET", f"{DOCS}/documents/{doc_id}")
    text = _doc_to_text(doc)
    return {"id": doc_id, "name": doc.get("title", ""), "text": text[:max_chars], "chars": len(text)}


def _doc_to_text(doc: dict) -> str:
    out: list[str] = []
    for el in (doc.get("body") or {}).get("content", []):
        para = el.get("paragraph")
        if not para:
            if el.get("table"):
                for row in el["table"].get("tableRows", []):
                    cells = []
                    for cell in row.get("tableCells", []):
                        cells.append(" ".join(_para_text(p) for c in cell.get("content", [])
                                              for p in [c.get("paragraph")] if p))
                    out.append(" | ".join(cells))
            continue
        text = _para_text(para)
        style = ((para.get("paragraphStyle") or {}).get("namedStyleType") or "")
        if style.startswith("HEADING"):
            level = style.replace("HEADING_", "")
            out.append("#" * int(level or 1) + " " + text)
        elif para.get("bullet"):
            out.append("- " + text)
        else:
            out.append(text)
    return "\n".join(out)


def _para_text(para: dict) -> str:
    return "".join(r.get("textRun", {}).get("content", "") for r in para.get("elements", []))


async def docs_append(doc_id: str, markdown: str, heading: str = "") -> dict:
    if demo_mode():
        data = _demo()
        f = _demo_file(data, doc_id)
        addition = (f"\n\n## {heading}\n" if heading else "\n\n") + markdown
        f["content"] = (f.get("content") or "") + addition
        f["modified"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _demo_save(data)
        return {"id": f["id"], "name": f["name"], "appended_chars": len(addition)}
    doc = await _call("GET", f"{DOCS}/documents/{doc_id}", params={"fields": "body(content(endIndex))"})
    end = 1
    for el in (doc.get("body") or {}).get("content", []):
        end = max(end, el.get("endIndex", 1))
    insert_at = max(1, end - 1)
    body = (f"\n\n## {heading}\n" if heading else "\n\n") + markdown
    reqs, _ = markdown_to_docs_requests(body, insert_at=insert_at)
    await _call("POST", f"{DOCS}/documents/{doc_id}:batchUpdate", json_body={"requests": reqs})
    return {"id": doc_id, "appended_chars": len(body)}


# ==========================================================================
#  SHEETS
# ==========================================================================
async def sheets_read(sheet_id: str, range_: str = "A1:Z100") -> dict:
    if demo_mode():
        f = _demo_file(_demo(), sheet_id)
        rows = f.get("rows") or []
        return {"id": f["id"], "name": f["name"], "rows": rows, "row_count": len(rows),
                "csv": _sheet_to_text(f)}
    resp = await _call("GET", f"{SHEETS}/spreadsheets/{sheet_id}/values/{range_}")
    return {"id": sheet_id, "range": resp.get("range"), "rows": resp.get("values", []),
            "row_count": len(resp.get("values", []))}


async def sheets_write(sheet_id: str, range_: str, values: list[list]) -> dict:
    if demo_mode():
        data = _demo()
        f = _demo_file(data, sheet_id)
        rows = f.setdefault("rows", [])
        m = re.match(r"([A-Z]+)(\d+)", (range_ or "A1").upper())
        col0 = 0
        row0 = 0
        if m:
            letters, rownum = m.group(1), int(m.group(2))
            for ch in letters:
                col0 = col0 * 26 + (ord(ch) - 64)
            col0 -= 1
            row0 = rownum - 1
        for i, row in enumerate(values):
            ri = row0 + i
            while len(rows) <= ri:
                rows.append([])
            for j, cell in enumerate(row):
                ci = col0 + j
                while len(rows[ri]) <= ci:
                    rows[ri].append("")
                rows[ri][ci] = cell
        _demo_save(data)
        return {"updated_range": range_, "updated_rows": len(values), "source": "demo"}
    resp = await _call("PUT", f"{SHEETS}/spreadsheets/{sheet_id}/values/{range_}",
                       params={"valueInputOption": "USER_ENTERED"}, json_body={"values": values})
    return {"updated_range": resp.get("updatedRange"), "updated_rows": resp.get("updatedRows", 0)}


async def sheets_append(sheet_id: str, values: list[list], range_: str = "A1") -> dict:
    if demo_mode():
        data = _demo()
        f = _demo_file(data, sheet_id)
        f.setdefault("rows", []).extend(values)
        _demo_save(data)
        return {"appended_rows": len(values), "source": "demo"}
    resp = await _call("POST", f"{SHEETS}/spreadsheets/{sheet_id}/values/{range_}:append",
                       params={"valueInputOption": "USER_ENTERED", "insertDataOption": "INSERT_ROWS"},
                       json_body={"values": values})
    return {"appended_rows": (resp.get("updates") or {}).get("updatedRows", 0),
            "updated_range": (resp.get("updates") or {}).get("updatedRange")}


async def sheets_create(title: str, values: list[list] | None = None, folder_id: str = "") -> dict:
    if demo_mode():
        data = _demo()
        fid = _demo_id("drv", data)
        entry = {"id": fid, "name": title, "mime": MD_SHEET, "kind": "sheet",
                 "modified": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 "owner": "demo@nimbus.local", "sheet_name": "Sheet1", "rows": values or []}
        if folder_id:
            entry["parent"] = folder_id
        data["files"].append(entry)
        _demo_save(data)
        return {"id": fid, "name": title, "kind": "sheet", "source": "demo"}
    resp = await _call("POST", f"{SHEETS}/spreadsheets", json_body={"properties": {"title": title}})
    sid = resp["spreadsheetId"]
    if values:
        await sheets_write(sid, "A1", values)
    return {"id": sid, "name": title, "kind": "sheet", "source": "google",
            "link": f"https://docs.google.com/spreadsheets/d/{sid}/edit"}


# ==========================================================================
#  GMAIL
# ==========================================================================
async def gmail_list(query: str = "", limit: int = 10, label: str = "") -> dict:
    limit = max(1, min(limit, 50))
    if demo_mode():
        data = _demo()
        out = []
        for m in data["messages"]:
            if label and label.upper() not in [l.upper() for l in m.get("labels", [])]:
                continue
            if not _demo_gmail_match(m, query):
                continue
            out.append({"id": m["id"], "from": m["from"], "to": m["to"], "subject": m["subject"],
                        "date": m["date"], "labels": m.get("labels", []),
                        "snippet": m["body"][:160].replace("\n", " "),
                        "attachments": m.get("attachments", [])})
        return {"messages": out[:limit], "count": len(out), "source": "demo"}
    q = query or ""
    if label:
        q = f"{q} label:{label}".strip()
    resp = await _call("GET", f"{GMAIL}/users/me/messages",
                       params={"q": q, "maxResults": limit})
    ids = resp.get("messages", [])
    out = []
    for item in ids:
        msg = await _call("GET", f"{GMAIL}/users/me/messages/{item['id']}",
                          params={"format": "metadata", "metadataHeaders": ["From", "To", "Subject", "Date"]})
        headers = {h["name"].lower(): h["value"] for h in (msg.get("payload") or {}).get("headers", [])}
        out.append({"id": item["id"], "from": headers.get("from", ""), "to": headers.get("to", ""),
                    "subject": headers.get("subject", ""), "date": headers.get("date", ""),
                    "labels": msg.get("labelIds", []), "snippet": msg.get("snippet", "")})
    return {"messages": out, "count": len(out), "source": "google", "raw_count": resp.get("resultSizeEstimate")}


def _demo_gmail_match(m: dict, query: str) -> bool:
    """Understand the common Gmail search operators against demo data."""
    from datetime import datetime
    q = (query or "").strip()
    if not q:
        return True
    for term in q.split():
        t = term.lower()
        if t.startswith("newer_than:") or t.startswith("older_than:"):
            try:
                num = int(re.findall(r"\d+", t)[0])
                unit = re.findall(r"[a-z]+$", t)[0][0]
                secs = num * {"d": 86400, "h": 3600, "m": 60, "y": 31536000}.get(unit, 86400)
                ts = datetime.fromisoformat(m["date"].replace("Z", "+00:00")).timestamp()
                if t.startswith("newer_than:") and ts < time.time() - secs:
                    return False
                if t.startswith("older_than:") and ts >= time.time() - secs:
                    return False
            except Exception:
                pass
        elif t.startswith("from:"):
            if t[5:] not in m["from"].lower():
                return False
        elif t.startswith("to:"):
            if t[3:] not in m["to"].lower():
                return False
        elif t.startswith("subject:"):
            if t[8:] not in m["subject"].lower():
                return False
        elif t in ("has:attachment", "has:attachments"):
            if not m.get("attachments"):
                return False
        elif t.startswith(("is:", "in:", "label:", "category:")):
            continue  # recognised operator we don't model in demo mode
        elif ":" in t:
            continue  # unknown operator → ignore rather than fail
        else:
            hay = f"{m['subject']} {m['from']} {m['body']}".lower()
            if t not in hay:
                return False
    return True


async def gmail_read(message_id: str) -> dict:
    if demo_mode():
        for m in _demo()["messages"]:
            if m["id"] == message_id:
                return {"id": m["id"], "from": m["from"], "to": m["to"], "subject": m["subject"],
                        "date": m["date"], "body": m["body"], "attachments": m.get("attachments", [])}
        raise GoogleError(f"no demo message {message_id!r}")
    msg = await _call("GET", f"{GMAIL}/users/me/messages/{message_id}", params={"format": "full"})
    payload = msg.get("payload") or {}
    headers = {h["name"].lower(): h["value"] for h in payload.get("headers", [])}
    body, attachments = _gmail_body(payload)
    return {"id": message_id, "from": headers.get("from", ""), "to": headers.get("to", ""),
            "subject": headers.get("subject", ""), "date": headers.get("date", ""),
            "body": body[:40000], "attachments": attachments, "labels": msg.get("labelIds", [])}


def _gmail_body(payload: dict) -> tuple[str, list[str]]:
    attachments: list[str] = []
    text = ""

    def walk(part: dict) -> None:
        nonlocal text
        mime = part.get("mimeType", "")
        fname = part.get("filename") or ""
        body = part.get("body") or {}
        if fname:
            attachments.append(fname)
        if mime == "text/plain" and body.get("data"):
            text += base64.urlsafe_b64decode(body["data"] + "===").decode("utf-8", "replace")
        elif mime == "text/html" and body.get("data") and not text:
            html = base64.urlsafe_b64decode(body["data"] + "===").decode("utf-8", "replace")
            text += re.sub(r"<[^>]+>", " ", html)
        for p in part.get("parts") or []:
            walk(p)

    walk(payload)
    return re.sub(r"[ \t]{2,}", " ", text), attachments


async def gmail_send(to: str, subject: str, body: str, cc: str = "", attachments: list[Path] | None = None,
                     html: bool = False) -> dict:
    attachments = attachments or []
    # Gmail's own ceiling applies in demo mode too — better to explain it than to fake success.
    total = sum(p.stat().st_size for p in attachments if p.exists())
    if total > settings.gmail_attachment_mb * 1024 * 1024:
        raise GoogleError(
            f"attachments total {total // (1024 * 1024)} MB — Gmail refuses messages over "
            f"{settings.gmail_attachment_mb} MB. Upload the file to Drive with gdrive_upload and send "
            f"the link instead.")
    if demo_mode():
        data = _demo()
        mid = _demo_id("msg", data)
        data["messages"].append({
            "id": mid, "from": "demo@nimbus.local", "to": to, "subject": subject,
            "date": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "labels": ["SENT"],
            "body": body, "attachments": [p.name for p in attachments]})
        _demo_save(data)
        return {"id": mid, "to": to, "subject": subject, "source": "demo",
                "note": "Demo mode: the email was stored locally, not actually sent."}
    msg = EmailMessage()
    msg["To"] = to
    if cc:
        msg["Cc"] = cc
    msg["Subject"] = subject
    msg.set_content(re.sub(r"<[^>]+>", "", body) if html else body)
    if html:
        msg.add_alternative(body, subtype="html")
    for path in attachments:
        if not path.exists():
            continue
        ctype, _ = mimetypes.guess_type(path.name)
        maintype, _, subtype = (ctype or "application/octet-stream").partition("/")
        msg.add_attachment(path.read_bytes(), maintype=maintype, subtype=subtype, filename=path.name)
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    resp = await _call("POST", f"{GMAIL}/users/me/messages/send", json_body={"raw": raw})
    return {"id": resp.get("id"), "to": to, "subject": subject, "source": "google"}


async def gmail_draft(to: str, subject: str, body: str) -> dict:
    if demo_mode():
        return {"draft": True, "to": to, "subject": subject, "body": body, "source": "demo"}
    msg = EmailMessage()
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    resp = await _call("POST", f"{GMAIL}/users/me/drafts", json_body={"message": {"raw": raw}})
    return {"id": (resp.get("message") or {}).get("id"), "draft_id": resp.get("id"), "source": "google"}


# ==========================================================================
#  CALENDAR
# ==========================================================================
async def calendar_list(time_min: str = "", time_max: str = "", limit: int = 10) -> dict:
    limit = max(1, min(limit, 50))
    if demo_mode():
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        out = []
        for e in _demo()["events"]:
            try:
                start = datetime.fromisoformat(e["start"])
            except Exception:
                continue
            if time_min == "now" and start < now:
                continue
            out.append(e)
        out.sort(key=lambda x: x["start"])
        return {"events": out[:limit], "count": len(out), "source": "demo"}
    params = {"maxResults": limit, "singleEvents": "true", "orderBy": "startTime",
              "timeMin": time_min or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if time_max:
        params["timeMax"] = time_max
    resp = await _call("GET", f"{CAL}/calendars/primary/events", params=params)
    return {"events": [{"id": e.get("id"), "summary": e.get("summary", ""),
                        "start": (e.get("start") or {}).get("dateTime") or (e.get("start") or {}).get("date"),
                        "end": (e.get("end") or {}).get("dateTime") or (e.get("end") or {}).get("date"),
                        "location": e.get("location", ""),
                        "attendees": [a.get("email") for a in e.get("attendees", [])],
                        "link": e.get("htmlLink", "")} for e in resp.get("items", [])],
            "count": len(resp.get("items", [])), "source": "google"}


async def calendar_create(summary: str, start: str, end: str, description: str = "",
                          attendees: list[str] | None = None, location: str = "",
                          timezone_: str = "UTC") -> dict:
    attendees = attendees or []
    if demo_mode():
        data = _demo()
        eid = _demo_id("evt", data)
        data["events"].append({"id": eid, "summary": summary, "start": start, "end": end,
                               "attendees": attendees, "location": location, "description": description})
        _demo_save(data)
        return {"id": eid, "summary": summary, "source": "demo"}
    body = {
        "summary": summary, "description": description, "location": location,
        "start": {"dateTime": start, "timeZone": timezone_},
        "end": {"dateTime": end, "timeZone": timezone_},
        "attendees": [{"email": a} for a in attendees],
    }
    resp = await _call("POST", f"{CAL}/calendars/primary/events", json_body=body)
    return {"id": resp.get("id"), "summary": summary, "link": resp.get("htmlLink"), "source": "google"}


# ==========================================================================
#  Status for the UI
# ==========================================================================
def status() -> dict:
    conn = connection()
    return {
        "google": conn,
        "demo_data_dir": str(settings.demo_google_dir),
        "capabilities": ["drive search/read/upload/delete", "docs create/read/append (markdown→native styles)",
                         "sheets read/write/append/create", "gmail list/read/send/draft (+attachments)",
                         "calendar list/create"],
    }
