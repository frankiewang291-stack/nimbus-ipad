"""
MCP (Model Context Protocol) client.

Connects Nimbus agents to external MCP tool servers, exactly like Grok Bot's
MCP support — either `stdio` (spawn a local server process) or HTTP
(streamable-HTTP / SSE style endpoints).

Discovered tools are registered as `mcp__<server>__<tool>` and appear in the
tool picker, audit log and approval flow like any other tool.
"""
from __future__ import annotations

import asyncio
import json
import os
import shlex
from typing import Any

import httpx

from . import db
from .tools import register
from .tools.base import Tool, ToolResult

PROTOCOL_VERSION = "2025-06-18"
_clients: dict[str, "MCPClient"] = {}


class MCPError(RuntimeError):
    pass


class MCPClient:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.name = cfg["name"]
        self.transport = cfg.get("transport", "stdio")
        self.proc: asyncio.subprocess.Process | None = None
        self._id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._reader_task: asyncio.Task | None = None
        self.tools: list[dict] = []
        self.session_id = ""

    # ---------------------------------------------------------------- stdio
    async def _start_stdio(self) -> None:
        command = self.cfg.get("command") or ""
        args = self.cfg.get("args") or []
        if isinstance(args, str):
            args = shlex.split(args)
        if not command:
            raise MCPError("stdio server needs a command")
        env = dict(os.environ)
        env.update({k: str(v) for k, v in (self.cfg.get("env") or {}).items()})
        self.proc = await asyncio.create_subprocess_exec(
            command, *args, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, env=env)
        self._reader_task = asyncio.create_task(self._read_loop())

    async def _read_loop(self) -> None:
        assert self.proc and self.proc.stdout
        while True:
            line = await self.proc.stdout.readline()
            if not line:
                break
            try:
                msg = json.loads(line.decode("utf-8", "replace"))
            except Exception:
                continue
            self._dispatch(msg)

    # ------------------------------------------------------------ http/sse
    async def _http(self, payload: dict) -> dict:
        headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
                   "MCP-Protocol-Version": PROTOCOL_VERSION}
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=180)) as client:
            r = await client.post(self.cfg["url"], json=payload, headers=headers)
        if r.headers.get("mcp-session-id"):
            self.session_id = r.headers["mcp-session-id"]
        if r.status_code >= 400:
            raise MCPError(f"HTTP {r.status_code}: {r.text[:200]}")
        ctype = r.headers.get("content-type", "")
        if "text/event-stream" in ctype:
            for line in r.text.splitlines():
                if line.startswith("data:"):
                    try:
                        return json.loads(line[5:].strip())
                    except Exception:
                        continue
            raise MCPError("empty SSE response")
        return r.json() if r.content else {}

    # ---------------------------------------------------------------- rpc
    def _dispatch(self, msg: dict) -> None:
        if "id" in msg and msg["id"] in self._pending:
            fut = self._pending.pop(msg["id"])
            if not fut.done():
                if "error" in msg:
                    fut.set_exception(MCPError(str(msg["error"].get("message", msg["error"]))))
                else:
                    fut.set_result(msg.get("result") or {})

    async def rpc(self, method: str, params: dict | None = None, timeout: float = 60.0) -> dict:
        if self.transport == "stdio":
            self._id += 1
            rid = self._id
            assert self.proc and self.proc.stdin
            fut: asyncio.Future = asyncio.get_running_loop().create_future()
            self._pending[rid] = fut
            payload = {"jsonrpc": "2.0", "id": rid, "method": method, "params": params or {}}
            self.proc.stdin.write((json.dumps(payload) + "\n").encode())
            await self.proc.stdin.drain()
            return await asyncio.wait_for(fut, timeout=timeout)
        return await self._http({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})

    async def notify(self, method: str, params: dict | None = None) -> None:
        if self.transport == "stdio" and self.proc and self.proc.stdin:
            self.proc.stdin.write((json.dumps({"jsonrpc": "2.0", "method": method,
                                               "params": params or {}}) + "\n").encode())
            await self.proc.stdin.drain()

    # ---------------------------------------------------------------- lifecycle
    async def start(self) -> list[dict]:
        if self.transport == "stdio":
            await self._start_stdio()
        init = await self.rpc("initialize", {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {"roots": {"listChanged": False}, "sampling": {}},
            "clientInfo": {"name": "Nimbus", "version": "1.0.0"},
        })
        await self.notify("notifications/initialized")
        self.server_info = (init or {}).get("serverInfo", {})
        self.tools = (await self.rpc("tools/list", {})).get("tools", []) or []
        return self.tools

    async def call(self, tool_name: str, args: dict) -> dict:
        res = await self.rpc("tools/call", {"name": tool_name, "arguments": args}, timeout=300)
        content = res.get("content") or []
        chunks = []
        for c in content:
            if c.get("type") == "text":
                chunks.append(c.get("text", ""))
            else:
                chunks.append(json.dumps(c, ensure_ascii=False)[:2000])
        return {"text": "\n".join(chunks)[:20000], "isError": bool(res.get("isError"))}

    async def stop(self) -> None:
        try:
            if self._reader_task:
                self._reader_task.cancel()
            if self.proc:
                self.proc.terminate()
                try:
                    await asyncio.wait_for(self.proc.wait(), timeout=5)
                except Exception:
                    self.proc.kill()
        except Exception:
            pass
        self.proc = None


# --------------------------------------------------------------------------
#  Dynamic tool bridging
# --------------------------------------------------------------------------
class MCPTool(Tool):
    group = "MCP"
    icon = "🧩"
    risk = "medium"

    def __init__(self, server_name: str, tool_def: dict):
        raw = tool_def.get("name", "tool")
        self.server_name = server_name
        self.raw_name = raw
        self.name = f"mcp__{server_name}__{raw}"[:64]
        self.description = (tool_def.get("description") or f"MCP tool {raw} on {server_name}")[:900]
        schema = tool_def.get("inputSchema") or {"type": "object", "properties": {}}
        if "type" not in schema:
            schema["type"] = "object"
        self.parameters = schema

    async def call(self, args, ctx):
        client = _clients.get(self.server_name)
        if not client:
            return ToolResult(ok=False, error=f"MCP server {self.server_name} is not connected")
        try:
            res = await client.call(self.raw_name, args)
        except Exception as exc:
            return ToolResult(ok=False, error=f"MCP call failed: {exc}")
        if res.get("isError"):
            return ToolResult(ok=False, error=res.get("text") or "MCP tool returned an error")
        return ToolResult(data={"server": self.server_name, "tool": self.raw_name,
                                "result": res.get("text", "")})


async def connect(server_id: str) -> dict:
    cfg = db.q1("SELECT * FROM mcp_servers WHERE id=?", (server_id,))
    if not cfg:
        raise MCPError("no such MCP server")
    cfg["args"] = db.json_load(cfg.get("args"), [])
    cfg["env"] = db.json_load(cfg.get("env"), {})
    if cfg["name"] in _clients:
        await disconnect(cfg["name"])
    client = MCPClient(cfg)
    try:
        tools = await client.start()
    except Exception as exc:
        db.x("UPDATE mcp_servers SET status=? WHERE id=?", (f"error: {str(exc)[:120]}", server_id))
        raise MCPError(str(exc))
    _clients[cfg["name"]] = client
    for t in tools:
        register(MCPTool(cfg["name"], t))
    db.x("UPDATE mcp_servers SET status=?, tools=? WHERE id=?",
         ("connected", json.dumps([t.get("name") for t in tools]), server_id))
    db.audit(None, None, "mcp.connect", {"server": cfg["name"], "tools": len(tools)}, actor="user")
    return {"server": cfg["name"], "tools": [t.get("name") for t in tools]}


async def disconnect(name: str) -> None:
    client = _clients.pop(name, None)
    if client:
        await client.stop()
    row = db.q1("SELECT id FROM mcp_servers WHERE name=?", (name,))
    if row:
        db.x("UPDATE mcp_servers SET status='disconnected' WHERE id=?", (row["id"],))


async def connect_all() -> list[dict]:
    out = []
    for row in db.list_mcp_servers():
        if not row["enabled"]:
            continue
        try:
            out.append(await connect(row["id"]))
        except Exception as exc:
            out.append({"server": row["name"], "error": str(exc)})
    return out


async def stop_all() -> None:
    for name in list(_clients):
        await disconnect(name)


def client_status() -> list[dict]:
    out = []
    for row in db.list_mcp_servers():
        live = _clients.get(row["name"])
        out.append({**row, "live": bool(live), "tool_count": len(live.tools) if live else 0})
    return out
