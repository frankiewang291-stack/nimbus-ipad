"""
Routines engine: cron, interval and event triggers, plus the event bus bridge.

The user's event bus isn't the only trigger source — anything can emit:
    POST /api/events  {"kind": "email.received", "payload": {...}}

Routines run agents in the background, so work happens even with the app closed.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime, timezone

from . import bus, db
from .store import create_run, finish_run, create_thread, get_agent, update_thread
from .logging_config import get_logger

_tasks: set[asyncio.Task] = set()
_last_tick = 0.0

# Logger for this module
logger = get_logger(__name__)

try:
    from croniter import croniter
    HAVE_CRON = True
except Exception:  # graceful fallback: simple parser
    HAVE_CRON = False


def compute_next_run(kind: str, schedule: str, last: float | None) -> float | None:
    now = time.time()
    if kind == "interval":
        try:
            secs = max(30, int(float(schedule or "3600")))
        except Exception:
            secs = 3600
        return (last or now) + secs if last else now + secs
    if kind in ("cron", "manual"):
        if kind == "manual":
            return None
        if HAVE_CRON:
            try:
                base = datetime.fromtimestamp(now, tz=timezone.utc)
                return croniter(schedule, base).get_next(float)
            except Exception:
                return now + 3600
        # fallback: support "*/N * * * *" and "M H * * *" minimally
        try:
            parts = schedule.split()
            if len(parts) == 5 and parts[0] == "0" and parts[1].isdigit():
                target = datetime.fromtimestamp(now, tz=timezone.utc).replace(
                    hour=int(parts[1]), minute=0, second=0, microsecond=0)
                if target.timestamp() <= now:
                    target = target.replace(day=target.day)  # recompute below
                    return target.timestamp() + 86400
                return target.timestamp()
        except Exception:
            pass
        return now + 3600
    return None


# --------------------------------------------------------------------------
#  Running routines
# --------------------------------------------------------------------------
async def run_routine(routine: dict, trigger: str = "schedule", payload: dict | None = None) -> dict:
    from .agent import run_agent

    agent = get_agent(routine["agent_id"])
    if not agent:
        return {"ok": False, "error": "agent gone"}

    prompt = routine.get("prompt") or routine.get("name") or "Run your routine."
    if routine.get("skill_id"):
        skill = db.q1("SELECT * FROM skills WHERE id=?", (routine["skill_id"],))
        if skill:
            prompt = (f"Execute your skill **{skill['name']}** now.\n\n"
                      f"Skill instructions:\n{skill['instructions']}\n\n"
                      f"Required output: {skill.get('output_format') or 'clear, actionable result'}\n\n"
                      f"Routine goal: {routine.get('prompt') or skill['description']}")
    if trigger == "event" and payload:
        prompt += f"\n\nTrigger event `{routine.get('event_filter','')}` payload:\n{json.dumps(payload, ensure_ascii=False)[:3000]}"

    thread = create_thread(agent["id"], title=f"⏰ {routine['name']}", kind="routine")
    update_thread(thread["id"], {"meta": {"routine_id": routine["id"], "trigger": trigger}})
    run_id = create_run(routine["id"], agent["id"], thread["id"])
    bus.publish("*", {"type": "routine_start", "routine": routine["name"], "agent": agent["name"],
                      "thread_id": thread["id"], "run_id": run_id})
    db.audit(agent["id"], thread["id"], "routine.run",
             {"routine": routine["name"], "trigger": trigger}, risk="low", actor="scheduler")
    try:
        result = await run_agent(agent, prompt, thread_id=thread["id"])
        finish_run(run_id, "ok", result)
        status = {"ok": True, "thread_id": thread["id"], "result": result[:4000]}
    except asyncio.CancelledError as exc:
        finish_run(run_id, "cancelled", "", str(exc))
        status = {"ok": False, "thread_id": thread["id"], "error": "Routine was cancelled"}
        logger.warning("Routine was cancelled",
                      context={"routine_id": routine["id"], "routine_name": routine["name"]},
                      details={"error": str(exc)})
    except Exception as exc:
        finish_run(run_id, "error", "", str(exc))
        status = {"ok": False, "thread_id": thread["id"], "error": str(exc)}
        logger.error("Routine execution error",
                    context={"routine_id": routine["id"], "routine_name": routine["name"]},
                    exc_info=(type(exc), exc, exc.__traceback__))
    bus.publish("*", {"type": "routine_end", "routine": routine["name"], "ok": status["ok"],
                      "thread_id": thread["id"], "run_id": run_id})
    return status


def launch_routine(routine: dict, trigger: str = "schedule", payload: dict | None = None) -> None:
    task = asyncio.create_task(run_routine(routine, trigger, payload))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def emit_event(kind: str, payload: dict, source_agent: str = "") -> list[str]:
    """Event-triggered routines react to internal + external events."""
    try:
        db.insert("events", {"id": db.new_id(), "kind": kind, "payload": json.dumps(payload, ensure_ascii=False),
                             "handled": 0, "created_at": db.now()})
        bus.publish("*", {"type": "event", "kind": kind, "payload": payload, "source_agent": source_agent})
        fired: list[str] = []
        rows = db.q("SELECT * FROM routines WHERE enabled=1 AND kind='event'")
        for r in rows:
            filt = (r.get("event_filter") or "").strip()
            if not filt:
                continue
            patterns = [p.strip() for p in filt.split(",") if p.strip()]
            if any(kind == p or kind.startswith(p.rstrip("*")) for p in patterns):
                launch_routine(r, trigger="event", payload=payload)
                fired.append(r["name"])
        db.x("UPDATE events SET handled=1 WHERE kind=? AND created_at >= ?", (kind, db.now() - 1))
        return fired
    except (OSError, ValueError) as exc:
        logger.warning("Failed to emit event",
                      context={"kind": kind, "source_agent": source_agent},
                      details={"error": str(exc)})
        return []
    except Exception as exc:
        logger.error("Unexpected error emitting event",
                    context={"kind": kind, "source_agent": source_agent},
                    exc_info=(type(exc), exc, exc.__traceback__))
        return []


# --------------------------------------------------------------------------
#  The loop
# --------------------------------------------------------------------------
async def tick() -> None:
    now = time.time()
    try:
        rows = db.q("SELECT * FROM routines WHERE enabled=1 AND kind IN ('cron','interval')")
        for r in rows:
            nxt = r.get("next_run_at")
            if not nxt:
                db.x("UPDATE routines SET next_run_at=? WHERE id=?", 
                     (compute_next_run(r["kind"], r["schedule"], None), r["id"]))
                continue
            if nxt <= now:
                db.x("UPDATE routines SET next_run_at=? WHERE id=?",
                     (compute_next_run(r["kind"], r["schedule"], now), r["id"]))
                launch_routine(r, trigger="schedule")
        # thread.message events let routines react to any agent activity
        global _last_tick
        _last_tick = now
    except (OSError, ValueError) as exc:
        logger.warning("Scheduler tick database error",
                      details={"error": str(exc)})
    except Exception as exc:
        logger.error("Unexpected error in scheduler tick",
                    exc_info=(type(exc), exc, exc.__traceback__))


async def loop(interval: float = 15.0) -> None:
    while True:
        try:
            await tick()
        except asyncio.CancelledError:
            logger.info("Scheduler loop cancelled")
            raise
        except Exception as exc:
            logger.error("Scheduler loop error",
                        exc_info=(type(exc), exc, exc.__traceback__))
        await asyncio.sleep(interval)


def start() -> asyncio.Task:
    task = asyncio.create_task(loop())
    _tasks.add(task)
    return task


async def stop_all() -> None:
    """Stop all running tasks and clean up."""
    tasks = list(_tasks)
    for t in tasks:
        if not t.done():
            t.cancel()
            try:
                await t
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.warning("Error while stopping task",
                              exc_info=(type(exc), exc, exc.__traceback__))
    
    # Clear the _tasks set
    _tasks.clear()
    logger.info("All scheduler tasks stopped", context={"count": len(tasks)})
