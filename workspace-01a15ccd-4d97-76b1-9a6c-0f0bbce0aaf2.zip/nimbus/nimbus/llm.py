"""
Multi-provider LLM layer.

One internal message format (OpenAI-shaped) is translated to each provider's
native wire format, and every provider streams a normalized event stream:

    {"type": "text",       "text": "..."}          incremental assistant text
    {"type": "tool_calls", "calls": [ {id, name, arguments(dict)} ]}
    {"type": "usage",      "usage": {...}}
    {"type": "done",       "finish_reason": "stop"|"tool_calls"|"length"}

Providers:  xai · openai · anthropic · openrouter · groq · deepseek ·
            local (ollama/lmstudio/vllm) · custom · mock (offline demo)
"""
from __future__ import annotations

import asyncio
import json
import re
import time
from typing import Any, AsyncIterator

import httpx

from .config import PROVIDERS, get_base_url, get_key, language_info, provider_ready, settings
from .logging_config import get_logger

TIMEOUT = httpx.Timeout(connect=20.0, read=300.0, write=60.0, pool=20.0)

# Logger for this module
logger = get_logger(__name__)


class LLMError(RuntimeError):
    def __init__(self, message: str, provider: str = "", status: int = 0):
        super().__init__(message)
        self.provider = provider
        self.status = status


def friendly_error(provider: str, status: int, body: str) -> str:
    snippet = re.sub(r"\s+", " ", (body or ""))[:400]
    if status == 401:
        return f"{provider}: API key rejected (401). Check the key in Settings → Providers. {snippet}"
    if status == 403:
        return f"{provider}: access forbidden (403). {snippet}"
    if status == 404:
        return f"{provider}: model or endpoint not found (404). {snippet}"
    if status == 429:
        return f"{provider}: rate limited (429). {snippet}"
    return f"{provider}: HTTP {status}. {snippet}"


# --------------------------------------------------------------------------
#  Message format conversion
# --------------------------------------------------------------------------
def _as_openai(messages: list[dict]) -> list[dict]:
    out = []
    for m in messages:
        role = m.get("role")
        if role == "assistant" and m.get("tool_calls"):
            out.append({
                "role": "assistant",
                "content": m.get("content") or "",
                "tool_calls": [
                    {
                        "id": tc.get("id") or f"call_{i}",
                        "type": "function",
                        "function": {
                            "name": tc.get("name", ""),
                            "arguments": tc.get("arguments") if isinstance(tc.get("arguments"), str)
                            else json.dumps(tc.get("arguments") or {}, ensure_ascii=False),
                        },
                    }
                    for i, tc in enumerate(m["tool_calls"])
                ],
            })
        elif role == "tool":
            out.append({
                "role": "tool",
                "tool_call_id": m.get("tool_call_id") or "",
                "content": m.get("content") or "",
            })
        else:
            out.append({"role": role, "content": m.get("content") or ""})
    return out


def _as_anthropic(messages: list[dict]) -> tuple[str, list[dict]]:
    """Returns (system_prompt, anthropic_messages)."""
    system_parts: list[str] = []
    out: list[dict] = []
    for m in messages:
        role = m.get("role")
        if role == "system":
            system_parts.append(m.get("content") or "")
            continue
        if role == "assistant":
            blocks: list[dict] = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for tc in m.get("tool_calls") or []:
                args = tc.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.loads(args or "{}")
                    except Exception:
                        args = {}
                blocks.append({
                    "type": "tool_use", "id": tc.get("id") or "call_0",
                    "name": tc.get("name", ""), "input": args or {},
                })
            if blocks:
                out.append({"role": "assistant", "content": blocks})
            continue
        if role == "tool":
            out.append({
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": m.get("tool_call_id") or "",
                    "content": (m.get("content") or "")[:20000],
                }],
            })
            continue
        out.append({"role": "user", "content": m.get("content") or ""})
    # merge consecutive same-role turns (Anthropic requires alternation)
    merged: list[dict] = []
    for m in out:
        if merged and merged[-1]["role"] == m["role"]:
            prev, cur = merged[-1]["content"], m["content"]
            if isinstance(prev, str) and isinstance(cur, str):
                merged[-1]["content"] = prev + "\n\n" + cur
            else:
                merged[-1]["content"] = (
                    (prev if isinstance(prev, list) else [{"type": "text", "text": prev}])
                    + (cur if isinstance(cur, list) else [{"type": "text", "text": cur}])
                )
        else:
            merged.append(m)
    if not merged:
        merged = [{"role": "user", "content": "(continue)"}]
    return "\n\n".join(p for p in system_parts if p), merged


def _anthropic_tools(tools: list[dict]) -> list[dict]:
    return [
        {"name": t["name"], "description": t.get("description", ""),
         "input_schema": t.get("parameters") or {"type": "object", "properties": {}}}
        for t in tools
    ]


# --------------------------------------------------------------------------
#  OpenAI-compatible streaming
# --------------------------------------------------------------------------
async def _stream_openai(provider: str, model: str, messages: list[dict], tools: list[dict],
                         temperature: float, max_tokens: int | None) -> AsyncIterator[dict]:
    base = get_base_url(provider).rstrip("/")
    key = get_key(provider)
    url = f"{base}/chat/completions"
    payload: dict[str, Any] = {
        "model": model,
        "messages": _as_openai(messages),
        "stream": True,
        "temperature": temperature,
    }
    if tools:
        payload["tools"] = [{"type": "function", "function": t} for t in tools]
        payload["tool_choice"] = "auto"
    if max_tokens:
        payload["max_tokens"] = max_tokens

    headers = {"Content-Type": "application/json", "Accept": "text/event-stream"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    if provider == "openrouter":
        headers["HTTP-Referer"] = "http://localhost"
        headers["X-Title"] = "Nimbus"

    acc_calls: dict[int, dict] = {}
    finish = "stop"
    usage: dict = {}

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        async with client.stream("POST", url, json=payload, headers=headers) as resp:
            if resp.status_code >= 400:
                body = (await resp.aread()).decode("utf-8", "replace")
                raise LLMError(friendly_error(provider, resp.status_code, body), provider, resp.status_code)
            async for line in resp.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data in ("", "[DONE]"):
                    continue
                try:
                    chunk = json.loads(data)
                except Exception:
                    continue
                if chunk.get("usage"):
                    usage = chunk["usage"]
                for choice in chunk.get("choices") or []:
                    delta = choice.get("delta") or {}
                    if choice.get("finish_reason"):
                        finish = choice["finish_reason"]
                    if delta.get("content"):
                        yield {"type": "text", "text": delta["content"]}
                    for tc in delta.get("tool_calls") or []:
                        idx = tc.get("index", 0)
                        slot = acc_calls.setdefault(idx, {"id": "", "name": "", "arguments": ""})
                        if tc.get("id"):
                            slot["id"] = tc["id"]
                        fn = tc.get("function") or {}
                        if fn.get("name"):
                            slot["name"] = fn["name"]
                        if fn.get("arguments"):
                            slot["arguments"] += fn["arguments"]
                if chunk.get("choices") is None and chunk.get("error"):
                    raise LLMError(f"{provider}: {chunk['error']}", provider)

    if usage:
        yield {"type": "usage", "usage": usage}
    if acc_calls:
        calls = []
        for idx in sorted(acc_calls):
            slot = acc_calls[idx]
            try:
                args = json.loads(slot["arguments"] or "{}")
            except Exception:
                args = {"_raw": slot["arguments"]}
            calls.append({"id": slot["id"] or f"call_{idx}", "name": slot["name"], "arguments": args})
        yield {"type": "tool_calls", "calls": calls}
        finish = "tool_calls"
    yield {"type": "done", "finish_reason": finish}


# --------------------------------------------------------------------------
#  Anthropic streaming
# --------------------------------------------------------------------------
async def _stream_anthropic(provider: str, model: str, messages: list[dict], tools: list[dict],
                            temperature: float, max_tokens: int | None) -> AsyncIterator[dict]:
    system, msgs = _as_anthropic(messages)
    payload: dict[str, Any] = {
        "model": model,
        "messages": msgs,
        "max_tokens": max_tokens or 8192,
        "temperature": temperature,
        "stream": True,
    }
    if system:
        payload["system"] = system
    if tools:
        payload["tools"] = _anthropic_tools(tools)

    headers = {
        "Content-Type": "application/json",
        "Accept": "text/event-stream",
        "x-api-key": get_key(provider),
        "anthropic-version": "2023-06-01",
    }
    calls: list[dict] = []
    current: dict | None = None
    finish = "stop"
    usage: dict = {}

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        async with client.stream("POST", f"{get_base_url(provider).rstrip('/')}/messages",
                                 json=payload, headers=headers) as resp:
            if resp.status_code >= 400:
                body = (await resp.aread()).decode("utf-8", "replace")
                raise LLMError(friendly_error(provider, resp.status_code, body), provider, resp.status_code)
            async for line in resp.aiter_lines():
                if not line.startswith("data:"):
                    continue
                try:
                    ev = json.loads(line[5:].strip())
                except Exception:
                    continue
                etype = ev.get("type")
                if etype == "content_block_start":
                    blk = ev.get("content_block") or {}
                    if blk.get("type") == "tool_use":
                        current = {"id": blk.get("id", ""), "name": blk.get("name", ""), "arguments": ""}
                elif etype == "content_block_delta":
                    d = ev.get("delta") or {}
                    if d.get("type") == "text_delta" and d.get("text"):
                        yield {"type": "text", "text": d["text"]}
                    elif d.get("type") == "input_json_delta" and current is not None:
                        current["arguments"] += d.get("partial_json", "")
                elif etype == "content_block_stop":
                    if current is not None:
                        calls.append(current)
                        current = None
                elif etype == "message_delta":
                    d = ev.get("delta") or {}
                    if d.get("stop_reason"):
                        finish = d["stop_reason"]
                    if ev.get("usage"):
                        usage.update(ev["usage"])
                elif etype == "error":
                    raise LLMError(f"{provider}: {(ev.get('error') or {}).get('message', 'unknown error')}", provider)

    if usage:
        yield {"type": "usage", "usage": usage}
    if calls:
        norm = []
        for i, c in enumerate(calls):
            try:
                args = json.loads(c["arguments"] or "{}")
            except Exception:
                args = {"_raw": c["arguments"]}
            norm.append({"id": c["id"] or f"call_{i}", "name": c["name"], "arguments": args})
        yield {"type": "tool_calls", "calls": norm}
        finish = "tool_calls"
    yield {"type": "done", "finish_reason": finish}


# --------------------------------------------------------------------------
#  Mock (offline demo) model
# --------------------------------------------------------------------------
# Localised strings for the offline demo model (so the whole experience,
# including the demo model's own output, follows the language setting).
L10N: dict[str, dict[str, str]] = {
    "en": {
        "will_use": "I'll use `{tool}` to handle that.",
        "saving": "Got it — saving that to `{file}`.",
        "returned_n": "`{tool}` returned {n} item(s):",
        "returned": "`{tool}` returned:",
        "error_from": "`{tool}` returned an error: {err}",
        "retry": "I'd retry with adjusted arguments.",
        "offline_title": "**Offline demo model.**",
        "offline_body": ("I'm the built-in mock brain, so I can't reason like a real LLM — but everything "
                         "around me is fully live: tools, workspace, connectors, skills, routines, approvals, "
                         "delegation and the audit log all work exactly as they do with a real model."),
        "offline_add": ("Add a key in **Setup → Model providers** (xAI, OpenAI, Anthropic, OpenRouter, Groq, "
                        "DeepSeek, or a local Ollama server) and set it as this agent's model to get real "
                        "reasoning."),
        "video_read": "Read the transcript of **{title}** ({channel}, {duration}):",
        "video_none": "I couldn't get captions for that video: {err}",
        "you_said": "You said:",
        "requested": "Requested",
        "doc_overview": "Overview",
        "doc_overview_body": ("This document was created automatically by Nimbus. With a real model configured "
                              "it would contain researched, written content; the offline demo model fills it "
                              "with a structure you can replace."),
        "doc_sections": "Sections",
        "doc_next": "Next steps",
    },
    "zh": {
        "will_use": "我会用 `{tool}` 来处理这件事。",
        "saving": "好的——正在把结果保存到 `{file}`。",
        "returned_n": "`{tool}` 返回了 {n} 条结果：",
        "returned": "`{tool}` 返回：",
        "error_from": "`{tool}` 返回了一个错误：{err}",
        "retry": "我会调整参数后重试。",
        "offline_title": "**离线演示模型。**",
        "offline_body": ("我是内置的模拟大脑，无法像真正的语言模型那样推理——但我周围的一切都是真实运行的："
                         "工具、工作区、连接器、技能、例行任务、审批、委派与审计日志，都与使用真实模型时完全一致。"),
        "offline_add": ("请在**设置 → 模型提供商**中填入密钥（xAI、OpenAI、Anthropic、OpenRouter、Groq、"
                        "DeepSeek，或本地 Ollama 服务），并将其设为该智能体的模型，即可获得真正的推理能力。"),
        "video_read": "我读完了《{title}》（{channel}，{duration}）的字幕：",
        "video_none": "这个视频我拿不到字幕：{err}",
        "you_said": "你说的是：",
        "requested": "需求",
        "doc_overview": "概述",
        "doc_overview_body": ("本文档由 Nimbus 自动创建。若配置了真实模型，它会包含经过调研与撰写的内容；"
                              "离线演示模型仅填充一个可供你替换的结构。"),
        "doc_sections": "章节",
        "doc_next": "后续步骤",
    },
    "es": {
        "will_use": "Usaré `{tool}` para encargarme de eso.",
        "saving": "Entendido: guardando el resultado en `{file}`.",
        "returned_n": "`{tool}` devolvió {n} resultado(s):",
        "returned": "`{tool}` devolvió:",
        "error_from": "`{tool}` devolvió un error: {err}",
        "retry": "Reintentaría con argumentos ajustados.",
        "offline_title": "**Modelo de demostración sin conexión.**",
        "offline_body": ("Soy el cerebro simulado integrado, así que no puedo razonar como un LLM real, pero todo "
                         "lo que me rodea funciona de verdad: herramientas, espacio de trabajo, conectores, "
                         "habilidades, rutinas, aprobaciones, delegación y el registro de auditoría se comportan "
                         "igual que con un modelo real."),
        "offline_add": ("Añade una clave en **Configuración → Proveedores de modelo** (xAI, OpenAI, Anthropic, "
                        "OpenRouter, Groq, DeepSeek o un servidor Ollama local) y asígnala como modelo de este "
                        "agente para obtener razonamiento real."),
        "video_read": "Leí la transcripción de **{title}** ({channel}, {duration}):",
        "video_none": "No pude obtener los subtítulos de ese vídeo: {err}",
        "you_said": "Has dicho:",
        "requested": "Solicitado",
        "doc_overview": "Resumen",
        "doc_overview_body": ("Este documento lo ha creado Nimbus automáticamente. Con un modelo real contendría "
                              "contenido investigado y redactado; el modelo de demostración solo rellena una "
                              "estructura que puedes sustituir."),
        "doc_sections": "Secciones",
        "doc_next": "Próximos pasos",
    },
}


def mock_lang(user_text: str = "") -> str:
    """Which language the offline model should answer in."""
    want = language_info()["id"]
    if want == "auto":
        if re.search(r"[\u3400-\u9fff\uf900-\ufaff]", user_text or ""):
            return "zh"
        if re.search(r"[¿¡ñáéíóúü]|\b(qué|cómo|hola|gracias|por favor|resumen|correo)\b", (user_text or "").lower()):
            return "es"
        return "en"
    return want if want in L10N else "en"


def l10n(key: str, user_text: str = "", **vars) -> str:
    lang = mock_lang(user_text)
    table = L10N.get(lang) or L10N["en"]
    text = table.get(key) or L10N["en"].get(key, key)
    for k, v in vars.items():
        text = text.replace("{" + k + "}", str(v))
    return text


class MockModel:
    """
    A dependency-free stand-in model so Nimbus is fully usable with no API keys.
    It reasons over keywords, emits real tool calls, and summarises real tool
    output — good enough to exercise the entire agent loop offline.
    It follows the language setting too (English / 中文 / Español).
    """

    # each route lists candidate tools (first one the agent actually has wins)
    _ROUTES = [
        (r"(create|make|write|draft|new|build|创建|新建|写|撰写|写一份|起草|crear|crea|hacer|redactar|escribir)"
         r".{0,24}(doc|document|report|brief|memo|文件|报告|文档|文档|informe|documento)",
         ["gdocs_create", "write_file"],
         lambda m: {"title": _title_of(m, m), "markdown": _doc_body(m)}),
        (r"(create|make|new|build|创建|新建|建立|crear|crea|hacer).{0,24}"
         r"(sheet|spreadsheet|tracker|表格|試算表|hoja|planilla)",
         ["gsheets_create", "write_file"],
         lambda m: {"title": _title_of(m, m), "values": _sheet_seed(m)}),
        (r"(gmail|inbox|e-?mail|郵件|邮件|mail|收件箱|correo|bandeja)",
         ["gmail_list_messages", "gmail_send_email", "gmail_create_draft"],
         lambda m: {"query": "newer_than:7d", "max_results": 8}),
        (r"(calendar|meeting|schedule|日程|會議|会议|agenda|calendario|reunión)",
         ["gcal_list_events", "gcal_create_event"],
         lambda m: {"time_min": "now", "max_results": 8}),
        (r"(sheet|spreadsheet|試算表|表格|budget|tracker|hoja|presupuesto)",
         ["gsheets_read", "gdrive_search"],
         lambda m: {"spreadsheet_id": "Budget 2026", "range": "A1:E20"}),
        (r"(doc|document|文件|報告|报告|文档|documento|informe)",
         ["gdocs_list", "gdrive_search"],
         lambda m: {"max_results": 8}),
        (r"(drive|雲端硬碟|硬碟|我的雲端|云盘|云端硬盘|云端|谷歌硬盘|硬盘|files? in (my )?drive|unidad|mi drive|mi unidad)",
         ["gdrive_search"],
         lambda m: {"query": "", "max_results": 12}),
        (r"(search|research|news|look up|查|搜尋|搜索|研究|busca|buscar|investiga|noticias)",
         ["web_search"],
         lambda m: {"query": _clean_query(m), "max_results": 5}),
        (r"(youtu\.be|youtube\.com|video|影片|视频|視頻|vídeo)",
         ["youtube_transcript", "fetch_url"],
         lambda m: {"url": _first_url(m) or _first_youtube_id(m)}),
        (r"https?://",
         ["fetch_url", "browser_open"],
         lambda m: {"url": _first_url(m)}),
        (r"(open|visit|go to|browse|打开|访问|abre|abrir|visita).{0,30}"
         r"(site|page|website|url|网站|页面|página|sitio)",
         ["browser_open", "fetch_url"],
         lambda m: {"url": _first_url(m)}),
        (r"(write|save|create|写|保存|crear|guardar).{0,20}(file|note|notes|文件|笔记|archivo|nota)|存檔|寫入",
         ["write_file"],
         lambda m: {"path": "notes.md", "content": f"# Notes\n\n{m[:1500]}\n"}),
        (r"(list|show|what.{0,10}(in|are)|列出|查看|看看|看一下|有哪些|有什么|mostrar|lista).{0,20}"
         r"(file|workspace|文件|工作区|档案|硬盘|archivo|espacio)|檔案",
         ["list_files", "workspace_info"],
         lambda m: {"path": ""}),
        (r"(command|terminal|shell|run|執行|运行|命令|脚本|comando|ejecuta|script)",
         ["run_command"],
         lambda m: {"command": "ls -la", "timeout": 20}),
        (r"(remember|note that|記住|記下|记住|记下|recuerda|anota)",
         ["remember"],
         lambda m: {"key": "user_note", "value": m[:400]}),
        (r"(recall|what do you (know|remember)|memory|記憶|记忆|recuerda|memoria)",
         ["recall"],
         lambda m: {"query": ""}),
        (r"(routine|recurring|every day|daily|cron|排程|每天|例行|定时|rutina|diario|cada día)",
         ["list_routines", "create_routine"],
         lambda m: {}),
        (r"(skill|procedure|sop|runbook|技能|流程|habilidad|procedimiento)",
         ["list_skills", "read_skill"],
         lambda m: {}),
        (r"(agent|team|delegate|teammate|who works|智能体|团队|委派|agente|equipo|delegar)",
         ["list_team", "delegate_task"],
         lambda m: {}),
        (r"(summari[sz]e|brief me|catch me up|digest|总结|摘要|汇总|resume|resumen|resúmeme)",
         ["gmail_list_messages", "web_search", "list_files"],
         lambda m: {"query": "newer_than:3d", "max_results": 10}),
    ]

    async def stream(self, messages: list[dict], tools: list[dict]) -> AsyncIterator[dict]:
        last_user = next((m for m in reversed(messages) if m.get("role") == "user"), {"content": ""})
        text = (last_user.get("content") or "").strip()
        tool_msgs = [m for m in messages if m.get("role") == "tool"]
        tool_names = {t["name"] for t in tools}

        if tool_msgs:
            summary = self._summarize(tool_msgs[-1], text)
            # two-step behaviour: if the user asked for a file/report, persist what we found
            already_saved = any(m.get("name") == "write_file" for m in tool_msgs)
            wants_file = re.search(
                r"(save|write|create|file|report|summar\w*|notes"
                r"|保存|存档|存檔|保存到|摘要|总结|汇总|報告|报告|文件|笔记|记录"
                r"|guardar|guarda|resumen|resúmeme|informe|archivo|nota|documento)", text, re.I)
            if (not already_saved) and wants_file and "write_file" in tool_names and tool_msgs[-1].get("name") != "write_file":
                body = self._plain(tool_msgs[-1])
                fname = "summary.md" if re.search(r"summar|brief|摘要|总结|resumen", text, re.I) else "notes.md"
                preamble = l10n("saving", text, file=fname) + "\n\n"
                for chunk in _chunks(preamble):
                    await asyncio.sleep(0.01)
                    yield {"type": "text", "text": chunk}
                title = {"summary.md": {"en": "Summary", "zh": "摘要", "es": "Resumen"},
                         "notes.md": {"en": "Notes", "zh": "笔记", "es": "Notas"}}.get(fname, {})
                heading = title.get(mock_lang(text), fname.replace(".md", "").title())
                yield {"type": "tool_calls", "calls": [{"id": f"call_{int(time.time()*1000)%100000}",
                                                        "name": "write_file",
                                                        "arguments": {"path": fname,
                                                                      "content": f"# {heading}\n\n"
                                                                                 f"_{l10n('requested', text)}: {text[:200]}_\n\n{body}\n"}}]}
                yield {"type": "done", "finish_reason": "tool_calls"}
                return
            for chunk in _chunks(summary):
                await asyncio.sleep(0.012)
                yield {"type": "text", "text": chunk}
            yield {"type": "done", "finish_reason": "stop"}
            return

        for pattern, candidates, build in self._ROUTES:
            tool = next((c for c in candidates if c in tool_names), None)
            if tool and re.search(pattern, text, re.I):
                preamble = l10n("will_use", text, tool=tool) + "\n\n"
                for chunk in _chunks(preamble):
                    await asyncio.sleep(0.01)
                    yield {"type": "text", "text": chunk}
                yield {"type": "tool_calls", "calls": [{"id": f"call_{int(time.time()*1000)%100000}",
                                                        "name": tool, "arguments": build(text)}]}
                yield {"type": "done", "finish_reason": "tool_calls"}
                return

        reply = (f"{l10n('offline_title', text)} {l10n('offline_body', text)}\n\n"
                 f"{l10n('offline_add', text)}\n\n"
                 f"{l10n('you_said', text)} _{text[:300]}_")
        for chunk in _chunks(reply):
            await asyncio.sleep(0.012)
            yield {"type": "text", "text": chunk}
        yield {"type": "done", "finish_reason": "stop"}

    @staticmethod
    def _plain(tool_msg: dict) -> str:
        """A readable version of a tool result, for writing into files."""
        raw = tool_msg.get("content") or ""
        try:
            data = json.loads(raw)
        except Exception:
            return raw[:4000]
        if isinstance(data, dict):
            if data.get("transcript"):
                head = f"**{data.get('title') or data.get('video_id', '')}**"
                meta = " · ".join(x for x in (data.get("channel"), data.get("duration"), data.get("language")) if x)
                return (head + (f" — {meta}" if meta else "") + f"\n\nSource: {data.get('url', '')}"
                        + f"\n\n## Transcript\n\n{data['transcript']}")
            for key in ("items", "files", "results", "matches", "messages", "events", "rows"):
                if isinstance(data.get(key), list):
                    lines = []
                    for it in data[key][:20]:
                        if isinstance(it, dict):
                            label = it.get("name") or it.get("title") or it.get("subject") or it.get("text") or json.dumps(it, ensure_ascii=False)
                            extra = it.get("url") or it.get("snippet") or it.get("from") or ""
                            lines.append(f"- {str(label)[:160]}" + (f" — {str(extra)[:160]}" if extra else ""))
                        else:
                            lines.append(f"- {it}")
                    return f"{len(data[key])} item(s):\n" + "\n".join(lines)
            for key in ("text", "content", "summary", "csv"):
                if data.get(key):
                    return str(data[key])[:4000]
        return json.dumps(data, ensure_ascii=False)[:4000]

    @staticmethod
    def _summarize(tool_msg: dict, user_text: str = "") -> str:
        name = tool_msg.get("name") or "tool"
        raw = tool_msg.get("content") or ""
        try:
            data = json.loads(raw)
        except Exception:
            data = raw
        if isinstance(data, dict):
            if data.get("error"):
                if data.get("title"):
                    return l10n("video_none", user_text, err=str(data["error"])[:300]) + \
                           f"\n\n**{data['title']}** — {data.get('channel', '')} {data.get('duration', '')}"
                return l10n("error_from", user_text, tool=name, err=str(data["error"])[:400]) + \
                       "\n\n" + l10n("retry", user_text)
            if data.get("transcript"):
                head = l10n("video_read", user_text, title=data.get("title") or data.get("video_id", ""),
                            channel=data.get("channel", ""), duration=data.get("duration", ""))
                body = str(data["transcript"])
                if len(body) > 1800:
                    body = body[:1800].rsplit(" ", 1)[0] + " …"
                return head + "\n\n" + body
            for key in ("summary", "text", "content", "result", "matches", "files", "items", "messages", "events"):
                if key in data:
                    body = data[key]
                    if isinstance(body, list):
                        lines = [f"- {json.dumps(b, ensure_ascii=False)[:220]}" for b in body[:12]]
                        return l10n("returned_n", user_text, tool=name, n=len(body)) + "\n\n" + "\n".join(lines)
                    return l10n("returned", user_text, tool=name) + f"\n\n```\n{str(body)[:1500]}\n```"
            return l10n("returned", user_text, tool=name) + f"\n\n```json\n{json.dumps(data, ensure_ascii=False)[:1500]}\n```"
        return l10n("returned", user_text, tool=name) + f"\n\n```\n{str(data)[:1500]}\n```"


def _chunks(text: str, size: int = 22) -> list[str]:
    words = text.split(" ")
    out, buf = [], ""
    for w in words:
        buf = f"{buf} {w}".strip()
        if len(buf) >= size:
            out.append(buf + " ")
            buf = ""
    if buf:
        out.append(buf)
    return out or [text]


def _clean_query(text: str) -> str:
    q = re.sub(r"(?i)^(please\s+)?(search|google|research|look up|find|查|搜尋)\s*", "", text).strip(" ?.。")
    return q[:160] or text[:160]


def _sheet_seed(text: str) -> list[list[str]]:
    if mock_lang(text) == "zh":
        return [["项目", "负责人", "状态"], ["（待填写）", "", "进行中"]]
    if mock_lang(text) == "es":
        return [["Elemento", "Responsable", "Estado"], ["(por completar)", "", "abierto"]]
    return [["Item", "Owner", "Status"], ["(fill me in)", "", "open"]]


def _title_of(text: str, lang_hint: str = "") -> str:
    m = re.search(r"(?:called|titled|named|:)\s*[\"']?([^\"'.\n]{3,60})", text, re.I)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?:叫做|名为|标题为|叫|名為|標題為)[「“\"']?([^」”\"'.。\n]{2,60})", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?:llamad[oa]|titulad[oa]|con el nombre|nombre)\s*[«“\"']?([^»”\"'.\n]{3,60})", text, re.I)
    if m:
        return m.group(1).strip()
    words = [w for w in re.sub(r"[^\w\s]", " ", text).split() if len(w) > 2][:6]
    return " ".join(words).title() or "Untitled"


def _doc_body(text: str) -> str:
    lang = mock_lang(text)
    t = lambda key: l10n(key, text)  # noqa: E731
    if lang == "zh":
        sections = "- 背景与目标\n- 主要发现\n- 建议方案\n- 后续步骤与负责人"
        steps = "1. 审阅并修改\n2. 分享给团队\n"
    elif lang == "es":
        sections = "- Contexto y antecedentes\n- Hallazgos\n- Recomendaciones\n- Próximos pasos y responsables"
        steps = "1. Revisar y editar\n2. Compartir con el equipo\n"
    else:
        sections = "- Context and background\n- Findings\n- Recommendations\n- Next steps and owners"
        steps = "1. Review and edit\n2. Share with the team\n"
    return (f"# {_title_of(text)}\n\n"
            f"_{t('requested')}: {text[:200]}_\n\n"
            f"## {t('doc_overview')}\n\n"
            f"{t('doc_overview_body')}\n\n"
            f"## {t('doc_sections')}\n\n"
            f"{sections}\n\n"
            f"## {t('doc_next')}\n\n"
            f"{steps}")


def _first_youtube_id(text: str) -> str:
    from .youtube import extract_video_id
    m = re.search(r"\b[A-Za-z0-9_-]{11}\b", text or "")
    return extract_video_id(m.group(0)) if m else ""


def _first_url(text: str) -> str:
    m = re.search(r"https?://[^\s<>\"']+", text)
    return m.group(0) if m else ""


# --------------------------------------------------------------------------
#  Public entry point
# --------------------------------------------------------------------------
async def stream_chat(provider: str, model: str, messages: list[dict], tools: list[dict] | None = None,
                      temperature: float = 0.3, max_tokens: int | None = 8192) -> AsyncIterator[dict]:
    tools = tools or []
    spec = PROVIDERS.get(provider)
    if not spec:
        raise LLMError(f"unknown provider {provider!r}")
    if spec["api"] == "mock":
        async for ev in MockModel().stream(messages, tools):
            yield ev
        return
    if not provider_ready(provider):
        raise LLMError(
            f"{spec['label']} is not configured yet — add {spec.get('key_label') or 'a base URL'} "
            f"in Settings → Providers, or switch this agent to the offline demo model."
        )
    api = spec["api"]
    attempts = 0
    max_attempts = 3
    base_delay = 1.0
    
    while True:
        attempts += 1
        try:
            gen = (_stream_anthropic if api == "anthropic" else _stream_openai)(
                provider, model, messages, tools, temperature, max_tokens)
            async for ev in gen:
                yield ev
            return
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.RemoteProtocolError) as exc:
            if attempts >= max_attempts:
                extra = (" For a local server, start Ollama/LM Studio and set LOCAL_BASE_URL in Setup → "
                         "Providers (or switch this agent's model to the offline demo model).") if provider == "local" else ""
                raise LLMError(f"{provider}: connection failed ({exc}). Is the endpoint reachable?{extra}") from exc
            # Exponential backoff: 1s, 2s, 4s
            delay = base_delay * (2 ** (attempts - 1))
            logger.warning("LLM connection error, retrying",
                          context={"provider": provider, "model": model, "attempt": attempts},
                          details={"error": str(exc), "delay": delay, "max_attempts": max_attempts})
            await asyncio.sleep(delay)
        except LLMError as exc:
            if exc.status in (429, 500, 502, 503, 529) and attempts < max_attempts:
                # Exponential backoff for server errors too
                delay = base_delay * (2 ** (attempts - 1))
                logger.warning("LLM server error, retrying",
                              context={"provider": provider, "model": model, "attempt": attempts},
                              details={"status": exc.status, "delay": delay, "max_attempts": max_attempts})
                await asyncio.sleep(delay)
                continue
            raise


def estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)
