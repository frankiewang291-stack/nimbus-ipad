"""
The agent runtime: the loop that turns a message into multi-step work.

    user message → build context → model streams text + tool calls
                 → approval gate → execute tools → feed results back → repeat
                 → final answer (persisted, streamed, audited)

Every agent has its own cloud workspace, long-term memory, skills, routines and
model. Agents can delegate to each other and spawn new teammates.
"""
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from typing import Any, Callable, Awaitable

from . import bus, db
from .approvals import needs_approval, request_approval
from .config import PROVIDERS, language_info, settings
from .llm import LLMError, stream_chat
from .store import (add_message, create_thread, get_agent, get_thread, list_agents, list_messages,
                    list_mcp_servers, recall, update_agent, update_thread, workspace_path,
                    workspace_stats)
from .tools import get_tool, schemas
from .tools.base import ToolContext
from .tools.untrusted import UNTRUSTED_PROMPT
from .logging_config import get_logger, error as log_error

import logging

# Get timezone from settings with fallback to UTC
TIMEZONE = getattr(settings, 'timezone', 'UTC')
MAX_HISTORY = 60
TOOL_OUTPUT_LIMIT = 9000

# Use weak references to prevent memory leaks
import weakref
_ROOMS: dict[str, asyncio.Lock] = {}
_CANCELLED: set[str] = set()
_SEM = asyncio.Semaphore(6)

# Logger for this module
logger = get_logger(__name__)


def thread_lock(thread_id: str) -> asyncio.Lock:
    """Get or create a lock for a thread. Uses weak references for cleanup."""
    # Clean up old locks periodically
    if len(_ROOMS) > 100 and len(_ROOMS) % 100 == 0:
        _cleanup_rooms()
    return _ROOMS.setdefault(thread_id, asyncio.Lock())


def _cleanup_rooms() -> None:
    """Clean up stale thread locks."""
    global _ROOMS
    # Keep only locks that are still referenced
    # This is tricky with asyncio.Lock - we can't easily check if it's still in use
    # For now, just limit the size
    if len(_ROOMS) > 1000:
        # Remove oldest 500
        keys = list(_ROOMS.keys())[:500]
        for key in keys:
            del _ROOMS[key]
        logger.warning("Cleaned up stale thread locks", context={"count": len(keys)})


def cancel(thread_id: str) -> None:
    """Mark a thread as cancelled."""
    _CANCELLED.add(thread_id)
    # Clean up old cancelled threads periodically
    if len(_CANCELLED) > 100 and len(_CANCELLED) % 100 == 0:
        _cleanup_cancelled()


def _cleanup_cancelled() -> None:
    """Clean up stale cancelled thread IDs."""
    global _CANCELLED
    if len(_CANCELLED) > 1000:
        # Remove oldest 500
        items = list(_CANCELLED)
        for item in items[:500]:
            _CANCELLED.discard(item)
        logger.warning("Cleaned up stale cancelled threads", context={"count": 500})


def thread_lock(thread_id: str) -> asyncio.Lock:
    """Get or create a lock for a thread. Uses _ROOMS dict."""
    # Clean up old locks periodically
    if len(_ROOMS) > 100 and len(_ROOMS) % 100 == 0:
        _cleanup_rooms()
    return _ROOMS.setdefault(thread_id, asyncio.Lock())


def cancel(thread_id: str) -> None:
    """Mark a thread as cancelled."""
    _CANCELLED.add(thread_id)
    # Clean up old cancelled threads periodically
    if len(_CANCELLED) > 100 and len(_CANCELLED) % 100 == 0:
        _cleanup_cancelled()


def is_cancelled(thread_id: str) -> bool:
    return thread_id in _CANCELLED


class Cancelled(Exception):
    pass


# --------------------------------------------------------------------------
#  System prompt
# --------------------------------------------------------------------------
def build_system_prompt(agent: dict) -> str:
    now = datetime.now()
    team = [a for a in list_agents() if a["id"] != agent["id"]]
    skills = db.q("SELECT name, description, inputs FROM skills WHERE agent_id=? OR agent_id IS NULL OR agent_id='' "
                  "ORDER BY updated_at DESC LIMIT 20", (agent["id"],))
    routines = db.q("SELECT name, kind, schedule, enabled, next_run_at FROM routines WHERE agent_id=?", (agent["id"],))
    memories = recall(agent["id"], "", 25)
    from .store import workspace_listing
    try:
        listing = workspace_listing(agent["id"], "")
    except (OSError, ValueError, TypeError) as e:
        logger.warning("Failed to get workspace listing", 
                      context={"agent_id": agent["id"]}, 
                      details={"error": str(e)})
        listing = []
    except Exception as e:
        logger.error("Unexpected error getting workspace listing",
                     context={"agent_id": agent["id"]},
                     exc_info=(type(e), e, e.__traceback__))
        listing = []
    stats = workspace_stats(agent["id"])

    from .google_api import connection
    gconn = connection()
    
    # Get timezone from settings
    tz = getattr(settings, 'timezone', 'UTC')

    lines: list[str] = []
    lines.append(
        f"You are **{agent['name']}**"
        + (f", {agent['title']}" if agent.get("title") else "")
        + ", an autonomous agent running on Nimbus — an always-on agent platform "
          "with your own cloud computer (filesystem, shell, browser), workspace, memory, "
          "skills, schedules and connected apps."
    )
    if agent.get("description"):
        lines.append(f"Your role: {agent['description']}")
    if agent.get("persona"):
        lines.append(f"Persona and style: {agent['persona']}")

    lines.append(
        "\n## How you work\n"
        "- You ACT, you don't just advise. Use your tools to actually get the work done, then report the result.\n"
        "- Prefer doing over asking. Only ask the user when a decision is genuinely theirs (money, recipients, "
        "destructive changes) or when required information is truly missing.\n"
        "- Chain tools freely across steps. After each tool result, decide the next step based on what you learned.\n"
        "- Never fabricate tool output. If a tool fails, say what failed and try a different approach.\n"
        "- When you finish a task, give a short summary: what you did, what you produced (file paths, links, ids), "
        "and anything the user must decide next.\n"
        "- When the user gives you a link, open it with `fetch_url` (or `browser_open` for pages that need a real "
        "browser) and work from the real content — never guess what a page or video says.\n"
        "- For a YouTube link (or when the user asks about a video), call `youtube_transcript` first: it returns the "
        "spoken words with title, channel and duration, which you then summarise, translate, quote or save. Long "
        "videos can be read in slices with start/end, and `timestamps=true` gives [mm:ss] markers for citations."
    )

    # ---------------- language ----------------
    lang = language_info()
    agent_lang = (agent.get("language") or "inherit").lower()
    if agent_lang not in ("inherit", "", "auto") and agent_lang in ("en", "zh", "es"):
        lang = language_info(agent_lang)
    if lang["id"] == "auto":
        lines.append(
            "\n## Language\n"
            "- Reply in **the same language the user writes in** (如果用户用中文提问就用中文回答；"
            "si el usuario escribe en español, responde en español).\n"
            "- If a thread switches language, switch with it. Keep code, file names, tool names, "
            "URLs and IDs in their original form — translate only your own prose."
        )
    else:
        lines.append(
            f"\n## Language\n"
            f"- Write **everything you say to the user in {lang['prompt']}** — summaries, questions, "
            f"document content, email bodies, file contents, chat replies — even if the user writes in "
            f"another language.\n"
            f"- Keep code, file names, tool names, URLs, IDs and proper nouns in their original form.\n"
            f"- File names and folder names you create should stay ASCII-friendly (e.g. `report-2026-10.md`), "
            f"but their *content* must be in {lang['prompt']}."
        )

    lines.append(
        f"\n## Environment\n"
        f"- Current time: {now.strftime('%Y-%m-%d %H:%M:%S')} ({tz}), {now.strftime('%A')}.\n"
        f"- Model: {agent.get('provider')}/{agent.get('model')}\n"
        f"- Your workspace: {workspace_path(agent['id'])} ({stats['files']} files, {stats['bytes']} bytes) — "
        f"files you create live here and the user can browse/download them.\n"
        f"- Shell access: {'enabled' if settings.allow_shell else 'disabled'}"
        f"{' (network commands blocked)' if not settings.allow_shell_network else ''}\n"
        f"- Approval policy: {'every action needs approval' if agent.get('approval_mode') == 'all' else settings.approval_mode}"
    )

    if listing:
        names = ", ".join(f"{f['name']}{'/' if f['dir'] else ''}" for f in listing[:25])
        lines.append(f"- Workspace files: {names}")

    if gconn.get("demo"):
        google_state = ("DEMO backend (a local mock Drive/Docs/Sheets/Gmail/Calendar — actions are recorded "
                        "locally; nothing is really sent or published)")
    elif gconn.get("connected"):
        google_state = f"connected as {gconn.get('account')}"
    else:
        google_state = "not connected — tell the user they can connect it in Setup → Connectors"
    browser_state = ("real browser control (browser_* tools) available" if _browser_ok()
                     else "browser control unavailable (Playwright not installed); use fetch_url instead")
    mcp_count = len([m for m in list_mcp_servers() if m["enabled"]])
    lines.append(
        "\n## Connected apps\n"
        f"- Google Workspace: {google_state}\n"
        f"- Web: web_search + fetch_url always available; {browser_state}\n"
        f"- MCP servers: {mcp_count} enabled"
    )

    if team and agent.get("can_delegate"):
        roster = "\n".join(
            f"  - {a['name']} — {a['title'] or 'agent'}: {a['description'] or '(no description)'}"
            for a in team)
        lines.append(
            "\n## Your team (delegate instead of doing out-of-scope work yourself)\n"
            f"{roster}\n"
            "Use `list_team` for the full roster, `delegate_task(agent_name, task)` to hand over a self-contained "
            "brief (include all context — they cannot see this conversation), and `spawn_agent` to create a new "
            "specialist when nobody on the team fits."
        )
    elif agent.get("can_delegate"):
        lines.append("\n## Team\nYou are the only agent so far. Use `spawn_agent` if you need a specialist "
                     "(researcher, writer, analyst, engineer...) to work in parallel.")

    if skills:
        lines.append("\n## Your skills (reusable procedures — follow them when relevant)\n" +
                     "\n".join(f"  - {s['name']}: {s['description']}" for s in skills) +
                     "\nUse `read_skill(name)` for full instructions, `run_skill(name, inputs)` to execute one, "
                     "and `update_skill` to improve a skill after you notice a better way.")

    if routines:
        lines.append("\n## Your routines (scheduled work)\n" +
                     "\n".join(f"  - {r['name']} ({r['kind']} {r['schedule']}, {'on' if r['enabled'] else 'off'})"
                               for r in routines) +
                     "\nUse `create_routine` to schedule recurring work (cron, interval or event-triggered).")

    if memories:
        lines.append("\n## Long-term memory\n" +
                     "\n".join(f"  - {m['key']}: {m['value'][:220]}" for m in memories[:20]) +
                     "\nUse `remember` to save durable facts/preferences and `recall` to search them.")

    lines.append(
        "\n## Deliverables\n"
        "- Documents: build real files in your workspace (`.md`, `.csv`, `.html`, `.py`...), and when the "
        "user is on Google, publish with `gdocs_create` / `gsheets_create` / `gdrive_upload` instead of just "
        "pasting content in chat.\n"
        "- Email: use `gmail_send_email` (attachments must be workspace paths). Calendar: `gcal_create_event`.\n"
        "- Always tell the user the exact file path, doc id or link you produced."
    )
    
    # Add untrusted data handling rules
    lines.append(UNTRUSTED_PROMPT)
    
    return "\n".join(lines)


def _browser_ok() -> bool:
    try:
        import playwright  # noqa: F401
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------
#  Context building
# --------------------------------------------------------------------------
def build_messages(agent: dict, thread_id: str, extra_system: str = "") -> list[dict]:
    history = list_messages(thread_id)
    msgs: list[dict] = [{"role": "system", "content": build_system_prompt(agent)}]
    if extra_system:
        msgs.append({"role": "system", "content": extra_system})
    trimmed = history[-MAX_HISTORY:]
    while trimmed and trimmed[0]["role"] == "tool":  # never start with an orphan tool result
        trimmed.pop(0)
    for m in trimmed:
        role = m["role"]
        if role == "tool":
            msgs.append({"role": "tool", "tool_call_id": m.get("tool_call_id") or "",
                         "name": m.get("name") or "", "content": (m.get("content") or "")[:TOOL_OUTPUT_LIMIT]})
        elif role == "assistant" and m.get("tool_calls"):
            msgs.append({"role": "assistant", "content": m.get("content") or "",
                         "tool_calls": [{"id": tc.get("id"), "name": tc.get("name"),
                                         "arguments": tc.get("arguments")} for tc in m["tool_calls"]]})
        else:
            msgs.append({"role": role, "content": m.get("content") or ""})
    return msgs


# --------------------------------------------------------------------------
#  The runner
# --------------------------------------------------------------------------
class Runner:
    def __init__(self, agent: dict, thread_id: str, *, sink: Callable[[dict], Awaitable[None]] | None = None):
        self.agent = agent
        self.thread_id = thread_id
        self.sink = sink

    async def emit(self, event: dict) -> None:
        event.setdefault("thread_id", self.thread_id)
        event.setdefault("agent_id", self.agent["id"])
        event.setdefault("agent_name", self.agent["name"])
        event["ts"] = time.time()
        bus.publish(self.thread_id, event)
        if self.sink:
            try:
                await self.sink(event)
            except (asyncio.CancelledError, asyncio.TimeoutError) as exc:
                logger.warning("Sink timeout or cancellation",
                              context={"agent_id": self.agent["id"], "thread_id": self.thread_id},
                              details={"error": str(exc)})
            except Exception as exc:
                logger.error("Sink error",
                            context={"agent_id": self.agent["id"], "thread_id": self.thread_id},
                            exc_info=(type(exc), exc, exc.__traceback__))

    def ctx(self) -> ToolContext:
        return ToolContext(agent=self.agent, thread_id=self.thread_id,
                           workspace=workspace_path(self.agent["id"]), event_sink=self.emit)

    async def send(self, user_text: str, *, max_turns: int | None = None,
                   record_user: bool = True) -> str:
        """Run one full turn (may involve many model+tool iterations)."""
        agent = self.agent
        max_turns = max_turns or int(agent.get("max_iterations") or 12)
        tools_allowed = agent.get("tools") or []
        ctx = self.ctx()
        tool_specs = schemas(tools_allowed, ctx)

        if record_user and user_text:
            add_message(self.thread_id, "user", user_text)
            await self.emit({"type": "message", "role": "user", "content": user_text})

        update_agent(agent["id"], {"status": "working"})
        update_thread(self.thread_id, {"status": "running"})
        await self.emit({"type": "run_start", "agent": {"id": agent["id"], "name": agent["name"],
                                                        "emoji": agent.get("emoji")}})
        final_text = ""
        error: str | None = None
        try:
            messages = build_messages(agent, self.thread_id)
            for turn in range(max_turns):
                if is_cancelled(self.thread_id):
                    raise Cancelled()
                assistant_text: list[str] = []
                calls: list[dict] = []
                usage: dict = {}
                async for ev in stream_chat(agent.get("provider", "mock"), agent.get("model", ""),
                                            messages, tool_specs,
                                            temperature=float(agent.get("temperature") or 0.3)):
                    if ev["type"] == "text":
                        assistant_text.append(ev["text"])
                        await self.emit({"type": "delta", "text": ev["text"]})
                    elif ev["type"] == "tool_calls":
                        calls = ev["calls"]
                    elif ev["type"] == "usage":
                        usage = ev.get("usage") or {}
                text = "".join(assistant_text).strip()

                if not calls:
                    final_text = text or "(no output)"
                    add_message(self.thread_id, "assistant", final_text,
                                meta={"usage": usage, "turns": turn + 1})
                    await self.emit({"type": "message", "role": "assistant", "content": final_text,
                                     "meta": {"usage": usage, "turns": turn + 1}})
                    break

                add_message(self.thread_id, "assistant", text, tool_calls=calls,
                            meta={"usage": usage, "turns": turn + 1})
                await self.emit({"type": "message", "role": "assistant", "content": text,
                                 "tool_calls": calls, "meta": {"turns": turn + 1}})
                messages.append({"role": "assistant", "content": text, "tool_calls": calls})

                for call in calls:
                    if is_cancelled(self.thread_id):
                        raise Cancelled()
                    result_text = await self._execute(call, ctx)
                    messages.append({"role": "tool", "tool_call_id": call["id"],
                                     "name": call["name"], "content": result_text})
                if turn == max_turns - 1 and final_text == "":
                    final_text = text or "I hit my step limit for this turn — here's where I got to."
            else:
                final_text = final_text or "I reached my maximum number of steps for this turn."
        except Cancelled:
            final_text = final_text or "Stopped by user."
            await self.emit({"type": "cancelled"})
            logger.info("Agent run cancelled by user", 
                       context={"agent_id": agent["id"], "thread_id": self.thread_id})
        except LLMError as exc:
            error = str(exc)
            final_text = f"⚠️ Model error — {exc}"
            await self.emit({"type": "error", "message": error})
            logger.error("LLM error in agent run",
                        context={"agent_id": agent["id"], "thread_id": self.thread_id},
                        details={"provider": exc.provider, "status": exc.status})
        except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
            error = f"{type(exc).__name__}: {exc}"
            final_text = f"⚠️ Operation timed out or was cancelled: {error}"
            await self.emit({"type": "error", "message": error})
            logger.warning("Agent run timed out or cancelled",
                          context={"agent_id": agent["id"], "thread_id": self.thread_id},
                          details={"error": str(exc)})
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            final_text = f"⚠️ Something went wrong: {error}"
            await self.emit({"type": "error", "message": error})
            logger.error("Unexpected error in agent run",
                        context={"agent_id": agent["id"], "thread_id": self.thread_id},
                        exc_info=(type(exc), exc, exc.__traceback__))
        finally:
            _CANCELLED.discard(self.thread_id)
            update_agent(agent["id"], {"status": "idle"})
            update_thread(self.thread_id, {"status": "idle"})
            await self.emit({"type": "run_end", "ok": error is None, "error": error or ""})

        if error:
            add_message(self.thread_id, "assistant", final_text, meta={"error": error})
        return final_text

    async def _execute(self, call: dict, ctx: ToolContext) -> str:
        name = call.get("name") or ""
        args = call.get("arguments") or {}
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning("Failed to parse tool arguments as JSON",
                              context={"tool": name, "thread_id": self.thread_id},
                              details={"error": str(e), "args_type": type(args).__name__})
                args = {"_raw": args}
            except Exception as e:
                logger.error("Unexpected error parsing tool arguments",
                            context={"tool": name, "thread_id": self.thread_id},
                            exc_info=(type(e), e, e.__traceback__))
                args = {"_raw": args}
        call_id = call.get("id") or f"call_{int(time.time()*1000)%100000}"
        tool = get_tool(name)
        started = time.time()

        if tool is None:
            payload = {"error": f"unknown tool {name!r}"}
            add_message(self.thread_id, "tool", json.dumps(payload), tool_call_id=call_id, name=name)
            await self.emit({"type": "tool_end", "call_id": call_id, "name": name, "ok": False,
                             "error": "unknown tool", "args": args})
            return json.dumps(payload)

        if ctx.agent.get("tools") and name not in (ctx.agent.get("tools") or []):
            payload = {"error": f"tool {name!r} is not enabled for this agent"}
            add_message(self.thread_id, "tool", json.dumps(payload), tool_call_id=call_id, name=name)
            await self.emit({"type": "tool_end", "call_id": call_id, "name": name, "ok": False,
                             "error": "tool disabled for this agent", "args": args})
            return json.dumps(payload)

        reason = needs_approval(ctx.agent, tool, args, self.thread_id)
        if reason:
            decision = await request_approval(ctx.agent, self.thread_id, tool, args, reason)
            status = decision.get("status")
            if status in ("denied", "expired", "blocked"):
                note = decision.get("note") or status
                payload = {"error": f"action {status}: {note}. Do not retry this action; "
                                    f"tell the user it was not performed and offer an alternative."}
                add_message(self.thread_id, "tool", json.dumps(payload), tool_call_id=call_id, name=name)
                await self.emit({"type": "tool_end", "call_id": call_id, "name": name, "ok": False,
                                 "error": f"{status}: {note}", "args": args})
                return json.dumps(payload)

        await self.emit({"type": "tool_start", "call_id": call_id, "name": name, "args": args,
                         "risk": tool.risk, "icon": tool.icon, "group": tool.group})
        try:
            result = await tool.run(args, ctx)
        except asyncio.TimeoutError as exc:
            result = None
            payload_text = json.dumps({"error": f"Tool execution timed out: {exc}"})
            logger.warning("Tool execution timed out",
                          context={"tool": name, "thread_id": self.thread_id},
                          details={"timeout": str(exc)})
        except asyncio.CancelledError as exc:
            result = None
            payload_text = json.dumps({"error": f"Tool execution was cancelled: {exc}"})
            logger.warning("Tool execution was cancelled",
                          context={"tool": name, "thread_id": self.thread_id})
        except Exception as exc:
            result = None
            payload_text = json.dumps({"error": f"{type(exc).__name__}: {exc}"})
            logger.error("Tool execution error",
                        context={"tool": name, "thread_id": self.thread_id},
                        exc_info=(type(exc), exc, exc.__traceback__))
        else:
            payload_text = result.to_model()
        elapsed = round(time.time() - started, 2)
        add_message(self.thread_id, "tool", payload_text, tool_call_id=call_id, name=name)
        display = ""
        if result is not None and isinstance(result.data, dict):
            display = _short_display(result.data)
        await self.emit({"type": "tool_end", "call_id": call_id, "name": name,
                         "ok": bool(result.ok if result else False), "ms": int(elapsed * 1000),
                         "display": display, "args": args})
        db.audit(ctx.agent_id, self.thread_id, f"tool.{name}", {"args": _scrub(args)},
                 risk=tool.risk if result is None or result.ok else "low")
        return payload_text


def _scrub(args: dict) -> dict:
    out = {}
    for k, v in list(args.items())[:12]:
        s = str(v)
        out[k] = s[:300] + ("…" if len(s) > 300 else "")
    return out


def _short_display(data: dict) -> str:
    for key in ("summary", "count", "name", "path", "url", "title", "message", "saved", "created", "id"):
        if key in data and not isinstance(data[key], (list, dict)):
            return f"{key}: {data[key]}"
    for key, val in data.items():
        if isinstance(val, list):
            return f"{len(val)} × {key}"
    return ""


# --------------------------------------------------------------------------
#  Entry points
# --------------------------------------------------------------------------
async def run_agent(agent: dict, task: str, *, thread_id: str | None = None,
                    max_turns: int | None = None) -> str:
    """Run an agent to completion; used by delegation, routines and the API."""
    if not thread_id:
        thread = create_thread(agent["id"], title=task[:60] or "Task", kind="task")
        thread_id = thread["id"]
    async with _SEM:
        async with thread_lock(thread_id):
            runner = Runner(agent, thread_id)
            return await runner.send(task, max_turns=max_turns)


def agent_or_raise(agent_id: str) -> dict:
    agent = get_agent(agent_id)
    if not agent:
        raise KeyError(f"no agent {agent_id}")
    return agent
