"""Nimbus — a self-hosted, always-on agent platform (GrokBot-style)."""

__version__ = "1.0.0"
