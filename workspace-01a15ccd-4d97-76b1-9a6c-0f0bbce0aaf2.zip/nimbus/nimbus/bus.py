"""In-process pub/sub used to stream live activity to the browser (SSE)."""
from __future__ import annotations

import asyncio
from typing import Any


class EventBus:
    def __init__(self) -> None:
        self._subscribers: dict[str, set[asyncio.Queue]] = {"*": set()}

    def subscribe(self, channel: str = "*", maxsize: int = 500) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subscribers.setdefault(channel, set()).add(q)
        return q

    def unsubscribe(self, channel: str, q: asyncio.Queue) -> None:
        self._subscribers.get(channel, set()).discard(q)

    def publish(self, channel: str, event: dict[str, Any]) -> None:
        for target in (channel, "*"):
            for q in list(self._subscribers.get(target, set())):
                try:
                    q.put_nowait(event)
                except asyncio.QueueFull:
                    pass


bus = EventBus()


# module-level convenience wrappers (module `bus` is imported directly everywhere)
def publish(channel: str, event: dict[str, Any]) -> None:
    bus.publish(channel, event)


def subscribe(channel: str = "*", maxsize: int = 500) -> asyncio.Queue:
    return bus.subscribe(channel, maxsize)


def unsubscribe(channel: str, q: asyncio.Queue) -> None:
    bus.unsubscribe(channel, q)
