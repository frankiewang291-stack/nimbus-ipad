"""
Structured logging configuration for Nimbus.

Provides:
- Structured logging with JSON output
- Severity levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- Contextual logging (agent_id, thread_id, etc.)
- Log rotation and retention
"""
from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
from datetime import datetime
from typing import Any

from .config import settings


# --------------------------------------------------------------------------
#  Log levels
# --------------------------------------------------------------------------

class LogLevel:
    """Log levels with numeric values matching Python's logging module."""
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL


# --------------------------------------------------------------------------
#  Structured Logger
# --------------------------------------------------------------------------

class StructuredLogger:
    """
    A structured logger that outputs JSON logs.
    
    Each log entry is a JSON object with:
    - timestamp: ISO 8601 timestamp
    - level: log level name
    - severity: log level name (for compatibility)
    - message: the log message
    - context: additional context (agent_id, thread_id, etc.)
    - details: optional additional details
    """
    
    def __init__(self, name: str, level: int = LogLevel.INFO):
        self.name = name
        self.level = level
        self._logger = logging.getLogger(name)
        self._logger.setLevel(level)
        
        # Add handler if not already configured
        if not self._logger.handlers:
            self._configure_handler()
    
    def _configure_handler(self):
        """Configure the log handler."""
        # Check if we should log to file
        log_file = getattr(settings, 'log_file', None) or os.environ.get('NIMBUS_LOG_FILE')
        
        if log_file:
            # Rotating file handler
            handler = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=10 * 1024 * 1024,  # 10 MB
                backupCount=5,
                encoding='utf-8'
            )
        else:
            # Console handler
            handler = logging.StreamHandler(sys.stdout)
        
        # JSON formatter
        formatter = StructuredFormatter()
        handler.setFormatter(formatter)
        handler.setLevel(self.level)
        
        self._logger.addHandler(handler)
        
        # Prevent propagation to root logger
        self._logger.propagate = False
    
    def _log(self, level: int, level_name: str, msg: str, 
             context: dict | None = None, details: dict | None = None,
             exc_info: tuple | None = None) -> None:
        """Internal log method."""
        if level < self.level:
            return
        
        # Build log entry
        log_entry = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': level_name,
            'severity': level_name,
            'logger': self.name,
            'message': msg,
            'context': context or {},
            'details': details or {}
        }
        
        # Add exception info if provided
        if exc_info:
            log_entry['exception'] = {
                'type': exc_info[0].__name__ if exc_info[0] else None,
                'message': str(exc_info[1]) if exc_info[1] else None,
                'traceback': self._format_traceback(exc_info[2]) if exc_info[2] else None
            }
        
        # Log using the underlying logger
        self._logger.log(level, json.dumps(log_entry, default=str, ensure_ascii=False))
    
    def _format_traceback(self, tb) -> str:
        """Format traceback as string."""
        import traceback
        return ''.join(traceback.format_tb(tb))
    
    def debug(self, msg: str, context: dict | None = None, 
              details: dict | None = None) -> None:
        """Log a debug message."""
        self._log(LogLevel.DEBUG, 'DEBUG', msg, context, details)
    
    def info(self, msg: str, context: dict | None = None,
             details: dict | None = None) -> None:
        """Log an info message."""
        self._log(LogLevel.INFO, 'INFO', msg, context, details)
    
    def warning(self, msg: str, context: dict | None = None,
                details: dict | None = None) -> None:
        """Log a warning message."""
        self._log(LogLevel.WARNING, 'WARNING', msg, context, details)
    
    def error(self, msg: str, context: dict | None = None,
              details: dict | None = None, exc_info: tuple | None = None) -> None:
        """Log an error message."""
        self._log(LogLevel.ERROR, 'ERROR', msg, context, details, exc_info)
    
    def critical(self, msg: str, context: dict | None = None,
                 details: dict | None = None, exc_info: tuple | None = None) -> None:
        """Log a critical message."""
        self._log(LogLevel.CRITICAL, 'CRITICAL', msg, context, details, exc_info)


class StructuredFormatter(logging.Formatter):
    """Formatter that outputs JSON logs."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format the log record as JSON."""
        # If the message is already JSON, parse it
        try:
            msg_data = json.loads(record.getMessage())
            return json.dumps(msg_data, ensure_ascii=False)
        except (json.JSONDecodeError, TypeError):
            # Otherwise, create a structured log entry
            log_entry = {
                'timestamp': datetime.utcnow().isoformat() + 'Z',
                'level': record.levelname,
                'severity': record.levelname,
                'logger': record.name,
                'message': record.getMessage(),
                'context': {},
                'details': {}
            }
            
            # Add exception info if present
            if record.exc_info:
                log_entry['exception'] = {
                    'type': record.exc_info[0].__name__ if record.exc_info[0] else None,
                    'message': str(record.exc_info[1]) if record.exc_info[1] else None,
                    'traceback': self.formatException(record.exc_info)
                }
            
            return json.dumps(log_entry, default=str, ensure_ascii=False)


# --------------------------------------------------------------------------
#  Module-level logger
# --------------------------------------------------------------------------

# Create a default logger
_logger: StructuredLogger | None = None


def get_logger(name: str | None = None) -> StructuredLogger:
    """
    Get a structured logger.
    
    Args:
        name: Logger name (defaults to caller's module name)
    
    Returns:
        StructuredLogger instance
    """
    global _logger
    
    if name is None:
        # Get the caller's module name
        import inspect
        frame = inspect.currentframe()
        try:
            caller_frame = frame.f_back.f_back if frame and frame.f_back else None
            if caller_frame:
                module = inspect.getmodule(caller_frame)
                if module:
                    name = module.__name__
        finally:
            del frame
    
    if name is None:
        name = 'nimbus'
    
    # Check if we have a cached logger
    if _logger is None or _logger.name != name:
        _logger = StructuredLogger(name)
    
    return _logger


# Convenience functions
def debug(msg: str, context: dict | None = None, details: dict | None = None) -> None:
    """Log a debug message."""
    get_logger().debug(msg, context, details)


def info(msg: str, context: dict | None = None, details: dict | None = None) -> None:
    """Log an info message."""
    get_logger().info(msg, context, details)


def warning(msg: str, context: dict | None = None, details: dict | None = None) -> None:
    """Log a warning message."""
    get_logger().warning(msg, context, details)


def error(msg: str, context: dict | None = None, details: dict | None = None, 
          exc_info: tuple | None = None) -> None:
    """Log an error message."""
    get_logger().error(msg, context, details, exc_info)


def critical(msg: str, context: dict | None = None, details: dict | None = None,
             exc_info: tuple | None = None) -> None:
    """Log a critical message."""
    get_logger().critical(msg, context, details, exc_info)
