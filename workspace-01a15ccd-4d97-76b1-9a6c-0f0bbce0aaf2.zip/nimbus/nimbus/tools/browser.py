"""
Real browser control (computer-use style) via Playwright, with a graceful
fallback when Playwright/Chromium is not installed.

Install the real thing with:
    pip install playwright && playwright install chromium

Sessions are per-thread: each agent thread gets its own tab, so parallel agents
don't fight over the same page.
"""
from __future__ import annotations

import asyncio
import time
from pathlib import Path

from .base import Tool, ToolResult
from .ssrf_guard import SSRFError, guard_ssrf
from .untrusted import mark_thread_tainted, wrap_untrusted_content

SESSIONS: dict[str, "BrowserSession"] = {}
_LOCK = asyncio.Lock()

JS_SNAPSHOT = r"""
() => {
  document.querySelectorAll('[data-nimbus-idx]').forEach(e => e.removeAttribute('data-nimbus-idx'));
  const sel = 'a[href], button, input, select, textarea, [role=button], [role=link], [contenteditable=true]';
  const nodes = Array.from(document.querySelectorAll(sel)).filter(el => {
    const r = el.getBoundingClientRect();
    const st = window.getComputedStyle(el);
    return r.width > 1 && r.height > 1 && st.visibility !== 'hidden' && st.display !== 'none';
  });
  const out = nodes.slice(0, 120).map((el, i) => {
    el.setAttribute('data-nimbus-idx', String(i));
    const r = el.getBoundingClientRect();
    return {
      idx: i,
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute('type') || '',
      text: (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').trim().slice(0, 120),
      name: el.getAttribute('name') || '',
      href: el.href ? String(el.href).slice(0, 200) : '',
      top: Math.round(r.top + window.scrollY)
    };
  });
  const text = document.body ? document.body.innerText.slice(0, 20000) : '';
  return {title: document.title, url: location.href, text, elements: out,
          scrollY: window.scrollY, scrollHeight: document.body ? document.body.scrollHeight : 0};
}
"""


class BrowserSession:
    def __init__(self, thread_id: str, workspace: Path):
        self.thread_id = thread_id
        self.workspace = workspace
        self.pw = None
        self.browser = None
        self.page = None
        self.last_snapshot: dict = {}
        self.created = time.time()

    async def ensure(self):
        if self.page:
            return
        from playwright.async_api import async_playwright  # imported lazily
        self.pw = await async_playwright().start()
        self.browser = await self.pw.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage"])
        ctx = await self.browser.new_context(
            viewport={"width": 1440, "height": 960},
            user_agent=("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/124.0 Safari/537.36"),
            locale="en-US",
        )
        self.page = await ctx.new_page()
        self.page.set_default_timeout(20000)

    async def snapshot(self) -> dict:
        await self.ensure()
        data = await self.page.evaluate(JS_SNAPSHOT)
        self.last_snapshot = data
        return data

    async def close(self):
        try:
            if self.browser:
                await self.browser.close()
            if self.pw:
                await self.pw.stop()
        except Exception:
            pass
        self.page = self.browser = self.pw = None


async def get_session(ctx) -> BrowserSession:
    async with _LOCK:
        sess = SESSIONS.get(ctx.thread_id)
        if sess is None:
            sess = BrowserSession(ctx.thread_id, Path(ctx.workspace or "."))
            SESSIONS[ctx.thread_id] = sess
        return sess


def playwright_installed() -> bool:
    try:
        import playwright  # noqa: F401
        return True
    except Exception:
        return False


HELP = ("Browser control needs Playwright + Chromium:\n"
        "    pip install playwright\n    playwright install chromium\n"
        "Until then the `fetch_url` tool can still read pages as text.")


class BrowserOpenTool(Tool):
    name = "browser_open"
    description = ("Open a URL in a real headless browser you control (like a human at a screen). "
                   "Returns the page text plus a numbered list of clickable/fillable elements.")
    parameters = {"type": "object", "properties": {
        "url": {"type": "string"}, "wait_for": {"type": "string", "description": "css selector to wait for"}},
        "required": ["url"]}
    group = "Browser"
    icon = "🖥️"
    risk = "medium"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        
        url = args["url"]
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # SSRF Guard: Block requests to internal/private networks
        try:
            guard_ssrf(url, f" (browser_open called from thread {ctx.thread_id})")
        except SSRFError as e:
            return ToolResult(ok=False, error=str(e))
        
        sess = await get_session(ctx)
        await sess.ensure()
        await sess.page.goto(url, wait_until="domcontentloaded")
        if args.get("wait_for"):
            try:
                await sess.page.wait_for_selector(args["wait_for"], timeout=15000)
            except Exception:
                pass
        try:
            await sess.page.wait_for_load_state("networkidle", timeout=6000)
        except Exception:
            pass
        data = await sess.snapshot()
        await ctx.emit({"type": "browser", "url": data["url"], "title": data["title"]})
        
        # Wrap browser content as untrusted
        result = {"url": data["url"], "title": data["title"], "elements": data["elements"][:60],
                 "text": data["text"][:12000]}
        wrapped = wrap_untrusted_content(result, "browser_open", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped, risk="medium")


class BrowserSnapshotTool(Tool):
    name = "browser_snapshot"
    description = ("Re-read the current browser page: page text plus numbered interactive elements. "
                   "Always call this after navigating or clicking to see the new state.")
    parameters = {"type": "object", "properties": {"max_text": {"type": "integer"}}, "required": []}
    group = "Browser"
    icon = "📸"
    risk = "low"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open — call browser_open first")
        data = await sess.snapshot()
        
        # Wrap browser content as untrusted
        result = {"url": data["url"], "title": data["title"], "elements": data["elements"],
                 "text": data["text"][: int(args.get("max_text") or 12000)],
                 "scrollY": data["scrollY"], "scrollHeight": data["scrollHeight"]}
        wrapped = wrap_untrusted_content(result, "browser_snapshot", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class BrowserClickTool(Tool):
    name = "browser_click"
    description = "Click an interactive element by its index from the last snapshot, or by CSS selector/text."
    parameters = {"type": "object", "properties": {
        "index": {"type": "integer"}, "selector": {"type": "string"},
        "text": {"type": "string", "description": "click the element containing this text"}},
        "required": []}
    group = "Browser"
    icon = "🖱️"
    risk = "high"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open — call browser_open first")
        page = sess.page
        try:
            if args.get("index") is not None:
                await page.click(f'[data-nimbus-idx="{int(args["index"])}"]', timeout=15000)
            elif args.get("selector"):
                await page.click(args["selector"], timeout=15000)
            elif args.get("text"):
                await page.get_by_text(args["text"], exact=False).first.click(timeout=15000)
            else:
                return ToolResult(ok=False, error="provide index, selector or text")
        except Exception as exc:
            return ToolResult(ok=False, error=f"click failed: {exc}")
        try:
            await page.wait_for_load_state("networkidle", timeout=6000)
        except Exception:
            pass
        data = await sess.snapshot()
        
        # Wrap browser content as untrusted
        result = {"clicked": args, "url": data["url"], "title": data["title"],
                 "elements": data["elements"][:60], "text": data["text"][:8000]}
        wrapped = wrap_untrusted_content(result, "browser_click", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped, risk="high")


class BrowserTypeTool(Tool):
    name = "browser_type"
    description = "Type text into a field (by element index or selector). Set enter=true to submit."
    parameters = {"type": "object", "properties": {
        "index": {"type": "integer"}, "selector": {"type": "string"}, "text": {"type": "string"},
        "enter": {"type": "boolean"}, "clear_first": {"type": "boolean"}},
        "required": ["text"]}
    group = "Browser"
    icon = "⌨️"
    risk = "high"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open — call browser_open first")
        page = sess.page
        sel = None
        if args.get("index") is not None:
            sel = f'[data-nimbus-idx="{int(args["index"])}"]'
        elif args.get("selector"):
            sel = args["selector"]
        if not sel:
            return ToolResult(ok=False, error="provide index or selector")
        try:
            if args.get("clear_first", True):
                await page.fill(sel, "", timeout=15000)
            await page.type(sel, args["text"], delay=12)
            if args.get("enter"):
                await page.keyboard.press("Enter")
                try:
                    await page.wait_for_load_state("networkidle", timeout=8000)
                except Exception:
                    pass
        except Exception as exc:
            return ToolResult(ok=False, error=f"typing failed: {exc}")
        data = await sess.snapshot()
        
        # Wrap browser content as untrusted
        result = {"typed_into": sel, "url": data["url"], "elements": data["elements"][:40],
                 "text": data["text"][:6000]}
        wrapped = wrap_untrusted_content(result, "browser_type", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped, risk="high")


class BrowserKeyTool(Tool):
    name = "browser_key"
    description = "Press a keyboard key on the page (e.g. Enter, Tab, Escape, PageDown)."
    parameters = {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}
    group = "Browser"
    icon = "⏎"
    risk = "medium"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open")
        await sess.page.keyboard.press(args["key"])
        await asyncio.sleep(0.6)
        data = await sess.snapshot()
        
        # Wrap browser content as untrusted
        result = {"url": data["url"], "text": data["text"][:6000],
                 "elements": data["elements"][:40]}
        wrapped = wrap_untrusted_content(result, "browser_key", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class BrowserScrollTool(Tool):
    name = "browser_scroll"
    description = "Scroll the page (up/down/top/bottom)."
    parameters = {"type": "object", "properties": {
        "direction": {"type": "string", "enum": ["down", "up", "top", "bottom"]},
        "amount": {"type": "integer", "description": "pixels, default 800"}}, "required": []}
    group = "Browser"
    icon = "🖲️"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open")
        d = args.get("direction", "down")
        amount = int(args.get("amount") or 800)
        if d == "top":
            await sess.page.evaluate("window.scrollTo(0,0)")
        elif d == "bottom":
            await sess.page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        else:
            await sess.page.mouse.wheel(0, amount if d == "down" else -amount)
        await asyncio.sleep(0.5)
        data = await sess.snapshot()
        
        # Wrap browser content as untrusted
        result = {"scrollY": data["scrollY"], "scrollHeight": data["scrollHeight"],
                 "url": data["url"], "text": data["text"][:10000]}
        wrapped = wrap_untrusted_content(result, "browser_scroll", data["url"])
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class BrowserScreenshotTool(Tool):
    name = "browser_screenshot"
    description = "Take a screenshot of the current page and save it in your workspace (the user can view it)."
    parameters = {"type": "object", "properties": {"path": {"type": "string"}, "full_page": {"type": "boolean"}},
                  "required": []}
    group = "Browser"
    icon = "🖼️"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open")
        name = args.get("path") or f"shots/shot-{int(time.time())}.png"
        target = Path(ctx.workspace) / name
        target.parent.mkdir(parents=True, exist_ok=True)
        await sess.page.screenshot(path=str(target), full_page=bool(args.get("full_page")))
        rel = str(target.relative_to(Path(ctx.workspace))).replace("\\", "/")
        await ctx.emit({"type": "screenshot", "path": rel, "url": sess.page.url})
        
        # Screenshot is a file, not direct content, but still mark as untrusted source
        result = {"saved": rel, "url": sess.page.url}
        wrapped = wrap_untrusted_content(result, "browser_screenshot", sess.page.url)
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class BrowserExtractTool(Tool):
    name = "browser_extract"
    description = "Extract text from a CSS selector on the current page (all matches)."
    parameters = {"type": "object", "properties": {"selector": {"type": "string"}}, "required": ["selector"]}
    group = "Browser"
    icon = "🧲"

    async def call(self, args, ctx):
        if not playwright_installed():
            return ToolResult(ok=False, error=HELP)
        sess = await get_session(ctx)
        if not sess.page:
            return ToolResult(ok=False, error="no page open")
        try:
            items = await sess.page.eval_on_selector_all(
                args["selector"], "els => els.slice(0,100).map(e => (e.innerText||'').trim().slice(0,500))")
        except Exception as exc:
            return ToolResult(ok=False, error=str(exc))
        
        # Wrap extracted content as untrusted
        result = {"selector": args["selector"], "count": len(items), "items": items}
        wrapped = wrap_untrusted_content(result, "browser_extract", sess.page.url if sess.page else "")
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class BrowserCloseTool(Tool):
    name = "browser_close"
    description = "Close your browser session."
    parameters = {"type": "object", "properties": {}, "required": []}
    group = "Browser"
    icon = "🚪"

    async def call(self, args, ctx):
        sess = SESSIONS.pop(ctx.thread_id, None)
        if sess:
            await sess.close()
        return ToolResult(data={"closed": True})


TOOLS = [BrowserOpenTool(), BrowserSnapshotTool(), BrowserClickTool(), BrowserTypeTool(),
         BrowserKeyTool(), BrowserScrollTool(), BrowserScreenshotTool(), BrowserExtractTool(),
         BrowserCloseTool()]
