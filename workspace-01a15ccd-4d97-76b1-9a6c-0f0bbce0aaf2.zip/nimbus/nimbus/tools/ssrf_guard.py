"""
SSRF (Server-Side Request Forgery) Guard for Nimbus.

This module provides protection against SSRF attacks where a malicious actor
instructs the agent to make requests to internal/protected services.

Threat Model:
- Malicious web page or email instructs agent to:
  a) Call localhost API to approve its own actions
  b) Exfiltrate secrets from internal services
  c) Send email via internal services

Protection:
- Block all loopback addresses (127.0.0.0/8)
- Block link-local addresses (169.254.0.0/16)
- Block RFC1918 private addresses (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
- Block metadata service IPs (common cloud metadata endpoints)
- Handle IPv6 equivalents
- Handle decimal/hex/octal IP representations
- Check after DNS resolution (not just URL parsing)
- Support allowlist override via NIMBUS_SSRF_ALLOWLIST environment variable
"""
from __future__ import annotations

import ipaddress
import os
import re
import socket
from urllib.parse import urlparse


# Common metadata service IPs (AWS, GCP, Azure, etc.)
METADATA_IPS = {
    # AWS
    "169.254.169.254",  # AWS IMDS
    # GCP
    "169.254.169.254",  # GCP Metadata (same IP)
    "metadata.google.internal",
    "metadata",
    # Azure
    "169.254.169.254",  # Azure IMDS (same IP)
    # DigitalOcean
    "169.254.169.254",
    # Oracle Cloud
    "169.254.169.254",
    # Alibaba Cloud
    "100.100.100.200",
    # Huawei Cloud
    "169.254.169.125",
    # Tencent Cloud
    "169.254.0.188",
}

# Additional dangerous IPs
DANGEROUS_IPS = {
    "0.0.0.0",
    "::",
    "::1",
    "localhost",
    "localhost.localdomain",
}

# RFC1918 private networks
PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
]

# Link-local network
LINK_LOCAL_NETWORK = ipaddress.ip_network("169.254.0.0/16")

# Loopback network
LOOPBACK_NETWORK = ipaddress.ip_network("127.0.0.0/8")

# IPv6 loopback
IPV6_LOOPBACK = ipaddress.ip_network("::1/128")

# IPv6 link-local
IPV6_LINK_LOCAL = ipaddress.ip_network("fe80::/10")

# IPv6 unique local addresses (ULA)
IPV6_ULA = ipaddress.ip_network("fc00::/7")


# Load allowlist from environment
_SSRF_ALLOWLIST = set()
_allowlist_loaded = False


def _load_allowlist():
    """Load SSRF allowlist from environment variable."""
    global _SSRF_ALLOWLIST, _allowlist_loaded
    if _allowlist_loaded:
        return
    _allowlist_loaded = True
    allowlist_env = os.environ.get("NIMBUS_SSRF_ALLOWLIST", "").strip()
    if allowlist_env:
        _SSRF_ALLOWLIST = set(host.strip() for host in allowlist_env.split(",") if host.strip())


def is_allowed_by_allowlist(host: str, port: int | None = None) -> bool:
    """Check if host:port is in the allowlist."""
    _load_allowlist()
    if not _SSRF_ALLOWLIST:
        return False
    
    # Check exact match
    if host in _SSRF_ALLOWLIST:
        return True
    
    # Check host:port format
    if port:
        host_port = f"{host}:{port}"
        if host_port in _SSRF_ALLOWLIST:
            return True
    
    return False


def is_metadata_ip(host: str) -> bool:
    """Check if host is a known metadata service IP."""
    return host.lower() in {ip.lower() for ip in METADATA_IPS}


def is_dangerous_hostname(host: str) -> bool:
    """Check if hostname is dangerous (localhost, etc.)."""
    return host.lower() in {h.lower() for h in DANGEROUS_IPS}


def resolve_ipv4(ip_str: str) -> list[str]:
    """Resolve various IPv4 formats to standard dotted-decimal.
    
    Handles:
    - Standard dotted-decimal (127.0.0.1)
    - Decimal integer (2130706433 = 127.0.0.1)
    - Hex with 0x prefix (0x7f000001 = 127.0.0.1)
    - Octal with leading 0 (017700000001 = 127.0.0.1)
    - Dotted hex (0x7f.0x0.0x0.0x1)
    """
    ip_str = ip_str.strip()
    
    # Already standard dotted-decimal format
    if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', ip_str):
        return [ip_str]
    
    # Try decimal format (integer representation)
    try:
        num = int(ip_str)
        if 0 <= num <= 0xFFFFFFFF:
            return [socket.inet_ntoa(num.to_bytes(4, 'big'))]
    except (ValueError, OverflowError):
        pass
    
    # Try hex format (0x prefix)
    if ip_str.startswith('0x') or ip_str.startswith('\\x'):
        try:
            num = int(ip_str, 16)
            if 0 <= num <= 0xFFFFFFFF:
                return [socket.inet_ntoa(num.to_bytes(4, 'big'))]
        except (ValueError, OverflowError):
            pass
    
    # Try octal format (leading 0)
    if ip_str.startswith('0') and len(ip_str) > 1:
        try:
            num = int(ip_str, 8)
            if 0 <= num <= 0xFFFFFFFF:
                return [socket.inet_ntoa(num.to_bytes(4, 'big'))]
        except (ValueError, OverflowError):
            pass
    
    # Try dotted hex format (0x7f.0x0.0x0.0x1)
    parts = ip_str.split('.')
    if len(parts) == 4 and all(p.startswith('0x') or p.startswith('\\x') or p.isdigit() for p in parts):
        try:
            bytes_val = bytes(int(p, 16) if p.startswith('0x') or p.startswith('\\x') else int(p) for p in parts)
            return [socket.inet_ntoa(bytes_val)]
        except (ValueError, OverflowError):
            pass
    
    # Can't decode, return empty list (will trigger safe behavior)
    return []


def resolve_ipv6(ip_str: str) -> list[str]:
    """Resolve various IPv6 formats to standard format.
    
    Handles:
    - Standard IPv6 (::1, fe80::1, etc.)
    - Hex without colons/colons compressed
    """
    ip_str = ip_str.strip()
    
    # Already standard format
    try:
        ipaddress.IPv6Address(ip_str)
        return [ip_str]
    except ipaddress.AddressValueError:
        pass
    
    # Hex without colons (e.g., 00000000000000000000000001000000 = ::1)
    if re.match(r'^[0-9a-fA-F]+$', ip_str):
        try:
            # Pad to 32 hex chars (128 bits)
            padded = ip_str.zfill(32)
            # Convert to IPv6 format
            ip = ipaddress.IPv6Address(int(padded, 16))
            return [str(ip)]
        except (ValueError, OverflowError):
            pass
    
    # Can't decode, return empty list (will trigger safe behavior)
    return []


def is_private_ip(ip: str) -> bool:
    """Check if an IP address is in a private/protected range."""
    ip = ip.strip()
    
    # Try IPv4
    try:
        ip_obj = ipaddress.IPv4Address(ip)
        for network in PRIVATE_NETWORKS + [LINK_LOCAL_NETWORK, LOOPBACK_NETWORK]:
            if ip_obj in network:
                return True
        return False
    except ipaddress.AddressValueError:
        pass
    
    # Try IPv6
    try:
        ip_obj = ipaddress.IPv6Address(ip)
        for network in [IPV6_LOOPBACK, IPV6_LINK_LOCAL, IPV6_ULA]:
            if ip_obj in network:
                return True
        return False
    except ipaddress.AddressValueError:
        pass
    
    return False


def is_loopback_ip(ip: str) -> bool:
    """Check if an IP is loopback."""
    ip = ip.strip()
    
    try:
        ip_obj = ipaddress.IPv4Address(ip)
        return ip_obj in LOOPBACK_NETWORK
    except ipaddress.AddressValueError:
        pass
    
    try:
        ip_obj = ipaddress.IPv6Address(ip)
        return ip_obj in IPV6_LOOPBACK
    except ipaddress.AddressValueError:
        pass
    
    return False


def resolve_hostname(host: str) -> list[str]:
    """Resolve hostname to IP addresses, handling various formats.
    
    For IP addresses in various formats (decimal, hex, octal), resolves to standard
    dotted-decimal or colon-hex format. For hostnames, performs DNS resolution.
    """
    host = host.strip()
    
    # Handle port if present - be careful with IPv6 addresses
    # IPv6 addresses have multiple colons, so we need to check if this looks like
    # an IPv6 address before splitting on colon
    if ':' in host:
        # Check if it looks like an IPv6 address (multiple colons or starts with [)
        if host.startswith('[') or host.count(':') > 1:
            # It's an IPv6 address, don't split on colon
            host_only = host
            port = None
        else:
            # It's likely a hostname:port or IPv4:port
            host_only, port = host.rsplit(':', 1)
    else:
        host_only = host
        port = None
    
    # Check if it looks like an IP address (contains only digits, dots, colons, hex chars)
    # This is a heuristic to decide whether to try IP parsing first
    is_possible_ip = bool(re.match(r'^[0-9a-fA-F.:x]+$', host_only))
    
    # Try to parse as IP address first
    if is_possible_ip:
        try:
            ipaddress.ip_address(host_only)
            # It's a valid IP address, return it as-is
            return [host_only]
        except (ipaddress.AddressValueError, ValueError):
            # Might be encoded format (decimal, hex, octal)
            pass
        
        # Try to decode from various formats
        try:
            if ':' in host_only:
                decoded = resolve_ipv6(host_only)
                if decoded:
                    return decoded
            else:
                decoded = resolve_ipv4(host_only)
                if decoded:
                    return decoded
        except (ValueError, OverflowError):
            pass
    
    # It's a hostname or unparseable, try DNS resolution
    try:
        # Get all address info
        addr_info = socket.getaddrinfo(host_only, port or 80, proto=socket.IPPROTO_TCP)
        
        # Extract unique IPs
        ips = set()
        for info in addr_info:
            ip = info[4][0]  # (family, type, proto, canonname, sockaddr)
            ips.add(ip)
        
        return list(ips)
    except (socket.gaierror, socket.herror, OSError, ValueError):
        # If DNS resolution fails, we can't verify, so be safe
        return []


def check_ssrf(url: str, allow_redirects: bool = True) -> tuple[bool, str]:
    """
    Check if a URL would cause an SSRF vulnerability.
    
    Args:
        url: The URL to check
        allow_redirects: Whether to allow redirects (not implemented yet)
    
    Returns:
        tuple: (is_safe, reason_if_blocked)
    """
    _load_allowlist()
    
    # Parse URL
    try:
        parsed = urlparse(url)
        host = parsed.hostname
        port = parsed.port
    except Exception as e:
        return False, f"Invalid URL: {e}"
    
    if not host:
        return False, "No hostname in URL"
    
    # Check allowlist first
    if is_allowed_by_allowlist(host, port):
        return True, "Allowed by SSRF allowlist"
    
    # Check for dangerous hostnames
    if is_dangerous_hostname(host):
        return False, f"Blocked hostname: {host}"
    
    # Check for metadata IPs
    if is_metadata_ip(host):
        return False, f"Blocked metadata IP: {host}"
    
    # Resolve hostname to IPs
    resolved_ips = resolve_hostname(host)
    
    if not resolved_ips:
        # Couldn't resolve, be safe
        return False, f"Could not resolve hostname: {host}"
    
    # Check each resolved IP
    for ip in resolved_ips:
        if is_loopback_ip(ip):
            return False, f"Blocked loopback IP: {ip} (from {host})"
        if is_private_ip(ip):
            return False, f"Blocked private IP: {ip} (from {host})"
        if is_metadata_ip(ip):
            return False, f"Blocked metadata IP: {ip} (from {host})"
    
    return True, "Safe"


class SSRFError(Exception):
    """Raised when an SSRF attempt is detected."""
    pass


def guard_ssrf(url: str, context: str = "") -> str:
    """
    Guard against SSRF attacks.
    
    Args:
        url: The URL to check
        context: Optional context for error messages
    
    Returns:
        The URL if safe
    
    Raises:
        SSRFError: If the URL is blocked
    """
    is_safe, reason = check_ssrf(url)
    if not is_safe:
        raise SSRFError(f"SSRF blocked: {reason} {context}".strip())
    return url
