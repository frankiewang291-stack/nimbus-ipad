"""Tool registry for Nimbus agents."""
from __future__ import annotations

from .base import Tool, ToolResult, ToolContext  # noqa: F401
from . import workspace as _workspace
from . import web as _web
from . import browser as _browser
from . import google as _google
from . import memory as _memory
from . import skills as _skills
from . import delegation as _delegation

REGISTRY: dict[str, Tool] = {}


def register(tool: Tool) -> Tool:
    REGISTRY[tool.name] = tool
    return tool


def _bootstrap() -> None:
    if REGISTRY:
        return
    for mod in (_workspace, _web, _browser, _google, _memory, _skills, _delegation):
        for item in mod.TOOLS:
            register(item)


def get_tool(name: str) -> Tool | None:
    _bootstrap()
    return REGISTRY.get(name)


def all_tool_names() -> list[str]:
    _bootstrap()
    return list(REGISTRY.keys())


def schemas(names: list[str] | None = None, ctx: "ToolContext | None" = None) -> list[dict]:
    """JSON-schema tool definitions for the model, filtered by agent config."""
    _bootstrap()
    out = []
    for name, tool in REGISTRY.items():
        if names is not None and name not in names:
            continue
        if ctx is not None and not tool.available(ctx):
            continue
        out.append({"name": tool.name, "description": tool.description, "parameters": tool.parameters})
    return out


def grouped() -> list[dict]:
    """Tool metadata grouped by category for the UI."""
    _bootstrap()
    groups: dict[str, list[dict]] = {}
    for tool in REGISTRY.values():
        groups.setdefault(tool.group, []).append({
            "name": tool.name, "description": tool.description,
            "risk": tool.risk, "icon": tool.icon,
        })
    return [{"group": g, "tools": sorted(t, key=lambda x: x["name"])} for g, t in sorted(groups.items())]


# populate the registry on import so anything importing nimbus.tools sees every tool
_bootstrap()
