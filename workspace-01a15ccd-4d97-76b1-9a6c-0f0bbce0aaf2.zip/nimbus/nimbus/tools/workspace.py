"""Workspace tools: the agent's own jailed cloud-computer filesystem + shell."""
from __future__ import annotations

import asyncio
import fnmatch
import os
import shutil
import time
from pathlib import Path

import httpx

from ..config import settings
from ..store import rel_in_workspace, resolve_in_workspace, workspace_path
from .base import FunctionTool, Tool, ToolContext, ToolResult
from .ssrf_guard import SSRFError, guard_ssrf
from .untrusted import is_untrusted_source, mark_thread_tainted, requires_approval_due_to_taint, wrap_untrusted_content
from .command_runner import CommandRunner, get_runner

TEXT_EXT = {".txt", ".md", ".markdown", ".json", ".yaml", ".yml", ".csv", ".tsv", ".py", ".js",
            ".ts", ".tsx", ".jsx", ".html", ".htm", ".css", ".xml", ".sh", ".bash", ".sql", ".toml",
            ".ini", ".cfg", ".log", ".env", ".rst", ".tex", ".r", ".java", ".go", ".rs", ".c", ".h",
            ".cpp", ".rb", ".php", ".swift", ".kt", ".ipynb"}


class ListFilesTool(Tool):
    name = "list_files"
    description = "List files and folders inside your workspace. Use path='' for the root."
    parameters = {"type": "object", "properties": {
        "path": {"type": "string", "description": "Relative folder path, '' for root"}},
        "required": []}
    group = "Workspace"
    icon = "📁"

    async def call(self, args, ctx):
        from ..store import workspace_listing
        path = args.get("path", "")
        items = workspace_listing(ctx.agent_id, path)
        return ToolResult(data={"path": path or "/", "count": len(items), "items": items})


class ReadFileTool(Tool):
    name = "read_file"
    description = "Read a text file from your workspace. Returns its contents."
    parameters = {"type": "object", "properties": {
        "path": {"type": "string"}, "offset": {"type": "integer", "description": "start line (1-based)"},
        "limit": {"type": "integer", "description": "max lines"}}, "required": ["path"]}
    group = "Workspace"
    icon = "📄"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        if not p.exists() or not p.is_file():
            return ToolResult(ok=False, error=f"no such file: {args['path']}")
        size = p.stat().st_size
        if size > 8_000_000:
            return ToolResult(ok=False, error=(
                f"file too large for the model to read whole ({size:,} bytes) — use search_files to find "
                f"the interesting parts, or read_file with offset/limit to page through it"))
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            return ToolResult(ok=False, error=str(exc))
        lines = text.splitlines()
        off = max(1, int(args.get("offset") or 1))
        lim = int(args.get("limit") or 0)
        chunk = lines[off - 1: off - 1 + lim] if lim else lines[off - 1:]
        body = "\n".join(chunk)
        return ToolResult(data={"path": args["path"], "lines": len(lines), "shown_from": off,
                                "content": body[:180000]})


class WriteFileTool(Tool):
    name = "write_file"
    description = "Create or overwrite a text file in your workspace (parent folders are created)."
    parameters = {"type": "object", "properties": {
        "path": {"type": "string"}, "content": {"type": "string"},
        "mode": {"type": "string", "enum": ["overwrite", "append"]}}, "required": ["path", "content"]}
    group = "Workspace"
    icon = "✍️"
    risk = "medium"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        p.parent.mkdir(parents=True, exist_ok=True)
        mode = args.get("mode", "overwrite")
        with open(p, "a" if mode == "append" else "w", encoding="utf-8") as fh:
            fh.write(args.get("content", ""))
        return ToolResult(data={"path": args["path"], "mode": mode, "bytes": p.stat().st_size})


class EditFileTool(Tool):
    name = "edit_file"
    description = "Replace exact text inside a file. Use for surgical edits instead of rewriting whole files."
    parameters = {"type": "object", "properties": {
        "path": {"type": "string"}, "find": {"type": "string"}, "replace": {"type": "string"},
        "count": {"type": "integer", "description": "max replacements (default 1)"}},
        "required": ["path", "find", "replace"]}
    group = "Workspace"
    icon = "🩹"
    risk = "medium"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        if not p.is_file():
            return ToolResult(ok=False, error=f"no such file: {args['path']}")
        text = p.read_text(encoding="utf-8", errors="replace")
        find = args["find"]
        if find not in text:
            return ToolResult(ok=False, error="`find` text not found in file")
        n = int(args.get("count") or 1)
        new = text.replace(find, args.get("replace", ""), n)
        p.write_text(new, encoding="utf-8")
        return ToolResult(data={"path": args["path"], "replacements": text.count(find) if n == 0 else min(n, text.count(find))})


class DeleteFileTool(Tool):
    name = "delete_file"
    description = "Delete a file or folder inside your workspace."
    parameters = {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
    group = "Workspace"
    icon = "🗑️"
    risk = "high"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        if not p.exists():
            return ToolResult(ok=False, error=f"nothing at {args['path']}")
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return ToolResult(data={"deleted": args["path"]})


class MakeDirTool(Tool):
    name = "make_dir"
    description = "Create a folder in your workspace."
    parameters = {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}
    group = "Workspace"
    icon = "📂"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        p.mkdir(parents=True, exist_ok=True)
        return ToolResult(data={"created": args["path"]})


class MoveFileTool(Tool):
    name = "move_file"
    description = "Move or rename a file or folder inside your workspace."
    parameters = {"type": "object", "properties": {"src": {"type": "string"}, "dst": {"type": "string"}},
                  "required": ["src", "dst"]}
    group = "Workspace"
    icon = "🔀"

    async def call(self, args, ctx):
        s = resolve_in_workspace(ctx.agent_id, args["src"])
        d = resolve_in_workspace(ctx.agent_id, args["dst"])
        if not s.exists():
            return ToolResult(ok=False, error=f"nothing at {args['src']}")
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return ToolResult(data={"moved": f"{args['src']} -> {args['dst']}"})


class SearchFilesTool(Tool):
    name = "search_files"
    description = "Search file contents in your workspace (grep-style, case-insensitive)."
    parameters = {"type": "object", "properties": {
        "query": {"type": "string"}, "glob": {"type": "string", "description": "e.g. **/*.py"}},
        "required": ["query"]}
    group = "Workspace"
    icon = "🔎"

    async def call(self, args, ctx):
        root = workspace_path(ctx.agent_id)
        pattern = args.get("glob") or "**/*"
        q = (args.get("query") or "").lower()
        hits = []
        for p in root.rglob("*"):
            if not p.is_file() or not fnmatch.fnmatch(str(p.relative_to(root)), pattern):
                continue
            if p.suffix.lower() not in TEXT_EXT and p.stat().st_size > 200_000:
                continue
            try:
                for i, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                    if q in line.lower():
                        hits.append({"file": rel_in_workspace(ctx.agent_id, p), "line": i, "text": line.strip()[:240]})
                        if len(hits) >= 100:
                            raise StopIteration
            except StopIteration:
                break
            except Exception:
                continue
        return ToolResult(data={"query": args["query"], "matches": hits, "count": len(hits)})


class DownloadFileTool(Tool):
    name = "download_file"
    description = "Download a file from a URL into your workspace."
    parameters = {"type": "object", "properties": {"url": {"type": "string"}, "path": {"type": "string"}},
                  "required": ["url"]}
    group = "Workspace"
    icon = "⬇️"
    risk = "medium"

    async def call(self, args, ctx):
        url = args["url"]
        
        # SSRF Guard: Block requests to internal/private networks
        try:
            guard_ssrf(url, f" (download_file called from thread {ctx.thread_id})")
        except SSRFError as e:
            return ToolResult(ok=False, error=str(e))
        
        name = args.get("path") or os.path.basename(url.split("?")[0]) or "download.bin"
        target = resolve_in_workspace(ctx.agent_id, name)
        target.parent.mkdir(parents=True, exist_ok=True)
        limit = settings.max_download_mb * 1024 * 1024
        total = 0
        async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=180), follow_redirects=True) as client:
            async with client.stream("GET", url) as resp:
                if resp.status_code >= 400:
                    return ToolResult(ok=False, error=f"HTTP {resp.status_code} fetching {url}")
                declared = int(resp.headers.get("content-length") or 0)
                if declared and declared > limit:
                    return ToolResult(ok=False, error=(
                        f"that file is {declared // (1024 * 1024)} MB — over the {settings.max_download_mb} MB "
                        f"download limit (NIMBUS_MAX_DOWNLOAD_MB). Download it yourself, or raise the limit."))
                with open(target, "wb") as fh:
                    async for chunk in resp.aiter_bytes(65536):
                        total += len(chunk)
                        if total > limit:
                            fh.close()
                            target.unlink(missing_ok=True)
                            return ToolResult(ok=False, error=(
                                f"download stopped at the {settings.max_download_mb} MB limit "
                                f"(NIMBUS_MAX_DOWNLOAD_MB) — nothing was saved"))
                        fh.write(chunk)
        
        # Mark downloaded content as untrusted
        result = {"path": rel_in_workspace(ctx.agent_id, target), "bytes": total, "url": url}
        wrapped = wrap_untrusted_content(result, "download_file", url)
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


class RunCommandTool(Tool):
    name = "run_command"
    description = ("Run a shell command inside your workspace sandbox (cwd = your workspace). "
                   "Returns stdout/stderr and exit code. Uses isolated execution with resource limits.")
    parameters = {"type": "object", "properties": {
        "command": {"type": "string"}, 
        "timeout": {"type": "integer", "description": "seconds, default 60"},
        "tier": {"type": "string", "enum": ["tier1", "tier2"], 
                 "description": "Isolation tier: tier1 (native), tier2 (Docker). Default: tier1"}
    }, "required": ["command"]}
    group = "Workspace"
    icon = "🖥️"
    risk = "medium"  # destructive commands escalate to an approval request

    def available(self, ctx):
        return settings.allow_shell

    async def call(self, args, ctx):
        cmd = (args.get("command") or "").strip()
        if not cmd:
            return ToolResult(ok=False, error="empty command")
        
        # Get isolation tier (default to tier1)
        tier = args.get("tier", "tier1")
        timeout = min(int(args.get("timeout") or 60), 300)
        cwd = workspace_path(ctx.agent_id)
        
        # Create the runner
        runner = get_runner(tier, cwd, timeout)
        
        # Run the command
        result = await runner.run(cmd)
        
        # Check if the command was blocked by the runner
        # If stderr contains "not allowed" or "requires approval", return ok=False
        if result.get("stderr") and ("not allowed" in result["stderr"].lower() or 
                                        "requires approval" in result["stderr"].lower()):
            return ToolResult(ok=False, error=result["stderr"])
        
        # Check if we need approval for destructive commands
        # This is handled by the approvals system, not here
        
        return ToolResult(data={
            "command": result["command"],
            "exit_code": result["exit_code"], 
            "duration_s": result["duration_s"],
            "stdout": result["stdout"],
            "stderr": result["stderr"],
            "timed_out": result.get("timed_out", False),
            "killed": result.get("killed", False),
            "tier": tier
        })


class WorkspaceInfoTool(Tool):
    name = "workspace_info"
    description = "Show your workspace path, file count and total size."
    parameters = {"type": "object", "properties": {}}
    group = "Workspace"
    icon = "ℹ️"

    async def call(self, args, ctx):
        from ..store import workspace_stats
        st = workspace_stats(ctx.agent_id)
        return ToolResult(data={"workspace": str(workspace_path(ctx.agent_id)), **st,
                                "shell_enabled": settings.allow_shell,
                                "shell_network": settings.allow_shell_network})


TOOLS = [ListFilesTool(), ReadFileTool(), WriteFileTool(), EditFileTool(), DeleteFileTool(),
         MakeDirTool(), MoveFileTool(), SearchFilesTool(), DownloadFileTool(), RunCommandTool(),
         WorkspaceInfoTool()]
