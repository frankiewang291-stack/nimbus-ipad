"""Skills + Routines tools (learned procedures and scheduled/triggered work)."""
from __future__ import annotations

import json
import time

from .. import db
from .base import Tool, ToolResult


def _skill_dict(row: dict) -> dict:
    row = dict(row)
    row["inputs"] = db.json_load(row.get("inputs"), [])
    return row


class ListSkillsTool(Tool):
    name = "list_skills"
    description = "List the reusable skills available to you (name, description, required inputs)."
    parameters = {"type": "object", "properties": {"query": {"type": "string"}}, "required": []}
    group = "Skills"
    icon = "📚"

    async def call(self, args, ctx):
        sql = "SELECT * FROM skills WHERE agent_id=? OR agent_id IS NULL OR agent_id=''"
        params = [ctx.agent_id]
        rows = [_skill_dict(r) for r in db.q(sql + " ORDER BY updated_at DESC", params)]
        q = (args.get("query") or "").lower()
        if q:
            rows = [r for r in rows if q in r["name"].lower() or q in (r.get("description") or "").lower()]
        return ToolResult(data={"count": len(rows), "skills": [
            {"id": r["id"], "name": r["name"], "description": r["description"],
             "inputs": r["inputs"], "runs": r["runs"]} for r in rows]})


class ReadSkillTool(Tool):
    name = "read_skill"
    description = "Load a skill's full instructions, then follow them to complete the task."
    parameters = {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
    group = "Skills"
    icon = "📖"

    async def call(self, args, ctx):
        row = db.q1("SELECT * FROM skills WHERE lower(name)=lower(?) OR id=?", (args["name"], args["name"]))
        if not row:
            fuzzy = db.q("SELECT * FROM skills WHERE name LIKE ?", (f"%{args['name']}%",))
            row = fuzzy[0] if fuzzy else None
        if not row:
            return ToolResult(ok=False, error=f"no skill named {args['name']!r}")
        row = _skill_dict(row)
        return ToolResult(data={"name": row["name"], "description": row["description"],
                                "instructions": row["instructions"],
                                "output_format": row.get("output_format", ""), "inputs": row["inputs"]})


class CreateSkillTool(Tool):
    name = "create_skill"
    description = ("Save a reusable procedure as a skill so it can be replayed later "
                   "(optionally from a routine). Write steps as clear instructions.")
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "description": {"type": "string"},
        "instructions": {"type": "string", "description": "step-by-step procedure"},
        "inputs": {"type": "array", "items": {"type": "string"}, "description": "required inputs"},
        "output_format": {"type": "string"}}, "required": ["name", "instructions"]}
    group = "Skills"
    icon = "🛠️"

    async def call(self, args, ctx):
        sid = db.insert("skills", {
            "id": db.new_id(), "agent_id": ctx.agent_id, "name": args["name"][:120],
            "description": args.get("description", "")[:500], "instructions": args.get("instructions", ""),
            "inputs": json.dumps(args.get("inputs") or []), "output_format": args.get("output_format", ""),
            "source": "agent", "runs": 0, "created_at": db.now(), "updated_at": db.now(),
        })
        db.audit(ctx.agent_id, ctx.thread_id, "skill.create", {"name": args["name"]})
        return ToolResult(data={"created": args["name"], "id": sid})


class UpdateSkillTool(Tool):
    name = "update_skill"
    description = ("Refine a skill's instructions after a run — fix steps that were unclear or wrong. "
                   "Agents use this to get better over time.")
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "instructions": {"type": "string"},
        "description": {"type": "string"}, "change_note": {"type": "string"}},
        "required": ["name", "instructions"]}
    group = "Skills"
    icon = "🔧"

    async def call(self, args, ctx):
        row = db.q1("SELECT * FROM skills WHERE lower(name)=lower(?)", (args["name"],))
        if not row:
            return ToolResult(ok=False, error=f"no skill named {args['name']!r}")
        db.x("UPDATE skills SET instructions=?, description=COALESCE(NULLIF(?,''), description), updated_at=? WHERE id=?",
             (args["instructions"], args.get("description", ""), db.now(), row["id"]))
        db.audit(ctx.agent_id, ctx.thread_id, "skill.update",
                 {"name": args["name"], "note": args.get("change_note", "")})
        return ToolResult(data={"updated": args["name"]})


class DeleteSkillTool(Tool):
    name = "delete_skill"
    description = "Delete a skill."
    parameters = {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
    group = "Skills"
    icon = "🗑️"
    risk = "medium"

    async def call(self, args, ctx):
        row = db.q1("SELECT * FROM skills WHERE lower(name)=lower(?) OR id=?", (args["name"], args["name"]))
        if not row:
            return ToolResult(ok=False, error="skill not found")
        db.x("DELETE FROM skills WHERE id=?", (row["id"],))
        return ToolResult(data={"deleted": row["name"]})


class ListRoutinesTool(Tool):
    name = "list_routines"
    description = "List scheduled/triggered routines for you and the rest of the team."
    parameters = {"type": "object", "properties": {"all_agents": {"type": "boolean"}}, "required": []}
    group = "Routines"
    icon = "⏰"

    async def call(self, args, ctx):
        if args.get("all_agents"):
            rows = db.q("SELECT r.*, a.name AS agent_name FROM routines r LEFT JOIN agents a ON a.id=r.agent_id "
                        "ORDER BY r.created_at DESC")
        else:
            rows = db.q("SELECT r.*, a.name AS agent_name FROM routines r LEFT JOIN agents a ON a.id=r.agent_id "
                        "WHERE r.agent_id=? ORDER BY r.created_at DESC", (ctx.agent_id,))
        return ToolResult(data={"count": len(rows), "routines": [
            {"id": r["id"], "name": r["name"], "agent": r.get("agent_name"), "kind": r["kind"],
             "schedule": r["schedule"], "event_filter": r["event_filter"], "enabled": bool(r["enabled"]),
             "next_run_at": r["next_run_at"], "run_count": r["run_count"]} for r in rows]})


class CreateRoutineTool(Tool):
    name = "create_routine"
    description = ("Schedule recurring work. kind='cron' with a cron expression (e.g. '0 8 * * *' = daily 08:00), "
                   "kind='interval' with schedule in seconds, or kind='event' with event_filter matching "
                   "thread.message / file.upload / manual.")
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "prompt": {"type": "string", "description": "what to do each run"},
        "kind": {"type": "string", "enum": ["cron", "interval", "event"]},
        "schedule": {"type": "string"}, "event_filter": {"type": "string"},
        "skill_name": {"type": "string"}, "enabled": {"type": "boolean"}},
        "required": ["name", "prompt"]}
    group = "Routines"
    icon = "🗓️"
    risk = "medium"

    async def call(self, args, ctx):
        from ..scheduler import compute_next_run
        kind = args.get("kind", "cron")
        schedule = (args.get("schedule") or "0 9 * * *").strip()
        skill_id = ""
        if args.get("skill_name"):
            s = db.q1("SELECT id FROM skills WHERE lower(name)=lower(?)", (args["skill_name"],))
            skill_id = s["id"] if s else ""
        rid = db.insert("routines", {
            "id": db.new_id(), "agent_id": ctx.agent_id, "name": args["name"][:120], "kind": kind,
            "schedule": schedule, "event_filter": args.get("event_filter", ""), "prompt": args["prompt"],
            "skill_id": skill_id, "enabled": 1 if args.get("enabled", True) else 0,
            "last_run_at": None, "next_run_at": compute_next_run(kind, schedule, None),
            "run_count": 0, "created_at": db.now(),
        })
        db.audit(ctx.agent_id, ctx.thread_id, "routine.create",
                 {"name": args["name"], "kind": kind, "schedule": schedule})
        return ToolResult(data={"created": args["name"], "id": rid, "kind": kind, "schedule": schedule})


class DeleteRoutineTool(Tool):
    name = "delete_routine"
    description = "Delete a routine by name or id."
    parameters = {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}
    group = "Routines"
    icon = "🗑️"
    risk = "medium"

    async def call(self, args, ctx):
        row = db.q1("SELECT * FROM routines WHERE id=? OR lower(name)=lower(?)", (args["name"], args["name"]))
        if not row:
            return ToolResult(ok=False, error="routine not found")
        db.x("DELETE FROM routines WHERE id=?", (row["id"],))
        return ToolResult(data={"deleted": row["name"]})


class EmitEventTool(Tool):
    name = "emit_event"
    description = "Fire a custom event that event-triggered routines can react to."
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "payload": {"type": "object"}}, "required": ["name"]}
    group = "Routines"
    icon = "📡"
    risk = "medium"

    async def call(self, args, ctx):
        from ..scheduler import emit_event
        await emit_event(f"custom.{args['name']}", args.get("payload") or {}, source_agent=ctx.agent_id)
        return ToolResult(data={"emitted": args["name"]})


# ---- tiny helper so the model can ask for a skill to be executed by name ----
class RunSkillTool(Tool):
    name = "run_skill"
    description = ("Load a skill and execute it now with the given inputs. The skill's instructions are "
                   "returned to you — follow them exactly, then report the result.")
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "inputs": {"type": "object"}}, "required": ["name"]}
    group = "Skills"
    icon = "▶️"

    async def call(self, args, ctx):
        row = db.q1("SELECT * FROM skills WHERE lower(name)=lower(?) OR id=?", (args["name"], args["name"]))
        if not row:
            return ToolResult(ok=False, error=f"no skill named {args['name']!r}")
        db.x("UPDATE skills SET runs=runs+1, updated_at=? WHERE id=?", (db.now(), row["id"]))
        row = _skill_dict(row)
        return ToolResult(data={
            "skill": row["name"], "instructions": row["instructions"],
            "output_format": row.get("output_format", ""), "inputs": args.get("inputs") or {},
            "note": "Execute these instructions now and produce the output in the required format.",
        })


TOOLS = [ListSkillsTool(), ReadSkillTool(), CreateSkillTool(), UpdateSkillTool(), DeleteSkillTool(),
         RunSkillTool(), ListRoutinesTool(), CreateRoutineTool(), DeleteRoutineTool(), EmitEventTool()]
