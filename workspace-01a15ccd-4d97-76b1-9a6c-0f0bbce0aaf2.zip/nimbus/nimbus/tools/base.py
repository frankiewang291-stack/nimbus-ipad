"""Tool base classes shared by every Nimbus tool module."""
from __future__ import annotations

import asyncio
import inspect
import json
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable


@dataclass
class ToolResult:
    ok: bool = True
    data: Any = None
    display: str = ""
    error: str = ""
    risk: str | None = None

    def to_model(self) -> str:
        if not self.ok:
            return json.dumps({"error": self.error or "tool failed"}, ensure_ascii=False)[:20000]
        if isinstance(self.data, str):
            return self.data[:20000]
        try:
            return json.dumps(self.data, ensure_ascii=False, default=str)[:20000]
        except Exception:
            return str(self.data)[:20000]


@dataclass
class ToolContext:
    """Everything a tool may need to act on behalf of an agent."""
    agent: dict
    thread_id: str = ""
    workspace: Any = None          # pathlib.Path
    event_sink: Callable[[dict], Awaitable[None]] | None = None
    services: dict = field(default_factory=dict)

    @property
    def agent_id(self) -> str:
        return self.agent.get("id", "")

    async def emit(self, event: dict) -> None:
        if self.event_sink:
            try:
                await self.event_sink(event)
            except Exception:
                pass


class Tool:
    name: str = "tool"
    description: str = ""
    parameters: dict = {"type": "object", "properties": {}}
    risk: str = "low"                 # low | medium | high
    group: str = "General"
    icon: str = "🔧"
    run_in_executor: bool = False

    def available(self, ctx: ToolContext) -> bool:  # noqa: ARG002
        return True

    async def call(self, args: dict, ctx: ToolContext) -> ToolResult:  # pragma: no cover
        raise NotImplementedError

    async def run(self, args: dict, ctx: ToolContext) -> ToolResult:
        try:
            if self.run_in_executor:
                return await asyncio.to_thread(lambda: asyncio.run(self.call(args, ctx)))
            result = self.call(args, ctx)
            if inspect.isawaitable(result):
                return await result
            return result  # type: ignore[return-value]
        except Exception as exc:  # never let a tool crash the agent loop
            return ToolResult(ok=False, error=f"{type(exc).__name__}: {exc}")


class FunctionTool(Tool):
    """Adapter so tools can be written as plain functions."""

    def __init__(self, name: str, description: str, parameters: dict, func: Callable[[dict, ToolContext], Any],
                 risk: str = "low", group: str = "General", icon: str = "🔧",
                 available_fn: Callable[[ToolContext], bool] | None = None):
        self.name = name
        self.description = description
        self.parameters = parameters
        self.risk = risk
        self.group = group
        self.icon = icon
        self._func = func
        self._available_fn = available_fn

    def available(self, ctx: ToolContext) -> bool:
        return self._available_fn(ctx) if self._available_fn else True

    async def call(self, args: dict, ctx: ToolContext) -> ToolResult:
        result = self._func(args or {}, ctx)
        if inspect.isawaitable(result):
            result = await result
        if isinstance(result, ToolResult):
            return result
        return ToolResult(ok=True, data=result)
