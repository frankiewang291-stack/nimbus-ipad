"""Agent-to-agent tools: roster discovery, delegation, and spawning new teammates."""
from __future__ import annotations

import json

from .. import db
from ..store import (create_agent, create_thread, get_agent, get_thread, list_agents,
                     update_thread, workspace_stats)
from .base import Tool, ToolResult


class ListTeamTool(Tool):
    name = "list_team"
    description = ("List every agent on the account with their title, description, model and skills. "
                   "Use this to decide who to delegate to.")
    parameters = {"type": "object", "properties": {}, "required": []}
    group = "Team"
    icon = "👥"

    async def call(self, args, ctx):
        agents = []
        for a in list_agents():
            skills = db.q("SELECT name, description FROM skills WHERE agent_id=?", (a["id"],))
            agents.append({
                "id": a["id"], "name": a["name"], "title": a["title"], "description": a["description"],
                "provider": a["provider"], "model": a["model"], "is_you": a["id"] == ctx.agent_id,
                "can_delegate": a["can_delegate"], "skills": [s["name"] for s in skills],
                "status": a["status"],
            })
        return ToolResult(data={"count": len(agents), "agents": agents})


class DelegateTool(Tool):
    name = "delegate_task"
    description = ("Hand a self-contained task to another agent on the team and get their finished result back. "
                   "Include everything they need — they can't see this conversation.")
    parameters = {"type": "object", "properties": {
        "agent_name": {"type": "string"},
        "task": {"type": "string", "description": "full, self-contained instructions"},
        "context": {"type": "string", "description": "optional background they need"}},
        "required": ["agent_name", "task"]}
    group = "Team"
    icon = "🤝"
    risk = "medium"

    def available(self, ctx):
        return bool(ctx.agent.get("can_delegate"))

    async def call(self, args, ctx):
        from ..agent import run_agent  # local import avoids a cycle

        target_name = (args.get("agent_name") or "").strip()
        row = db.q1("SELECT * FROM agents WHERE lower(name)=lower(?)", (target_name,))
        if not row:
            near = db.q("SELECT name FROM agents WHERE name LIKE ? LIMIT 5", (f"%{target_name}%",))
            hint = ", ".join(n["name"] for n in near) or "use list_team to see the roster"
            return ToolResult(ok=False, error=f"no agent named {target_name!r} — {hint}")
        target = get_agent(row["id"])
        assert target
        if target["id"] == ctx.agent_id:
            return ToolResult(ok=False, error="you cannot delegate to yourself")

        brief = args["task"]
        if args.get("context"):
            brief = f"{brief}\n\n--- Context provided by {ctx.agent['name']} ---\n{args['context']}"

        # child thread is linked to the parent so the UI can show the handoff tree
        child = create_thread(target["id"], title=f"↳ {args['task'][:60]}", kind="delegation",
                              parent_thread_id=ctx.thread_id)
        update_thread(child["id"], {"meta": {"delegated_by": ctx.agent["name"], "brief": brief[:2000]}})
        await ctx.emit({"type": "delegation_start", "target": target["name"], "thread_id": child["id"],
                        "task": brief[:500], "agent_id": target["id"]})

        try:
            answer = await run_agent(target, brief, thread_id=child["id"], max_turns=8)
        except Exception as exc:
            return ToolResult(ok=False, error=f"{target['name']} failed: {exc}")
        answer = (answer or "").strip() or "(no output)"
        db.audit(ctx.agent_id, ctx.thread_id, "delegation",
                 {"to": target["name"], "thread_id": child["id"], "chars": len(answer)}, risk="medium")
        await ctx.emit({"type": "delegation_end", "target": target["name"], "thread_id": child["id"]})
        return ToolResult(data={"agent": target["name"], "thread_id": child["id"], "result": answer[:12000]})


class SpawnAgentTool(Tool):
    name = "spawn_agent"
    description = ("Create a new specialist agent (with its own cloud workspace, memory and model) "
                   "and immediately put it to work on a task. Use for building a team/fleet.")
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "title": {"type": "string"},
        "description": {"type": "string", "description": "what it does — this is how others find it"},
        "persona": {"type": "string", "description": "tone/behaviour instructions"},
        "task": {"type": "string", "description": "first task to run now"},
        "tools": {"type": "array", "items": {"type": "string"}}},
        "required": ["name", "description"]}
    group = "Team"
    icon = "🧬"
    risk = "medium"

    async def call(self, args, ctx):
        from ..agent import run_agent

        if db.q1("SELECT id FROM agents WHERE lower(name)=lower(?)", (args["name"],)):
            return ToolResult(ok=False, error=f"an agent named {args['name']!r} already exists")
        spawner = ctx.agent
        new = create_agent(
            args["name"], title=args.get("title", ""), description=args.get("description", ""),
            provider=spawner.get("provider", ""), model=spawner.get("model", ""),
            persona=args.get("persona", ""), emoji=args.get("emoji", "🤖") or "🤖",
            tools=args.get("tools") or None,
        )
        db.audit(ctx.agent_id, ctx.thread_id, "agent.spawn",
                 {"name": new["name"], "id": new["id"], "by": spawner["name"]}, risk="medium")
        await ctx.emit({"type": "agent_spawned", "agent": {"id": new["id"], "name": new["name"],
                                                           "title": new["title"]}})
        result = {"created": new["name"], "id": new["id"], "title": new["title"]}
        if args.get("task"):
            thread = create_thread(new["id"], title=f"First task: {args['task'][:50]}", kind="delegation",
                                   parent_thread_id=ctx.thread_id)
            try:
                result["first_task_result"] = (await run_agent(new, args["task"], thread_id=thread["id"],
                                                               max_turns=8))[:8000]
                result["thread_id"] = thread["id"]
            except Exception as exc:
                result["first_task_error"] = str(exc)
        return ToolResult(data=result)


class AgentCardTool(Tool):
    name = "agent_card"
    description = "Get a detailed profile of one agent: skills, routines, memory summary and workspace stats."
    parameters = {"type": "object", "properties": {"agent_name": {"type": "string"}}, "required": ["agent_name"]}
    group = "Team"
    icon = "🪪"

    async def call(self, args, ctx):
        a = db.q1("SELECT * FROM agents WHERE lower(name)=lower(?)", (args["agent_name"],))
        if not a:
            return ToolResult(ok=False, error="agent not found")
        skills = db.q("SELECT name, description FROM skills WHERE agent_id=?", (a["id"],))
        routines = db.q("SELECT name, kind, schedule, enabled FROM routines WHERE agent_id=?", (a["id"],))
        memories = db.q("SELECT key, value FROM memories WHERE agent_id=? ORDER BY created_at DESC LIMIT 12", (a["id"],))
        return ToolResult(data={
            "name": a["name"], "title": a["title"], "description": a["description"],
            "provider": a["provider"], "model": a["model"], "persona": a["persona"],
            "workspace": workspace_stats(a["id"]),
            "skills": skills, "routines": routines,
            "memory": [{"key": m["key"], "value": m["value"][:200]} for m in memories],
        })


TOOLS = [ListTeamTool(), DelegateTool(), SpawnAgentTool(), AgentCardTool()]
