"""Web tools: search + page fetching, with no-key fallbacks."""
from __future__ import annotations

import html
import os
import re
from urllib.parse import quote_plus, urlparse

import httpx

from .. import youtube
from .base import Tool, ToolResult
from .ssrf_guard import SSRFError, guard_ssrf
from .untrusted import UNTRUSTED_PROMPT, is_untrusted_source, mark_thread_tainted, wrap_untrusted_content

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Safari/537.36 Nimbus/1.0")

_TAG = re.compile(r"<(script|style|noscript|svg|head)[^>]*>.*?</\1>", re.S | re.I)
_BR = re.compile(r"</?(p|div|br|li|tr|h[1-6]|section|article)[^>]*>", re.I)
_TAGS = re.compile(r"<[^>]+>")
_WS = re.compile(r"[ \t\r\f\v]+")
_NL = re.compile(r"\n{3,}")


def html_to_text(raw: str) -> str:
    text = _TAG.sub(" ", raw)
    text = _BR.sub("\n", text)
    text = _TAGS.sub("", text)
    text = html.unescape(text)
    text = _WS.sub(" ", text)
    text = _NL.sub("\n\n", text)
    return "\n".join(line.strip() for line in text.splitlines()).strip()


class WebSearchTool(Tool):
    name = "web_search"
    description = ("Search the web. Returns titles, URLs and snippets. "
                   "Use tavily/brave when a key is set, otherwise DuckDuckGo.")
    parameters = {"type": "object", "properties": {
        "query": {"type": "string"}, "max_results": {"type": "integer"}}, "required": ["query"]}
    group = "Web"
    icon = "🌐"

    async def call(self, args, ctx):
        query = args["query"]
        limit = max(1, min(int(args.get("max_results") or 6), 15))
        headers = {"User-Agent": UA}

        # Note: Search engines themselves are external, but we still mark results as untrusted
        # since they contain user-facing content that could be malicious
        
        tavily = os.environ.get("TAVILY_API_KEY", "")
        brave = os.environ.get("BRAVE_API_KEY", "")
        async with httpx.AsyncClient(timeout=30, follow_redirects=True, headers=headers) as client:
            if tavily:
                r = await client.post("https://api.tavily.com/search", json={
                    "api_key": tavily, "query": query, "max_results": limit, "search_depth": "advanced"})
                if r.status_code < 400:
                    data = r.json()
                    result = {"engine": "tavily", "query": query, "results": [
                        {"title": x.get("title"), "url": x.get("url"), "snippet": x.get("content", "")[:600],
                         "score": x.get("score")} for x in data.get("results", [])],
                        "answer": data.get("answer", "")}
                    wrapped = wrap_untrusted_content(result, "web_search", f"query: {query}")
                    mark_thread_tainted(ctx.thread_id)
                    return ToolResult(data=wrapped)
            if brave:
                r = await client.get("https://api.search.brave.com/res/v1/web/search",
                                     params={"q": query, "count": limit},
                                     headers={"X-Subscription-Token": brave, "Accept": "application/json"})
                if r.status_code < 400:
                    data = r.json()
                    result = {"engine": "brave", "query": query, "results": [
                        {"title": x.get("title"), "url": x.get("url"),
                         "snippet": html_to_text(x.get("description", ""))[:600]}
                        for x in (data.get("web", {}) or {}).get("results", [])]}
                    wrapped = wrap_untrusted_content(result, "web_search", f"query: {query}")
                    mark_thread_tainted(ctx.thread_id)
                    return ToolResult(data=wrapped)

            # ---- keyless fallback: DuckDuckGo HTML endpoint ----
            r = await client.post("https://html.duckduckgo.com/html/", data={"q": query})
            if r.status_code >= 400:
                r = await client.get(f"https://duckduckgo.com/html/?q={quote_plus(query)}")
            results = self._parse_ddg(r.text, limit)
            if not results:
                return ToolResult(ok=False, error=("search returned nothing (the keyless DuckDuckGo endpoint "
                                                   "may be rate-limiting). Add TAVILY_API_KEY or BRAVE_API_KEY "
                                                   "in Settings → Providers for reliable search."))
            result = {"engine": "duckduckgo", "query": query, "results": results}
            wrapped = wrap_untrusted_content(result, "web_search", f"query: {query}")
            mark_thread_tainted(ctx.thread_id)
            return ToolResult(data=wrapped)

    @staticmethod
    def _parse_ddg(raw: str, limit: int) -> list[dict]:
        out = []
        for m in re.finditer(r'<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>(.*?)</a>', raw, re.S):
            url, title = m.group(1), html_to_text(m.group(2))
            if url.startswith("//duckduckgo.com/l/?uddg=") or "uddg=" in url:
                from urllib.parse import parse_qs, unquote
                qs = parse_qs(urlparse(url).query)
                if qs.get("uddg"):
                    url = unquote(qs["uddg"][0])
            out.append({"title": title, "url": url, "snippet": ""})
            if len(out) >= limit:
                break
        if not out:  # newer markup
            for m in re.finditer(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', raw, re.S):
                out.append({"title": html_to_text(m.group(2)), "url": m.group(1), "snippet": ""})
                if len(out) >= limit:
                    break
        snippets = [html_to_text(s) for s in re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', raw, re.S)]
        for i, s in enumerate(snippets[:len(out)]):
            out[i]["snippet"] = s[:600]
        return out


class FetchUrlTool(Tool):
    name = "fetch_url"
    description = "Fetch a URL and return readable text (HTML is converted to plain text)."
    parameters = {"type": "object", "properties": {
        "url": {"type": "string"}, "max_chars": {"type": "integer"}}, "required": ["url"]}
    group = "Web"
    icon = "📥"

    async def call(self, args, ctx):
        url = args["url"]
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        
        # SSRF Guard: Block requests to internal/private networks
        try:
            guard_ssrf(url, f" (fetch_url called from thread {ctx.thread_id})")
        except SSRFError as e:
            return ToolResult(ok=False, error=str(e))
        
        # a video page has no readable text of its own — read the captions instead
        if youtube.is_youtube_url(url):
            data = await youtube.fetch_video(url, lang=preferred_caption_lang(ctx),
                                             max_chars=max(1000, min(int(args.get("max_chars") or 40000), 120000)))
            if data.get("ok"):
                data["note"] = ("This is the video's spoken content (captions), not the page HTML. "
                                "Summarise or quote it as needed.")
                # Mark as untrusted since it comes from external source
                wrapped = wrap_untrusted_content(data, "youtube_transcript", url)
                mark_thread_tainted(ctx.thread_id)
                return ToolResult(data=wrapped)
            return ToolResult(ok=False, error=data.get("error", "no captions"), data=data)
        limit = max(1000, min(int(args.get("max_chars") or 60000), 200000))
        async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=60), follow_redirects=True,
                                     headers={"User-Agent": UA}) as client:
            r = await client.get(url)
        if r.status_code >= 400:
            return ToolResult(ok=False, error=f"HTTP {r.status_code} for {url}")
        ctype = r.headers.get("content-type", "")
        if "json" in ctype:
            # Wrap JSON content as untrusted
            wrapped = wrap_untrusted_content({"url": str(r.url), "content_type": ctype, "text": r.text[:limit]}, "fetch_url", url)
            mark_thread_tainted(ctx.thread_id)
            return ToolResult(data=wrapped)
        text = html_to_text(r.text) if ("html" in ctype or r.text.lstrip().startswith("<")) else r.text
        title = ""
        m = re.search(r"<title[^>]*>(.*?)</title>", r.text, re.S | re.I)
        if m:
            title = html_to_text(m.group(1))[:300]
        
        # Wrap fetched content as untrusted
        result = {"url": str(r.url), "title": title, "content_type": ctype,
                 "chars": len(text), "text": text[:limit]}
        wrapped = wrap_untrusted_content(result, "fetch_url", url)
        mark_thread_tainted(ctx.thread_id)
        return ToolResult(data=wrapped)


def preferred_caption_lang(ctx) -> str:
    """Which caption language to prefer: the agent's own, else the UI language."""
    from ..config import current_language
    own = ((ctx.agent or {}).get("language") or "inherit").lower()
    code = own if own in ("en", "zh", "es") else current_language()
    return "" if code in ("auto", "", "inherit") else code


class YouTubeTranscriptTool(Tool):
    name = "youtube_transcript"
    description = ("Read what is said in a YouTube video: give a link (or video id) and get the transcript, "
                   "title, channel and duration. Use this for 'summarise this video' requests — never guess "
                   "what a video contains. Optional: lang to prefer a caption language, max_chars, "
                   "timestamps=true for [mm:ss] markers.")
    parameters = {"type": "object", "properties": {
        "url": {"type": "string", "description": "YouTube link or 11-character video id"},
        "lang": {"type": "string", "description": "preferred caption language, e.g. en, zh, es, ja"},
        "max_chars": {"type": "integer", "description": "cap on transcript length (default 60000)"},
        "timestamps": {"type": "boolean", "description": "include [mm:ss] markers"},
        "start": {"type": "string", "description": "only from this point, e.g. '5:00' (long videos)"},
        "end": {"type": "string", "description": "only up to this point, e.g. '12:30'"}},
        "required": ["url"]}
    group = "Web"
    icon = "🎬"

    async def call(self, args, ctx):
        url = args.get("url") or args.get("video") or ""
        lang = (args.get("lang") or "").strip() or preferred_caption_lang(ctx)
        data = await youtube.fetch_video(
            url, lang=lang,
            max_chars=max(2000, min(int(args.get("max_chars") or 60000), 400000)),
            timestamps=bool(args.get("timestamps")),
            start=args.get("start", 0), end=args.get("end", 0))
        if not data.get("ok"):
            return ToolResult(ok=False, error=data.get("error", "could not read that video"), data=data)
        data["note"] = ("Transcript of the spoken words. Summarise it, translate it, or save it — "
                        "and cite the title/channel. Line breaks are caption boundaries, not paragraphs.")
        return ToolResult(data=data)


TOOLS = [WebSearchTool(), FetchUrlTool(), YouTubeTranscriptTool()]
