"""Memory tools — persistent, inspectable long-term memory per agent."""
from __future__ import annotations

from ..store import forget, recall, remember
from .base import Tool, ToolResult


class RememberTool(Tool):
    name = "remember"
    description = ("Save a durable fact, preference or decision to long-term memory. "
                   "Use scope='team' to share it with every agent on the account.")
    parameters = {"type": "object", "properties": {
        "key": {"type": "string", "description": "short label, e.g. 'report_style'"},
        "value": {"type": "string"},
        "tags": {"type": "string", "description": "comma separated"},
        "scope": {"type": "string", "enum": ["agent", "team"]}}, "required": ["key", "value"]}
    group = "Memory"
    icon = "🧠"

    async def call(self, args, ctx):
        remember(ctx.agent_id, args["key"][:200], args.get("value", "")[:8000],
                 args.get("tags", ""), args.get("scope", "agent"))
        return ToolResult(data={"saved": args["key"], "scope": args.get("scope", "agent")})


class RecallTool(Tool):
    name = "recall"
    description = "Search your long-term memory. Start with an empty query to load your profile."
    parameters = {"type": "object", "properties": {
        "query": {"type": "string"}, "limit": {"type": "integer"}}, "required": []}
    group = "Memory"
    icon = "🔍"

    async def call(self, args, ctx):
        rows = recall(ctx.agent_id, args.get("query", ""), int(args.get("limit") or 30))
        return ToolResult(data={"count": len(rows),
                                "memories": [{"key": r["key"], "value": r["value"][:600],
                                              "scope": r["scope"], "tags": r["tags"]} for r in rows]})


class ForgetTool(Tool):
    name = "forget"
    description = "Delete a memory by key."
    parameters = {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}
    group = "Memory"
    icon = "🧽"
    risk = "medium"

    async def call(self, args, ctx):
        n = forget(ctx.agent_id, args["key"])
        return ToolResult(data={"deleted": n, "key": args["key"]})


TOOLS = [RememberTool(), RecallTool(), ForgetTool()]
