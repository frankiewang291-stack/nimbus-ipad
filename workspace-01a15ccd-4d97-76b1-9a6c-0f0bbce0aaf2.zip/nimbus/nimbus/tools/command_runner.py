"""
Isolated command runner for RunCommandTool.

Security design:
- Allow-by-isolation: commands run in isolated environments
- Tier 1 (default): subprocess without shell, scrubbed env, resource limits, process group
- Tier 2 (optional): Docker/bubblewrap with --network none and read-only root
- No denylist: we allow by design, not block by pattern

This module provides a secure way to run commands with proper isolation.
"""
from __future__ import annotations

import asyncio
import os
import resource
import signal
import shlex
import shutil
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base import ToolContext


# =============================================================================
# TIER 1: Native isolation using subprocess + resource limits
# =============================================================================

# Commands that are explicitly allowed (whitelist approach)
# These are safe, non-destructive commands commonly needed in a workspace
ALLOWED_COMMANDS = frozenset({
    # File inspection
    'ls', 'tree', 'find', 'locate', 'stat', 'file', 'wc', 'du', 'df',
    # Text processing
    'cat', 'head', 'tail', 'less', 'more', 'grep', 'egrep', 'fgrep', 'ag', 'rg',
    'awk', 'sed', 'sort', 'uniq', 'cut', 'paste', 'join', 'tr', 'fold', 'fmt',
    'column', 'nl', 'od', 'xxd', 'hexdump', 'base64', 'base32',
    # Compression
    'gzip', 'gunzip', 'bzip2', 'bunzip2', 'xz', 'unxz', 'zip', 'unzip',
    'tar', 'gtar', '7z', '7za',
    # Code tools
    'python', 'python3', 'python3.11', 'python3.12', 'python3.13',
    'node', 'nodejs', 'npm', 'yarn', 'pnpm',
    'git', 'hg', 'svn',
    'make', 'cmake', 'ninja',
    'gcc', 'clang', 'rustc', 'cargo', 'go', 'javac', 'java',
    # Formatting
    'fmt', 'gofmt', 'black', 'isort', 'flake8', 'mypy', 'pylint', 'eslint', 'prettier',
    'jq', 'yaml', 'yamllint',
    # System info (read-only)
    'uname', 'whoami', 'id', 'date', 'uptime', 'free', 'top', 'ps', 'pstree',
    'env', 'printenv', 'echo', 'printf', 'test', 'true', 'false',
    # Shell builtins (safe subset)
    'cd', 'pwd', 'pushd', 'popd', 'dirs',
})

# Commands that modify state and require approval
RISKY_COMMANDS = frozenset({
    'rm', 'rmdir', 'rm -r', 'rm -rf', 'del', 'erase',
    'mv', 'move', 'cp', 'copy',
    'chmod', 'chown', 'chgrp',
    'mkdir', 'mkfs', 'dd',
    'kill', 'pkill', 'killall', 'pkill',
    'shutdown', 'reboot', 'halt', 'poweroff',
    'apt', 'apt-get', 'yum', 'dnf', 'pacman', 'brew', 'pip', 'pip3',
    'curl', 'wget', 'scp', 'rsync', 'ssh', 'nc', 'ncat', 'telnet', 'ftp', 'sftp',
    'git clone', 'git push', 'git pull',
    'docker', 'podman', 'lxc',
    'useradd', 'userdel', 'usermod', 'passwd',
    'cron', 'crontab', 'at',
    'sudo', 'su', 'doas',
})

# Maximum resource limits for Tier 1
MAX_CPU_SECONDS = 30      # CPU time limit
MAX_MEMORY_MB = 512       # Memory limit (soft)
MAX_MEMORY_HARD_MB = 1024 # Memory limit (hard)
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB file size limit
MAX_PROCESSES = 20        # Max child processes
MAX_OPEN_FILES = 128     # Max open files


def get_safe_env(workspace_path: Path | None = None) -> dict:
    """
    Create a scrubbed environment with only safe variables.
    Removes API keys, credentials, and other sensitive data.
    """
    # Start with a minimal safe environment
    safe_env = {
        'PATH': os.environ.get('PATH', '/usr/local/bin:/usr/bin:/bin'),
        'HOME': str(Path.home()) if workspace_path is None else str(workspace_path),
        'USER': os.environ.get('USER', 'nimbus'),
        'SHELL': os.environ.get('SHELL', '/bin/sh'),
        'LANG': os.environ.get('LANG', 'C.UTF-8'),
        'LC_ALL': os.environ.get('LC_ALL', 'C.UTF-8'),
        'PWD': os.getcwd(),
        # Workspace-specific
        'NIMBUS_WORKSPACE': str(workspace_path) if workspace_path else os.getcwd(),
    }
    
    # Add Python-specific variables if python is in PATH
    if 'python' in safe_env['PATH'] or 'python3' in safe_env['PATH']:
        safe_env['PYTHONPATH'] = os.environ.get('PYTHONPATH', '')
        safe_env['PYTHONUNBUFFERED'] = '1'
    
    # Filter out variables that might contain sensitive data
    # Keep only whitelisted variables
    SAFE_VARS = {
        'PATH', 'HOME', 'USER', 'SHELL', 'LANG', 'LC_ALL', 'LC_CTYPE', 'LC_MESSAGES',
        'PWD', 'OLDPWD', 'TZ', 'TERM', 'COLUMNS', 'LINES',
        'NIMBUS_WORKSPACE', 'PYTHONPATH', 'PYTHONUNBUFFERED', 'PYTHONDONTWRITEBYTECODE',
        'VIRTUAL_ENV', 'CONDA_DEFAULT_ENV',
    }
    
    # Remove any variables that might contain secrets
    # Common patterns for sensitive environment variables
    SECRET_PATTERNS = [
        'KEY', 'SECRET', 'TOKEN', 'PASSWORD', 'PASSWD', 'CREDENTIAL',
        'API', 'ACCESS', 'PRIVATE', 'AUTH', 'OAUTH', 'JWT',
        'DATABASE', 'DB', 'SQL', 'MONGO', 'REDIS', 'POSTGRES',
        'AWS', 'GCP', 'AZURE', 'GOOGLE', 'AMAZON',
    ]
    
    # Filter existing env vars - only keep safe ones
    for key, value in os.environ.items():
        # Skip if already in safe_env
        if key in safe_env:
            continue
        # Skip if it looks like a secret
        if any(pattern in key.upper() for pattern in SECRET_PATTERNS):
            continue
        # Only keep if it's in our whitelist
        if key.upper() in SAFE_VARS:
            safe_env[key] = value
    
    return safe_env


def parse_command(command: str) -> list[str]:
    """
    Parse a command string into a list of arguments using shlex.
    This properly handles quoted strings, escape sequences, etc.
    """
    try:
        # Use posix=True for proper shell-like parsing (even on Windows)
        return shlex.split(command, posix=True)
    except ValueError:
        # Fallback: split on whitespace if shlex fails
        return command.split()


def get_base_command(args: list[str]) -> str:
    """
    Extract the base command name from parsed arguments.
    Handles cases like: ['rm', '-rf', '/'] -> 'rm'
    """
    if not args:
        return ''
    return args[0]


def is_allowed_command(command: str, args: list[str]) -> tuple[bool, str]:
    """
    Check if a command is allowed.
    
    Returns:
        tuple: (is_allowed, reason_if_denied)
    """
    base_cmd = get_base_command(args)
    
    # Extract the base command name (handle paths like /usr/bin/ls)
    cmd_name = os.path.basename(base_cmd) if base_cmd else ''
    
    # Check if it's in our allowlist
    if cmd_name in ALLOWED_COMMANDS:
        return True, ''
    
    # Check for risky commands
    if cmd_name in RISKY_COMMANDS:
        return False, f"command '{cmd_name}' requires approval"
    
    # Check for absolute paths that might bypass our restrictions
    if base_cmd.startswith('/') or base_cmd.startswith('\\'):
        # Allow absolute paths to known safe binaries
        safe_paths = ['/usr/bin/', '/bin/', '/usr/local/bin/']
        if any(base_cmd.startswith(p) for p in safe_paths):
            cmd_name = os.path.basename(base_cmd)
            if cmd_name in ALLOWED_COMMANDS:
                return True, ''
            if cmd_name in RISKY_COMMANDS:
                return False, f"command '{cmd_name}' requires approval"
        else:
            return False, f"absolute path '{base_cmd}' not in allowed locations"
    
    # Check for command substitutions and shell tricks
    # These should be caught by our parsing (since we don't use shell=True)
    # But let's be extra careful
    for arg in args:
        if any(c in arg for c in [';', '&', '|', '$(', '`', '<', '>']):
            return False, f"command contains shell metacharacters: {command[:100]}"
    
    # Default: allow if we don't recognize it (but it will run with restrictions)
    return True, ''


def check_destructive_command(command: str, args: dict) -> str | None:
    """
    Check if a command is destructive using proper parsing.
    
    This replaces the substring matching in approvals.py.
    
    Returns:
        str: reason to require approval, or None if safe
    """
    try:
        parsed = parse_command(command)
        if not parsed:
            return None
        
        base_cmd = get_base_command(parsed)
        cmd_name = os.path.basename(base_cmd) if base_cmd else ''
        
        # Destructive commands
        destructive = {
            'rm', 'rmdir', 'del', 'erase', 'unlink',
            'mv', 'move', 'cp', 'copy',
            'chmod', 'chown', 'chgrp',
            'mkdir', 'mkfs', 'dd',
            'kill', 'pkill', 'killall',
            'shutdown', 'reboot', 'halt', 'poweroff',
            'format', 'fdisk', 'parted',
        }
        
        if cmd_name in destructive:
            return f"shell command looks destructive: {command[:120]}"
        
        # Check for destructive flags
        if cmd_name == 'rm' and any(arg in ['-r', '-rf', '-R'] for arg in parsed[1:]):
            return f"shell command looks destructive: {command[:120]}"
        
        if cmd_name == 'chmod' and '-R' in parsed[1:]:
            return f"shell command looks destructive: {command[:120]}"
        
        if cmd_name == 'dd' and any(arg in ['if=/dev/zero', 'of='] for arg in parsed[1:]):
            return f"shell command looks destructive: {command[:120]}"
        
        # Network commands
        network = {
            'curl', 'wget', 'scp', 'rsync', 'ssh', 'nc', 'ncat', 'telnet', 'ftp', 'sftp',
            'git clone', 'git push', 'git pull', 'git fetch',
        }
        
        if cmd_name in network or any(cmd_name == n for n in network):
            return f"shell command uses network: {command[:120]}"
        
        return None
        
    except Exception:
        # If parsing fails, require approval
        return f"could not parse command safely: {command[:120]}"


class CommandRunner:
    """
    Isolated command runner with resource limits.
    
    Uses subprocess without shell=True for security.
    Implements resource limits via preexec_fn (Unix only).
    """
    
    def __init__(self, workspace_path: Path, timeout: int = 60):
        self.workspace_path = workspace_path
        self.timeout = min(max(timeout, 1), 300)  # Clamp to 1-300 seconds
        self.process_group = None
    
    def _setup_resource_limits(self):
        """
        Set up resource limits for the subprocess.
        Uses preexec_fn to set limits before exec.
        """
        def set_limits():
            # CPU time limit
            resource.setrlimit(resource.RLIMIT_CPU, (MAX_CPU_SECONDS, MAX_CPU_SECONDS + 1))
            
            # Memory limit (soft and hard)
            soft_mem = MAX_MEMORY_MB * 1024 * 1024
            hard_mem = MAX_MEMORY_HARD_MB * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (soft_mem, hard_mem))
            
            # File size limit
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_FILE_SIZE, MAX_FILE_SIZE))
            
            # Process limit
            resource.setrlimit(resource.RLIMIT_NPROC, (MAX_PROCESSES, MAX_PROCESSES))
            
            # Open files limit
            resource.setrlimit(resource.RLIMIT_NOFILE, (MAX_OPEN_FILES, MAX_OPEN_FILES))
            
            # Create new process group for clean termination
            os.setpgid(0, 0)
        
        return set_limits
    
    async def run(self, command: str) -> dict:
        """
        Run a command with isolation.
        
        Args:
            command: The command string to run
        
        Returns:
            dict: {
                'command': str,
                'exit_code': int,
                'stdout': str,
                'stderr': str,
                'duration_s': float,
                'timed_out': bool,
                'killed': bool
            }
        """
        start_time = time.time()
        
        # Parse the command
        try:
            args = parse_command(command)
        except ValueError as e:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Command parsing error: {e}',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        if not args:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': 'Empty command',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        # Check if command is allowed
        is_allowed, reason = is_allowed_command(command, args)
        if not is_allowed:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Command not allowed: {reason}',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        # Get base command for validation
        base_cmd = get_base_command(args)
        cmd_name = os.path.basename(base_cmd) if base_cmd else ''
        
        # Build the environment
        env = get_safe_env(self.workspace_path)
        
        # Run the command
        stdout_data = bytearray()
        stderr_data = bytearray()
        timed_out = False
        killed = False
        
        try:
            # Use subprocess without shell=True for security
            # This prevents shell injection attacks
            proc = await asyncio.create_subprocess_exec(
                args[0],
                *args[1:],
                cwd=str(self.workspace_path),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                preexec_fn=self._setup_resource_limits() if sys.platform != 'win32' else None,
            )
            
            # Store process for potential cleanup
            self.process_group = proc
            
            # Wait for completion with timeout
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.timeout
                )
                stdout_data.extend(stdout_bytes)
                stderr_data.extend(stderr_bytes)
            except asyncio.TimeoutError:
                timed_out = True
                # Kill the entire process group
                try:
                    if sys.platform != 'win32':
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    else:
                        proc.kill()
                    killed = True
                    stdout_bytes, stderr_bytes = await proc.communicate()
                    stdout_data.extend(stdout_bytes)
                    stderr_data.extend(stderr_bytes)
                except (ProcessLookupError, PermissionError):
                    pass
            
        except FileNotFoundError as e:
            return {
                'command': command,
                'exit_code': 127,
                'stdout': '',
                'stderr': f'Command not found: {e}',
                'duration_s': round(time.time() - start_time, 2),
                'timed_out': False,
                'killed': False
            }
        except PermissionError as e:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Permission denied: {e}',
                'duration_s': round(time.time() - start_time, 2),
                'timed_out': False,
                'killed': False
            }
        except Exception as e:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Error executing command: {e}',
                'duration_s': round(time.time() - start_time, 2),
                'timed_out': False,
                'killed': False
            }
        
        duration = round(time.time() - start_time, 2)
        
        # Decode output
        try:
            stdout_str = stdout_data.decode('utf-8', errors='replace')
        except Exception:
            stdout_str = str(stdout_data)
        
        try:
            stderr_str = stderr_data.decode('utf-8', errors='replace')
        except Exception:
            stderr_str = str(stderr_data)
        
        # Truncate output to prevent memory issues
        max_stdout = 20000
        max_stderr = 8000
        
        return {
            'command': command,
            'exit_code': proc.returncode if 'proc' in locals() else 1,
            'stdout': stdout_str[-max_stdout:],
            'stderr': stderr_str[-max_stderr:],
            'duration_s': duration,
            'timed_out': timed_out,
            'killed': killed
        }


# =============================================================================
# TIER 2: Docker/bubblewrap isolation (optional)
# =============================================================================

class DockerCommandRunner:
    """
    Optional Tier 2: Docker-based isolation.
    
    Runs commands in a container with:
    - --network none (no network access)
    - Read-only root filesystem
    - Workspace mounted as read-write volume
    - No privileged mode
    - Resource limits
    """
    
    def __init__(self, workspace_path: Path, timeout: int = 60):
        self.workspace_path = workspace_path
        self.timeout = timeout
    
    async def run(self, command: str) -> dict:
        """
        Run a command in a Docker container.
        
        Note: Docker must be installed and the user must have permission
        to run Docker containers.
        """
        start_time = time.time()
        
        # Parse the command
        try:
            args = parse_command(command)
        except ValueError as e:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Command parsing error: {e}',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        if not args:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': 'Empty command',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        # Check if Docker is available
        try:
            proc = await asyncio.create_subprocess_exec(
                'docker', '--version',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            await proc.communicate()
            if proc.returncode != 0:
                return {
                    'command': command,
                    'exit_code': 1,
                    'stdout': '',
                    'stderr': 'Docker not available or not working',
                    'duration_s': 0,
                    'timed_out': False,
                    'killed': False
                }
        except FileNotFoundError:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': 'Docker not installed',
                'duration_s': 0,
                'timed_out': False,
                'killed': False
            }
        
        # Build Docker command
        docker_args = [
            'docker', 'run', '--rm',
            '--network', 'none',  # No network access
            '--read-only',         # Read-only root
            '-v', f'{self.workspace_path}:/workspace',  # Mount workspace
            '-w', '/workspace',    # Working directory
            '--memory', f'{MAX_MEMORY_HARD_MB}m',
            '--cpus', str(MAX_CPU_SECONDS / 60),  # CPU limit
            '--pids-limit', str(MAX_PROCESSES),
            'alpine:latest',       # Lightweight base image
            'sh', '-c', command
        ]
        
        try:
            proc = await asyncio.create_subprocess_exec(
                *docker_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.timeout
                )
            except asyncio.TimeoutError:
                proc.kill()
                stdout_bytes, stderr_bytes = await proc.communicate()
                return {
                    'command': command,
                    'exit_code': -1,
                    'stdout': stdout_bytes.decode('utf-8', errors='replace')[-20000:],
                    'stderr': (stderr_bytes + b'\nCommand timed out').decode('utf-8', errors='replace')[-8000:],
                    'duration_s': round(time.time() - start_time, 2),
                    'timed_out': True,
                    'killed': True
                }
            
            duration = round(time.time() - start_time, 2)
            return {
                'command': command,
                'exit_code': proc.returncode,
                'stdout': stdout_bytes.decode('utf-8', errors='replace')[-20000:],
                'stderr': stderr_bytes.decode('utf-8', errors='replace')[-8000:],
                'duration_s': duration,
                'timed_out': False,
                'killed': False
            }
            
        except Exception as e:
            return {
                'command': command,
                'exit_code': 1,
                'stdout': '',
                'stderr': f'Docker error: {e}',
                'duration_s': round(time.time() - start_time, 2),
                'timed_out': False,
                'killed': False
            }


def get_runner(tier: str, workspace_path: Path, timeout: int = 60) -> CommandRunner:
    """
    Get the appropriate command runner based on tier.
    
    Args:
        tier: 'tier1' for native isolation, 'tier2' for Docker isolation
        workspace_path: The workspace directory
        timeout: Command timeout in seconds
    
    Returns:
        CommandRunner instance
    """
    if tier == 'tier2':
        return DockerCommandRunner(workspace_path, timeout)
    return CommandRunner(workspace_path, timeout)
