"""Google Workspace tools — Drive, Docs, Sheets, Gmail, Calendar."""
from __future__ import annotations

from .. import google_api as g
from ..store import resolve_in_workspace
from .base import Tool, ToolResult, ToolContext
from .untrusted import is_untrusted_source, mark_thread_tainted, wrap_untrusted_content


class _GoogleTool(Tool):
    group = "Google Workspace"
    icon = "🔵"

    def available(self, ctx: ToolContext) -> bool:
        return True  # demo backend keeps these usable without credentials

    async def _guard(self, coro):
        try:
            return ToolResult(data=await coro)
        except g.NotConnected as exc:
            return ToolResult(ok=False, error=f"Google not connected: {exc} "
                                              f"(Connectors → Connect Google, or use demo mode)")
        except g.GoogleError as exc:
            return ToolResult(ok=False, error=str(exc))


# ------------------------------------------------------------------ Drive
class GDriveSearchTool(_GoogleTool):
    name = "gdrive_search"
    description = ("Search Google Drive by file name or content. Empty query lists recent files. "
                   "Returns file ids you can pass to other Drive/Docs/Sheets tools.")
    parameters = {"type": "object", "properties": {
        "query": {"type": "string"}, "max_results": {"type": "integer"},
        "kind": {"type": "string", "enum": ["", "doc", "sheet", "slide", "folder", "file"]}},
        "required": []}

    async def call(self, args, ctx):
        mime = {"doc": g.MD_DOC, "sheet": g.MD_SHEET, "slide": g.MD_SLIDE, "folder": g.MD_FOLDER}.get(args.get("kind", ""), "")
        result = await self._guard(g.drive_search(args.get("query", ""), int(args.get("max_results") or 20), mime))
        if result and result.ok:
            # Wrap Drive search results as untrusted
            wrapped = wrap_untrusted_content(result.data, "gdrive_search", args.get("query", ""))
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GDriveReadTool(_GoogleTool):
    name = "gdrive_read"
    description = "Read a Drive file's text by id or exact name (Docs and Sheets are auto-converted to text)."
    parameters = {"type": "object", "properties": {
        "file_id": {"type": "string"}, "max_chars": {"type": "integer"}}, "required": ["file_id"]}

    async def call(self, args, ctx):
        result = await self._guard(g.drive_read(args["file_id"], int(args.get("max_chars") or 40000)))
        if result and result.ok:
            # Wrap Drive content as untrusted
            wrapped = wrap_untrusted_content(result.data, "gdrive_read", args.get("file_id", ""))
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GDriveUploadTool(_GoogleTool):
    name = "gdrive_upload"
    description = ("Upload a file from your workspace to Google Drive. "
                   "Set convert=true to turn a .md/.txt into a native Google Doc.")
    parameters = {"type": "object", "properties": {
        "path": {"type": "string", "description": "workspace path"},
        "name": {"type": "string", "description": "name in Drive (optional)"},
        "folder_id": {"type": "string"}, "convert": {"type": "boolean"}}, "required": ["path"]}
    risk = "medium"
    icon = "⬆️"

    async def call(self, args, ctx):
        p = resolve_in_workspace(ctx.agent_id, args["path"])
        if not p.is_file():
            return ToolResult(ok=False, error=f"no such file in workspace: {args['path']}")
        return await self._guard(g.drive_upload(p, args.get("name", ""), args.get("folder_id", ""),
                                                bool(args.get("convert"))))


class GDriveFolderTool(_GoogleTool):
    name = "gdrive_create_folder"
    description = "Create a folder in Google Drive."
    parameters = {"type": "object", "properties": {
        "name": {"type": "string"}, "parent_id": {"type": "string"}}, "required": ["name"]}
    risk = "medium"
    icon = "📁"

    async def call(self, args, ctx):
        return await self._guard(g.drive_create_folder(args["name"], args.get("parent_id", "")))


class GDriveDeleteTool(_GoogleTool):
    name = "gdrive_delete"
    description = "Permanently delete a file from Google Drive by id."
    parameters = {"type": "object", "properties": {"file_id": {"type": "string"}}, "required": ["file_id"]}
    risk = "high"
    icon = "🗑️"

    async def call(self, args, ctx):
        return await self._guard(g.drive_delete(args["file_id"]))


# ------------------------------------------------------------------ Docs
class GDocsListTool(_GoogleTool):
    name = "gdocs_list"
    description = "List Google Docs (most recently modified first)."
    parameters = {"type": "object", "properties": {"max_results": {"type": "integer"}}, "required": []}

    async def call(self, args, ctx):
        result = await self._guard(g.drive_search("", int(args.get("max_results") or 20), g.MD_DOC))
        if result and result.ok:
            # Wrap Docs list as untrusted
            wrapped = wrap_untrusted_content(result.data, "gdocs_list", "")
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GDocsCreateTool(_GoogleTool):
    name = "gdocs_create"
    description = ("Create a Google Doc from markdown. Headings, bullet lists, bold text and code blocks "
                   "are converted into real Google Docs formatting.")
    parameters = {"type": "object", "properties": {
        "title": {"type": "string"},
        "markdown": {"type": "string", "description": "document body in markdown"},
        "folder_id": {"type": "string"}}, "required": ["title"]}
    risk = "medium"
    icon = "📝"

    async def call(self, args, ctx):
        return await self._guard(g.docs_create(args["title"], args.get("markdown", ""), args.get("folder_id", "")))


class GDocsReadTool(_GoogleTool):
    name = "gdocs_read"
    description = "Read a Google Doc as markdown-ish text."
    parameters = {"type": "object", "properties": {
        "doc_id": {"type": "string"}, "max_chars": {"type": "integer"}}, "required": ["doc_id"]}

    async def call(self, args, ctx):
        result = await self._guard(g.docs_read(args["doc_id"], int(args.get("max_chars") or 40000)))
        if result and result.ok:
            # Wrap Docs content as untrusted
            wrapped = wrap_untrusted_content(result.data, "gdocs_read", args.get("doc_id", ""))
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GDocsAppendTool(_GoogleTool):
    name = "gdocs_append"
    description = "Append markdown to the end of an existing Google Doc, optionally under a new heading."
    parameters = {"type": "object", "properties": {
        "doc_id": {"type": "string"}, "markdown": {"type": "string"}, "heading": {"type": "string"}},
        "required": ["doc_id", "markdown"]}
    risk = "medium"
    icon = "➕"

    async def call(self, args, ctx):
        return await self._guard(g.docs_append(args["doc_id"], args["markdown"], args.get("heading", "")))


# ------------------------------------------------------------------ Sheets
class GSheetsReadTool(_GoogleTool):
    name = "gsheets_read"
    description = "Read cell values from a Google Sheet (A1 notation range, e.g. 'Sheet1!A1:E20')."
    parameters = {"type": "object", "properties": {
        "spreadsheet_id": {"type": "string"}, "range": {"type": "string"}}, "required": ["spreadsheet_id"]}

    async def call(self, args, ctx):
        return await self._guard(g.sheets_read(args["spreadsheet_id"], args.get("range") or "A1:Z100"))


class GSheetsWriteTool(_GoogleTool):
    name = "gsheets_write"
    description = "Write a 2-D array of values into a Google Sheet range (overwrites that range)."
    parameters = {"type": "object", "properties": {
        "spreadsheet_id": {"type": "string"}, "range": {"type": "string"},
        "values": {"type": "array", "items": {"type": "array", "items": {}}}},
        "required": ["spreadsheet_id", "range", "values"]}
    risk = "medium"
    icon = "✏️"

    async def call(self, args, ctx):
        return await self._guard(g.sheets_write(args["spreadsheet_id"], args["range"], args.get("values") or []))


class GSheetsAppendTool(_GoogleTool):
    name = "gsheets_append"
    description = "Append rows to a Google Sheet (great for logs, trackers and recurring reports)."
    parameters = {"type": "object", "properties": {
        "spreadsheet_id": {"type": "string"},
        "values": {"type": "array", "items": {"type": "array", "items": {}}},
        "range": {"type": "string"}}, "required": ["spreadsheet_id", "values"]}
    risk = "medium"
    icon = "➕"

    async def call(self, args, ctx):
        return await self._guard(g.sheets_append(args["spreadsheet_id"], args.get("values") or [],
                                                 args.get("range") or "A1"))


class GSheetsCreateTool(_GoogleTool):
    name = "gsheets_create"
    description = "Create a new Google Sheet, optionally filling it with values."
    parameters = {"type": "object", "properties": {
        "title": {"type": "string"}, "values": {"type": "array", "items": {"type": "array", "items": {}}},
        "folder_id": {"type": "string"}}, "required": ["title"]}
    risk = "medium"
    icon = "📊"

    async def call(self, args, ctx):
        return await self._guard(g.sheets_create(args["title"], args.get("values") or [], args.get("folder_id", "")))


# ------------------------------------------------------------------ Gmail
class GmailListTool(_GoogleTool):
    name = "gmail_list_messages"
    description = ("List/search Gmail messages. Query supports Gmail syntax: 'is:unread', "
                   "'from:boss@x.com', 'newer_than:7d', 'has:attachment'.")
    parameters = {"type": "object", "properties": {
        "query": {"type": "string"}, "max_results": {"type": "integer"}, "label": {"type": "string"}},
        "required": []}

    async def call(self, args, ctx):
        result = await self._guard(g.gmail_list(args.get("query", ""), int(args.get("max_results") or 10),
                                              args.get("label", "")))
        if result and result.ok:
            # Wrap Gmail list as untrusted
            wrapped = wrap_untrusted_content(result.data, "gmail_list_messages", args.get("query", ""))
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GmailReadTool(_GoogleTool):
    name = "gmail_read_message"
    description = "Read one Gmail message in full (body + attachment names)."
    parameters = {"type": "object", "properties": {"message_id": {"type": "string"}}, "required": ["message_id"]}

    async def call(self, args, ctx):
        result = await self._guard(g.gmail_read(args["message_id"]))
        if result and result.ok:
            # Wrap Gmail message as untrusted
            wrapped = wrap_untrusted_content(result.data, "gmail_read_message", args.get("message_id", ""))
            mark_thread_tainted(ctx.thread_id)
            result.data = wrapped
        return result


class GmailSendTool(_GoogleTool):
    name = "gmail_send_email"
    description = ("Send an email. Attach workspace files with the attachments array "
                   "(paths relative to your workspace).")
    parameters = {"type": "object", "properties": {
        "to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"},
        "cc": {"type": "string"}, "html": {"type": "boolean"},
        "attachments": {"type": "array", "items": {"type": "string"}}},
        "required": ["to", "subject", "body"]}
    risk = "high"
    icon = "✉️"

    async def call(self, args, ctx):
        paths = []
        for rel in args.get("attachments") or []:
            try:
                p = resolve_in_workspace(ctx.agent_id, rel)
                if p.is_file():
                    paths.append(p)
            except Exception:
                continue
        return await self._guard(g.gmail_send(args["to"], args["subject"], args["body"],
                                              args.get("cc", ""), paths, bool(args.get("html"))))


class GmailDraftTool(_GoogleTool):
    name = "gmail_create_draft"
    description = "Create a Gmail draft (does not send)."
    parameters = {"type": "object", "properties": {
        "to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}},
        "required": ["to", "subject", "body"]}
    risk = "medium"
    icon = "📨"

    async def call(self, args, ctx):
        return await self._guard(g.gmail_draft(args["to"], args["subject"], args["body"]))


# ------------------------------------------------------------------ Calendar
class GCalListTool(_GoogleTool):
    name = "gcal_list_events"
    description = "List calendar events. time_min='now' lists upcoming events."
    parameters = {"type": "object", "properties": {
        "time_min": {"type": "string", "description": "ISO 8601 or 'now'"},
        "time_max": {"type": "string"}, "max_results": {"type": "integer"}}, "required": []}

    async def call(self, args, ctx):
        return await self._guard(g.calendar_list(args.get("time_min", "now"), args.get("time_max", ""),
                                                int(args.get("max_results") or 10)))


class GCalCreateTool(_GoogleTool):
    name = "gcal_create_event"
    description = "Create a calendar event. Use ISO 8601 datetimes, e.g. 2026-10-09T15:00:00+08:00."
    parameters = {"type": "object", "properties": {
        "summary": {"type": "string"}, "start": {"type": "string"}, "end": {"type": "string"},
        "description": {"type": "string"}, "location": {"type": "string"},
        "attendees": {"type": "array", "items": {"type": "string"}},
        "timezone": {"type": "string"}}, "required": ["summary", "start", "end"]}
    risk = "medium"
    icon = "📅"

    async def call(self, args, ctx):
        return await self._guard(g.calendar_create(args["summary"], args["start"], args["end"],
                                                   args.get("description", ""), args.get("attendees") or [],
                                                   args.get("location", ""), args.get("timezone") or "Asia/Taipei"))


TOOLS = [
    GDriveSearchTool(), GDriveReadTool(), GDriveUploadTool(), GDriveFolderTool(), GDriveDeleteTool(),
    GDocsListTool(), GDocsCreateTool(), GDocsReadTool(), GDocsAppendTool(),
    GSheetsReadTool(), GSheetsWriteTool(), GSheetsAppendTool(), GSheetsCreateTool(),
    GmailListTool(), GmailReadTool(), GmailSendTool(), GmailDraftTool(),
    GCalListTool(), GCalCreateTool(),
]
