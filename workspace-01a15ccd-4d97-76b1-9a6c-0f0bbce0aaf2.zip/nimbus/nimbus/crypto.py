"""
At-rest encryption for OAuth tokens and stored provider keys.

Uses Fernet (AES-128-CBC + HMAC) with a key kept in data/.secret_key.
If `cryptography` isn't installed we degrade to obfuscation and say so loudly
rather than storing raw secrets in plaintext.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path

from .config import settings

_KEY_FILE = settings.data_dir / ".secret_key"
_warned = False

try:  # pragma: no cover - optional dependency
    from cryptography.fernet import Fernet, InvalidToken

    _HAVE_FERNET = True
except Exception:  # pragma: no cover
    Fernet = None  # type: ignore
    InvalidToken = Exception  # type: ignore
    _HAVE_FERNET = False


def _key() -> bytes:
    if _KEY_FILE.exists():
        return _KEY_FILE.read_bytes().strip()
    key = Fernet.generate_key() if _HAVE_FERNET else base64.urlsafe_b64encode(os.urandom(32))
    _KEY_FILE.write_bytes(key)
    try:
        os.chmod(_KEY_FILE, 0o600)
    except Exception:
        pass
    return key


def encrypt(plain: str) -> str:
    if not plain:
        return ""
    blob = plain.encode("utf-8")
    if _HAVE_FERNET:
        return "enc:" + Fernet(_key()).encrypt(blob).decode()
    return "obf:" + base64.urlsafe_b64encode(blob).decode()


def decrypt(token: str) -> str:
    global _warned
    if not token:
        return ""
    try:
        if token.startswith("enc:") and _HAVE_FERNET:
            return Fernet(_key()).decrypt(token[4:].encode()).decode()
        if token.startswith("obf:"):
            if not _warned:
                print("[nimbus] WARNING: `cryptography` not installed — secrets are only "
                      "obfuscated, not encrypted. Run: pip install cryptography")
                _warned = True
            return base64.urlsafe_b64decode(token[4:]).decode()
        return token
    except Exception:
        return ""


def encrypt_json(obj: dict) -> str:
    return encrypt(json.dumps(obj, ensure_ascii=False))


def decrypt_json(token: str) -> dict:
    raw = decrypt(token)
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except Exception:
        return {}


def secrets_encrypted() -> bool:
    return _HAVE_FERNET
