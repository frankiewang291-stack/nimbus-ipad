"""
SQLite persistence layer.

Deliberately dependency-free (stdlib sqlite3) so the whole platform installs in
seconds and stores everything in one portable file: data/nimbus.db
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from typing import Any, Iterable

from .config import settings

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None


SCHEMA = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS agents (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  title TEXT DEFAULT '',
  description TEXT DEFAULT '',
  provider TEXT DEFAULT 'mock',
  model TEXT DEFAULT '',
  persona TEXT DEFAULT '',
  emoji TEXT DEFAULT '🤖',
  tools TEXT DEFAULT '[]',
  approval_mode TEXT DEFAULT 'inherit',
  temperature REAL DEFAULT 0.3,
  max_iterations INTEGER DEFAULT 12,
  can_delegate INTEGER DEFAULT 1,
  is_reviewer INTEGER DEFAULT 0,
  status TEXT DEFAULT 'idle',
  created_at REAL,
  updated_at REAL
);

CREATE TABLE IF NOT EXISTS threads (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  title TEXT DEFAULT 'New thread',
  kind TEXT DEFAULT 'chat',
  parent_thread_id TEXT,
  status TEXT DEFAULT 'idle',
  meta TEXT DEFAULT '{}',
  created_at REAL,
  updated_at REAL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  thread_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT DEFAULT '',
  tool_calls TEXT DEFAULT '[]',
  tool_call_id TEXT,
  name TEXT DEFAULT '',
  meta TEXT DEFAULT '{}',
  created_at REAL
);

CREATE TABLE IF NOT EXISTS skills (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  instructions TEXT DEFAULT '',
  inputs TEXT DEFAULT '[]',
  output_format TEXT DEFAULT '',
  source TEXT DEFAULT 'manual',
  runs INTEGER DEFAULT 0,
  created_at REAL,
  updated_at REAL
);

CREATE TABLE IF NOT EXISTS routines (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  name TEXT NOT NULL,
  kind TEXT DEFAULT 'cron',
  schedule TEXT DEFAULT '',
  event_filter TEXT DEFAULT '',
  prompt TEXT DEFAULT '',
  skill_id TEXT,
  enabled INTEGER DEFAULT 1,
  last_run_at REAL,
  next_run_at REAL,
  run_count INTEGER DEFAULT 0,
  created_at REAL
);

CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY,
  routine_id TEXT,
  agent_id TEXT,
  thread_id TEXT,
  status TEXT DEFAULT 'running',
  result TEXT DEFAULT '',
  error TEXT DEFAULT '',
  started_at REAL,
  finished_at REAL
);

CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  thread_id TEXT,
  tool TEXT,
  args TEXT DEFAULT '{}',
  reason TEXT DEFAULT '',
  risk TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'pending',
  note TEXT DEFAULT '',
  created_at REAL,
  decided_at REAL
);

CREATE TABLE IF NOT EXISTS tool_rules (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  tool TEXT,
  action TEXT DEFAULT 'allow',
  note TEXT DEFAULT '',
  created_at REAL
);

CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  thread_id TEXT,
  actor TEXT DEFAULT 'agent',
  action TEXT NOT NULL,
  detail TEXT DEFAULT '{}',
  risk TEXT DEFAULT 'low',
  created_at REAL
);

CREATE TABLE IF NOT EXISTS memories (
  id TEXT PRIMARY KEY,
  agent_id TEXT,
  scope TEXT DEFAULT 'agent',
  key TEXT DEFAULT '',
  value TEXT DEFAULT '',
  tags TEXT DEFAULT '',
  source TEXT DEFAULT '',
  created_at REAL
);

CREATE TABLE IF NOT EXISTS oauth (
  id TEXT PRIMARY KEY,
  provider TEXT UNIQUE,
  account TEXT DEFAULT '',
  token TEXT DEFAULT '',
  scopes TEXT DEFAULT '',
  updated_at REAL
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS mcp_servers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  transport TEXT DEFAULT 'stdio',
  command TEXT DEFAULT '',
  args TEXT DEFAULT '[]',
  url TEXT DEFAULT '',
  env TEXT DEFAULT '{}',
  enabled INTEGER DEFAULT 1,
  status TEXT DEFAULT 'unknown',
  tools TEXT DEFAULT '[]',
  created_at REAL
);

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  payload TEXT DEFAULT '{}',
  handled INTEGER DEFAULT 0,
  created_at REAL
);

CREATE INDEX IF NOT EXISTS idx_messages_thread ON messages(thread_id, created_at);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_created ON runs(started_at DESC);
"""


def connect() -> sqlite3.Connection:
    global _conn
    with _lock:
        if _conn is None:
            _conn = sqlite3.connect(settings.db_path, check_same_thread=False, timeout=30)
            _conn.row_factory = sqlite3.Row
            _conn.executescript(SCHEMA)
            _migrate(_conn)
            _upgrade_agent_tools(_conn)
            _conn.commit()
        return _conn


# Columns added after v1.0 shipped — applied in place so existing data survives.
MIGRATIONS: dict[str, list[tuple[str, str]]] = {
    "agents": [("language", "TEXT DEFAULT 'inherit'")],
}


def _migrate(conn: sqlite3.Connection) -> None:
    for table, columns in MIGRATIONS.items():
        try:
            existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        except sqlite3.Error:
            continue
        for name, ddl in columns:
            if name not in existing:
                try:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
                    print(f"[nimbus] migrated: {table}.{name}")
                except sqlite3.Error as exc:
                    print(f"[nimbus] migration skipped for {table}.{name}: {exc}")


def _upgrade_agent_tools(conn: sqlite3.Connection) -> None:
    """Give web-capable agents newly shipped tools exactly once.

    Existing installs keep their per-agent tool allow-lists; when Nimbus gains a
    tool that belongs to a capability an agent already opted into, it is added
    here (once — removing it later in the UI sticks).
    """
    upgrades = {"youtube_transcript": {"fetch_url", "web_search", "browser_open"}}
    try:
        done = {row[0] for row in conn.execute("SELECT key FROM settings WHERE key LIKE 'tools_upgraded.%'")}
    except sqlite3.Error:
        return
    try:
        rows = conn.execute("SELECT id, name, tools FROM agents").fetchall()
    except sqlite3.Error:
        return
    for new_tool, triggers in upgrades.items():
        if f"tools_upgraded.{new_tool}" in done:
            continue
        for aid, aname, tools_json in rows:
            try:
                tools = json.loads(tools_json or "[]")
            except Exception:
                continue
            if not tools or new_tool in tools or not (set(tools) & triggers):
                continue
            tools.append(new_tool)
            conn.execute("UPDATE agents SET tools=? WHERE id=?", (json.dumps(tools), aid))
            print(f"[nimbus] {aname}: added the new {new_tool} tool")
        conn.execute("INSERT INTO settings (key, value) VALUES (?, ?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                     (f"tools_upgraded.{new_tool}", "1"))
    conn.commit()


def q(sql: str, params: Iterable[Any] = ()) -> list[dict]:
    with _lock:
        cur = connect().execute(sql, tuple(params))
        rows = [dict(r) for r in cur.fetchall()]
        cur.close()
        return rows


def q1(sql: str, params: Iterable[Any] = ()) -> dict | None:
    rows = q(sql, params)
    return rows[0] if rows else None


def x(sql: str, params: Iterable[Any] = ()) -> None:
    with _lock:
        conn = connect()
        conn.execute(sql, tuple(params))
        conn.commit()


def insert(table: str, data: dict, id_field: str = "id") -> str:
    data = dict(data)
    if id_field and not data.get(id_field):
        data[id_field] = new_id()
    cols = ", ".join(data.keys())
    marks = ", ".join("?" for _ in data)
    x(f"INSERT INTO {table} ({cols}) VALUES ({marks})", list(data.values()))
    return data[id_field]


def new_id() -> str:
    return uuid.uuid4().hex[:12]


def now() -> float:
    return time.time()


def json_load(value: Any, fallback: Any) -> Any:
    if value is None or value == "":
        return fallback
    if isinstance(value, (list, dict)):
        return value
    try:
        return json.loads(value)
    except Exception:
        return fallback


# ---------------------------------------------------------------- settings kv
def get_setting(key: str, default: str = "") -> str:
    row = q1("SELECT value FROM settings WHERE key=?", (key,))
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    x(
        "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, value),
    )


def all_settings() -> dict[str, str]:
    return {r["key"]: r["value"] for r in q("SELECT key, value FROM settings")}


# --------------------------------------------------------------------------
#  Module-level fallback: `nimbus.store` holds the higher-level helpers
#  (audit, oauth, approvals, runs, mcp rows). Exposing them as db.<name> keeps
#  call sites short without creating an import cycle.
# --------------------------------------------------------------------------
def __getattr__(name: str):
    import importlib
    store = importlib.import_module(".store", __package__)
    if hasattr(store, name):
        return getattr(store, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
