"""
YouTube links → readable transcript.

Nimbus can't watch video, but almost every public video has captions. This module
turns a YouTube URL (or bare video id) into the spoken text, so an agent can read
it, summarise it, translate it, or save it into a file/Doc.

Three layers, cheapest first:

1. **Watch page** — read `ytInitialPlayerResponse` from the page, take the caption
   track, download it as JSON3 (falling back to the plain XML/`srv3` form).
2. **yt-dlp** — if that returns nothing and `yt-dlp` is available, ask it for the
   subtitle file only (`--skip-download`); it handles the cases where the plain
   HTTP path is refused.
3. **Metadata only** — title, channel, duration and description, so the agent can
   still be useful (and say honestly that the video has no captions).

Nothing here downloads audio or video.
"""
from __future__ import annotations

import asyncio
import html as html_mod
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import httpx

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_TS = re.compile(r"^(\d+):(\d\d):(\d\d)[.,](\d+)$")
_TS2 = re.compile(r"^(\d\d?):(\d\d)[.,](\d+)$")


# --------------------------------------------------------------------------
#  URLs
# --------------------------------------------------------------------------
def extract_video_id(value: str) -> str:
    """Accept a URL in any of YouTube's shapes, or a bare 11-char id."""
    value = (value or "").strip()
    if VIDEO_ID.match(value):
        return value
    if not value:
        return ""
    if "//" not in value:
        value = "https://" + value
    try:
        u = urlparse(value)
    except Exception:
        return ""
    host = (u.netloc or "").lower().split(":")[0]
    if host.startswith("www."):
        host = host[4:]
    if host in ("youtu.be", "www.youtu.be"):
        cand = (u.path or "/").strip("/").split("/")[0]
        return cand if VIDEO_ID.match(cand) else ""
    if host.endswith("youtube.com") or host.endswith("youtube-nocookie.com"):
        qs = parse_qs(u.query or "")
        if qs.get("v") and VIDEO_ID.match(qs["v"][0]):
            return qs["v"][0]
        parts = [p for p in (u.path or "").split("/") if p]
        if parts and parts[0] in ("shorts", "embed", "live", "v", "e"):
            if len(parts) > 1 and VIDEO_ID.match(parts[1]):
                return parts[1]
    return ""


def is_youtube_url(value: str) -> bool:
    return bool(extract_video_id(value))


def watch_url(video_id: str) -> str:
    return f"https://www.youtube.com/watch?v={video_id}"


# --------------------------------------------------------------------------
#  Watch page → player response
# --------------------------------------------------------------------------
def _json_object_at(text: str, start: int) -> str:
    """Slice out a balanced {...} object starting at `start` (string-aware)."""
    depth, i, in_str, esc = 0, start, False, False
    while i < len(text):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
        i += 1
    return ""


def parse_player_response(page: str) -> dict:
    """Pull `ytInitialPlayerResponse` out of a watch-page HTML string."""
    for marker in ("ytInitialPlayerResponse\\s*=\\s*", "ytInitialPlayerResponse\\s*:\\s*"):
        m = re.search(marker, page)
        if not m:
            continue
        brace = page.find("{", m.end())
        if brace < 0:
            continue
        blob = _json_object_at(page, brace)
        if not blob:
            continue
        try:
            return json.loads(blob)
        except Exception:
            continue
    return {}


def video_details(player: dict, page: str = "") -> dict:
    """Title / channel / duration / description, from the player JSON (or the page)."""
    d = (player or {}).get("videoDetails") or {}
    if not d and page:
        def grab(key: str) -> str:
            m = re.search(rf'"{key}":"(.*?)"', page)
            return m.group(1) if m else ""
        d = {"title": grab("title"), "author": grab("author"),
             "lengthSeconds": grab("lengthSeconds"), "shortDescription": grab("shortDescription")}
    out = {
        "title": html_mod.unescape(str(d.get("title") or "")),
        "channel": html_mod.unescape(str(d.get("author") or "")),
        "duration_seconds": 0,
        "description": html_mod.unescape(str(d.get("shortDescription") or ""))[:4000],
        "views": int(d.get("viewCount") or 0) if str(d.get("viewCount") or "").isdigit() else 0,
    }
    try:
        out["duration_seconds"] = int(d.get("lengthSeconds") or 0)
    except Exception:
        out["duration_seconds"] = 0
    return out


def caption_tracks(player: dict) -> list[dict]:
    """Normalised caption tracks: [{url, lang, name, auto}]."""
    tracks = (((player or {}).get("captions") or {})
              .get("playerCaptionsTracklistRenderer", {}) or {}).get("captionTracks") or []
    out = []
    for t in tracks:
        url = (t.get("baseUrl") or "").replace("\\u0026", "&")
        if not url:
            continue
        name = (t.get("name") or {})
        label = t.get("trackName") or name.get("simpleText") or name.get("runs", [{}])[0].get("text") or ""
        out.append({"url": url,
                    "lang": (t.get("languageCode") or "").split("-")[0].lower(),
                    "lang_full": t.get("languageCode") or "",
                    "name": label,
                    "auto": t.get("kind") == "asr"})
    return out


def pick_track(tracks: list[dict], lang: str = "") -> dict | None:
    """Prefer the requested language, then any English, then the first track.

    Within a language, human-written captions beat auto-generated ones.
    """
    if not tracks:
        return None
    want = (lang or "").split("-")[0].lower()

    def rank(t: dict) -> tuple:
        lang_ok = 0 if (want and t["lang"] == want) else (1 if not want else 2)
        if lang_ok == 2 and t["lang"] in ("en", ""):
            lang_ok = 1
        return (lang_ok, 1 if t["auto"] else 0)

    return sorted(tracks, key=rank)[0]


# --------------------------------------------------------------------------
#  Caption payloads → text
# --------------------------------------------------------------------------
def json3_to_text(payload: str | dict) -> str:
    """YouTube JSON3 caption events → plain text."""
    try:
        data = json.loads(payload) if isinstance(payload, str) else payload
    except Exception:
        return ""
    lines: list[str] = []
    for ev in (data or {}).get("events") or []:
        segs = ev.get("segs") or []
        text = "".join(s.get("utf8", "") for s in segs)
        text = text.replace("\n", " ").strip()
        if text:
            lines.append(text)
    return " ".join(lines)


def _from_ts(stamp: str) -> float:
    m = _TS.match(stamp.strip())
    if m:
        h, mi, s, frac = m.groups()
        return int(h) * 3600 + int(mi) * 60 + int(s) + float("0." + frac)
    m = _TS2.match(stamp.strip())
    if m:
        mi, s, frac = m.groups()
        return int(mi) * 60 + int(s) + float("0." + frac)
    return 0.0


def vtt_to_text(payload: str) -> str:
    """WebVTT (or SRT) → plain text, dropping cues, timings and inline tags."""
    out: list[str] = []
    for raw in (payload or "").replace("\r\n", "\n").split("\n"):
        line = raw.strip()
        if not line or line.startswith(("WEBVTT", "Kind:", "Language:", "NOTE", "STYLE", "REGION")):
            continue
        if "-->" in line or line.isdigit() or _TS.match(line) or _TS2.match(line):
            continue
        line = re.sub(r"<[^>]+>", "", line)
        line = re.sub(r"\{[^}]*\}", "", line)
        line = html_mod.unescape(line).strip()
        if line:
            out.append(line)
    return " ".join(out)


def xml_to_text(payload: str) -> str:
    """timedtext XML (`<text>` or `srv3` `<p><s>`) → plain text."""
    out: list[str] = []
    for para in re.findall(r"<p\b[^>]*>(.*?)</p>", payload or "", re.S):
        seg = "".join(re.findall(r"<s[^>]*>(.*?)</s>", para, re.S)) or para
        seg = re.sub(r"<br\s*/?>", " ", seg)
        seg = re.sub(r"<[^>]+>", "", seg)
        out.append(seg)
    if not out:
        out = re.findall(r"<text\b[^>]*>(.*?)</text>", payload or "", re.S)
    text = " ".join(out)
    text = html_mod.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def parse_caption_payload(payload: str) -> str:
    """Auto-detect json3 / XML / VTT and return plain text."""
    raw = (payload or "").lstrip("\ufeff \t\r\n")
    if not raw:
        return ""
    if raw.startswith("{"):
        return json3_to_text(raw)
    if raw.startswith("WEBVTT") or _TS.match(raw.split("\n", 1)[0]) or "-->" in raw[:400]:
        return vtt_to_text(raw)
    if raw.startswith("<"):
        return xml_to_text(raw)
    return re.sub(r"\s+", " ", raw).strip()


def clean_transcript(text: str) -> str:
    """Collapse whitespace and drop the rolling duplicates auto-captions produce."""
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return ""
    chunks = re.split(r"(?<=[.!?。！？])\s+", text)
    out: list[str] = []
    for chunk in chunks:
        c = chunk.strip()
        if not c:
            continue
        if out and (c == out[-1] or out[-1].endswith(c) or c.startswith(out[-1])):
            if len(c) > len(out[-1]):
                out[-1] = c
            continue
        out.append(c)
    return " ".join(out).strip()


def with_timestamps(payload: str) -> str:
    """JSON3 / VTT payload → `[mm:ss] line` blocks (nice for chapters and quotes)."""
    raw = (payload or "").lstrip()
    blocks: list[tuple[float, str]] = []
    if raw.startswith("{"):
        try:
            data = json.loads(raw)
        except Exception:
            return ""
        for ev in data.get("events") or []:
            text = "".join(s.get("utf8", "") for s in ev.get("segs") or []).replace("\n", " ").strip()
            if text:
                blocks.append((float(ev.get("tStartMs") or 0) / 1000.0, text))
    else:
        for m in re.finditer(r"([\d:.,]+)\s*-->\s*([\d:.,]+)[^\n]*\n(.*?)(?=\n\s*\n|\Z)", raw, re.S):
            text = re.sub(r"<[^>]+>", "", m.group(3)).replace("\n", " ").strip()
            if text:
                blocks.append((_from_ts(m.group(1)), text))
    if not blocks:
        return ""
    merged: list[tuple[float, str]] = []
    for t, text in blocks:
        if merged and t - merged[-1][0] < 12:  # group nearby cues into ~12s blocks
            merged[-1] = (merged[-1][0], f"{merged[-1][1]} {text}")
        else:
            merged.append((t, text))
    lines = []
    for t, text in merged:
        lines.append(f"[{int(t) // 60:02d}:{int(t) % 60:02d}] {clean_transcript(text)}")
    return "\n".join(lines)


def parse_time(value) -> float:
    """'5:00', '1:02:30', '300' or 300 → seconds."""
    if value in (None, "", 0):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if re.fullmatch(r"\d+(\.\d+)?", text):
        return float(text)
    parts = text.split(":")
    try:
        parts = [float(p) for p in parts]
    except ValueError:
        return 0.0
    while len(parts) < 3:
        parts.insert(0, 0.0)
    return parts[0] * 3600 + parts[1] * 60 + parts[2]


def slice_timed(text: str, start: float = 0.0, end: float = 0.0) -> str:
    """Keep only the `[mm:ss]` blocks inside [start, end] (end=0 → to the end)."""
    keep = []
    for line in (text or "").splitlines():
        m = re.match(r"^\[(\d+):(\d\d)\]", line.strip())
        if not m:
            continue
        t = int(m.group(1)) * 60 + int(m.group(2))
        if t + 0.5 < start:
            continue
        if end and t > end:
            continue
        keep.append(line)
    return "\n".join(keep)


def fmt_duration(seconds: int) -> str:
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# --------------------------------------------------------------------------
#  Fetching
# --------------------------------------------------------------------------
async def _get(client: httpx.AsyncClient, url: str, **kw) -> str:
    r = await client.get(url, **kw)
    if r.status_code >= 400:
        return ""
    return r.text


async def _watch_page(client: httpx.AsyncClient, video_id: str, accept_language: str = "en") -> dict:
    """Fetch the watch page and return {page, player, details, tracks}."""
    headers = {"User-Agent": UA, "Accept-Language": f"{accept_language},en;q=0.8",
               "Accept": "text/html,application/xhtml+xml"}
    page = ""
    for url in (watch_url(video_id), f"https://www.youtube.com/watch?v={video_id}&hl={accept_language}"):
        page = await _get(client, url, headers=headers)
        if page and "ytInitialPlayerResponse" in page:
            break
    player = parse_player_response(page)
    return {"page": page, "player": player,
            "details": video_details(player, page), "tracks": caption_tracks(player)}


async def _download_caption(client: httpx.AsyncClient, track: dict) -> str:
    """Try the caption URL in the richest formats available."""
    headers = {"User-Agent": UA, "Accept-Language": "en,en;q=0.8",
               "Origin": "https://www.youtube.com", "Referer": "https://www.youtube.com/"}
    for suffix in ("&fmt=json3", "", "&fmt=srv3"):
        try:
            text = await _get(client, track["url"] + suffix, headers=headers)
        except Exception:
            text = ""
        parsed = parse_caption_payload(text)
        if parsed:
            return parsed
    return ""


def yt_dlp_path() -> str:
    """The yt-dlp console script, if it is on PATH."""
    return shutil.which("yt-dlp") or ""


def yt_dlp_command() -> list[str]:
    """How to invoke yt-dlp: the script if we have it, else `python -m yt_dlp`.

    Returns [] when yt-dlp isn't installed at all (the caller then falls back to
    the plain-HTTP path and finally to metadata-only).
    """
    exe = yt_dlp_path()
    if exe:
        return [exe]
    try:
        import importlib.util
        if importlib.util.find_spec("yt_dlp") is not None:
            return [sys.executable, "-m", "yt_dlp"]
    except Exception:
        pass
    return []


async def _yt_dlp_subtitles(video_id: str, lang: str = "", timeout: int = 150) -> tuple[str, str, str]:
    """Ask yt-dlp for the subtitle file only. Returns (text, language, raw payload)."""
    base = yt_dlp_command()
    if not base:
        return "", "", ""
    langs = [l for l in (lang, "en", "en-orig") if l]
    langs = list(dict.fromkeys(langs)) or ["en"]
    with tempfile.TemporaryDirectory(prefix="nimbus-subs-") as tmp:
        out_tpl = os.path.join(tmp, "%(id)s.%(ext)s")
        for attempt in (langs[0], "en", "en-orig"):
            cmd = [*base, "--skip-download", "--write-subs", "--write-auto-subs",
                   "--sub-langs", attempt, "--sub-format", "json3/vtt/best", "--no-playlist",
                   "--no-warnings", "--no-progress", "--no-check-certificates",
                   "--extractor-args", "youtube:skip=hls,dash,translated_subs",
                   "-o", out_tpl, watch_url(video_id)]
            try:
                proc = await asyncio.create_subprocess_exec(
                    *cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except (asyncio.TimeoutError, Exception):
                try:
                    proc.kill()  # type: ignore[union-attr]
                except Exception:
                    pass
                continue
            files = sorted(Path(tmp).glob("*"))
            pick = next((f for f in files if f.suffix in (".json3", ".srv3", ".vtt", ".srt", ".xml")), None)
            if pick:
                try:
                    raw_payload = pick.read_text(encoding="utf-8", errors="replace")
                    text = clean_transcript(parse_caption_payload(raw_payload))
                except Exception:
                    raw_payload, text = "", ""
                if text:
                    parts = pick.name.split(".")
                    got_lang = parts[-2] if len(parts) >= 3 else (lang or "en")
                    return text, got_lang, raw_payload
            for f in files:
                try:
                    f.unlink()
                except Exception:
                    pass
    return "", "", ""


async def fetch_video(url_or_id: str, lang: str = "", max_chars: int = 60000,
                      timestamps: bool = False, allow_yt_dlp: bool = True,
                      start=0, end=0) -> dict:
    """The whole pipeline. Never raises: returns ok/err dict with what it found."""
    video_id = extract_video_id(url_or_id)
    if not video_id:
        return {"ok": False, "error": f"that doesn't look like a YouTube link or video id: {url_or_id[:120]}"}

    lang = (lang or "").split("-")[0].lower()
    async with httpx.AsyncClient(timeout=httpx.Timeout(30, read=60), follow_redirects=True) as client:
        try:
            page = await _watch_page(client, video_id, lang or "en")
        except Exception as exc:
            page = {"page": "", "player": {}, "details": {}, "tracks": []}
            page["error"] = str(exc)[:200]
        details, tracks = page.get("details") or {}, page.get("tracks") or []

        transcript, used_lang, source, payload = "", "", "", ""
        track = pick_track(tracks, lang)
        if track:
            payload = await _download_caption(client, track)
            if payload:
                transcript, used_lang, source = payload, track["lang"], "captions"
        if not transcript and allow_yt_dlp:
            text, got_lang, raw = await _yt_dlp_subtitles(video_id, lang)
            if text:
                transcript, used_lang, source = text, got_lang or lang or "en", "yt-dlp"
                payload = raw or ""

    transcript = clean_transcript(transcript)
    want_start, want_end = parse_time(start), parse_time(end)
    sliced = False
    timed_text = with_timestamps(payload) if (payload and (timestamps or want_start or want_end)) else ""
    if timed_text:
        if want_start or want_end:
            part = slice_timed(timed_text, want_start, want_end)
            if part:
                transcript, sliced = part, True
        elif timestamps:
            transcript = timed_text

    result = {
        "video_id": video_id,
        "url": watch_url(video_id),
        "title": details.get("title", ""),
        "channel": details.get("channel", ""),
        "duration": fmt_duration(details.get("duration_seconds", 0)),
        "duration_seconds": details.get("duration_seconds", 0),
        "description": details.get("description", ""),
        "caption_languages": [t["lang_full"] or t["lang"] for t in tracks],
        "auto_generated": bool(track and track.get("auto")) if source == "captions" else False,
        "language": used_lang,
        "source": source or "metadata",
        "transcript": transcript[:max_chars],
        "chars": len(transcript),
        "words": len(transcript.split()),
        "truncated": len(transcript) > max_chars,
        "range": (f"{fmt_duration(want_start)}–{fmt_duration(want_end) if want_end else 'end'}"
                  if sliced else "full video"),
    }
    if not transcript:
        result["ok"] = False
        result["error"] = ("no captions available for this video"
                           + (f" (caption languages listed: {', '.join(result['caption_languages'])})"
                              if result["caption_languages"] else "")
                           + " — try another video, or open the page with browser_open and read it there")
        if not details.get("title"):
            result["error"] = ("could not read this video's page (it may be private, age-restricted, "
                               "region-locked or removed): " + video_id)
    else:
        result["ok"] = True
    return result
