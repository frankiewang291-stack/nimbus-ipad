"""
Approval gates + Auto Review.

Policy (per agent, falling back to the server setting):
  auto   — run everything, log it
  risky  — ask before high-risk actions (default)
  all    — ask before every tool call

If an agent is flagged as reviewer, its model also *watches* risky actions and
can allow / ask / block them before a human is bothered — the same idea as
Grok Bot's Auto Review layer.

Taint tracking: After untrusted content enters a thread, outbound actions
always require human approval, even when "Always allow" is set.
"""
from __future__ import annotations

import asyncio
import json
import logging
import shlex
import time
from typing import TYPE_CHECKING

from . import bus, db
from .config import settings
from .llm import stream_chat
from .logging_config import get_logger
from .store import (create_approval, decide_approval, get_agent, has_tool_rule, list_agents,
                    list_tool_rules)
from .tools.untrusted import is_thread_tainted, OUTBOUND_ACTIONS

# Use a WeakValueDictionary to prevent memory leaks
import weakref
_PENDING: dict[str, asyncio.Future] = {}

# Logger for this module
logger = get_logger(__name__)


# For backward compatibility, keep the old name
PENDING = _PENDING

HIGH_RISK_TOOLS = {"gmail_send_email", "gdrive_delete", "delete_file", "delete_skill",
                   "delete_routine", "browser_click", "browser_type"}


def policy_for(agent: dict) -> str:
    mode = (agent.get("approval_mode") or "inherit").lower()
    return settings.approval_mode if mode in ("", "inherit") else mode


def needs_approval(agent: dict, tool, args: dict, thread_id: str = "") -> str | None:
    """Return a human-readable reason to ask, or None to run.
    
    Taint check: If thread is tainted (has received untrusted content) and this is
    an outbound action, always require approval regardless of user rules.
    """
    # Taint check: outbound actions after untrusted content always need approval
    if thread_id and is_thread_tainted(thread_id):
        if tool.name in OUTBOUND_ACTIONS:
            return f"tainted thread: outbound action {tool.name} requires approval after untrusted content"
    
    # 0. an explicit rule from the user ("Always allow") beats the policy —
    #    that is the whole point of the button, including for high-risk tools.
    #    BUT: taint check above overrides even explicit allow rules
    if has_tool_rule(agent.get("id", ""), tool.name):
        return None
    mode = policy_for(agent)
    if mode == "auto":
        return None
    if mode == "all":
        return "policy is 'approve everything'"
    # risky mode
    if tool.name in HIGH_RISK_TOOLS or tool.risk == "high":
        if tool.name == "gmail_send_email":
            return f"about to send email to {args.get('to', '?')}"
        return f"high-risk action: {tool.name}"
    if tool.name == "run_command":
        # Use proper command parsing with shlex instead of substring matching
        cmd = args.get("command", "")
        try:
            # Parse the command to get the base command name
            parsed = shlex.split(cmd)
            if parsed:
                base_cmd = parsed[0]
                cmd_name = base_cmd.split('/')[-1]  # Get basename (handles /usr/bin/rm)
                
                # Destructive commands - check the actual command, not substrings
                destructive_commands = {
                    'rm', 'rmdir', 'del', 'erase', 'unlink',
                    'mv', 'move', 'cp', 'copy',
                    'chmod', 'chown', 'chgrp',
                    'mkdir', 'mkfs', 'dd',
                    'kill', 'pkill', 'killall',
                    'shutdown', 'reboot', 'halt', 'poweroff',
                    'format', 'fdisk', 'parted',
                }
                
                if cmd_name in destructive_commands:
                    return f"shell command looks destructive: {cmd[:120]}"
                
                # Check for destructive flags
                if cmd_name == 'rm' and any(arg in ['-r', '-rf', '-R', '--recursive', '--force'] for arg in parsed[1:]):
                    return f"shell command looks destructive: {cmd[:120]}"
                
                if cmd_name == 'chmod' and '-R' in parsed[1:]:
                    return f"shell command looks destructive: {cmd[:120]}"
                
                if cmd_name == 'dd' and any(arg.startswith('if=') or arg.startswith('of=') for arg in parsed[1:]):
                    return f"shell command looks destructive: {cmd[:120]}"
                
                # Network commands
                network_commands = {
                    'curl', 'wget', 'scp', 'rsync', 'ssh', 'nc', 'ncat', 'telnet', 'ftp', 'sftp',
                }
                
                if cmd_name in network_commands:
                    if not settings.allow_shell_network:
                        return f"shell command uses network: {cmd[:120]}"
        except (ValueError, AttributeError):
            # If parsing fails, use fallback substring check
            cmd_lower = cmd.lower()
            for danger in ("rm ", "mv ", "> /", "chmod", "kill", "pkill", "truncate"):
                if danger in cmd_lower:
                    return f"shell command looks destructive: {cmd[:120]}"
    if tool.name == "spawn_agent":
        return f"about to create a new agent: {args.get('name')}"
    return None


async def llm_complete(provider: str, model: str, messages: list[dict], max_tokens: int = 400,
                       temperature: float = 0.0) -> str:
    """Non-streaming convenience wrapper (accumulates the configured stream)."""
    text = []
    async for ev in stream_chat(provider, model, messages, tools=[], temperature=temperature,
                                max_tokens=max_tokens):
        if ev["type"] == "text":
            text.append(ev["text"])
    return "".join(text)


def reviewer_agent() -> dict | None:
    for a in list_agents():
        if a.get("is_reviewer"):
            return a
    return None


async def auto_review(agent: dict, tool_name: str, args: dict, reason: str) -> dict:
    """Ask the reviewer agent to judge a risky action."""
    reviewer = reviewer_agent()
    if not reviewer or reviewer["id"] == agent.get("id"):
        return {"decision": "ask", "note": "no reviewer configured"}
    prompt = [
        {"role": "system", "content":
            "You are Auto Review, a security reviewer for an AI agent platform. Given a proposed tool "
            "call, decide: allow, ask, or block. Protect user data, money, credentials and the user's "
            "reputation. Destructive/irreversible actions, sending untrusted content out, or anything "
            "touching credentials should be 'ask' at minimum. Reply ONLY with JSON: "
            '{"decision":"allow|ask|block","reason":"short reason"}'},
        {"role": "user", "content": json.dumps({
            "agent": agent.get("name"), "agent_role": agent.get("title"),
            "tool": tool_name, "arguments": args, "policy_reason": reason}, ensure_ascii=False)[:4000]},
    ]
    try:
        raw = await llm_complete(reviewer.get("provider", "mock"), reviewer.get("model", ""), prompt)
        start, end = raw.find("{"), raw.rfind("}")
        data = json.loads(raw[start:end + 1]) if start >= 0 else {}
        decision = str(data.get("decision", "ask")).lower()
        if decision not in ("allow", "ask", "block"):
            decision = "ask"
        return {"decision": decision, "note": data.get("reason", ""), "reviewer": reviewer["name"]}
    except (asyncio.TimeoutError, asyncio.CancelledError) as exc:
        logger.warning("Auto-review timed out or was cancelled",
                      context={"reviewer": reviewer.get("name"), "tool": tool_name},
                      details={"error": str(exc)})
        return {"decision": "ask", "note": f"reviewer unavailable (timeout)", "reviewer": reviewer["name"]}
    except (json.JSONDecodeError, ValueError) as exc:
        logger.warning("Auto-review failed to parse response",
                      context={"reviewer": reviewer.get("name"), "tool": tool_name},
                      details={"error": str(exc)})
        return {"decision": "ask", "note": f"reviewer unavailable (parse error)", "reviewer": reviewer["name"]}
    except Exception as exc:
        logger.error("Auto-review unexpected error",
                    context={"reviewer": reviewer.get("name"), "tool": tool_name},
                    exc_info=(type(exc), exc, exc.__traceback__))
        return {"decision": "ask", "note": f"reviewer unavailable ({exc})", "reviewer": reviewer["name"]}


async def request_approval(agent: dict, thread_id: str, tool, args: dict, reason: str,
                           timeout: float = 900.0) -> dict:
    """Create an approval request, notify the UI, and wait for a human decision."""
    review = {"decision": "ask", "note": "", "reviewer": ""}
    if tool.risk == "high" or tool.name in HIGH_RISK_TOOLS:
        review = await auto_review(agent, tool.name, args, reason)
        if review["decision"] == "block":
            db.audit(agent["id"], thread_id, "approval.auto_block",
                     {"tool": tool.name, "args": args, "reason": review["note"]}, risk="high", actor="reviewer")
            return {"status": "blocked", "note": f"Auto Review blocked this: {review['note']}"}
        if review["decision"] == "allow":
            db.audit(agent["id"], thread_id, "approval.auto_allow",
                     {"tool": tool.name, "args": args, "reason": review["note"]}, risk="medium", actor="reviewer")
            return {"status": "approved", "note": f"Auto Review allowed: {review['note']}",
                    "auto": True}

    row = create_approval(agent["id"], thread_id, tool.name, args, reason, tool.risk)
    if review.get("reviewer"):
        row["reviewer_note"] = f"{review['reviewer']} recommends: ask ({review['note']})"
    loop = asyncio.get_running_loop()
    fut: asyncio.Future = loop.create_future()
    _PENDING[row["id"]] = fut
    
    # Add cleanup callback to remove from PENDING when future is done
    def cleanup_future(fut: asyncio.Future):
        _PENDING.pop(row["id"], None)
    
    fut.add_done_callback(cleanup_future)
    
    bus.publish(thread_id, {"type": "approval_request", "approval": row})
    bus.publish("*", {"type": "approval_request", "approval": row})
    db.audit(agent["id"], thread_id, "approval.request", {"tool": tool.name, "args": args}, risk=tool.risk)
    try:
        decision = await asyncio.wait_for(fut, timeout=timeout)
    except asyncio.TimeoutError:
        decision = {"status": "expired", "note": "no response within timeout"}
        decide_approval(row["id"], "expired", decision["note"])
        bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "expired"})
        logger.warning("Approval request timed out",
                      context={"approval_id": row["id"], "thread_id": thread_id, "tool": tool.name})
        return decision
    except asyncio.CancelledError:
        decision = {"status": "cancelled", "note": "request was cancelled"}
        decide_approval(row["id"], "cancelled", decision["note"])
        bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "cancelled"})
        logger.warning("Approval request was cancelled",
                      context={"approval_id": row["id"], "thread_id": thread_id})
        return decision
    except Exception as exc:
        decision = {"status": "error", "note": f"internal error: {exc}"}
        decide_approval(row["id"], "error", decision["note"])
        bus.publish(thread_id, {"type": "approval_resolved", "approval_id": row["id"], "status": "error"})
        logger.error("Error in approval request",
                    context={"approval_id": row["id"], "thread_id": thread_id},
                    exc_info=(type(exc), exc, exc.__traceback__))
        return decision
    
    # Cleanup - remove from PENDING (should already be done by callback, but be safe)
    _PENDING.pop(row["id"], None)
    return decision


def resolve(approval_id: str, decision: str, note: str = "", actor: str = "user") -> dict | None:
    """Called by the API when the human clicks Allow/Deny."""
    try:
        row = decide_approval(approval_id, decision, note)
        if not row:
            return None
        db.audit(row.get("agent_id"), row.get("thread_id"), f"approval.{decision}",
                 {"tool": row["tool"], "note": note}, risk=row.get("risk", "medium"), actor=actor)
        fut = _PENDING.get(approval_id)
        if fut and not fut.done():
            fut.set_result({"status": decision, "note": note})
        bus.publish(row.get("thread_id") or "*", {"type": "approval_resolved", "approval_id": approval_id,
                                                  "status": decision, "note": note})
        # Clean up from PENDING
        _PENDING.pop(approval_id, None)
        logger.info("Approval resolved",
                   context={"approval_id": approval_id, "decision": decision, "actor": actor})
        return row
    except Exception as exc:
        logger.error("Error resolving approval",
                    context={"approval_id": approval_id, "decision": decision, "actor": actor},
                    exc_info=(type(exc), exc, exc.__traceback__))
        return None


def cleanup_pending_approvals() -> int:
    """
    Clean up pending approvals that have been resolved but not removed.
    
    Returns:
        Number of cleaned up approvals
    """
    global _PENDING
    cleaned = 0
    stale_ids = []
    
    for approval_id, fut in list(_PENDING.items()):
        if fut.done():
            stale_ids.append(approval_id)
    
    for approval_id in stale_ids:
        _PENDING.pop(approval_id, None)
        cleaned += 1
    
    if cleaned > 0:
        logger.info("Cleaned up stale pending approvals", context={"count": cleaned})
    
    return cleaned


async def graceful_shutdown() -> int:
    """
    Graceful shutdown: resolve all pending approvals with 'expired' status.
    
    Returns:
        Number of resolved approvals
    """
    global _PENDING
    resolved = 0
    
    for approval_id, fut in list(_PENDING.items()):
        if not fut.done():
            # Cancel the future
            fut.cancel()
            # Resolve in database
            decide_approval(approval_id, "expired", "Shutdown in progress")
            bus.publish("*", {"type": "approval_resolved", "approval_id": approval_id, 
                            "status": "expired", "note": "Shutdown in progress"})
            resolved += 1
    
    # Clear the dict
    _PENDING.clear()
    
    if resolved > 0:
        logger.info("Resolved pending approvals during shutdown", context={"count": resolved})
    
    return resolved
