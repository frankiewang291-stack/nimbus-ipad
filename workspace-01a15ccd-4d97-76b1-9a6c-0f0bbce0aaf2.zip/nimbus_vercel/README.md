# Nimbus for Vercel

**Deploy this folder directly to Vercel for instant Nimbus on iPad**

---

## 🚀 Quick Deploy

### Method 1: Drag & Drop (Easiest)
1. Go to [https://vercel.com/new](https://vercel.com/new)
2. Drag and drop this `nimbus_vercel` folder
3. Click **Deploy**
4. Wait 1-2 minutes
5. Done! Your Nimbus is live at the URL Vercel gives you

### Method 2: Vercel CLI
```bash
# Install Vercel CLI
npm install -g vercel

# Navigate to this folder
cd nimbus_vercel

# Deploy
vercel --prod
```

### Method 3: GitHub Integration
1. Push this folder to a GitHub repository
2. Go to [https://vercel.com/new](https://vercel.com/new)
3. Import your GitHub repository
4. Click **Deploy**

---

## 📱 Use on iPad

1. **Open Safari** on your iPad
2. **Go to your Vercel URL** (e.g., `https://nimbus-yourname.vercel.app`)
3. **Tap Share button** (↑ arrow in square)
4. **Scroll down and tap "Add to Home Screen"**
5. **Name it "Nimbus" and tap Add**

**Done!** You now have a Nimbus app icon on your iPad.

---

## 📁 What's in This Folder

| File | Purpose |
|------|---------|
| `index.html` | Main Nimbus web interface (iPad-optimized) |
| `vercel.json` | Vercel configuration for deployment |
| `README.md` | This file |

---

## ✨ Features

### Without Backend (Local Mode)
✅ Works immediately after deployment
✅ Ask about Nimbus features
✅ Get setup instructions
✅ Learn about all integrations
✅ Touch-optimized for iPad

### With Backend (Full AI)
🔹 Connect to Slack & Teams
🔹 Daily Brief notifications
🔹 Teach-by-Demonstration
🔹 400+ Connector Library
🔹 Multi-Channel Publishing

---

## ⚙️ Connect a Backend

To enable full AI features:

1. **Deploy your Nimbus backend** to:
   - Railway.app
   - Render.com
   - Fly.io
   - Another Vercel project

2. **Get the backend URL** (e.g., `https://nimbus-backend.vercel.app`)

3. **In Nimbus app on iPad:**
   - Tap **Settings** (gear icon)
   - Enter **Backend URL**
   - Tap **Save**

---

## 🎯 What You Can Ask

Try these commands in Nimbus:

| Command | Response |
|---------|----------|
| `Hello` | Welcome message with quick start |
| `What can you do?` | Full feature list |
| `Tell me about Slack` | Slack & Teams integration details |
| `What's daily brief?` | Proactive summary feature |
| `How does teach-by-demo work?` | Workflow recording explanation |
| `What connectors do you have?` | 400+ connector library |
| `What is multi-channel publishing?` | Agent deployment feature |
| `Help` | Complete help guide |

---

## 💡 iPad Tips

### Enable Desktop Mode
1. Tap the **AA icon** in Safari address bar
2. Select **"Request Desktop Website"**
3. Better UI experience

### Add to Dock
- Long press the Nimbus icon
- Tap **"Edit Home Screen"**
- Drag to Dock

### Use Split View
- Swipe from right edge
- Open another app
- Nimbus stays active

### External Keyboard
- Enter to send
- Shift+Enter for new line
- Cmd+F to find

---

## 🔧 Troubleshooting

### "Add to Home Screen" not working
- Make sure you're using **Safari** (not Chrome)
- Try again - sometimes takes a second tap
- Check if icon is on another Home Screen page

### App not loading
- **Clear cache:** Settings → Safari → Clear History and Website Data
- **Try Chrome:** Sometimes works better
- **Check URL:** Make sure it's correct

### Backend not connecting
- **Verify URL:** Check in Settings
- **Check if running:** Is your backend deployed and running?
- **CORS issues:** Make sure backend allows your Vercel URL

---

## 📚 Learn More

- [Nimbus Documentation](../README_IPAD.md)
- [Quick Start Guide](../QUICK_START.md)
- [All Features](../INTEGRATIONS_IMPLEMENTED.md)

---

## 🎉 Success!

You now have Nimbus running on Vercel and accessible from your iPad!

**Next steps:**
1. ✅ Deployed to Vercel
2. ✅ Added to iPad Home Screen
3. 🔄 Try local mode
4. 🔄 Connect a backend (optional)
5. 🔄 Explore all features

---

**Enjoy Nimbus on your iPad!** 🚀
